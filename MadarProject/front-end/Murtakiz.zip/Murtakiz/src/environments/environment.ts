export const environment = {
  production: false,
  API_ROOT: 'http://localhost:9090/api/v1/murtakiz', 
};

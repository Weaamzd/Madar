import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormGroup,
  FormControl,
  FormsModule,   
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService, UserSummary } from '../../core/auth/authService';
import { finalize, debounceTime, distinctUntilChanged, filter, map, firstValueFrom } from 'rxjs';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';


import { UserManagementService } from '../../modules/system-settings/services/user-management/user-management-service';
import { OrgLookup } from '../../modules/system-settings/services/org/org-lookup';
import {
  UniteMiniDto,
  SubUniteDto,
  CurrentRegionDto,
} from '../../modules/system-settings/models/org.models';
import {
  CreateUserRequest,
  CreateUserForExistingEmployeeRequest,
  EmployeeForUserCreationDto,
} from '../../modules/system-settings/models/employee-directory.models';
import {
  CreateExternalUserRequest,
} from '../../modules/system-settings/models/external-user.models';
import { Delegations } from '../../modules/delegation/services/delegations';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';

type UserType = 'INTERNAL' | 'EXTERNAL';

interface Region {
  id: number;
  code: string;
  name: string;
  dbKey?: string;
}

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatSnackBarModule, CommonModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,FormsModule,  ],
  templateUrl: './login.html',
  styleUrls: ['./login.css'],
})
export class Login implements OnInit {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private snack = inject(MatSnackBar);


  private userService = inject(UserManagementService);
  private delegationsService = inject(Delegations);
  private orgApi = inject(OrgLookup);


  mode = signal<'LOGIN' | 'REGISTER'>('LOGIN');


  loading = signal(false);
  errorMsg = signal<string | null>(null);
  welcomeName = signal<string | null>(null);

  loginForm = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    password: ['', [Validators.required, Validators.minLength(4)]],
  });

  get f() {
    return this.loginForm.controls;
  }

  switchToLogin() {
    this.mode.set('LOGIN');
  }

switchToRegister() {
  this.mode.set('REGISTER');
  this.currentStep.set(1);  
}


  onSubmitLogin() {
    this.errorMsg.set(null);
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.loading.set(true);
    const { username, password } = this.loginForm.value as {
      username: string;
      password: string;
    };

    const returnUrl =
      this.route.snapshot.queryParamMap.get('returnUrl') || '/userProfile';

    this.auth
      .loginAndFetchMe({ username, password })
      .pipe(finalize(() => this.loading.set(false)))
      .subscribe({
        next: (_u: UserSummary) => {
          this.router.navigateByUrl(returnUrl, { replaceUrl: true });
        },
        error: (err) => {
          if (err?.status === 401)
            this.errorMsg.set('اسم المستخدم أو كلمة المرور غير صحيحة.');
          else if (err?.status === 0)
            this.errorMsg.set('لا يمكن الاتصال بالخادم. تأكد من تشغيل الباك إند.');
          else this.errorMsg.set('حدث خطأ غير متوقع. حاول مرة أخرى.');
        },
      });
  }



    jobTitles: string[] = [
    'محاسب',
    'محلل نظم',
    'مطوّر واجهات',
    'مهندس بيانات',
    'أخصائي موارد بشرية',
    'مدير مشروع',
  ];

  candidateStatus: 'IDLE' | 'ELIGIBLE' | 'HAS_USER' | 'NOT_FOUND' = 'IDLE';
  candidateLoading = false;
  candidateDto: EmployeeForUserCreationDto | null = null;

  private upsertJobTitle(title?: string | null): void {
    const t = (title ?? '').toString().trim();
    if (!t) return;

    if (!this.jobTitles.includes(t)) {
      this.jobTitles = [t, ...this.jobTitles];
    }
  }

  get isCandidateEligible() {
    return this.candidateStatus === 'ELIGIBLE';
  }
  get isCandidateHasUser() {
    return this.candidateStatus === 'HAS_USER';
  }


  unitesMini: UniteMiniDto[] = [];
  selectedUniteId: number | null = null;

  selectedSubUniteId: number | null = null;

selectedLevel1Id: number | null = null;
selectedLevel2Id: number | null = null;
selectedLevel3Id: number | null = null;
selectedLevel4Id: number | null = null;

level1List: SubUniteDto[] = [];
level2List: SubUniteDto[] = [];
level3List: SubUniteDto[] = [];
level4List: SubUniteDto[] = [];

  debugJson: string | null = null;

  previewPayload(): void {
    if (!this.employeeStepValid || !this.accountStepValid) {
      this.registerForm.markAllAsTouched();
      this.toast('الرجاء استكمال بيانات الموظف وبيانات الحساب أولاً.', 'warn');
      return;
    }

    let payload: any;
    let mode: string;

    if (this.isExternal) {
      mode = 'EXTERNAL';
      payload = this.buildExternalPayload();
    } else if (this.isCandidateEligible) {
      mode = 'INTERNAL_EXISTING_EMP';
      payload = this.buildInternalExistingEmpPayload();
    } else {
      mode = 'INTERNAL_NEW_EMP';
      payload = this.buildInternalNewPayload();
    }

    this.debugJson = JSON.stringify({ mode, payload }, null, 2);
    console.log('🔍 Registration payload preview:', { mode, payload });
  }



  regions: Region[] = [];
  currentRegion: CurrentRegionDto | null = null;
  regionLoading = false;


  registrationSubmitting = false;
  registrationDone = false;
  registrationResult: any = null;


  registerForm: FormGroup = new FormGroup({
    userType: new FormControl<UserType>('INTERNAL', {
      nonNullable: true,
      validators: [Validators.required],
    }),

    personId: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),

    fullNameAr: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    email: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.email],
    }),
    jobTitle: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),


    hireDate: new FormControl<string>('', { nonNullable: true }), 
    startDate: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),


    uniteId: new FormControl<number | null>(null, {
      validators: [Validators.required],
    }),
    subUniteId: new FormControl<number | null>(null, {
      validators: [Validators.required],
    }),

  
    managerNo: new FormControl<string>('', { nonNullable: true }),
    managerEmpNo: new FormControl<string>('', { nonNullable: true }),

    username: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required],
    }),
    password: new FormControl<string>('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(8)],
    }),

    currentRegionId: new FormControl<number | null>(null, {
      validators: [Validators.required],
    }),

    organizationName: new FormControl<string>('', { nonNullable: true }),
    collaborationType: new FormControl<string>('', { nonNullable: true }),
    endDate: new FormControl<string | null>(null),
    phone: new FormControl<string | null>(null),
    notes: new FormControl<string | null>(null),
  });

  get rf() {
    return this.registerForm.controls;
  }

  get isExternal(): boolean {
    return this.registerForm.get('userType')!.value === 'EXTERNAL';
  }

  ngOnInit(): void {
    this.loadUnitesMini();
    this.registerForm
      .get('personId')!
      .valueChanges.pipe(
        map((v) => (v || '').toString().trim()),
        distinctUntilChanged()
      )
      .subscribe((val) => {
        this.registerForm.get('username')?.setValue(val, { emitEvent: false });
      });

    this.registerForm
      .get('personId')!
      .valueChanges.pipe(
        map((v) => (v || '').toString().trim()),
        debounceTime(500),
        distinctUntilChanged(),
        filter(() => !this.isExternal),
        filter((v) => v.length >= 2)
      )
      .subscribe((empNo) => this.runEmpCandidateCheck(empNo));

    this.registerForm
      .get('userType')!
      .valueChanges.subscribe(() => this.updateValidatorsByUserType());
    this.updateValidatorsByUserType();
  }

  private toast(msg: string, cls: 'ok' | 'warn' | 'err' = 'warn') {
    this.snack.open(msg, 'حسناً', {
      duration: 3500,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass:
        cls === 'ok'
          ? ['snack-ok']
          : cls === 'err'
          ? ['snack-error']
          : ['snack-warn'],
    });
  }


  private loadUnitesMini(): void {
    this.orgApi.listAllUnitesMini().subscribe({
      next: (data) => (this.unitesMini = data || []),
      error: () => (this.unitesMini = []),
    });
  }

 
onUniteChanged(uniteId: number | string | null): void {
  const idNum = Number(uniteId);
  const safeId = Number.isFinite(idNum) ? idNum : null;
  this.registerForm.get('uniteId')?.setValue(safeId, { emitEvent: false });


  this.handleUniteChange(safeId);
}





private handleUniteChange(
  uniteId: number | null,
  preselectSubId?: number | null
): void {
  const idNum = Number(uniteId);
  this.selectedUniteId = Number.isFinite(idNum) ? idNum : null;
  this.selectedLevel1Id = this.selectedLevel2Id =
    this.selectedLevel3Id = this.selectedLevel4Id = null;

  this.level1List = this.level2List = this.level3List = this.level4List = [];

  this.selectedSubUniteId = null;
  this.registerForm.get('subUniteId')?.setValue(null);


  const regionCtrl = this.registerForm.get('currentRegionId');
  regionCtrl?.setValue(null, { emitEvent: false });

  if (!this.selectedUniteId) {
    this.currentRegion = null;
    this.regions = [];
    return;
  }

  this.regionLoading = true;
  this.orgApi.getCurrentRegion(this.selectedUniteId).subscribe({
    next: (cr) => {
      this.currentRegion = cr;
      const regIdNum = Number(cr?.id);
      if (Number.isFinite(regIdNum)) {
        const region: Region = {
          id: regIdNum,
          code: cr.regionCode,
          name: cr.uniteName || cr.uniteCode || 'Current Region',
          dbKey: cr.regionDbKey,
        };
        this.regions = [region];
        regionCtrl?.setValue(regIdNum, { emitEvent: true });
      } else {
        this.regions = [];
        regionCtrl?.setValue(null, { emitEvent: true });
      }
      this.regionLoading = false;
    },
    error: () => {
      this.currentRegion = null;
      this.regions = [];
      regionCtrl?.setValue(null, { emitEvent: true });
      this.regionLoading = false;
    },
  });

  if (preselectSubId) {
    this.autoSelectFullHierarchy(this.selectedUniteId, preselectSubId).then(
      () => {
        this.autoAssignManager();
      }
    );
  } else {
    this.orgApi.listDirectUnderUnite(this.selectedUniteId).subscribe({
      next: (list) => {
        this.level1List = list || [];
        this.syncDeepestSelection();
      },
      error: () => {
        this.level1List = [];
        this.syncDeepestSelection();
      },
    });
  }
}




private loadChildren(parentSubUniteId: number, targetLevel: 2 | 3 | 4): void {
  this.orgApi.listDirectChildren(parentSubUniteId).subscribe({
    next: (kids) => {
      const list = kids || [];
      if (targetLevel === 2) this.level2List = list;
      if (targetLevel === 3) this.level3List = list;
      if (targetLevel === 4) this.level4List = list;
      this.syncDeepestSelection();
    },
    error: () => {
      if (targetLevel === 2) this.level2List = [];
      if (targetLevel === 3) this.level3List = [];
      if (targetLevel === 4) this.level4List = [];
      this.syncDeepestSelection();
    },
  });
}

onLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
  const subId = Number(subIdRaw);

  if (level === 1) {
    this.selectedLevel1Id = Number.isFinite(subId) ? subId : null;
    this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level2List = this.level3List = this.level4List = [];
    if (this.selectedLevel1Id) this.loadChildren(this.selectedLevel1Id, 2);
  } else if (level === 2) {
    this.selectedLevel2Id = Number.isFinite(subId) ? subId : null;
    this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level3List = this.level4List = [];
    if (this.selectedLevel2Id) this.loadChildren(this.selectedLevel2Id, 3);
  } else if (level === 3) {
    this.selectedLevel3Id = Number.isFinite(subId) ? subId : null;
    this.selectedLevel4Id = null;
    this.level4List = [];
    if (this.selectedLevel3Id) this.loadChildren(this.selectedLevel3Id, 4);
  } else {
    this.selectedLevel4Id = Number.isFinite(subId) ? subId : null;
  }

  this.syncDeepestSelection();
  this.autoAssignManager();  
}

private syncDeepestSelection(): void {
  const deepest =
    this.selectedLevel4Id ??
    this.selectedLevel3Id ??
    this.selectedLevel2Id ??
    this.selectedLevel1Id ??
    null;

  this.selectedSubUniteId = deepest;
  this.registerForm.get('subUniteId')?.setValue(deepest);
}

get showL1(): boolean {
  return this.level1List.length > 0;
}
get showL2(): boolean {
  return this.level2List.length > 0;
}
get showL3(): boolean {
  return this.level3List.length > 0;
}
get showL4(): boolean {
  return this.level4List.length > 0;
}



onSubUniteChanged(): void {
  const subId = this.registerForm.get('subUniteId')?.value as number | null;
  const idNum = Number(subId);
  this.selectedSubUniteId = Number.isFinite(idNum) ? idNum : null;
  this.autoAssignManager();
}


  private resetCandidateState(): void {
    this.candidateStatus = 'IDLE';
    this.candidateDto = null;
    this.candidateLoading = false;
  }

  private runEmpCandidateCheck(empNoRaw: string): void {
    const empNo = (empNoRaw || '').trim();
    if (!empNo || this.isExternal) {
      this.resetCandidateState();
      return;
    }

    this.candidateLoading = true;
    this.candidateStatus = 'IDLE';
    this.candidateDto = null;

    this.userService
      .precheck({ empNo })
      .subscribe({
        next: (dto) => {
          const employeeExists = !!dto.employeeExists;
          const userExists = !!dto.userExists;

          if (employeeExists && !userExists) {
            this.userService.precheckCandidateByEmpNo(empNo).subscribe({
              next: (full: EmployeeForUserCreationDto | null) => {
                if (full) {
                  this.candidateDto = full;
                  this.candidateStatus = 'ELIGIBLE';
                  this.applyCandidateToForm(full);
                } else {
                  this.candidateStatus = 'NOT_FOUND';
                }
              },
              error: () => {
                this.candidateStatus = 'NOT_FOUND';
              },
              complete: () => (this.candidateLoading = false),
            });
            return;
          }

          if (employeeExists && userExists) {
            this.candidateStatus = 'HAS_USER';
            this.candidateLoading = false;
            return;
          }

          this.candidateStatus = 'NOT_FOUND';
          this.candidateLoading = false;
        },
        error: () => {
          this.candidateStatus = 'NOT_FOUND';
          this.candidateLoading = false;
        },
      });
  }

  private applyCandidateToForm(dto: EmployeeForUserCreationDto): void {
  this.upsertJobTitle(dto.jobTitle);

  this.registerForm.patchValue(
    {
      fullNameAr: dto.fullNameAr ?? '',
      email: dto.email ?? '',
      jobTitle: dto.jobTitle ?? '',
      hireDate: dto.hireDate ?? '',
      startDate: dto.startDate ?? '',
    },
    { emitEvent: false }
  );

  const uniteIdNum = Number(dto.uniteId);
  const subIdNum = Number(dto.subUniteId);

  if (Number.isFinite(uniteIdNum)) {
    this.registerForm.get('uniteId')?.setValue(uniteIdNum, { emitEvent: false });

    this.handleUniteChange(
      uniteIdNum,
      Number.isFinite(subIdNum) ? subIdNum : null
    );
  }

  if (Number.isFinite(subIdNum)) {
    this.registerForm.get('subUniteId')?.setValue(subIdNum, { emitEvent: false });
    this.selectedSubUniteId = subIdNum;
  }

  if (dto.managerNo) {
    this.registerForm
      .get('managerNo')
      ?.setValue(dto.managerNo, { emitEvent: false });
  } else {
    this.autoAssignManager();
  }
}


  private autoAssignManager(): void {
    if (this.isExternal) {
      return;
    }

    const uniteId = this.selectedUniteId;
    const subUniteId = this.selectedSubUniteId;

    if (!uniteId && !subUniteId) {
      this.registerForm.get('managerNo')?.setValue('', { emitEvent: false });
      return;
    }

    const query: { uniteId?: number | null; subUniteId?: number | null } = {};
    if (subUniteId) query.subUniteId = subUniteId;
    else query.uniteId = uniteId!;

    this.userService.listManagersByScope(query).subscribe({
      next: (rows) => {
        if (rows && rows.length > 0) {
          const first = rows[0];
          this.registerForm
            .get('managerNo')
            ?.setValue(first.empNo, { emitEvent: true });
        } else {
          this.registerForm.get('managerNo')?.setValue('', { emitEvent: true });
        }
      },
      error: () => {
        this.registerForm.get('managerNo')?.setValue('', { emitEvent: true });
      },
    });
  }


  private updateValidatorsByUserType(): void {
    const type = this.registerForm.get('userType')!.value as UserType;

    const orgNameCtrl = this.registerForm.get('organizationName')!;
    const collTypeCtrl = this.registerForm.get('collaborationType')!;
    const hireDateCtrl = this.registerForm.get('hireDate')!;
    const emailCtrl = this.registerForm.get('email')!;

    if (type === 'EXTERNAL') {
      hireDateCtrl.clearValidators();
      emailCtrl.clearValidators();

      orgNameCtrl.setValidators([Validators.required]);
      collTypeCtrl.setValidators([Validators.required]);
    } else {

      hireDateCtrl.setValidators([Validators.required]);
      emailCtrl.clearValidators();

      orgNameCtrl.clearValidators();
      collTypeCtrl.clearValidators();
    }

    hireDateCtrl.updateValueAndValidity({ onlySelf: true });
    emailCtrl.updateValueAndValidity({ onlySelf: true });
    orgNameCtrl.updateValueAndValidity({ onlySelf: true });
    collTypeCtrl.updateValueAndValidity({ onlySelf: true });
  }



  get employeeStepValid(): boolean {
    if (this.isExternal) {
      return (
        this.registerForm.get('userType')!.valid &&
        this.registerForm.get('personId')!.valid &&
        this.registerForm.get('fullNameAr')!.valid &&
        this.registerForm.get('organizationName')!.valid &&
        this.registerForm.get('collaborationType')!.valid &&
        this.registerForm.get('startDate')!.valid &&
        this.registerForm.get('uniteId')!.valid &&
        this.registerForm.get('subUniteId')!.valid
      );
    }
    return (
      this.registerForm.get('userType')!.valid &&
      this.registerForm.get('personId')!.valid &&
      this.registerForm.get('fullNameAr')!.valid &&
      this.registerForm.get('jobTitle')!.valid &&
      this.registerForm.get('hireDate')!.valid &&
      this.registerForm.get('startDate')!.valid &&
      this.registerForm.get('uniteId')!.valid &&
      this.registerForm.get('subUniteId')!.valid
    );
  }

  get accountStepValid(): boolean {
    return (
      this.registerForm.get('username')!.valid &&
      this.registerForm.get('password')!.valid &&
      this.registerForm.get('currentRegionId')!.valid
    );
  }


  private buildInternalNewPayload(): CreateUserRequest {
    const f = this.registerForm.value;

    const status: 'Active' | 'Inactive' = 'Active';
    const currentRegionId =
      f.currentRegionId == null ? null : Number(f.currentRegionId);

    const managerNoRaw = (f.managerNo as string) ?? '';
    const managerNo =
      managerNoRaw && managerNoRaw.trim().length > 0
        ? managerNoRaw.trim()
        : null;

    const req: CreateUserRequest = {
      username: f.username!,
      password: f.password!,
      status,
      currentRegionId,

      empNo: f.personId!, 
      fullNameAr: f.fullNameAr!,
      email: f.email || null,
      jobTitle: f.jobTitle!,
      hireDate: f.hireDate!,
      startDate: f.startDate!,
      managerNo,
      subUniteId: Number(f.subUniteId),
      rolesNames: ['EMPLOYEE'],
    };

    return req;
  }

  private buildInternalExistingEmpPayload(): CreateUserForExistingEmployeeRequest {
    const f = this.registerForm.value;

    const status: 'Active' | 'Inactive' = 'Active';
    const currentRegionId =
      f.currentRegionId == null ? null : Number(f.currentRegionId);

    const req: CreateUserForExistingEmployeeRequest = {
      empNo: f.personId!, 
      username: f.username!,
      password: f.password!,
      status,
      currentRegionId,
      rolesNames: ['EMPLOYEE'],
    };

    return req;
  }

  private buildExternalPayload(): CreateExternalUserRequest {
    const f = this.registerForm.value;

    const status: 'Active' | 'Inactive' = 'Inactive';
    const currentRegionId =
      f.currentRegionId == null ? null : Number(f.currentRegionId);

    const req: CreateExternalUserRequest = {
      extEmpId: f.personId!,
      username: f.username!,
      password: f.password!,
      status,
      currentRegionId,

      fullNameAr: f.fullNameAr!,
      fullNameEn: null,
      email: f.email || null,
      phone: f.phone || null,
      organizationName: f.organizationName!,
      jobTitle: f.jobTitle || null,
      collaborationType: f.collaborationType!,
      startDate: f.startDate!,
      endDate: f.endDate || null,
      notes: f.notes || null,

      managerEmpNo:
        (f.managerEmpNo || '').toString().trim() || null,
      subUniteId: Number(f.subUniteId),

      rolesNames: ['EMPLOYEE'],
    };

    return req;
  }


  submitRegistration(): void {
    this.registrationDone = false;
    this.registrationResult = null;

    if (!this.employeeStepValid || !this.accountStepValid) {
      this.registerForm.markAllAsTouched();
      this.toast('الرجاء استكمال الحقول المطلوبة.', 'warn');
      return;
    }

    if (!this.isExternal && this.isCandidateHasUser) {
      this.toast('هذا الموظف يملك حساب مستخدم بالفعل.', 'err');
      return;
    }

    this.registrationSubmitting = true;

    if (this.isExternal) {
      const payload = this.buildExternalPayload();
      this.delegationsService
        .createExternalUserWithRegistration(payload)
        .pipe(finalize(() => (this.registrationSubmitting = false)))
        .subscribe({
          next: (res) => {
            this.registrationResult = res;
            this.registrationDone = true;
            this.toast('تم إرسال طلب إنشاء حساب خارجي بنجاح.', 'ok');
          },
          error: (err) => {
            this.toast(
              err?.error?.message || 'فشل في إرسال طلب إنشاء حساب خارجي.',
              'err'
            );
          },
        });
      return;
    }

    if (this.isCandidateEligible) {
      const payload = this.buildInternalExistingEmpPayload();
      this.userService
        .createUserForExistingEmp(payload)
        .pipe(finalize(() => (this.registrationSubmitting = false)))
        .subscribe({
          next: (res) => {
            this.registrationResult = res;
            this.registrationDone = true;
            this.toast('تم إرسال طلب إنشاء حساب لموظف حالي.', 'ok');
          },
          error: (err) => {
            this.toast(
              err?.error?.message ||
                'فشل في إرسال طلب إنشاء حساب لموظف حالي.',
              'err'
            );
          },
        });
    } else {
      const payload = this.buildInternalNewPayload();
      this.userService
        .createUserWithRegistration(payload)
        .pipe(finalize(() => (this.registrationSubmitting = false)))
        .subscribe({
          next: (res) => {
            this.registrationResult = res;
            this.registrationDone = true;
            this.toast(
              'تم إرسال طلب إنشاء حساب وبيانات الموظف بنجاح.',
              'ok'
            );
          },
          error: (err) => {
            this.toast(
              err?.error?.message ||
                'فشل في إرسال طلب إنشاء حساب جديد.',
              'err'
            );
          },
        });
    }
  }

  currentStep = signal<1 | 2 | 3>(1);

  goToStep(step: 1 | 2 | 3) {
    this.currentStep.set(step);
  }

  nextStep() {
    const step = this.currentStep();
    if (step === 1 && !this.employeeStepValid) {
      this.registerForm.markAllAsTouched();
      this.toast('الرجاء استكمال بيانات الموظف / المشارك.', 'warn');
      return;
    }

    if (step === 2 && !this.accountStepValid) {
      this.registerForm.markAllAsTouched();
      this.toast('الرجاء استكمال بيانات الحساب.', 'warn');
      return;
    }

    if (step < 3) {
      this.currentStep.set((step + 1) as 1 | 2 | 3);
    }
  }

  prevStep() {
    const step = this.currentStep();
    if (step > 1) {
      this.currentStep.set((step - 1) as 1 | 2 | 3);
    }
  }

  getSelectedUniteName(): string {
    const id = this.registerForm.value.uniteId as number | null | undefined;
    if (!id) {
      return '-';
    }
    const u = this.unitesMini.find(x => x.id === id);
    return u?.name ?? '-';
  }

getSelectedSubUniteName(): string {
  const id = this.registerForm.value.subUniteId as number | null | undefined;
  if (!id) {
    return '-';
  }

  const allSubs: SubUniteDto[] = [
    ...(this.level1List || []),
    ...(this.level2List || []),
    ...(this.level3List || []),
    ...(this.level4List || []),
  ];

  const s = allSubs.find(x => x.id === id);
  return s?.name ?? '-';
}


  getSelectedRegionName(): string {
    const id = this.registerForm.value.currentRegionId as number | null | undefined;
    if (!id) {
      return '-';
    }
    const r = this.regions.find(x => x.id === id);
    return r?.name ?? '-';
  }

  onMatDate(
  event: MatDatepickerInputEvent<Date>,
  controlName: 'hireDate' | 'startDate' | 'endDate'
): void {
  const date = event.value;
  const str = date ? this.formatDate(date) : '';

  this.registerForm.get(controlName)?.setValue(str);
}

private formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}




private async autoSelectFullHierarchy(
  uniteId: number,
  targetSubId: number
): Promise<void> {
  if (!uniteId || !targetSubId) {
    this.syncDeepestSelection();
    return;
  }


  this.selectedLevel1Id = this.selectedLevel2Id =
    this.selectedLevel3Id = this.selectedLevel4Id = null;

  this.level1List = this.level2List = this.level3List = this.level4List = [];

  this.level1List =
    (await firstValueFrom(this.orgApi.listDirectUnderUnite(uniteId))) || [];

  let l1Match = this.level1List.find((s) => s.id === targetSubId);
  if (l1Match) {
    this.selectedLevel1Id = l1Match.id;
    this.syncDeepestSelection();
    return;
  }


  for (const l1 of this.level1List) {
    const level2 =
      (await firstValueFrom(this.orgApi.listDirectChildren(l1.id))) || [];

    this.level2List = level2;

    let l2Match = level2.find((s) => s.id === targetSubId);
    if (l2Match) {
      this.selectedLevel1Id = l1.id;
      this.selectedLevel2Id = l2Match.id;
      this.syncDeepestSelection();
      return;
    }


    for (const l2 of level2) {
      const level3 =
        (await firstValueFrom(this.orgApi.listDirectChildren(l2.id))) || [];

      this.level3List = level3;

      let l3Match = level3.find((s) => s.id === targetSubId);
      if (l3Match) {
        this.selectedLevel1Id = l1.id;
        this.selectedLevel2Id = l2.id;
        this.selectedLevel3Id = l3Match.id;
        this.syncDeepestSelection();
        return;
      }

      for (const l3 of level3) {
        const level4 =
          (await firstValueFrom(this.orgApi.listDirectChildren(l3.id))) || [];

        this.level4List = level4;

        let l4Match = level4.find((s) => s.id === targetSubId);
        if (l4Match) {
          this.selectedLevel1Id = l1.id;
          this.selectedLevel2Id = l2.id;
          this.selectedLevel3Id = l3.id;
          this.selectedLevel4Id = l4Match.id;
          this.syncDeepestSelection();
          return;
        }
      }
    }
  }

  this.syncDeepestSelection();
}




}

import { Routes } from '@angular/router';
import { Login } from './auth/login/login';
import { MainLayout } from './layout/main-layout/main-layout';
import { authGuard } from './core/guards/auth/authguard';
import { roleguardGuard } from '../../src/app/core/guards/role/roleguard-guard';


export const routes: Routes = [
  { path: 'auth/login', component: Login },
  { path: '', pathMatch: 'full', redirectTo: 'auth/login' },


  // { path: 'dashboard', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) },

  {
    path: '',
    component: MainLayout,
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'delegationuser' },
      {
        path: 'userProfile',
        //canActivate: [roleGuard],
        //data: { roles: ['ADMIN'] },
        canActivate: [roleguardGuard],
        data: { roles: ['DEPARTMENT_MANAGER', 'EMPLOYEE'] },
        loadChildren: () =>
          import('./modules/inside-bar-menu/inside-bar-menu-module')
            .then(m => m.InsideBarMenuModule)
      },
      {
        path: 'SystemSettings',
        canActivate: [roleguardGuard],
        data: { roles: ['DEPARTMENT_MANAGER', 'SUB_ADMIN'] },
        loadChildren: () =>
          import('./modules/system-settings/system-settings-module')
            .then(m => m.SystemSettingsModule)
      },
      {
        path: 'RequestCreateAccount',
        canActivate: [roleguardGuard],
        data: { roles: ['DEPARTMENT_MANAGER'] },
        loadChildren: () =>
          import('./modules/system-settings/system-settings-module')
            .then(m => m.SystemSettingsModule)
      },
      {
        path: 'delegationuser',
        canActivate: [roleguardGuard],
        loadChildren: () =>
          import('./modules/delegation/delegation-routing-module')
            .then(m => m.DelegationRoutingModule)
      },

      {
        path: 'employee-supervision',
        canActivate: [roleguardGuard],
        loadChildren: () =>
          import('./modules/employee-supervision/employee-supervision-routing-module')
            .then(m => m.EmployeeSupervisionRoutingModule)
      },

       {
        path: 'service-request',
        canActivate: [roleguardGuard],
        loadChildren: () =>
          import('./modules/service-request/service-request-routing-module')
            .then(m => m.ServiceRequestRoutingModule)
      },

      {
    path: 'kpi-management',
    loadChildren: () =>
      import('./modules/kpi-management/kpi-management-module').then(
        (m) => m.KpiManagementModule
      )
  },

  





    ]
  },



  { path: '**', redirectTo: 'auth/login' },
];

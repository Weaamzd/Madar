import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackMyRequest } from './track-my-request';

describe('TrackMyRequest', () => {
  let component: TrackMyRequest;
  let fixture: ComponentFixture<TrackMyRequest>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TrackMyRequest]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrackMyRequest);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TrackMyRequest } from './pages/track-my-request/track-my-request';

const routes: Routes = [
  { path: 'track-my-request', component: TrackMyRequest},
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ServiceRequestRoutingModule { }

import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, PageEvent, MatPaginatorIntl } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs';

import { UserManagementService } from '../../../system-settings/services/user-management/user-management-service';
import { UserRegistrationRequestSummaryDto } from '../../../system-settings/models/registration-requests.models';
import { AuthService } from '../../../../core/auth/authService';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'app-track-my-request',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    MatDialogModule,
    MatSnackBarModule,
    MatCheckboxModule
  ],
  templateUrl: './track-my-request.html',
  styleUrl: './track-my-request.css',
})
export class TrackMyRequest implements OnInit {

  loading = false;


  rows: UserRegistrationRequestSummaryDto[] = [];
  displayedColumns: string[] = [
    'id',
    'createdAt',
    'currentStage',
    'stageStatus',
    'waitingForEmpNo',
    'notes',
    'actions'
  ];

  totalElements = 0;
  pageIndex = 0;
  pageSize = 10;

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  username: string | null = null;


  @ViewChild('termsDialog') termsDialogTpl!: TemplateRef<any>;
  private termsDialogRef: MatDialogRef<any> | null = null;
  pendingRow: UserRegistrationRequestSummaryDto | null = null;
  termsAgreeChecked = false;
  termsLoading = false;

  constructor(
    private svc: UserManagementService,
    private auth: AuthService,
    private dialog: MatDialog,
    private snack: MatSnackBar,
    paginatorIntl: MatPaginatorIntl
  ) {

    paginatorIntl.itemsPerPageLabel = 'عدد العناصر في الصفحة:';
    paginatorIntl.nextPageLabel = 'الصفحة التالية';
    paginatorIntl.previousPageLabel = 'الصفحة السابقة';
    paginatorIntl.firstPageLabel = 'الأولى';
    paginatorIntl.lastPageLabel = 'الأخيرة';
    paginatorIntl.getRangeLabel = (page, pageSize, length) => {
      if (length === 0 || pageSize === 0) return '0 من 0';
      const startIndex = page * pageSize;
      const endIndex = Math.min(startIndex + pageSize, length);
      return `${startIndex + 1}–${endIndex} من ${length}`;
    };
    paginatorIntl.changes.next();
  }

  ngOnInit(): void {
    this.loading = true;

    this.auth.ensureMe().pipe(take(1)).subscribe({
      next: (user) => {
        this.username = user?.username ?? null;
        this.fetchMyRequests();
      },
      error: () => {
        this.loading = false;
        this.username = null;
        this.snack.open('تعذّر جلب بيانات المستخدم الحالي.', 'موافق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl'
        });

        this.fetchMyRequests();
      }
    });
  }



  fetchMyRequests(): void {
  this.loading = true;

  const handleList = (list: UserRegistrationRequestSummaryDto[] | null | undefined) => {
    const all = list ?? [];

    const candidateIds = new Set(all.map(r => r.id));

    for (const r of all) {
      if (r.parentRequestId != null) {
        candidateIds.delete(r.parentRequestId); 
      }
    }

    this.rows = all.filter(r => candidateIds.has(r.id));

    this.rows.sort((a, b) => {
      const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const db = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return db - da;
    });

    this.totalElements = this.rows.length;
  };

  if (this.username) {
    this.svc.listMyRegistrationRequestsByUsername(this.username)
      .pipe(take(1))
      .subscribe({
        next: handleList,
        error: () => {
          this.rows = [];
          this.totalElements = 0;
          this.snack.open('تعذّر تحميل طلباتك حاليًا.', 'موافق', {
            duration: 3000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
            direction: 'rtl'
          });
        },
        complete: () => this.loading = false
      });
  } else {
    this.svc.listMyRegistrationRequests()
      .pipe(take(1))
      .subscribe({
        next: handleList,
        error: () => {
          this.rows = [];
          this.totalElements = 0;
        },
        complete: () => this.loading = false
      });
  }
}



  onPage(e: PageEvent) {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
  }

  getStageLabel(row: UserRegistrationRequestSummaryDto): string {
    switch (row.currentStage) {
      case 'ADMIN_REVIEW':    return 'مراجعة الإدارة';
      case 'SECURITY_REVIEW': return 'مراجعة أمنية';
      case 'USER_TERMS':      return 'موافقة المستخدم على الشروط';
      default:                return row.currentStage || 'غير معروفة';
    }
  }


  getStatusLabel(row: UserRegistrationRequestSummaryDto): string {

  if (row.currentStage === 'ADMIN_REVIEW' && row.stageStatus === 'PENDING') {
    return 'بانتظار موافقة مسؤول النظام';
  }


  if (row.currentStage === 'USER_TERMS' && row.stageStatus === 'PENDING') {
    return 'بانتظار موافقة المستخدم على الشروط';
  }

  switch (row.stageStatus) {
    case 'PENDING':  return 'قيد المعالجة';
    case 'APPROVED': return 'معتمد';
    case 'REJECTED': return 'مرفوض';
    default:         return row.stageStatus || 'غير معروفة';
  }
}



  getStatusChipClass(row: UserRegistrationRequestSummaryDto): string {
  const s = (row.stageStatus || '').toUpperCase();
  if (row.currentStage === 'ADMIN_REVIEW' && s === 'PENDING') {
    return 'chip-waiting-admin';
  }

  if (row.currentStage === 'USER_TERMS' && s === 'PENDING') {
    return 'chip-waiting-user';
  }

  if (s === 'PENDING')  return 'chip-pending';
  if (s === 'APPROVED') return 'chip-success';
  if (s === 'REJECTED') return 'chip-danger';
  return 'chip-muted';
}


  get approvedCount(): number {
    return this.rows.filter(r => r.stageStatus === 'APPROVED').length;
  }

  get pendingCount(): number {
    return this.rows.filter(r => r.stageStatus === 'PENDING').length;
  }

  canApproveTerms(row: UserRegistrationRequestSummaryDto): boolean {
    return row.currentStage === 'USER_TERMS' && row.stageStatus === 'PENDING';
  }

  openApproveTermsDialog(row: UserRegistrationRequestSummaryDto) {
    if (!this.username) {
      this.snack.open('لا يوجد اسم مستخدم حالي.', 'موافق', {
        duration: 2500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
      });
      return;
    }

    this.pendingRow = row;
    this.termsAgreeChecked = false;
    this.termsLoading = false;

    this.termsDialogRef = this.dialog.open(this.termsDialogTpl, {
      width: '1050px',
      maxWidth: '95vw',
      direction: 'rtl',
      disableClose: true,
      data: {
        username: this.username,
        requestId: row.id
      }
    });

    this.termsDialogRef.afterClosed().subscribe(result => {
      if (result === 'APPROVED_TERMS') {
        this.fetchMyRequests();
      }
    });
  }

  closeTermsDialog() {
    this.termsDialogRef?.close('CANCEL');
  }

  confirmApproveTerms() {
    if (!this.username || !this.pendingRow) {
      this.snack.open('لا يمكن تنفيذ العملية، يرجى المحاولة مرة أخرى.', 'موافق', {
        duration: 2500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
      });
      return;
    }

    if (!this.termsAgreeChecked) {
      this.snack.open('يجب الموافقة على الشروط والأحكام أولاً.', 'موافق', {
        duration: 2500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
      });
      return;
    }

    this.termsLoading = true;

    this.svc.approveUserTerms(this.username)
      .pipe(take(1))
      .subscribe({
        next: () => {
          this.termsLoading = false;
          this.snack.open('✅ تم تسجيل موافقتك على الشروط والأحكام بنجاح.', 'إغلاق', {
            duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
          });
          this.termsDialogRef?.close('APPROVED_TERMS');
        },
        error: () => {
          this.termsLoading = false;
          this.snack.open('حدث خطأ أثناء تسجيل الموافقة. حاول مرة أخرى.', 'موافق', {
            duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
          });
        }
      });
  }
}

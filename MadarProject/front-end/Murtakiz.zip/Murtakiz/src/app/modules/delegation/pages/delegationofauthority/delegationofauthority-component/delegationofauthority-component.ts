import { Component, OnInit, ViewChild, TemplateRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { Delegations } from '../../../services/delegations';
import { AuthService } from '../../../../../core/auth/authService';
import { DelegationFullDto } from '../../../models/delegations.models';

@Component({
  selector: 'app-delegationofauthority-component',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatIconModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
    MatButtonModule
  ],
  templateUrl: './delegationofauthority-component.html',
  styleUrl: './delegationofauthority-component.css'
})
export class DelegationofauthorityComponent implements OnInit {

  totalDelegations = 0;
activeDelegations = 0;
pendingDelegations = 0;

  tab: 'created' | 'onMe' = 'created';


  private delegationsSvc = inject(Delegations);
  private dialog = inject(MatDialog);
  private auth = inject(AuthService);

    setTab(tab: 'created' | 'onMe'): void {
    this.tab = tab;

    if (tab === 'created') {

      this.loadMyDelegations();
    } else {

      this.loadDelegationsOnMe();
    }
  }

  loadDelegationsOnMe(): void {

    //
    // this.auth.ensureMe().subscribe(user => {
    //   if (!user?.empNo) { return; }
    //   this.delegationsSvc.listForDelegatee(user.empNo).subscribe(res => {
    //     
    //   });
    // });
  }


  dataSource = new MatTableDataSource<DelegationFullDto>([]);
  loading = false;
  errorMsg: string | null = null;

  displayedColumns: string[] = [
    'delegationId',
    'status',
    'scopeType',
    'delegator',
    'delegatee',
    'window',
    'activeNow',
    'requireAcceptance',
    'allowSubdelegate',
    'createdAt',
    'activeSessionsCount',
    'actions'
  ];

  selectedDelegation: DelegationFullDto | null = null;

  searchActive = false;                 
  selectedSort = 'createdAt,desc';      
  searchText = '';                    
  statusFilter = '';                   

  @ViewChild('delegationDetailsDialog') detailsTpl!: TemplateRef<any>;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  ngOnInit(): void {
    this.loadMyDelegations();
  }

loadMyDelegations(): void {
  this.loading = true;
  this.errorMsg = null;

  this.auth.ensureMe().subscribe({
    next: (user) => {
      if (!user?.empNo) {
        this.loading = false;
        this.errorMsg = 'لم يتم العثور على رقم الموظف في الجلسة.';
        this.totalDelegations   = 0;
        this.activeDelegations  = 0;
        this.pendingDelegations = 0;
        return;
      }

      this.delegationsSvc.listCreatedBy(user.empNo).subscribe({
        next: (res) => {
          this.dataSource = new MatTableDataSource<DelegationFullDto>(res);

          this.totalDelegations   = res.length;
          this.activeDelegations  = res.filter(d => d.status === 'ACTIVE').length;
          this.pendingDelegations = res.filter(d => d.status === 'PENDING').length;


          this.dataSource.filterPredicate = (row, filter) => {
            if (!filter) return true;

            let parsed: { text: string; status: string };
            try {
              parsed = JSON.parse(filter);
            } catch {
              parsed = { text: filter, status: '' };
            }

            const text   = (parsed.text || '').trim().toLowerCase();
            const status = (parsed.status || '').trim();

            let matchesText = true;
            if (text) {
              matchesText =
                (row.delegationId + '').includes(text) ||
                (row.delegatorEmpNo ?? '').toLowerCase().includes(text) ||
                (row.delegatorUsername ?? '').toLowerCase().includes(text) ||
                (row.delegateeEmpNo ?? '').toLowerCase().includes(text) ||
                (row.delegateeUsername ?? '').toLowerCase().includes(text) ||
                (row.status ?? '').toLowerCase().includes(text);
            }

            let matchesStatus = true;
            if (status) {
              matchesStatus = (row.status ?? '') === status;
            }

            return matchesText && matchesStatus;
          };

          if (this.paginator) {
            this.dataSource.paginator = this.paginator;
          }

          this.loading = false;

          this.applySort();
          this.updateFilter();
        },
        error: (err) => {
          console.error(err);
          this.loading = false;
          this.errorMsg = 'حدث خطأ أثناء جلب التفويضات.';
          this.totalDelegations   = 0;
          this.activeDelegations  = 0;
          this.pendingDelegations = 0;
        }
      });
    },
    error: (err) => {
      console.error(err);
      this.loading = false;
      this.errorMsg = 'تعذر تحميل بيانات المستخدم.';
      this.totalDelegations   = 0;
      this.activeDelegations  = 0;
      this.pendingDelegations = 0;
    }
  });
}




  /** تحديث كائن الفلتر (نص + حالة) على الجدول */
  private updateFilter(): void {
    if (!this.dataSource) return;

    const payload = {
      text: (this.searchText || '').trim().toLowerCase(),
      status: this.statusFilter || ''
    };

    this.dataSource.filter = JSON.stringify(payload);

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  /** بحث في الجدول من حقل النص */
  applyFilter(event: Event): void {
    this.searchText = (event.target as HTMLInputElement).value || '';
    this.updateFilter();
  }

  /** تغيير قيمة فلتر الحالة من الـ select */
  onStatusFilterChange(value: string): void {
    this.statusFilter = value || '';
    this.updateFilter();
  }

  /** تغيير قيمة الـ select للفرز */
  onSortChanged(sortValue: string): void {
    this.selectedSort = sortValue;
    this.applySort();
  }

  /** تطبيق الفرز على dataSource حسب selectedSort */
  private applySort(): void {
    if (!this.dataSource?.data) return;

    const [field, dir] = this.selectedSort.split(',') as [string, 'asc' | 'desc'];

    const sorted = [...this.dataSource.data].sort((a: any, b: any) => {
      const av = (a?.[field] ?? '').toString();
      const bv = (b?.[field] ?? '').toString();

      if (av === bv) return 0;
      const res = av > bv ? 1 : -1;
      return dir === 'desc' ? -res : res;
    });

    this.dataSource.data = sorted;
  }

  /** تنسيق نافذة الفترة (بداية/نهاية أو بدون انتهاء) */
  buildWindow(row: DelegationFullDto): string {
    if (row.noExpiry) {
      return 'من ' + (row.startAt ? row.startAt : '—') + ' • بدون انتهاء';
    }
    return `${row.startAt ?? '—'}  →  ${row.endAt ?? '—'}`;
  }


  getStatusBadgeClass(status: string): string {
    switch (status) {
      case 'ACTIVE': return 'status-done';
      case 'PENDING': return 'status-pending';
      case 'REJECTED':
      case 'REVOKED':
      case 'EXPIRED': return 'status-rejected';
      default: return 'status-pending';
    }
  }


  openDetails(row: DelegationFullDto): void {
    this.selectedDelegation = row;
   this.dialog.open(this.detailsTpl, {
  width: '45vw',       
  height: '50vh',       
  maxWidth: '95vw',
  direction: 'rtl',
  panelClass: ['custom-dialog-container']
});

  }

  openCreateDelegationDialog(): void {
    // this.dialog.open(CreatedelegationDialog, {...})
  }

  retry(): void {
    this.loadMyDelegations();
  }
}

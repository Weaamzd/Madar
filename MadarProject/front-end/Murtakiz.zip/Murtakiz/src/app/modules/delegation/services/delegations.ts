import { Injectable } from '@angular/core';


import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  CreateDelegationRequest,
  DelegationFullDetailsDto,
  DelegationFullDto,
  DelegationResponse,
  DelegationsByScopeParams,
  DelegationsSearchParams,
  PageResponse
} from '../../delegation/models/delegations.models';
import { CreateExternalUserRequest, ExternalUserSummaryDto } from '../../system-settings/models/external-user.models';

export interface ActingTokenResponse {
  accessToken: string;
  expiresAt: string;
  jti: string;
  actingSessionId: number;
  delegationId: number;
  tokenType?: string; 
}
@Injectable({
  providedIn: 'root'
})
export class Delegations {
  private readonly apiRoot = 'http://localhost:9090/api/v1/murtakiz';
  private readonly baseUrl = `${this.apiRoot}/delegations`;

  constructor(private http: HttpClient) {}

  listCreatedBy(empNo: string): Observable<DelegationFullDto[]> {
    return this.http.get<DelegationFullDto[]>(
      `${this.baseUrl}/created-by/${encodeURIComponent(empNo)}`
    );
  }


    listByScopeFull(params: DelegationsByScopeParams = {}): Observable<PageResponse<DelegationFullDetailsDto>> {
    let hp = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && String(v).trim() !== '') {
        hp = hp.set(k, String(v));
      }
    });
    return this.http.get<PageResponse<DelegationFullDetailsDto>>(`${this.baseUrl}/by-scope/full`, { params: hp });
  }

  searchAllFullFiltered(params: DelegationsSearchParams): Observable<DelegationFullDetailsDto[]> {
    let hp = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && String(v).trim() !== '') {
        hp = hp.set(k, String(v));
      }
    });

    return this.http.get<DelegationFullDetailsDto[]>(
      `${this.baseUrl}/all-full/search`,
      { params: hp }
    );
  }


allFullFilteredByScope(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  creatorEmpNo?: string | null;
  delegatorEmpNo?: string | null;
  delegateeEmpNo?: string | null;
  status?: 'PENDING' | 'ACTIVE' | 'REJECTED' | 'REVOKED' | 'EXPIRED' | null;
}) {
  let hp = new HttpParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && String(v).trim() !== '') {
      hp = hp.set(k, String(v));
    }
  });

  return this.http.get<DelegationFullDetailsDto[]>(
    `${this.baseUrl}/all-full/by-scope`,
    { params: hp }
  );
}



  create(req: CreateDelegationRequest): Observable<DelegationResponse> {
    return this.http.post<DelegationResponse>(this.baseUrl, req);
  }


  revoke(id: number) {
    return this.http.post<DelegationResponse>(`${this.baseUrl}/${id}/revoke`, {});
  }


  listActingContexts() {
    return this.http.get<any[]>(`${this.baseUrl}/act/contexts`);
  }


  startActing(delegationId: number): Observable<ActingTokenResponse> {
    return this.http.post<ActingTokenResponse>(`${this.baseUrl}/${delegationId}/act/start`, {});
  }
  stopActing() {
    return this.http.post<void>(`${this.baseUrl}/act/stop`, {});
  }


createExternalUserWithRegistration(req: CreateExternalUserRequest) {
  return this.http.post<ExternalUserSummaryDto>(
    `${this.apiRoot}/admin/external-users/with-registration`,
    req
  );
}

}

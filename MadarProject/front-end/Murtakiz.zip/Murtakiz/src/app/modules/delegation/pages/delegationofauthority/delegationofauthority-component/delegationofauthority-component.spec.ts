import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DelegationofauthorityComponent } from './delegationofauthority-component';

describe('DelegationofauthorityComponent', () => {
  let component: DelegationofauthorityComponent;
  let fixture: ComponentFixture<DelegationofauthorityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DelegationofauthorityComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DelegationofauthorityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

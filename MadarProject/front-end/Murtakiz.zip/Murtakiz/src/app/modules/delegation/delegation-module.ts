import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DelegationRoutingModule } from './delegation-routing-module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DelegationRoutingModule
  ]
})
export class DelegationModule { }

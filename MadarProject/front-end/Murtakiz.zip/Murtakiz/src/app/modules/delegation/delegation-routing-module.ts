import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DelegationofauthorityComponent} from '../../modules/delegation/pages/delegationofauthority/delegationofauthority-component/delegationofauthority-component';
const routes: Routes = [
  { path: '', component: DelegationofauthorityComponent },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DelegationRoutingModule { }

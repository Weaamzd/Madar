import { CommonModule } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { jwtDecode } from 'jwt-decode';
import { MatDialogRef } from '@angular/material/dialog';


import { AuthService } from '../../../../core/auth/authService';

import { Delegations } from '../../services/delegations';
import { OrgLookup } from '../../../system-settings/services/org/org-lookup';


import { CreateDelegationRequest, DelegationResponse } from '../../models/delegations.models';
import { UniteDto, SubUniteDto } from '../../../system-settings/models/org.models';

type TargetType = 'UNITE' | 'SUBS';
type ActionsMode = 'ALL' | 'CUSTOM';


type DelegationSuccessVM = {
  delegationId: number | string;
  status?: string;
  delegatorEmpNo?: string;
  delegateeEmpNo?: string;
  scopeType?: 'ALL' | 'LIMITED';
  scopesCount?: number;
  startAt?: string;
  endAt?: string | null;
  noExpiry?: boolean;


  actions?: string[];
  uniteId?: number | null;
  subUnitIds?: number[] | null;
};

@Component({
  selector: 'app-createdelegation-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './createdelegation-dialog.html',
  styleUrls: ['./createdelegation-dialog.css']
})
export class CreatedelegationDialog implements OnInit {


  @Output() closed = new EventEmitter<void>();

  actionOptions = ['READ', 'CREATE', 'UPDATE', 'DELETE', 'APPROVE'];

  unites: UniteDto[] = [];
  unitesLoading = false;

  selectedUniteId: number | null = null;
  selectedLevel1Id: number | null = null;
  selectedLevel2Id: number | null = null;
  selectedLevel3Id: number | null = null;
  selectedLevel4Id: number | null = null;

  level1List: SubUniteDto[] = [];
  level2List: SubUniteDto[] = [];
  level3List: SubUniteDto[] = [];
  level4List: SubUniteDto[] = [];

  subUnitsLoading = false;

  submitting = false;
  showPreview = false;
  creationDone = false;         
  result: DelegationResponse | null = null;


  resultVm: DelegationSuccessVM | null = null;


  form = new FormGroup({
    delegateeEmpNo: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    delegatorEmpNo: new FormControl<string>('', { nonNullable: true }),

    targetType: new FormControl<TargetType | null>(null),

    actionsMode: new FormControl<ActionsMode>('ALL', { nonNullable: true }),
    actions: new FormControl<string[]>([], { nonNullable: true }),

    startAt: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    noExpiry: new FormControl<boolean>(true, { nonNullable: true }),
    endAt: new FormControl<string | null>(null),

    requireAcceptance: new FormControl<boolean>(false, { nonNullable: true }),
    allowSubdelegate: new FormControl<boolean>(false, { nonNullable: true }),

    uniteId: new FormControl<number | null>(null),
    subUnitIds: new FormControl<number[] | null>(null),
  });

  constructor(
    private delegations: Delegations,
    private orgApi: OrgLookup,
    private auth: AuthService,
    private dialogRef: MatDialogRef<CreatedelegationDialog>   
  ) {}


  ngOnInit(): void {
    this.form.patchValue({ startAt: this.toLocalInput(new Date()) });

    let empNo =
      this.auth.userSig()?.empNo ||
      localStorage.getItem('empNo') ||
      '';

    if (!empNo) {
      try {
        const t = this.auth.getToken();
        if (t) {
          const { empNo: claimEmp } = (jwtDecode as any)(t) as { empNo?: string };
          if (claimEmp) empNo = claimEmp;
        }
      } catch {}
    }
    this.form.patchValue({ delegatorEmpNo: empNo });

    this.loadUnites();

    this.form.get('noExpiry')?.valueChanges.subscribe(v => {
      if (v) this.form.patchValue({ endAt: null });
    });
  }

  private loadUnites() {
    this.unitesLoading = true;
    this.orgApi.listAllUnites().subscribe({
      next: (rows) => this.unites = rows || [],
      error: () => this.unites = [],
      complete: () => this.unitesLoading = false
    });
  }

  private loadChildren(parentId: number, targetLevel: 2 | 3 | 4): void {
    this.subUnitsLoading = true;
    this.orgApi.listDirectChildren(parentId).subscribe({
      next: (kids) => {
        if (targetLevel === 2) this.level2List = kids || [];
        if (targetLevel === 3) this.level3List = kids || [];
        if (targetLevel === 4) this.level4List = kids || [];
        this.subUnitsLoading = false;
        this.syncDeepestSelectionToForm();
      },
      error: () => {
        if (targetLevel === 2) this.level2List = [];
        if (targetLevel === 3) this.level3List = [];
        if (targetLevel === 4) this.level4List = [];
        this.subUnitsLoading = false;
        this.syncDeepestSelectionToForm();
      }
    });
  }

  private loadFirstLevel(uniteId: number): void {
    this.subUnitsLoading = true;
    this.orgApi.listDirectUnderUnite(uniteId).subscribe({
      next: (kids) => {
        this.level1List = kids || [];
        this.subUnitsLoading = false;
        this.syncDeepestSelectionToForm();
      },
      error: () => {
        this.level1List = [];
        this.subUnitsLoading = false;
        this.syncDeepestSelectionToForm();
      }
    });
  }


  onTargetTypeChange(): void {
    this.selectedUniteId = null;
    this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;

    this.level1List = [];
    this.level2List = [];
    this.level3List = [];
    this.level4List = [];

    this.form.patchValue({
      uniteId: null,
      subUnitIds: null,
      actionsMode: 'ALL',
      actions: []
    });
  }

  onUniteTopChanged(uniteIdRaw: any): void {
    const id = Number(uniteIdRaw);
    this.selectedUniteId = Number.isFinite(id) ? id : null;

    this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level1List = this.level2List = this.level3List = this.level4List = [];

    if (!this.selectedUniteId) {
      this.syncDeepestSelectionToForm();
      return;
    }

    this.loadFirstLevel(this.selectedUniteId);

    this.syncDeepestSelectionToForm();
  }

  onLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
    const id = Number(subIdRaw);

    if (level === 1) {
      this.selectedLevel1Id = Number.isFinite(id) ? id : null;
      this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level2List = this.level3List = this.level4List = [];
      if (this.selectedLevel1Id) this.loadChildren(this.selectedLevel1Id, 2);
    }

    if (level === 2) {
      this.selectedLevel2Id = Number.isFinite(id) ? id : null;
      this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level3List = this.level4List = [];
      if (this.selectedLevel2Id) this.loadChildren(this.selectedLevel2Id, 3);
    }

    if (level === 3) {
      this.selectedLevel3Id = Number.isFinite(id) ? id : null;
      this.selectedLevel4Id = null;
      this.level4List = [];
      if (this.selectedLevel3Id) this.loadChildren(this.selectedLevel3Id, 4);
    }

    if (level === 4) {
      this.selectedLevel4Id = Number.isFinite(id) ? id : null;
    }

    this.syncDeepestSelectionToForm();
  }

  onActionsModeChange(): void {
    if (this.form.value.actionsMode === 'ALL') {
      this.form.patchValue({ actions: [] });
    }
  }

  onNoExpiryChange(): void {
    if (this.form.value.noExpiry) {
      this.form.patchValue({ endAt: null });
    }
  }

  private syncDeepestSelectionToForm(): void {
    const target = this.form.value.targetType;
    const deepestSub =
      this.selectedLevel4Id ??
      this.selectedLevel3Id ??
      this.selectedLevel2Id ??
      this.selectedLevel1Id ??
      null;

    if (target === 'UNITE') {
      this.form.patchValue({
        uniteId: this.selectedUniteId ?? null,
        subUnitIds: null
      }, { emitEvent: false });
      return;
    }

    if (target === 'SUBS') {
      this.form.patchValue({
        uniteId: this.selectedUniteId ?? null,
        subUnitIds: deepestSub ? [deepestSub] : null
      }, { emitEvent: false });
    }
  }

  f(name: string) { return this.form.get(name)!; }

  get showActionsBlock(): boolean {
    return !!this.form.value.targetType;
  }

  get actionsInvalid(): boolean {
    return this.form.value.actionsMode === 'CUSTOM'
      && (!this.form.value.actions || this.form.value.actions.length === 0);
  }

  get subsInvalid(): boolean {
    return this.form.value.targetType === 'SUBS'
      && (!this.form.value.subUnitIds || this.form.value.subUnitIds.length === 0);
  }

  get endAtInvalid(): boolean {
    if (this.form.value.noExpiry) return false;
    const endAt = this.form.value.endAt;
    const startAt = this.form.value.startAt;
    if (!endAt || !startAt) return true;
    return new Date(endAt).getTime() <= new Date(startAt).getTime();
  }

  get canSubmit(): boolean {
    const v = this.form.value;

    if (this.form.invalid) return false;
    if (!v.delegateeEmpNo || !v.startAt) return false;

    if (!v.targetType) return false;

    if (v.targetType === 'UNITE' && !this.selectedUniteId) return false;
    if (v.targetType === 'SUBS' && this.subsInvalid) return false;

    if (v.actionsMode === 'CUSTOM' && this.actionsInvalid) return false;

    if (!v.noExpiry && this.endAtInvalid) return false;

    return true;
  }


  buildRequest(): CreateDelegationRequest {
    const v = this.form.getRawValue();
    const actions = (v.actionsMode === 'ALL') ? [] : (v.actions || []);

    const req: any = {
      delegatorEmpNo: v.delegatorEmpNo || undefined,
      delegateeEmpNo: v.delegateeEmpNo!,
      scopeType: 'LIMITED',
      actions,
      startAt: this.toIso(v.startAt!),
      noExpiry: v.noExpiry!,
      requireAcceptance: v.requireAcceptance!,
      allowSubdelegate: v.allowSubdelegate!
    };

    if (!v.noExpiry) req.endAt = this.toIso(v.endAt || '');

    if (v.targetType === 'UNITE') {
      req.uniteId = this.selectedUniteId != null ? Number(this.selectedUniteId) : null;
    } else if (v.targetType === 'SUBS') {
      req.uniteId = this.selectedUniteId != null ? Number(this.selectedUniteId) : null;
      req.subUnitIds = (v.subUnitIds || []).map(Number);
    }

    return req as CreateDelegationRequest;
  }

  togglePreview() { this.showPreview = !this.showPreview; }

  submit() {
    if (!this.canSubmit) return;

    const req = this.buildRequest();
    this.submitting = true;
    this.result = null;
    this.resultVm = null;

    this.delegations.create(req).subscribe({
      next: (res) => {
        this.result = res;

        this.resultVm = {
          ...res,                                            
          actions: Array.isArray(req.actions) ? req.actions : [],
          uniteId: (req as any).uniteId ?? null,
          subUnitIds: (req as any).subUnitIds ?? null,
        };

        this.submitting = false;
        this.creationDone = true; 
      },
      error: (err) => {
        this.submitting = false;
        alert(err?.error?.message || 'فشل إنشاء التفويض');
      }
    });
  }


  onClose(): void {
    this.closed.emit();        
    this.dialogRef.close(this.resultVm ?? this.result ?? true);  
  }

  resetForm(): void {
    const empNo =
      this.auth.userSig()?.empNo ||
      localStorage.getItem('empNo') ||
      '';

    this.selectedUniteId = null;
    this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level1List = this.level2List = this.level3List = this.level4List = [];

    this.form.reset({
      delegatorEmpNo: empNo,
      delegateeEmpNo: '',
      targetType: null,
      actionsMode: 'ALL',
      actions: [],
      uniteId: null,
      subUnitIds: null,
      startAt: this.toLocalInput(new Date()),
      noExpiry: true,
      endAt: null,
      requireAcceptance: false,
      allowSubdelegate: false
    });

    this.result = null;
    this.resultVm = null;
    this.showPreview = false;
    this.creationDone = false; 
  }

  private toIso(localValue: string): string {
    if (!localValue) return '';
    return localValue.length === 16 ? localValue + ':00' : localValue;
  }
  private toLocalInput(d: Date): string {
    const pad = (n: number) => (n < 10 ? '0' + n : n);
    const yyyy = d.getFullYear();
    const mm = pad(d.getMonth() + 1);
    const dd = pad(d.getDate());
    const hh = pad(d.getHours());
    const mi = pad(d.getMinutes());
    return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
  }
}


import { CommonModule, DatePipe } from '@angular/common';
import { Component, Inject, OnInit, computed, signal } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { DelegationFullDetailsDto, DelegationScopeDtoFull, DelegationsSearchParams } from '../../models/delegations.models';
import { Delegations } from '../../services/delegations';



type DialogData = {
  delegationId?: number;                  
  search?: DelegationsSearchParams;      
};

@Component({
  selector: 'app-delegation-details-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatIconModule,
    MatTabsModule,
    MatTableModule,
    MatButtonModule,
    MatProgressSpinnerModule,
  ],
  templateUrl: './delegation-details-dialog.html',
  styleUrls: ['./delegation-details-dialog.css'],
  providers: [DatePipe]
})
export class DelegationDetailsDialog implements OnInit {

  loading = true;
  error: string | null = null;


  dataLoaded = signal<DelegationFullDetailsDto | null>(null);

  displayedScopeCols = ['scope', 'region', 'module', 'permission', 'actions'];

  constructor(
    private api: Delegations,
    private date: DatePipe,
    public dialogRef: MatDialogRef<DelegationDetailsDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {}

  ngOnInit(): void {
    if (!this.data?.delegationId && !this.data?.search) {
      this.error = 'الطلب غير صحيح: يلزم delegationId أو search params.';
      this.loading = false;
      return;
    }

    const params: DelegationsSearchParams = this.data.search ?? {};
    this.api.searchAllFullFiltered(params).subscribe({
      next: (list) => {
        const id = this.data.delegationId;
        const picked = id ? (list.find(d => d.delegationId === id) ?? null)
                          : (list.length ? list[0] : null);
        if (!picked) {
          this.error = 'لم يتم العثور على التفويض المطلوب.';
        } else {
          this.dataLoaded.set(picked);
        }
        this.loading = false;
      },
      error: () => {
        this.error = 'تعذر جلب بيانات التفويض.';
        this.loading = false;
      }
    });
  }

  na(v: unknown): string {
    if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) return '—';
    return String(v);
  }
  formatDate(iso: string | null | undefined, fmt: string = 'yyyy-MM-dd HH:mm'): string {
    if (!iso) return '—';
    return this.date.transform(iso, fmt) ?? iso;
  }
  scopeToText(s: DelegationScopeDtoFull): string {
    if (s.uniteName && !s.subUniteName) return `${s.uniteName} (إدارة)`;
    if (s.subUniteName) return `${s.subUniteName} (وحدة/شعبة)`;
    return '—';
  }
  actionsMaskToText(mask?: number | null, all?: string[] | null): string {
    if (all && all.length) return all.join('، ');
    if (mask === null || mask === undefined) return '—';
    return `mask=${mask}`;
  }

  isActive(d: DelegationFullDetailsDto | null): boolean { return !!d?.activeNow; }
  isWithin(d: DelegationFullDetailsDto | null): boolean { return !!d?.withinWindow; }
  isNoExpiry(d: DelegationFullDetailsDto | null): boolean { return !!d?.noExpiry; }
}

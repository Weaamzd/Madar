import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatedelegationDialog } from './createdelegation-dialog';

describe('CreatedelegationDialog', () => {
  let component: CreatedelegationDialog;
  let fixture: ComponentFixture<CreatedelegationDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CreatedelegationDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreatedelegationDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

export type DelegationScopeType = 'ALL' | 'LIMITED';

export interface CreateDelegationRequest {
  delegatorEmpNo?: string;     
  delegateeEmpNo: string;
  scopeType: DelegationScopeType;
  uniteId?: number | null;     
  subUnitIds?: number[];       
  actions?: string[];        
  startAt: string;            
  endAt?: string | null;     
  noExpiry: boolean;
  requireAcceptance: boolean;
  allowSubdelegate: boolean;
}

export interface DelegationResponse {
  delegationId: number;
  status: 'PENDING' | 'ACTIVE' | 'REJECTED' | 'REVOKED' | 'EXPIRED';
  startAt: string;
  endAt: string | null;
  noExpiry: boolean;
  delegatorEmpNo: string;
  delegateeEmpNo: string;
  scopeType: DelegationScopeType;
  scopesCount: number;
}


export type DelegationStatus = 'PENDING' | 'ACTIVE' | 'REJECTED' | 'REVOKED' | 'EXPIRED';

export interface DelegationScopeDtoFull {
  scopeId: number;
  uniteId?: number | null;
  uniteName?: string | null;
  subUniteId?: number | null;
  subUniteName?: string | null;
  regionCode?: string | null;
  moduleKey?: string | null;
  permissionKey?: string | null;
  actionsMask?: number | null;
}

export interface DelegationFullDetailsDto {
  delegationId: number;
  status: DelegationStatus;
  scopeType: DelegationScopeType;

  requireAcceptance: boolean;
  allowSubdelegate: boolean;
  noExpiry: boolean;

  startAt: string | null; 
  endAt: string | null;   
  createdAt: string;      

  activeNow: boolean;
  withinWindow: boolean;

  delegatorEmpNo: string;
  delegatorUsername: string;
  delegatorFullNameAr: string;

  delegateeEmpNo: string;
  delegateeUsername: string;
  delegateeFullNameAr: string;

  createdByEmpNo: string;
  createdByUsername: string;
  createdByFullNameAr: string;

  acceptedAt?: string | null;
  acceptedByEmpNo?: string | null;
  acceptedByUsername?: string | null;
  acceptedByFullNameAr?: string | null;

  actionsMaskAggregated?: number | null;
  actionsAll?: string[] | null;

  activeSessionsCount?: number | null;
  totalSessionsCount?: number | null;

  scopes: DelegationScopeDtoFull[];
}

export interface DelegationsSearchParams {
  creatorEmpNo?: string | null;
  delegatorEmpNo?: string | null;
  delegateeEmpNo?: string | null;
  status?: DelegationStatus | null;
}

export interface DelegationRow {
  delegationId: number;
  status: DelegationStatus;
  activeNow: boolean;

  delegatorEmpNo: string;
  delegatorName: string;

  delegateeEmpNo: string;
  delegateeName: string;

  scopeType: 'ALL' | 'LIMITED';
  window: string;              
  actionsAllShort: string;   
  sessionsSummary: string;     
  createdAt: string;         
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  page?: number | null;
  size?: number | null;
  last: boolean;
}

export interface DelegationScopeDtoFull {
  scopeId: number;
  uniteId?: number | null;
  uniteCode?: string | null;
  uniteName?: string | null;
  subUniteId?: number | null;
  subUniteCode?: string | null;
  subUniteName?: string | null;
  regionCode?: string | null;
  moduleKey?: string | null;
  permissionKey?: string | null;
  actionsMask?: number | null;
  actions?: string[] | null;
}

export interface DelegationsByScopeParams {
  uniteId?: number | null;
  subUniteId?: number | null;
  creatorEmpNo?: string | null;
  delegatorEmpNo?: string | null;
  delegateeEmpNo?: string | null;
  status?: DelegationStatus | null;
  page?: number | null;  
  size?: number | null;
  unpaged?: boolean | null;
}

export interface DelegationFullDto {
  delegationId: number;
  status: DelegationStatus;

  startAt: string | null;      
  endAt: string | null;
  noExpiry: boolean;
  requireAcceptance: boolean;
  allowSubdelegate: boolean;

  scopeType: DelegationScopeType;

  actionsMaskAggregated: number | null;
  scopes: DelegationScopeDtoFull[];

  delegatorEmpNo: string;
  delegatorUsername: string;

  delegateeEmpNo: string;
  delegateeUsername: string;

  createdAt: string;
  createdByEmpNo: string;

  activeNow: boolean;
  activeSessionsCount: number;
}

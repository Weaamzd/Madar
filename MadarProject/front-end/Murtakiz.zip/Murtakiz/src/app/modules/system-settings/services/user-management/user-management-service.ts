import { Injectable } from '@angular/core';
import { catchError, map, Observable, of } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';

import { EmployeeOrgInfo, EmployeeOrgWithManagersDto, PageResponse, UnifiedPersonApi } from '../../models/people-directory.models';
import { EmployeeProfileApi, UserStatusResult, ManagerNameDto, EmployeeForUserCreationDto, CreateUserForExistingEmployeeRequest, ExternalEmployeeUserProfileDto, UserWithHistoryDto, UnifiedPersonDetailsDto } from '../../models/employee-directory.models';

import { CreateUser, LinkExternalByExtIdUsernameRequest, LinkInternalByEmpNoUsernameRequest, UnlinkByUsernameRequest } from '../../models/user-admin.models';
import { CreateUserRequest, UserSummaryDto, UserEmployeePrecheckDto } from '../../models/employee-directory.models';

import { ExternalUserSummaryDto, CreateExternalUserRequest } from '../../models/external-user.models';
import { UserRegistrationRequestSummaryDto } from '../../models/registration-requests.models';

@Injectable({ providedIn: 'root' })
export class UserManagementService {
  private readonly apiRoot      = 'http://localhost:9090/api/v1/murtakiz';
  private readonly employeesUrl = `${this.apiRoot}/org/employees`;
  private readonly profilesUrl  = `${this.employeesUrl}/profiles`;

  private readonly baseUrl      = `${this.apiRoot}/admin/users`;

  constructor(private http: HttpClient) {}

listPeople(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  q?: string | null;              
  fullNameAr?: string | null;
  username?: string | null;
  userStatus?: string | null;
  loggedIn?: boolean | null;
  uniteName?: string | null;
  subUniteName?: string | null;
  managerNo?: string | null;       
  page?: number;
  size?: number;
  unpaged?: boolean;
}): Observable<PageResponse<UnifiedPersonDetailsDto>> {
  let p = new HttpParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
  });
  return this.http.get<PageResponse<UnifiedPersonDetailsDto>>(
    `${this.employeesUrl}/people`,
    { params: p }
  );
}



getOrgByEmpNo(empNo: string): Observable<EmployeeOrgInfo> {
  return this.http.get<EmployeeOrgInfo>(`${this.employeesUrl}/${encodeURIComponent(empNo)}/org`);
}

getOrgWithManagers(empNo: string): Observable<EmployeeOrgWithManagersDto> {
  return this.http.get<EmployeeOrgWithManagersDto>(`${this.employeesUrl}/${encodeURIComponent(empNo)}/org-with-managers`);
}

  listAllPeopleProfiles(params: {
    empNo?: string | null;
    fullNameAr?: string | null;
    username?: string | null;
    userStatus?: string | null;
    loggedIn?: boolean | null;
    uniteName?: string | null;
    subUniteName?: string | null;
    page?: number;     
    size?: number;
    sort?: string | null; 
  }) {
    let p = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
    });

    return this.http.get<PageResponse<UnifiedPersonApi>>(
      `${this.employeesUrl}/people/all`,
      { params: p }
    );
  }

listAllPeopleByScope(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  q?: string | null;            
  fullNameAr?: string | null;
  username?: string | null;
  userStatus?: string | null;
  loggedIn?: boolean | null;
  uniteName?: string | null;
  subUniteName?: string | null;
  page?: number;                  
  size?: number;
  unpaged?: boolean;
}): Observable<PageResponse<UnifiedPersonDetailsDto>> {
  let p = new HttpParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
  });

  return this.http.get<PageResponse<UnifiedPersonDetailsDto>>(
    `${this.employeesUrl}/people/by-scope/all`,
    { params: p }
  );
}


  listAllEmployeeProfiles(): Observable<EmployeeProfileApi[]> {
    return this.http.get<EmployeeProfileApi[]>(this.profilesUrl);
  }

  getEmployeeProfile(empNo: string): Observable<EmployeeProfileApi> {
    return this.http.get<EmployeeProfileApi>(
      `${this.employeesUrl}/${encodeURIComponent(empNo)}/profile`
    );
  }

  getExternalEmployeeProfile(extEmpId: string) {

  return this.http.get<ExternalEmployeeUserProfileDto>(`${this.employeesUrl}/${encodeURIComponent(extEmpId)}/exprofile`);
}


getUserWithHistoryByUsernameParam(username: string) {
  const url = `${this.employeesUrl}/users/with-history`;
  return this.http.get<UserWithHistoryDto>(url, {
    params: new HttpParams().set('username', username)
  });
}


  listUsersWithHistory(params: {
    username?: string | null;
    userStatus?: 'Active' | 'Inactive' | 'Suspended' | null;
    linkedState?: 'UNLINKED' | 'LINKED' | 'ALL' | null; 
    page?: number;         
    size?: number;
    unpaged?: boolean;    
  }): Observable<PageResponse<UserWithHistoryDto>> {
    let p = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
    });

    return this.http.get<PageResponse<UserWithHistoryDto>>(
      `${this.employeesUrl}/users`,
      { params: p }
    );
  }


listUsersWithHistoryByScope(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  username?: string | null;
  userStatus?: 'Active' | 'Inactive' | 'Suspended' | null; 
  linkedState?: 'UNLINKED' | 'LINKED' | 'ALL' | null;      
  page?: number;          
  size?: number;
  unpaged?: boolean;
}) {
  let p = new HttpParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
  });

  return this.http.get<PageResponse<UserWithHistoryDto>>(
    `${this.employeesUrl}/users/by-scope`,
    { params: p }
  );
}


  listAllPeopleWithoutUser(params: {
    q?: string | null;            
    fullNameAr?: string | null;
    uniteName?: string | null;
    subUniteName?: string | null;
    page?: number;              
    size?: number;
    unpaged?: boolean;            
  }): Observable<PageResponse<UnifiedPersonDetailsDto>> {
    let p = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
    });

    return this.http.get<PageResponse<UnifiedPersonDetailsDto>>(
      `${this.employeesUrl}/people/unlinked`,
      { params: p }
    );
  }


listAllPeopleWithoutUserByScope(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  q?: string | null;              
  fullNameAr?: string | null;
  page?: number;                  
  size?: number;
  unpaged?: boolean;
}): Observable<PageResponse<UnifiedPersonDetailsDto>> {
  let p = new HttpParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') p = p.set(k, String(v));
  });

  return this.http.get<PageResponse<UnifiedPersonDetailsDto>>(
    `${this.employeesUrl}/people/unlinked/by-scope`,
    { params: p }
  );
}


  createUser(req: CreateUser): Observable<UserSummaryDto> {
    return this.http.post<UserSummaryDto>(`${this.baseUrl}`, req);
  }

  updateUser(req: CreateUser): Observable<UserSummaryDto> {

    return this.http.put<UserSummaryDto>(`${this.baseUrl}/update`, req);
  }

  toggleStatusByEmpNo(empNo: string, revokeAllSessions: boolean = true): Observable<UserStatusResult> {
    return this.http.patch<UserStatusResult>(
      `${this.baseUrl}/toggle-status`,
      {},
      { params: { empNo, revokeAllSessions: String(revokeAllSessions) } }
    );
  }

  toggleStatusByUsername(username: string, revokeAllSessions: boolean = true) {
  return this.http.patch<UserStatusResult>(
    `${this.baseUrl}/toggle-status/by-username`,
    {},
    { params: { username, revokeAllSessions: String(revokeAllSessions) } }
  );
}

  listAllManagers(): Observable<ManagerNameDto[]> {
    return this.http.get<ManagerNameDto[]>(`${this.employeesUrl}/managers`);
  }

  listManagersByScope(params: { uniteId?: number | null; subUniteId?: number | null }) {
    let p = new HttpParams();
    if (params?.subUniteId) p = p.set('subUniteId', String(params.subUniteId));
    else if (params?.uniteId) p = p.set('uniteId', String(params.uniteId));
    return this.http.get<ManagerNameDto[]>(`${this.employeesUrl}/managers/by-scope`, { params: p });
  }

  createExternalUser(req: CreateExternalUserRequest) {
    return this.http.post<ExternalUserSummaryDto>(
      `${this.apiRoot}/admin/external-users`,
      req
    );
  }

  precheck(params: { username?: string | null; empNo?: string | null }) {
    let httpParams = new HttpParams();
    if (params.username) httpParams = httpParams.set('username', params.username);
    if (params.empNo)    httpParams = httpParams.set('empNo', params.empNo);

    return this.http.get<UserEmployeePrecheckDto>(`${this.baseUrl}/precheck`, { params: httpParams });
  }


  precheckCandidateByEmpNo(empNo: string): Observable<EmployeeForUserCreationDto | null> {
    return this.http.get<EmployeeForUserCreationDto>(
      `${this.baseUrl}/precheck/empno`,
      {
        params: { empNo },
        observe: 'response'  
      }
    ).pipe(
      map(resp => resp.status === 200 ? (resp.body as EmployeeForUserCreationDto) : null),
      catchError((err: HttpErrorResponse) => {

        return of(null);
      })
    );
  }


  createUserForExistingEmployee(req: CreateUserForExistingEmployeeRequest): Observable<UserSummaryDto> {
    return this.http.post<UserSummaryDto>(
      `${this.baseUrl}/create-for-existing-employee`,
      req
    );
  }

  linkInternalByEmpNoUsername(req: LinkInternalByEmpNoUsernameRequest) {
    return this.http.patch<void>(`${this.baseUrl}/link/internal/by-empno`, req);
  }

  linkExternalByExtIdUsername(req: LinkExternalByExtIdUsernameRequest) {
    return this.http.patch<void>(`${this.baseUrl}/link/external/by-extid`, req);
  }

  unlinkByUsername(req: UnlinkByUsernameRequest) {
    return this.http.patch<void>(`${this.baseUrl}/unlink/by-username`, req);
  }

searchRegistrationRequests(params: {
  username?: string | null;
  stageStatus?: 'PENDING' | 'APPROVED' | 'REJECTED' | null;
  page?: number;    
  size?: number;
}): Observable<PageResponse<UserRegistrationRequestSummaryDto>> {
  let p = new HttpParams();

  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') {
      p = p.set(k, String(v));
    }
  });

  return this.http.get<PageResponse<UserRegistrationRequestSummaryDto>>(
    `${this.baseUrl}/registration-requests/search`,
    { params: p }
  );
}

searchRegistrationRequestsByScope(params: {
  uniteId?: number | null;
  subUniteId?: number | null;
  username?: string | null;
  stageStatus?: 'PENDING' | 'APPROVED' | 'REJECTED' | null;
  page?: number;    
  size?: number;
}): Observable<PageResponse<UserRegistrationRequestSummaryDto>> {
  let p = new HttpParams();

  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') {
      p = p.set(k, String(v));
    }
  });

  return this.http.get<PageResponse<UserRegistrationRequestSummaryDto>>(
    `${this.baseUrl}/registration-requests/search-scope`,
    { params: p }
  );
}


approveAdminRegistration(
  requestId: number,
  approved: boolean,
  notes?: string | null
) {
  const url = `${this.baseUrl}/registration/${requestId}/approve-admin`;

  let params = new HttpParams().set('approved', String(approved)); 

  if (notes !== undefined && notes !== null && notes !== '') {
    params = params.set('notes', notes);
  }

  return this.http.post<void>(url, null, { params });
}


approveUserTerms(username: string) {
  const url = `${this.baseUrl}/registration/user-terms/approve`;

  const params = new HttpParams().set('username', username);

  return this.http.post<void>(url, null, { params });
}

listMyRegistrationRequestsByUsername(username: string) {
  const url = `${this.baseUrl}/registration-requests/my-by-username`;

  const params = new HttpParams().set('username', username);

  return this.http.get<UserRegistrationRequestSummaryDto[]>(url, { params });
}

listMyRegistrationRequests() {
  const url = `${this.baseUrl}/registration-requests/my`;
  return this.http.get<UserRegistrationRequestSummaryDto[]>(url);
}

createUserWithRegistration(req: CreateUserRequest): Observable<UserSummaryDto> {
  return this.http.post<UserSummaryDto>(
    `${this.baseUrl}/create-users`,
    req
  );
}


createUserForExistingEmp(req: CreateUserForExistingEmployeeRequest): Observable<UserSummaryDto> {
  return this.http.post<UserSummaryDto>(
    `${this.baseUrl}/create-for-existing-emp`,
    req
  );
}






}

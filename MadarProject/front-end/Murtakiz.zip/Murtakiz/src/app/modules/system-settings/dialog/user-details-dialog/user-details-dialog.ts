import { CommonModule, DatePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs'; 
import { UserManagementService } from '../../services/user-management/user-management-service';

// ==== DTOs ====
export interface UserLinkEventDto {
  linkType: 'INTERNAL' | 'EXTERNAL';
  empNo?: string | null;
  extEmpId?: string | null;
  linkedAt: string;     // ISO
  unlinkedAt?: string | null;
  actionNote?: string | null;
  actorEmpNo?: string | null;
}
export interface UserWithHistoryDto {
  userId: number;
  username: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  lastLoginAt: string | null;
  empNo: string | null;
  empFullNameAr: string | null;
  externalEmpId: string | null;
  externalFullNameAr: string | null;
  email: string | null;
  jobTitle: string | null;
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
  roles: string[];
  loggedIn: boolean;
  linkHistory: UserLinkEventDto[];
}


type DialogData = { username: string };

@Component({
  selector: 'app-user-details-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatTableModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatTabsModule,
  ],
  templateUrl: './user-details-dialog.html',
  styleUrls: ['./user-details-dialog.css'],
  providers: [DatePipe], 
})
export class UserDetailsDialog implements OnInit {

  loading = true;
  error: string | null = null;
  username!: string;

  dataLoaded: UserWithHistoryDto | null = null;


  displayedColumns = ['type', 'empNo', 'extEmpId', 'linkedAt', 'unlinkedAt', 'note', 'actor'];

  constructor(
    private svc: UserManagementService,
    private datePipe: DatePipe,
    public dialogRef: MatDialogRef<UserDetailsDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {}

  ngOnInit(): void {
    const u = (this.data?.username || '').trim();
    if (!u) {
      this.error = 'الطلب غير صحيح: لم يتم تمرير اسم المستخدم.';
      this.loading = false;
      return;
    }
    this.username = u;


    this.svc.getUserWithHistoryByUsernameParam(u).subscribe({
      next: (dto) => {
        this.dataLoaded = dto;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        if (err?.status === 404) this.error = `المستخدم "${u}" غير موجود.`;
        else if (err?.status === 400) this.error = 'الطلب غير صحيح. يرجى التأكد من اسم المستخدم.';
        else this.error = 'حدث خطأ غير متوقع أثناء جلب البيانات.';
      }
    });
  }


  na(v: unknown): string {
    if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) return '—';
    return String(v);
  }
  joinRoles(arr: string[] | null | undefined): string {
    return arr && arr.length ? arr.join('، ') : '—';
  }
  formatDate(iso: string | null | undefined): string {
    if (!iso) return '—';

    return this.datePipe.transform(iso, 'yyyy-MM-dd HH:mm') || iso;
  }


  statusColor(status?: string | null): 'green' | 'red' | 'orange' {
    const s = (status || '').toLowerCase();
    if (s === 'active') return 'green';
    if (s === 'inactive') return 'red';
    return 'orange'; 
  }
}

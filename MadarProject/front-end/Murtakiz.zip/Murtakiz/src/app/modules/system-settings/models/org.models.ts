export interface UniteDto {
  id: number;
  code: string;
  name: string;
  uniteTypeId: number;
  uniteTypeName: string;
}

export interface UniteMiniDto {
  id: number;
  code: string;
  name: string;
}

export interface SubUniteDto {
  id: number;
  code: string;
  name: string;
  uniteId?: number | null;        
  uniteTypeId?: number | null;
  uniteTypeName?: string | null;
  parentSubUniteId?: number | null;
  hasChildren: boolean;
}

export interface SubUniteTreeDto {
  id: number;
  code: string;
  name: string;
  uniteId?: number | null;
  uniteTypeId?: number | null;
  uniteTypeName?: string | null;
  parentSubUniteId?: number | null;
  hasChildren: boolean;
  children: SubUniteTreeDto[];
}

export interface CurrentRegionDto {
  id: number;               
  regionCode: string;
  regionDbKey: string;
  uniteId: number;
  uniteCode: string;
  uniteName: string;
}


import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { UserManagementService } from '../../services/user-management/user-management-service';

type Context = 'FROM_USER' | 'FROM_EMPLOYEE';
type LinkedState = 'LINKED' | 'UNLINKED';
type Mode = 'UNLINK' | 'LINK_USER_TO_EMP' | 'LINK_EMP_TO_USER';

@Component({
  selector: 'app-link-unlink-user-dialog',
  standalone: true,
  templateUrl: './link-unlink-user-dialog.html',
  styleUrls: ['./link-unlink-user-dialog.css'],
  imports: [
    CommonModule,
    // Material you actually use in the template:
    MatDialogModule,            // mat-dialog-content, mat-dialog-actions
    MatProgressSpinnerModule,   // mat-progress-spinner
    MatButtonModule,            // mat-stroked-button, mat-raised-button
    MatFormFieldModule,         // mat-form-field
    MatSelectModule,            // mat-select, mat-option
    MatIconModule,               // mat-icon (زر الإغلاق)
    MatSnackBarModule 
  ]
})
export class LinkUnlinkUserDialog implements OnInit {

  // ====== Data in ======
  context!: Context;
  username: string | null = null;
  linkedState!: LinkedState;
  empNo: string | null = null;
  extEmpId: string | null = null;

  // ====== Derived mode ======
  mode!: Mode; // UNLINK | LINK_USER_TO_EMP | LINK_EMP_TO_USER

  // ====== UI data ======
  loading = false;
  error: string | null = null;

  // للبطاقات
  userMini: any;       // getUserWithHistoryByUsernameParam
  employeeMini: any;   // getEmployeeProfile(empNo) (للدخلي)
  externalMini: any;   // getExternalEmployeeProfile(extEmpId) (للخارجي، إن رغبت)

  // قوائم الربط
  unlinkedPeople: any[] = []; // listAllPeopleWithoutUser (LINK_USER_TO_EMP)
  unlinkedUsers: any[]  = []; // listUsersWithHistory (LINK_EMP_TO_USER)

  // اختيارات
  selectedPerson: any = null; // شخص (داخلي/خارجي) عند LINK_USER_TO_EMP
  selectedUser: any = null;   // مستخدم عند LINK_EMP_TO_USER

  // فصل
  revokeAllSessions = true;

constructor(
  @Inject(MAT_DIALOG_DATA) public data: {
    context: Context;
    username: string | null;
    linkedState: LinkedState;
    empNo: string | null;
    extEmpId: string | null;
  },
  public ref: MatDialogRef<LinkUnlinkUserDialog>,  // <-- كانت private
  private svc: UserManagementService,
  private snack: MatSnackBar   
) {}


  async ngOnInit() {
    this.context     = this.data.context;
    this.username    = this.data.username;
    this.linkedState = this.data.linkedState;
    this.empNo       = this.data.empNo;
    this.extEmpId    = this.data.extEmpId;


    if (this.context === 'FROM_USER') {
      this.mode = (this.linkedState === 'LINKED') ? 'UNLINK' : 'LINK_USER_TO_EMP';
    } else {
      this.mode = 'LINK_EMP_TO_USER';
    }

    try {
      this.loading = true;

      if (this.username) {
        this.userMini = await this.svc.getUserWithHistoryByUsernameParam(this.username).toPromise();
      }

      if (this.mode === 'UNLINK') {

        if (this.empNo) {
          this.employeeMini = await this.svc.getEmployeeProfile(this.empNo).toPromise().catch(() => undefined);
        }
      
      }

      if (this.mode === 'LINK_USER_TO_EMP') {

        const resp = await this.svc.listAllPeopleWithoutUser({ unpaged: true }).toPromise();
        this.unlinkedPeople = resp?.content || [];
      }

      if (this.mode === 'LINK_EMP_TO_USER') {

        const resp = await this.svc.listUsersWithHistory({ linkedState: 'UNLINKED', unpaged: true }).toPromise();
        this.unlinkedUsers = resp?.content || [];

        if (this.empNo) {
          this.employeeMini = await this.svc.getEmployeeProfile(this.empNo).toPromise().catch(() => undefined);
        }
       
      }
    } catch (e: any) {
      this.error = 'تعذر جلب البيانات.';
    } finally {
      this.loading = false;
    }
  }

async onChoosePerson(p: any) {
  this.selectedPerson = p;
  this.summaryLoading = true;
  this.summary = { linkType: null };   

  try {
    this.buildUserSummary();           

    if (p?.empNo) {
      this.summary.linkType = 'INTERNAL';
      const e = await this.svc.getEmployeeProfile(p.empNo).toPromise().catch(() => undefined);
      this.employeeMini = e;          
      this.buildEmployeeInternalSummary(e);
    } else if (p?.extEmpId) {
      this.summary.linkType = 'EXTERNAL';
      const x = await this.svc.getExternalEmployeeProfile(p.extEmpId).toPromise().catch(() => undefined);
      this.externalMini = x;
      this.buildEmployeeExternalSummary(x);
    }
  } finally {
    this.summaryLoading = false;
  }
}


async onChooseUser(u: any) {
  this.selectedUser = u;
  this.summaryLoading = true;
  this.summary = { linkType: null };

  try {

    this.userMini = await this.svc.getUserWithHistoryByUsernameParam(u.username).toPromise();
    this.buildUserSummary();

    if (this.empNo) {
      this.summary.linkType = 'INTERNAL';
      const e = await this.svc.getEmployeeProfile(this.empNo).toPromise().catch(() => undefined);
      this.employeeMini = e;
      this.buildEmployeeInternalSummary(e);
    } else if (this.extEmpId) {
      this.summary.linkType = 'EXTERNAL';
      const x = await this.svc.getExternalEmployeeProfile(this.extEmpId).toPromise().catch(() => undefined);
      this.externalMini = x;
      this.buildEmployeeExternalSummary(x);
    }
  } finally {
    this.summaryLoading = false;
  }
}


async confirm() {
  try {
    this.loading = true;

    if (this.mode === 'UNLINK') {
      if (!this.username) return;
      await this.svc.unlinkByUsername({
        username: this.username,
        revokeSessions: this.revokeAllSessions
      }).toPromise();

        const msg = '✅ تم فصل المستخدم عن الموظف بنجاح';

     this.snack.open(msg, 'إغلاق', {
  duration: 3000,
  horizontalPosition: 'center',
  verticalPosition: 'top',
  direction: 'rtl',
  panelClass: ['snack-on-top'], 
});


      this.ref.close({ ok: true, action: 'UNLINK', username: this.username });
      return;
    }

    if (this.mode === 'LINK_USER_TO_EMP') {
      if (!this.username || !this.selectedPerson) return;
      const p = this.selectedPerson;

      if (p.empNo) {
        await this.svc.linkInternalByEmpNoUsername({
          username: this.username, empNo: p.empNo, note: null
        }).toPromise();

        this.snack.open(`✅ تم ربط @${this.username} بالموظف ${p.empNo} (داخلي) بنجاح`, 'إغلاق', {
          duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl',
        });
      } else if (p.extEmpId) {
        await this.svc.linkExternalByExtIdUsername({
          username: this.username, extEmpId: p.extEmpId, note: null
        }).toPromise();

        this.snack.open(`✅ تم ربط @${this.username} بالموظف ${p.extEmpId} (خارجي) بنجاح`, 'إغلاق', {
          duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl',
        });
      }

      this.ref.close({ ok: true, action: 'LINK_USER_TO_EMP', username: this.username });
      return;
    }

    if (this.mode === 'LINK_EMP_TO_USER') {
      if (!this.selectedUser) return;

      if (this.empNo) {
        await this.svc.linkInternalByEmpNoUsername({
          username: this.selectedUser.username, empNo: this.empNo, note: null
        }).toPromise();

        this.snack.open(`✅ تم ربط الموظف ${this.empNo} بالمستخدم @${this.selectedUser.username} (داخلي) بنجاح`, 'إغلاق', {
          duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl',
        });
      } else if (this.extEmpId) {
        await this.svc.linkExternalByExtIdUsername({
          username: this.selectedUser.username, extEmpId: this.extEmpId, note: null
        }).toPromise();

        this.snack.open(`✅ تم ربط الموظف ${this.extEmpId} بالمستخدم @${this.selectedUser.username} (خارجي) بنجاح`, 'إغلاق', {
          duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl',
        });
      }

      this.ref.close({ ok: true, action: 'LINK_EMP_TO_USER', username: this.selectedUser.username });
      return;
    }

  } catch (e: any) {
    this.error = 'تعذر تنفيذ العملية.';
    this.snack.open('⛔ حدث خطأ أثناء التنفيذ', 'إغلاق', {
      duration: 3500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl',
    });
  } finally {
    this.loading = false;
  }
}


  na(v: any){ return v ?? '—'; }
  /* joinRoles(a: string[]){ return (a?.length ? a.join(', ') : '—'); } */

joinRoles(a?: string[] | null): string {
  return (a && a.length) ? a.join(', ') : '—';
}



  formatDate(d: any){ return d ? new Date(d) : null; }


summaryLoading = false;

summary: {
  linkType: 'INTERNAL' | 'EXTERNAL' | null,
  user?: {
    username: string;
    status?: string | null;
    lastLoginAt?: string | null;
    regionCode?: string | null;
    regionDbKey?: string | null;
    roles?: string[] | null;
  },
  employee?: {
    kind: 'INTERNAL' | 'EXTERNAL';
    id: string;               // empNo أو extEmpId
    fullNameAr?: string | null;
    email?: string | null;
    jobTitle?: string | null;
    unitName?: string | null;
    uniteName?: string | null;
    orgName?: string | null;  
    hireDate?: string | null; 
    startDate?: string | null;
    status?: string | null;  
  }
} = { linkType: null };

private buildUserSummary() {
  const u = this.userMini;
  this.summary.user = {
    username: u?.username || this.username || '',
    status: u?.status ?? null,
    lastLoginAt: u?.lastLoginAt ?? null,
    regionCode: u?.regionCode ?? null,
    regionDbKey: u?.regionDbKey ?? null,
    roles: u?.roles ?? null
  };
}

private buildEmployeeInternalSummary(e: any) {
  this.summary.employee = {
    kind: 'INTERNAL',
    id: e?.empNo,
    fullNameAr: e?.fullNameAr,
    email: e?.email,
    jobTitle: e?.jobTitle,
    unitName: e?.subUnite?.name ?? null,
    uniteName: e?.unite?.name ?? null,
    hireDate: e?.hireDate ?? null,
    startDate: e?.startDate ?? null
  };
}

private buildEmployeeExternalSummary(x: any) {
  const d = x?.details ?? {};
  this.summary.employee = {
    kind: 'EXTERNAL',
    id: d?.id,
    fullNameAr: d?.fullNameAr,
    email: d?.email,
    jobTitle: d?.jobTitle,
    orgName: d?.organizationName ?? null,
    startDate: d?.startDate ?? null,
    status: d?.status ?? null,
    unitName: d?.subUnite?.name ?? null,
    uniteName: d?.unite?.name ?? null
  };
}

/* readyToLink(): boolean {
  if (this.mode === 'LINK_USER_TO_EMP')
    return !!(this.summary.user?.username && this.summary.employee?.id);
  if (this.mode === 'LINK_EMP_TO_USER')
    return !!(this.summary.user?.username && this.summary.employee?.id);
  return false;
} */

readyToLink(): boolean {
  if (this.mode === 'LINK_USER_TO_EMP') return !!(this.userMini && this.selectedPerson && !this.summaryLoading);
  if (this.mode === 'LINK_EMP_TO_USER') return !!(this.selectedUser && (this.empNo || this.extEmpId) && !this.summaryLoading);
  return false;
}


}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkUnlinkUserDialog } from './link-unlink-user-dialog';

describe('LinkUnlinkUserDialog', () => {
  let component: LinkUnlinkUserDialog;
  let fixture: ComponentFixture<LinkUnlinkUserDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LinkUnlinkUserDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LinkUnlinkUserDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

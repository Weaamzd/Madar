export interface CreateExternalUserRequest {
  username: string;
  password: string;
  status?: 'Active' | 'Inactive';
  currentRegionId?: number | null;

  extEmpId: string;
  fullNameAr: string;
  fullNameEn?: string | null;
  email?: string | null;
  phone?: string | null;
  organizationName: string;
  jobTitle?: string | null;
  collaborationType: string;      
  startDate: string;              // "YYYY-MM-DD"
  endDate?: string | null;        // "YYYY-MM-DD" أو null
  notes?: string | null;

  managerEmpNo?: string | null;
  subUniteId: number;

  rolesNames: string[];
}

export interface ExternalUserSummaryDto {
  userId: number;
  username: string;

  extEmpId: string;

  fullNameAr: string;
  fullNameEn?: string | null;
  email?: string | null;
  phone?: string | null;
  organizationName?: string | null;
  jobTitle?: string | null;
  collaborationType?: string | null;
  startDate?: string;            // ISO أو "YYYY-MM-DD"
  endDate?: string | null;
  status: string;

  subUniteId: number;
  subUniteName: string;

  regionCode?: string | null;
  regionDbKey?: string | null;

  roles: string[];
}

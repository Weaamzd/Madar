import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTabsModule } from '@angular/material/tabs'; 
import { UserManagementService } from '../../services/user-management/user-management-service';
import { MatProgressSpinner } from "@angular/material/progress-spinner";


export interface SubUniteMiniDto { id: number; code: string; name: string; }
export interface UniteMiniDto    { id: number; code: string; name: string; }

export interface UserMiniDto {
  userId: number;
  username: string;
  status: string;
  lastLoginAt: string | null;   // ISO LocalDateTime
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
}

export interface EmployeeUserDetailsDto {
  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // LocalDate as string
  startDate: string;  // LocalDate as string
  managerNo: string | null;

  subUnite: SubUniteMiniDto | null;
  unite:   UniteMiniDto | null;

  user: UserMiniDto | null;

  roles: string[];
  loggedIn: boolean;
}
export type EmployeeProfileApi = EmployeeUserDetailsDto;


export interface ExternalEmployeeDetailsDto {
  id: string;
  fullNameAr: string;
  fullNameEn: string;
  email: string;
  phone: string;
  organizationName: string;
  jobTitle: string;
  collaborationType: string;
  startDate: string;
  endDate: string;
  status: string;
  notes: string;
  managerEmpNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}
export interface ExternalEmployeeUserProfileDto {
  details: ExternalEmployeeDetailsDto;
  user: UserMiniDto | null;
  roles: string[];
  loggedIn: boolean;
}

type SourceType = 'INTERNAL' | 'EXTERNAL';
type DialogData =
  | { sourceType: 'INTERNAL'; empNo: string }
  | { sourceType: 'EXTERNAL'; extEmpId: string };

@Component({
  selector: 'app-employee-details-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatTableModule,
    MatSelectModule,
    MatPaginatorModule,
    MatCheckboxModule,
    FormsModule,
    MatIconModule,
    MatSortModule,
    MatFormFieldModule,
    MatTabsModule,
    MatProgressSpinner
],
  templateUrl: './employee-details-dialog.html',
  styleUrl: './employee-details-dialog.css'
})
export class EmployeeDetailsDialog implements OnInit {

  loading = true;
  error: string | null = null;

  sourceType!: SourceType;
  internalProfile: EmployeeProfileApi | null = null;
  externalProfile: ExternalEmployeeUserProfileDto | null = null;

  constructor(
    public dialogRef: MatDialogRef<EmployeeDetailsDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private directory: UserManagementService
  ) {}

  ngOnInit(): void {
    if (!this.data || !this.data.sourceType) {
      this.error = 'لم يتم تحديد نوع المصدر.';
      this.loading = false;
      return;
    }

    this.sourceType = this.data.sourceType;

    if (this.sourceType === 'INTERNAL') {
      const empNo = (this.data as { empNo: string }).empNo?.trim();
      if (!empNo) {
        this.error = 'لم يتم تمرير الرقم الوظيفي.';
        this.loading = false;
        return;
      }

      this.directory.getEmployeeProfile(empNo).subscribe({
        next: (res) => { this.internalProfile = res; this.loading = false; },
        error: (err) => { console.error(err); this.error = 'تعذّر جلب بيانات الموظف (داخلي).'; this.loading = false; }
      });

    } else {
      const extEmpId = (this.data as { extEmpId: string }).extEmpId?.trim();
      if (!extEmpId) {
        this.error = 'لم يتم تمرير المعرّف الخارجي.';
        this.loading = false;
        return;
      }

      this.directory.getExternalEmployeeProfile(extEmpId).subscribe({
        next: (res) => { this.externalProfile = res; this.loading = false; },
        error: (err) => { console.error(err); this.error = 'تعذّر جلب بيانات الموظف (خارجي).'; this.loading = false; }
      });
    }
  }


  na(v: unknown): string {
    if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) return '-';
    return String(v);
  }
  joinRoles(roles: string[] | null | undefined): string {
    return roles && roles.length ? roles.join('، ') : '-';
  }
}

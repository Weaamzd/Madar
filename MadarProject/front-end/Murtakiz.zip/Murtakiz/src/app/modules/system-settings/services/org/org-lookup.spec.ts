import { TestBed } from '@angular/core/testing';

import { OrgLookup } from './org-lookup';

describe('OrgLookup', () => {
  let service: OrgLookup;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OrgLookup);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

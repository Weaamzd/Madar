
export interface CreateUser {
  username: string;
  password: string;
  status: 'Active' | 'Inactive';
  currentRegionId: number | null;

  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // YYYY-MM-DD
  startDate: string;  // YYYY-MM-DD
  managerNo: string | null;  
  subUniteId: number;

  rolesNames: string[];
}


export interface LinkInternalByEmpNoUsernameRequest {
  username: string;
  empNo: string;
  note?: string | null;
}

export interface LinkExternalByExtIdUsernameRequest {
  username: string;
  extEmpId: string;
  note?: string | null;
}


export interface UnlinkByUsernameRequest {
  username: string;
  type?: 'INTERNAL' | 'EXTERNAL'; 
  note?: string | null;
  revokeSessions?: boolean;      
}

export interface SubUniteMiniDto {
  id: number;
  code: string;
  name: string;
}

export interface UniteMiniDto {
  id: number;
  code: string;
  name: string;
}

export interface UserMiniDto {
  userId: number;
  username: string;
  status: string;
  lastLoginAt: string | null;   
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
}

export interface ManagerNameDto {
  empNo: string;
  fullNameAr: string;
}


export interface EmployeeUserDetailsDto {

  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // LocalDate → string
  startDate: string;  // LocalDate → string
  managerNo: string | null;

  // Org
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;

  // User
  user: UserMiniDto | null;

  // Roles
  roles: string[];

  loggedIn: boolean;
}



export interface SubUniteMiniDto { id: number; code: string; name: string; }
export interface UniteMiniDto    { id: number; code: string; name: string; }

export interface UserMiniDto {
  userId: number;
  username: string;
  status: string;
  lastLoginAt: string | null;   // ISO LocalDateTime
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
}

export interface EmployeeUserDetailsDto {
  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // LocalDate as string
  startDate: string;  // LocalDate as string
  managerNo: string | null;

  subUnite: SubUniteMiniDto | null;
  unite:   UniteMiniDto | null;

  user: UserMiniDto | null;

  roles: string[];
  loggedIn: boolean;
}


export type EmployeeProfileApi = EmployeeUserDetailsDto;


export interface EmployeeRow {
  id: string;           
  username: string;
  fullNameAr: string;
  empNo: string;
  email: string;
  jobTitle: string;
  department: string;   
  unit: string;         
  regionCode: string;
  status: string;       
  lastLoginAt: string | null;
  loggedIn: boolean;
  roles: string[];     
  hireDate: string;
  startDate: string;
}
export interface UserStatusResult {
  userId: number;
  username: string;
  oldStatus: string;
  newStatus: string;
  revokedSessions: number;  
  changedAt: string;      
}



export interface CreateUserRequest {
  username: string;
  password: string;
  status: 'Active' | 'Inactive';
  currentRegionId: number | null;

  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // YYYY-MM-DD
  startDate: string;  // YYYY-MM-DD
  managerNo: string | null; 
  subUniteId: number;

  rolesNames: string[];

  isManager?: boolean;
  managerScopeType?: 'UNITE' | 'SUB_L1' | 'SUB_L2' | 'SUB_L3' | 'SUB_L4';
  managerTargetId?: number | null; 
}


export interface UserSummaryDto {
  userId: number;
  username: string;
  empNo: string;
  fullName: string;
  email: string;
  jobTitle: string;
  status: 'Active' | 'Inactive';
  regionCode?: string | null;
  regionDbKey?: string | null;
  lastLoginAt: string | null;

  subUniteId: number;
  subUniteCode: string;
  subUniteName: string;

  roles: string[];
}


export interface UserEmployeePrecheckDto {
  userExists: boolean;
  employeeExists: boolean;

  empNo?: string | null;
  username?: string | null;

  fullNameAr?: string | null;
  email?: string | null;
  jobTitle?: string | null;
  hireDate?: string | null;       // LocalDate -> string
  startDate?: string | null;      // LocalDate -> string
  managerNo?: string | null;

  subUniteId?: number | null;
  subUniteCode?: string | null;
  subUniteName?: string | null;
  uniteId?: number | null;
  uniteCode?: string | null;
  uniteName?: string | null;

  userId?: number | null;
  status?: string | null;
  lastLoginAt?: string | null;    
  currentRegionId?: number | null;
  regionCode?: string | null;
  regionDbKey?: string | null;
  roles?: string[] | null;
}


export interface EmployeeForUserCreationDto {
  empNo: string;
  fullNameAr?: string | null;
  email?: string | null;
  jobTitle?: string | null;
  hireDate?: string | null;   // "YYYY-MM-DD"
  startDate?: string | null;  // "YYYY-MM-DD"
  managerNo?: string | null;

  subUniteId?: number | null;
  subUniteCode?: string | null;
  subUniteName?: string | null;

  uniteId?: number | null;
  uniteCode?: string | null;
  uniteName?: string | null;
}

export interface CreateUserForExistingEmployeeRequest {
  username: string;
  password: string;

 
  status?: 'Active' | 'Inactive';
  currentRegionId?: number | null;

  empNo: string;

  rolesNames: string[];
}





export interface ExternalEmployeeDetailsDto {
  id: string;
  fullNameAr: string;
  fullNameEn: string;
  email: string;
  phone: string;
  organizationName: string;
  jobTitle: string;
  collaborationType: string;
  startDate: string; // LocalDate -> string "YYYY-MM-DD"
  endDate: string;   // LocalDate -> string "YYYY-MM-DD"
  status: string;
  notes: string;
  managerEmpNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}

export interface ExternalEmployeeUserProfileDto {
  details: ExternalEmployeeDetailsDto;
  user: UserMiniDto | null;
  roles: string[];
  loggedIn: boolean;
}


export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  page: number | null;
  size: number | null;
  last: boolean;
}


export interface UserLinkEventDto {
  linkType: 'INTERNAL' | 'EXTERNAL';
  empNo?: string | null;
  extEmpId?: string | null;
  linkedAt: string;     // ISO LocalDateTime
  unlinkedAt?: string | null;
  actionNote?: string | null;
  actorEmpNo?: string | null;
}

export interface UserWithHistoryDto {
  userId: number;
  username: string;
  status: 'Active' | 'Inactive' | 'Suspended';
  lastLoginAt: string | null;

  empNo: string | null;
  empFullNameAr: string | null;
  externalEmpId: string | null;
  externalFullNameAr: string | null;

  email: string | null;
  jobTitle: string | null;

  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;

  roles: string[];
  loggedIn: boolean;

  linkHistory: UserLinkEventDto[];
}


export type PersonSourceType = 'INTERNAL' | 'EXTERNAL';

export interface UnifiedPersonDetailsDto {
  sourceType: PersonSourceType;

  empNo: string | null;
  extEmpId: string | null;

  fullNameAr: string;
  fullNameEn?: string | null;
  email?: string | null;
  phone?: string | null;
  jobTitle?: string | null;

  hireDate?: string | null;
  startDate?: string | null;
  managerNo?: string | null;         
  hasUser: boolean;                   

  organizationName?: string | null;
  collaborationType?: string | null;
  externalStartDate?: string | null;
  externalEndDate?: string | null;
  externalStatus?: string | null;

  subUnite: { id: number; code: string; name: string } | null;
  unite:    { id: number; code: string; name: string } | null;

  user: {
    userId: number;
    username: string;
    status: string;
    lastLoginAt: string | null;
    currentRegionId: number | null;
    regionCode: string | null;
    regionDbKey: string | null;
  } | null;

  regionCode: string | null;
  regionDbKey: string | null;
  roles: string[];
  loggedIn: boolean;
}



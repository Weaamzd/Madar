import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';


export interface TimelineStage {
  key: RegistrationRow['currentStage'];
  label: string;
  state: 'done' | 'current' | 'pending';
}

const STAGE_ORDER: RegistrationRow['currentStage'][] = [
  'ADMIN_REVIEW',
  'SECURITY_REVIEW',
  'USER_TERMS',
];


export interface RegistrationRow {
  id: number;
  createdAt: string;
  currentStage: 'ADMIN_REVIEW' | 'SECURITY_REVIEW' | 'USER_TERMS';
  stageStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  employeeType: 'INTERNAL' | 'EXTERNAL';
  username: string;
  empNo: string;
  fullNameAr: string;
  regionName: string;
  uniteName: string;
  subUniteName: string;

  waitingForEmpNo?: string | null;
  userStatus?: 'Active' | 'Inactive' | 'Suspended' | string;

  regionId?: number;
  uniteId?: number;
  subUniteId?: number;
}


@Component({
  selector: 'app-details-of-account-creation-requests',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatDividerModule,
    MatTooltipModule,
  ],
  templateUrl: './details-of-account-creation-requests.html',
  styleUrl: './details-of-account-creation-requests.css',
})
export class DetailsOfAccountCreationRequests {

  stages: TimelineStage[] = [];

constructor(
  public dialogRef: MatDialogRef<DetailsOfAccountCreationRequests>,
  @Inject(MAT_DIALOG_DATA) public data: { row: RegistrationRow },
) {
  this.buildTimeline();
}

get row(): RegistrationRow {
  return this.data.row;
}


private buildTimeline(): void {
  const stage = this.row.currentStage;
  const status = this.row.stageStatus; // PENDING / APPROVED / REJECTED

  this.stages = STAGE_ORDER.map((key): TimelineStage => {
    let state: 'done' | 'current' | 'pending' = 'pending';

    switch (stage) {


      case 'ADMIN_REVIEW': {
        if (status === 'PENDING') {

          if (key === 'ADMIN_REVIEW') state = 'current';
          else state = 'pending';
        } else {

          if (key === 'ADMIN_REVIEW') state = 'done';
          else state = 'pending';
        }
        break;
      }

      case 'SECURITY_REVIEW': {
        if (status === 'PENDING') {

          if (key === 'ADMIN_REVIEW') state = 'done';
          else if (key === 'SECURITY_REVIEW') state = 'current';
          else state = 'pending';
        } else {
          if (key === 'ADMIN_REVIEW' || key === 'SECURITY_REVIEW') {
            state = 'done';
          } else {
            state = 'pending';
          }
        }
        break;
      }

      case 'USER_TERMS': {
        if (status === 'PENDING') {

          if (key === 'ADMIN_REVIEW' || key === 'SECURITY_REVIEW') {
            state = 'done';
          } else if (key === 'USER_TERMS') {
            state = 'current';
          }
        } else {

          state = 'done'; 
        }
        break;
      }


      default: {
        if (key === stage) state = 'current';
        else state = 'pending';
      }
    }

    return {
      key,
      label: this.getStageLabelByKey(key),
      state,
    };
  });
}



private getStageLabelByKey(stage: RegistrationRow['currentStage']): string {
  switch (stage) {
    case 'ADMIN_REVIEW':    return 'مراجعة الإدارة';
    case 'SECURITY_REVIEW': return 'مراجعة أمنية';
    case 'USER_TERMS':      return 'انتظار موافقة المستخدم';
    default:                return stage;
  }
}


  na(v: unknown): string {
    if (v === null || v === undefined) return '—';
    if (typeof v === 'string' && v.trim() === '') return '—';
    return String(v);
  }

  getStageChipClass(): string {
    const s = (this.row.stageStatus || '').toLowerCase();
    if (s === 'pending')  return 'chip-pending';
    if (s === 'approved') return 'chip-success';
    if (s === 'rejected') return 'chip-danger';
    return 'chip-muted';
  }

  getEmployeeTypeLabel(): string {
    return this.row.employeeType === 'INTERNAL' ? 'داخلي' : 'خارجي';
  }

getStageLabel(): string {
  return this.getStageLabelByKey(this.row.currentStage);
}

getStatusLabel(): string {

  if (this.row.currentStage === 'USER_TERMS' && this.row.stageStatus === 'PENDING') {
    return 'بانتظار موافقة المستخدم';
  }

  switch (this.row.stageStatus) {
    case 'PENDING':  return 'قيد المعالجة';
    case 'APPROVED': return 'مُعتمد';
    case 'REJECTED': return 'مرفوض';
    default:         return this.row.stageStatus;
  }
}


}

import { Component, ViewChild, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { firstValueFrom, take } from 'rxjs';

import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, MatPaginatorIntl, PageEvent } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatBadgeModule } from '@angular/material/badge';
import { MatSelectModule } from '@angular/material/select';
import { NgSelectModule } from '@ng-select/ng-select';

import { UserManagementService } from '../../services/user-management/user-management-service';
import { PersonRow, UnifiedPersonApi, PageResponse, LoginFilter, StatusFilter } from '../../models/people-directory.models';

import { EmployeeDetailsDialog } from '../../dialog/employee-details-dialog/employee-details-dialog';
import { ModifyuserstatusDialog } from '../../dialog/modifyuserstatus-dialog/modifyuserstatus-dialog';
import { ModifyuserpermissionDialog } from '../../dialog/modifyuserpermission-dialog/modifyuserpermission-dialog';
import { UnifiedPersonDetailsDto, UserWithHistoryDto } from '../../models/employee-directory.models';
import { UserDetailsDialog } from '../../dialog/user-details-dialog/user-details-dialog';
import { DelegationFullDetailsDto, DelegationRow, DelegationStatus } from '../../../delegation/models/delegations.models';
import { Delegations } from '../../../delegation/services/delegations';
import { DelegationDetailsDialog } from '../../../delegation/dialog/delegation-details-dialog/delegation-details-dialog';
import { LinkUnlinkUserDialog } from '../../dialog/link-unlink-user-dialog/link-unlink-user-dialog';
import { AuthService } from '../../../../core/auth/authService';
import { DetailsOfAccountCreationRequests } from '../../dialog/details-of-account-creation-requests/details-of-account-creation-requests';
import { TakeActionOnAccountRequest } from '../../dialog/take-action-on-account-request/take-action-on-account-request';


export interface UserHistoryRow {
  id: string;
  username: string;
  status: 'Active' | 'Inactive' | 'Suspended' | string;
  linkedState: 'LINKED' | 'UNLINKED';
  isExternal: boolean;
  empNo?: string;
  externalEmpId?: string;
  fullNameAr?: string;
  jobTitle?: string;
  regionCode?: string;
  lastLoginAt: string | null;
  loggedIn: boolean;
  roles: string[];
}


export interface UnlinkedRow {
  isExternal: boolean;
  empNo?: string;
  extEmpId?: string;
  fullNameAr: string;
  jobTitle?: string;
  department?: string;
  unit?: string;
  email?: string;
  managerNo?: string | null;
  hireDate?: string | null;
  startDate?: string | null;
}


export interface RegistrationRow {
  id: number;
  parentRequestId?: number | null;  

  createdAt: string;
  currentStage: 'ADMIN_REVIEW' | 'SECURITY_REVIEW' | 'USER_TERMS';
  stageStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  employeeType: 'INTERNAL' | 'EXTERNAL';

  username: string;
  empNo: string;
  fullNameAr: string;
  regionName: string;
  uniteName: string;
  subUniteName: string;


  waitingForEmpNo?: string | null;
  userStatus?: 'Active' | 'Inactive' | 'Suspended' | string;
  regionId?: number;
  uniteId?: number;
  subUniteId?: number;
}


interface UserRegistrationRequestSummaryDto {
  id: number;

  parentRequestId?: number | null;
  parentId?: number | null;

  createdAt: string;
  currentStage: 'ADMIN_REVIEW' | 'SECURITY_REVIEW' | 'USER_TERMS';
  stageStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  employeeType: 'INTERNAL' | 'EXTERNAL';

  username: string;
  empNo: string;
  fullNameAr: string;
  regionName: string;
  uniteName: string;
  subUniteName: string;

  waitingForEmpNo?: string | null;
  userStatus?: 'Active' | 'Inactive' | 'Suspended' | string;
  regionId?: number;
  uniteId?: number;
  subUniteId?: number;
}



@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatTableModule, MatPaginatorModule, MatSortModule,
    MatCheckboxModule, MatFormFieldModule, MatInputModule,
    MatIconModule, MatButtonModule, MatProgressSpinnerModule,
    MatTooltipModule, MatBadgeModule, MatSelectModule,
    MatDialogModule, NgSelectModule, RouterModule,
  ],
  templateUrl: './user-management.html',
  styleUrls: ['./user-management.css']
})
export class UserManagement {

  loading = signal(false);
  errorMsg = signal<string | null>(null);

  dataSource = new MatTableDataSource<PersonRow>([]);
  linkedState?: 'LINKED' | 'UNLINKED';

  statusFilter: StatusFilter = 'any';
  loginFilter: LoginFilter = 'any';

  statusFilterOptions: { label: string; value: StatusFilter }[] = [
    { label: 'الكل', value: 'any' },
    { label: 'نشط', value: 'active' },
    { label: 'غير نشط', value: 'inactive' },
    { label: 'موقوف', value: 'suspended' },
  ];

  loginFilterOptions: { label: string; value: LoginFilter }[] = [
    { label: 'الكل', value: 'any' },
    { label: 'متصل الآن', value: 'online' },
    { label: 'غير متصل', value: 'offline' },
  ];

  allColumns = [
    { name: 'username', label: 'اسم المستخدم', visible: true },
    { name: 'fullNameAr', label: 'اسم الموظف', visible: true },
    { name: 'idSmart', label: 'رقم الموظف', visible: true },
    { name: 'jobTitle', label: 'المسمى الوظيفي', visible: true },
    { name: 'department', label: 'الإدارة', visible: true },
    { name: 'unit', label: 'الوحدة', visible: true },
    { name: 'isExternal', label: 'خارجي؟', visible: true },
    { name: 'status', label: 'الحالة', visible: true },
    { name: 'loggedIn', label: 'متصل الآن', visible: true },
    { name: 'lastLoginAt', label: 'آخر دخول', visible: true },
    { name: 'actions', label: 'الإجراء', visible: true },
  ];
  get displayedColumns(): string[] {
    return ['select', ...this.allColumns.filter(c => c.visible).map(c => c.name)];
  }

  readonly sortOptions = [
    { label: 'الأحدث تسجيل دخول', value: 'lastLoginDesc' },
    { label: 'الأقدم تسجيل دخول', value: 'lastLoginAsc' },
    { label: 'اسم المستخدم (أ-ي)', value: 'userAsc' },
    { label: 'اسم المستخدم (ي-أ)', value: 'userDesc' },
    { label: 'اسم الموظف (أ-ي)', value: 'nameAsc' },
    { label: 'اسم الموظف (ي-أ)', value: 'nameDesc' },
  ] as const;
  selectedSort = 'lastLoginDesc';

  searchActive = false;
  searchText = '';

  selection = new Set<string>();

  totalElements = 0;
  pageIndex = 0;
  pageSize = 10;

  selectedUniteId: number | null = null;
  selectedSubUniteId: number | null = null;
  isScopeEnforced = false;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    private svc: UserManagementService,
    paginatorIntl: MatPaginatorIntl,
    private dialog: MatDialog,
    private router: Router,
    private delegSvc: Delegations,
    private auth: AuthService,
  ) {
  
    paginatorIntl.itemsPerPageLabel = 'عدد العناصر في الصفحة:';
    paginatorIntl.nextPageLabel = 'الصفحة التالية';
    paginatorIntl.previousPageLabel = 'الصفحة السابقة';
    paginatorIntl.firstPageLabel = 'الأولى';
    paginatorIntl.lastPageLabel = 'الأخيرة';
    paginatorIntl.getRangeLabel = (page, pageSize, length) => {
      if (length === 0 || pageSize === 0) return '0 من 0';
      const startIndex = page * pageSize;
      const endIndex = Math.min(startIndex + pageSize, length);
      return `${startIndex + 1}–${endIndex} من ${length}`;
    };
    paginatorIntl.changes.next();

    this.dataSource.filterPredicate = (row, filter) => {
      const f = (filter || '').trim().toLowerCase();
      if (!f) return true;
      const haystack = [
        row.username,
        row.fullNameAr,
        row.empNo,
        row.extEmpId,
        row.jobTitle,
        row.department,
        row.unit,
        row.email,
        row.regionCode,
        row.status,
        row.isExternal ? 'external خارجي' : 'internal داخلي',
        ...(row.roles || [])
      ].filter(Boolean).join(' | ').toLowerCase();
      return haystack.includes(f);
    };


    this.dataSource.sortingDataAccessor = (row: PersonRow, colId: string) => {
      switch (colId) {
        case 'idSmart':
          return (row.isExternal ? (row.extEmpId || '') : (row.empNo || '')).toLowerCase();
        case 'username': return (row.username || '').toLowerCase();
        case 'fullNameAr': return (row.fullNameAr || '').toLowerCase();
        case 'department': return (row.department || '').toLowerCase();
        case 'unit': return (row.unit || '').toLowerCase();
        case 'status': return (row.status || '').toLowerCase();
        case 'isExternal': return row.isExternal ? 1 : 0;
        case 'loggedIn': return row.loggedIn ? 1 : 0;
        case 'lastLoginAt': return row.lastLoginAt ? new Date(row.lastLoginAt).getTime() : 0;
        default: return (row as any)[colId] ?? '';
      }
    };
  }

  ngOnInit(): void {
    this.isScopeEnforced = this.auth.hasAnyRole('SUB_ADMIN');

    if (!this.isScopeEnforced) {
      this.fetchAllPeople();
      if (typeof this.fetchUsersHistory === 'function') this.fetchUsersHistory();
      if (typeof this.fetchUnlinkedPeople === 'function') this.fetchUnlinkedPeople();
      if (typeof this.fetchRegistrationRequests === 'function') this.fetchRegistrationRequests();
      return;
    }

    this.auth.ensureMe().pipe(take(1)).subscribe({
      next: (me) => {
        const emp = me?.empNo ?? null;
        if (!emp) { this.fetchAllPeople(); return; }

        this.svc.getOrgByEmpNo(emp).pipe(take(1)).subscribe({
          next: (org) => {
            const uId = (org as any)?.uniteId ?? (org as any)?.unite?.id ?? null;
            const sId = (org as any)?.subUniteId ?? (org as any)?.subUnite?.id ?? null;
            const uName = (org as any)?.unite?.name ?? (org as any)?.uniteName ?? null;
            this.selectedUniteId = uId;
            this.selectedSubUniteId = sId;
            this.selectedUniteName = uName;

            this.fetchAllPeople();
            if (typeof this.fetchUsersHistory === 'function') this.fetchUsersHistory();
            if (typeof this.fetchUnlinkedPeople === 'function') this.fetchUnlinkedPeople();
            if (this.tab === 'delegations') this.fetchDelegations();
            if (this.tab === 'registrations') this.fetchRegistrationRequests();
          },
          error: () => this.fetchAllPeople()
        });
      },
      error: () => this.fetchAllPeople()
    });
  }

  chooseId(row: PersonRow): string | undefined {
    return row.isExternal ? (row.extEmpId || row.empNo) : (row.empNo || row.extEmpId);
  }
  buildIdTooltip(row: PersonRow): string {
    const emp = row.empNo ? `رقم الموظف: ${row.empNo}` : null;
    const ext = row.extEmpId ? `المعرّف الخارجي: ${row.extEmpId}` : null;
    return [emp, ext].filter(Boolean).join(' — ') || 'لا توجد بيانات معرّف';
  }

  private load() {
    this.loading.set(true);
    this.errorMsg.set(null);

    const params = this.buildQueryParams();
    this.svc.listAllPeopleProfiles(params).subscribe({
      next: (page: PageResponse<UnifiedPersonApi>) => {
        const rows = (page.content || []).map(this.mapApiToRow);
        this.dataSource.data = rows;
        this.totalElements = page.totalElements ?? rows.length;
        this.pageIndex = page.page ?? 0;
        this.pageSize = page.size ?? this.pageSize;
        this.applySortByKey(this.selectedSort);
      },
      error: () => this.errorMsg.set('تعذر تحميل البيانات. تأكد من خدمة الـ API.'),
      complete: () => this.loading.set(false),
    });
  }

  private buildQueryParams() {
    const raw = (this.searchText || '').trim();
    if (!raw) {
      return {
        empNo: null, fullNameAr: null, username: null,
        uniteName: null, subUniteName: null,
        userStatus: null as (string | null),
        loggedIn: null as (boolean | null),
        page: this.pageIndex, size: this.pageSize, sort: this.selectedSort
      };
    }

    const m = raw.match(/^(user|u|emp|id|name|n|unit|uunit|dept|sub|su|section)\s*:\s*(.+)$/i);
    if (m) {
      const key = m[1].toLowerCase();
      const val = m[2].trim();
      return {
        empNo: (key === 'emp' || key === 'id') ? val : null,
        username: (key === 'user' || key === 'u') ? val : null,
        fullNameAr: (key === 'name' || key === 'n') ? val : null,
        uniteName: (key === 'unit' || key === 'uunit' || key === 'dept') ? val : null,
        subUniteName: (key === 'sub' || key === 'su' || key === 'section') ? val : null,
        userStatus: null as (string | null),
        loggedIn: null as (boolean | null),
        page: this.pageIndex, size: this.pageSize, sort: this.selectedSort
      };
    }

    const onlyDigits = /^\d+$/.test(raw);
    const hasArabic = /[\u0600-\u06FF]/.test(raw);
    const looksUser = /^[a-zA-Z][\w.\-@]*$/.test(raw);
    const empLike = /^(?:E|EMP|EM|X|EXT)?\d+$/i.test(raw);
    const looksSubUnit = hasArabic && /(شعبة|وحدة|مكتب|قسم|مستودع|ورشة)/.test(raw);
    const looksUnit = hasArabic && /(قسم|إدارة|الادارة|ادارة)/.test(raw);

    let params: any = { empNo: null, fullNameAr: null, username: null, uniteName: null, subUniteName: null };
    if (onlyDigits || empLike) params.empNo = raw;
    else if (looksSubUnit) params.subUniteName = raw;
    else if (looksUnit) params.uniteName = raw;
    else if (hasArabic) params.fullNameAr = raw;
    else if (looksUser) params.username = raw;
    else params.username = raw;

    return {
      ...params,
      userStatus: null as (string | null),
      loggedIn: null as (boolean | null),
      page: this.pageIndex, size: this.pageSize, sort: this.selectedSort
    };
  }

  applyFilter(evt: Event) {
    const v = (evt.target as HTMLInputElement).value?.trim() ?? '';
    this.searchText = v;
    this.pageIndex = 0;
    this.fetchAllPeople();
  }
  onFocus(f: boolean) { this.searchActive = f || !!this.searchText?.trim(); }

  onPage(e: PageEvent) {
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.fetchAllPeople();
  }
  sortChanged(key: string) {
    this.selectedSort = key;
    this.fetchAllPeople();
  }

  private applySortByKey(key: string) {
    const ds = [...this.dataSource.data];
    switch (key) {
      case 'lastLoginDesc':
        ds.sort((a, b) =>
          (b.lastLoginAt ? +new Date(b.lastLoginAt) : 0) -
          (a.lastLoginAt ? +new Date(a.lastLoginAt) : 0)
        );
        break;
      case 'lastLoginAsc':
        ds.sort((a, b) =>
          (a.lastLoginAt ? +new Date(a.lastLoginAt) : 0) -
          (b.lastLoginAt ? +new Date(b.lastLoginAt) : 0)
        );
        break;
      case 'userAsc':
        ds.sort((a, b) => (a.username || '').localeCompare(b.username || '', 'ar'));
        break;
      case 'userDesc':
        ds.sort((a, b) => (b.username || '').localeCompare(a.username || '', 'ar'));
        break;
      case 'nameAsc':
        ds.sort((a, b) => (a.fullNameAr || '').localeCompare(b.fullNameAr || '', 'ar'));
        break;
      case 'nameDesc':
        ds.sort((a, b) => (b.fullNameAr || '').localeCompare(a.fullNameAr || '', 'ar'));
        break;
    }
    this.dataSource.data = ds;
  }

  private mapApiToRow = (api: UnifiedPersonApi): PersonRow => {
    const isLinked = !!(api.user?.id && (api.empNo || api.extEmpId));
    const rawStatus = api.user?.status ?? '';
    const norm = (rawStatus || '').trim().toLowerCase();
    const status =
      norm === 'active' ? 'Active' :
        norm === 'inactive' ? 'Inactive' :
          norm === 'suspended' ? 'Suspended' :
            (rawStatus ? rawStatus.trim() : undefined);

    return {
      id: String(api.user?.id ?? api.empNo ?? api.extEmpId ?? Math.random()),
      username: api.user?.username || '',
      isExternal: api.sourceType === 'EXTERNAL',
      fullNameAr: api.fullNameAr || '',
      empNo: api.empNo || undefined,
      extEmpId: api.extEmpId || undefined,
      email: api.email || '',
      jobTitle: api.jobTitle || '',
      department: api.unite?.name || '',
      unit: api.subUnite?.name || '',
      regionCode: api.regionCode || '',
      status,
      lastLoginAt: api.user?.lastLoginAt || null,
      loggedIn: !!api.loggedIn,
      roles: api.roles || [],
      hireDate: api.hireDate || api.externalStartDate || null,
      startDate: api.startDate || null,
      linkedState: isLinked ? 'LINKED' : 'UNLINKED',
    };
  };

  isSelected(row: PersonRow): boolean { return this.selection.has(row.id); }
  toggleSelection(row: PersonRow) {
    this.isSelected(row) ? this.selection.delete(row.id) : this.selection.add(row.id);
  }
  toggleAllRows(event: any) {
    if (event?.checked) this.dataSource.data.forEach(r => this.selection.add(r.id));
    else this.selection.clear();
  }
  isAllSelected(): boolean {
    const ds = this.dataSource.data;
    return !!ds.length && this.selection.size === ds.length;
  }

  getStatusBadgeClass(status?: string): string {
    const s = (status || '').trim().toLowerCase();
    if (s === 'active') return 'status-done';
    if (s === 'inactive') return 'status-rejected';
    if (s === 'suspended') return 'status-pending';
    return 'status-pending';
  }

  onView(row: PersonRow) {
    if (row.isExternal) {
      if (!row.extEmpId) { alert('لا يوجد معرّف خارجي (extEmpId).'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'EXTERNAL', extEmpId: row.extEmpId }
      });
    } else {
      if (!row.empNo) { alert('لا يوجد رقم وظيفي (empNo).'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'INTERNAL', empNo: row.empNo }
      });
    }
  }

  openModifyStatusDialog(row: PersonRow) {
    if (!row.username) { alert('لا يوجد حساب مستخدم مرتبط.'); return; }
    this.dialog.open(ModifyuserstatusDialog, {
      direction: 'rtl',
      width: '990px',
      maxWidth: '95vw',
      panelClass: 'custom-dialog-container',
      data: {
        empNo: row.empNo,
        extEmpId: row.extEmpId,
        fullName: row.fullNameAr,
        username: row.username,
        currentStatus: this.normalizeStatus(row.status)
      },
    }).afterClosed().subscribe(result => {
      if (result) {
        row.status = result.newStatus;
        this.dataSource.data = [...this.dataSource.data];
      }
    });
  }

  openModifyPermissionDialog(row: PersonRow) {
    if (!row.username) { alert('لا يوجد حساب مستخدم مرتبط.'); return; }
    this.dialog.open(ModifyuserpermissionDialog, {
      direction: 'rtl',
      width: '990px',
      maxWidth: '95vw',
      panelClass: 'custom-dialog-container',
      data: {
        empNo: row.empNo,
        extEmpId: row.extEmpId,
        fullName: row.fullNameAr,
        username: row.username,
        currentRoles: row.roles ?? []
      },
    }).afterClosed().subscribe(result => {
      if (result?.updatedRoles) {
        row.roles = result.updatedRoles;
        this.dataSource.data = [...this.dataSource.data];
      }
    });
  }

  private normalizeStatus(s?: string): 'Active' | 'Inactive' | undefined {
    const v = (s || '').trim().toLowerCase();
    if (v === 'active' || v === 'نشط') return 'Active';
    if (v === 'inactive' || v === 'غير نشط') return 'Inactive';
    return undefined;
  }

  goToCreateAccount() {
    const roles = JSON.parse(localStorage.getItem('roles') || '[]');
    if (roles.includes('DEPARTMENT_MANAGER') || roles.includes('EMPLOYEE')) {
      this.router.navigate(['/SystemSettings/request-create-account']);
    } else {
      alert('ليس لديك صلاحية للدخول إلى هذه الصفحة');
    }
  }

  private classifyQuery(raw: string) {
    const base = { empNo: null, fullNameAr: null, username: null, uniteName: null, subUniteName: null };
    const onlyDigits = /^\d+$/.test(raw);
    const hasArabic = /[\u0600-\u06FF]/.test(raw);
    const looksUser = /^[a-zA-Z][\w.\-@]*$/.test(raw);
    const empLike = /^(?:E|EMP|EM|X|EXT)?\d+$/i.test(raw);
    const kwSub = /(شعبة|وحدة|مكتب|مستودع|ورشة)/;
    const kwUnit = /(قسم|إدارة|الادارة|ادارة|عمادة|مركز|قطاع|مديرية)/;

    const m = raw.match(/^(user|u|emp|id|name|n|unit|uunit|dept|sub|su|section)\s*:\s*(.+)$/i);
    if (m) {
      const key = m[1].toLowerCase();
      const val = m[2].trim();
      return {
        primary: {
          ...base,
          empNo: (key === 'emp' || key === 'id') ? val : null,
          username: (key === 'user' || key === 'u') ? val : null,
          fullNameAr: (key === 'name' || key === 'n') ? val : null,
          uniteName: (key === 'unit' || key === 'uunit' || key === 'dept') ? val : null,
          subUniteName: (key === 'sub' || key === 'su' || key === 'section') ? val : null,
        },
        fallbacks: []
      };
    }

    if (onlyDigits || empLike) return { primary: { ...base, empNo: raw }, fallbacks: [] };
    if (hasArabic && kwSub.test(raw)) return { primary: { ...base, subUniteName: raw }, fallbacks: [] };
    if (hasArabic && kwUnit.test(raw)) return { primary: { ...base, uniteName: raw }, fallbacks: [] };
    if (hasArabic) return { primary: { ...base, fullNameAr: raw }, fallbacks: [{ ...base, uniteName: raw }, { ...base, subUniteName: raw }] };
    if (looksUser) return { primary: { ...base, username: raw }, fallbacks: [] };
    return { primary: { ...base, username: raw }, fallbacks: [] };
  }

  onStatusFilterChange(v: typeof this.statusFilter) {
    this.statusFilter = v;
    this.pageIndex = 0;
    this.fetchAllPeople();
  }
  onLoginFilterChange(v: typeof this.loginFilter) {
    this.loginFilter = v;
    this.pageIndex = 0;
    this.fetchAllPeople();
  }

  private callSearch(primaryParams: any, fallbacks: any[]) {
    const withCommon = (p: any) => ({
      ...p,
      userStatus: this.statusFilter === 'any' ? null : this.statusFilter,
      loggedIn: this.loginFilter === 'any' ? null : (this.loginFilter === 'online'),
      page: this.pageIndex,
      size: this.pageSize,
      sort: this.selectedSort,
    });

    const tryOnce = (p: any): Promise<PageResponse<UnifiedPersonApi>> => {
      const basePayload = withCommon(p);
      const scoped = this.isScopeEnforced && (this.selectedUniteId != null || this.selectedSubUniteId != null);

      if (scoped) {
        const callUniteId = this.selectedUniteId ?? (this.selectedSubUniteId ? 0 : null);
        const callSubUniteId = this.selectedSubUniteId ?? (this.selectedUniteId ? 0 : null);
        const scopedPayload = { ...basePayload, uniteId: callUniteId, subUniteId: callSubUniteId };
        return firstValueFrom(this.svc.listAllPeopleByScope(scopedPayload) as any);
      }
      return firstValueFrom(this.svc.listAllPeopleProfiles(basePayload));
    };

    const run = async () => {
      try {
        let page = await tryOnce(primaryParams);
        if ((page?.totalElements ?? 0) === 0 && fallbacks.length) {
          for (const fb of fallbacks) {
            const alt = await tryOnce(fb);
            if ((alt?.totalElements ?? 0) > 0) { page = alt; break; }
          }
        }
        const rows = (page.content || []).map(this.mapApiToRow);
        this.dataSource.data = rows;
        this.totalElements = page.totalElements ?? rows.length;
        this.pageIndex = page.page ?? 0;
        this.pageSize = page.size ?? this.pageSize;
        this.applySortByKey(this.selectedSort);
        this.errorMsg.set(null);
      } catch {
        this.errorMsg.set('تعذر تحميل البيانات. تأكد من خدمة الـ API.');
      } finally {
        this.loading.set(false);
      }
    };

    this.loading.set(true);
    this.errorMsg.set(null);
    run();
  }

  public fetchAllPeople() {
    const raw = (this.searchText || '').trim();
    if (!raw) {
      this.callSearch({ empNo: null, fullNameAr: null, username: null, uniteName: null, subUniteName: null }, []);
      return;
    }
    const { primary, fallbacks } = this.classifyQuery(raw);
    this.callSearch(primary, fallbacks);
  }


  tab: 'users' | 'usersHistory' | 'unlinked' | 'delegations' | 'registrations' | 'stats' | 'logs' = 'users';

  setTab(t: 'users' | 'usersHistory' | 'unlinked' | 'delegations' | 'registrations' | 'stats' | 'logs') {
    this.tab = t;
    if (t === 'usersHistory' && (!this.dataSourceHist.data || this.dataSourceHist.data.length === 0)) {
      this.fetchUsersHistory();
    }
    if (t === 'unlinked' && (!this.dataSourceUnlinked.data || this.dataSourceUnlinked.data.length === 0)) {
      this.fetchUnlinkedPeople();
    }
    if (t === 'delegations' && (!this._delegAllRows || this._delegAllRows.length === 0)) {
      this.fetchDelegations();
    }
    if (t === 'registrations' && (!this.dataSourceReg.data || this.dataSourceReg.data.length === 0)) {
      this.fetchRegistrationRequests();
    }
  }


  selectedUniteName: string | null = null;
  get isSuperAdmin() { return this.auth.hasAnyRole('SUPER_ADMIN'); }
  get isSubAdmin() { return this.auth.hasAnyRole('SUB_ADMIN'); }

  get roleDisplay(): string {
    return this.isSuperAdmin ? 'سوبر أدمن'
      : this.isSubAdmin ? 'صب-أدمن'
        : 'مستخدم';
  }
  get mainUnitDisplay(): string {
    if (this.isSuperAdmin) return 'كل الوحدات';
    return this.selectedUniteName || '—';
  }

  get totalUsers(): number {
    return (this as any).totalElements ?? (this.dataSource?.data?.length || 0);
  }
  get activeUsers(): number {
    return (this.dataSource?.data || []).filter(u => u.status === 'Active' || u.status === 'نشط').length;
  }
  get loggedInUsers(): number {
    return (this.dataSource?.data || []).filter(u => !!u.loggedIn).length;
  }

  private isScopeReady(): boolean {
    return this.isScopeEnforced && (this.selectedUniteId != null || this.selectedSubUniteId != null);
  }

  dataSourceHist = new MatTableDataSource<UserHistoryRow>([]);
  @ViewChild('paginatorHist') paginatorHist!: MatPaginator;
  @ViewChild('sortHist') sortHist!: MatSort;

  totalElementsHist = 0;
  pageIndexHist = 0;
  pageSizeHist = 10;
  searchTextHist = '';
  selectedSortHist = 'lastLoginDesc';

  statusFilterHist: 'any' | 'active' | 'inactive' | 'suspended' = 'any';
  loginFilterHist: 'any' | 'online' | 'offline' = 'any';
  linkedFilterHist: 'ALL' | 'LINKED' | 'UNLINKED' = 'ALL';

  statusFilterOptionsHist = [
    { label: 'الكل', value: 'any' },
    { label: 'نشط', value: 'active' },
    { label: 'غير نشط', value: 'inactive' },
    { label: 'موقوف', value: 'suspended' },
  ];

  loginFilterOptionsHist = [
    { label: 'الكل', value: 'any' },
    { label: 'متصل الآن', value: 'online' },
    { label: 'غير متصل', value: 'offline' },
  ];

  linkedFilterOptionsHist = [
    { label: 'الكل (مرتبط/غير مرتبط)', value: 'ALL' },
    { label: 'مرتبط', value: 'LINKED' },
    { label: 'غير مرتبط', value: 'UNLINKED' },
  ];

  displayedColumnsHist = [
    'username', 'idSmart', 'fullNameAr', 'jobTitle', 'regionCode',
    'roles', 'lastLoginAt', 'status', 'linkedState', 'loggedIn', 'actions'
  ];

  searchHistActive = false;

  private applySortByKeyHist(key: string) {
    const ds = [...this.dataSourceHist.data];
    switch (key) {
      case 'lastLoginDesc':
        ds.sort((a, b) => (b.lastLoginAt ? +new Date(b.lastLoginAt) : 0) - (a.lastLoginAt ? +new Date(a.lastLoginAt) : 0));
        break;
      case 'lastLoginAsc':
        ds.sort((a, b) => (a.lastLoginAt ? +new Date(a.lastLoginAt) : 0) - (b.lastLoginAt ? +new Date(b.lastLoginAt) : 0));
        break;
      case 'userAsc':
        ds.sort((a, b) => (a.username || '').localeCompare(b.username || '', 'ar'));
        break;
      case 'userDesc':
        ds.sort((a, b) => (b.username || '').localeCompare(a.username || '', 'ar'));
        break;
      case 'nameAsc':
        ds.sort((a, b) => (a.fullNameAr || '').localeCompare(b.fullNameAr || '', 'ar'));
        break;
      case 'nameDesc':
        ds.sort((a, b) => (b.fullNameAr || '').localeCompare(a.fullNameAr || '', 'ar'));
        break;
    }
    this.dataSourceHist.data = ds;
  }

  private mapHistoryApiToRow = (api: UserWithHistoryDto): UserHistoryRow => {
    const linked = (api.empNo || api.externalEmpId) ? 'LINKED' as const : 'UNLINKED' as const;
    const isExternal = !!api.externalEmpId;
    const rawStatus = api.status || '';
    const norm = rawStatus.trim().toLowerCase();
    const status =
      norm === 'active' ? 'Active' :
        norm === 'inactive' ? 'Inactive' :
          norm === 'suspended' ? 'Suspended' :
            rawStatus;

    return {
      id: String(api.userId ?? Math.random()),
      username: api.username || '',
      status,
      linkedState: linked,
      isExternal,
      empNo: api.empNo || undefined,
      externalEmpId: api.externalEmpId || undefined,
      fullNameAr: api.empFullNameAr || api.externalFullNameAr || undefined,
      jobTitle: api.jobTitle || undefined,
      regionCode: api.regionCode || undefined,
      lastLoginAt: api.lastLoginAt || null,
      loggedIn: !!api.loggedIn,
      roles: api.roles || [],
    };
  };

  private classifyQueryHist(raw: string) {
    const base = { username: null };
    const m = raw.match(/^(user|u|name|n|emp|id)\s*:\s*(.+)$/i);
    if (m) {
      const key = m[1].toLowerCase();
      const val = m[2].trim();
      return {
        primary: {
          ...base,
          username: (key === 'user' || key === 'u') ? val : null,
        },
        fallbacks: []
      };
    }
    const looksUser = /^[a-zA-Z][\w.\-@]*$/.test(raw);
    if (looksUser) return { primary: { username: raw }, fallbacks: [] };
    return { primary: { username: raw }, fallbacks: [] };
  }

  onStatusFilterChangeHist(v: typeof this.statusFilterHist) {
    this.statusFilterHist = v; this.pageIndexHist = 0; this.fetchUsersHistory();
  }
  onLoginFilterChangeHist(v: typeof this.loginFilterHist) {
    this.loginFilterHist = v; this.pageIndexHist = 0; this.fetchUsersHistory();
  }
  onLinkedFilterChangeHist(v: typeof this.linkedFilterHist) {
    this.linkedFilterHist = v; this.pageIndexHist = 0; this.fetchUsersHistory();
  }

  applyFilterHist(evt: Event) {
    const v = (evt.target as HTMLInputElement).value?.trim() ?? '';
    this.searchTextHist = v;
    this.pageIndexHist = 0;
    this.fetchUsersHistory();
  }
  onPageHist(e: PageEvent) {
    this.pageIndexHist = e.pageIndex;
    this.pageSizeHist = e.pageSize;
    this.fetchUsersHistory();
  }
  sortChangedHist(key: string) {
    this.selectedSortHist = key;
    this.fetchUsersHistory();
  }

  private buildUsersHistoryParams() {
    const userStatus = this.statusFilterHist === 'any' ? null : this.statusFilterHist;
    const linkedState = this.linkedFilterHist;
    const loggedIn =
      this.loginFilterHist === 'any' ? null :
        this.loginFilterHist === 'online' ? true : false;

    const raw = (this.searchTextHist || '').trim();
    let username: string | null = null;
    if (raw) {
      const { primary } = this.classifyQueryHist(raw);
      username = (primary as any).username;
    }

    return {
      username,
      userStatus: userStatus as any,
      linkedState,
      page: this.pageIndexHist,
      size: this.pageSizeHist,
      unpaged: false,
    };
  }

  public fetchUsersHistory() {
    this.loading.set(true);
    this.errorMsg.set(null);

    const base = this.buildUsersHistoryParams();
    const scoped = this.isScopeEnforced && (this.selectedUniteId != null || this.selectedSubUniteId != null);

    const call$ = scoped
      ? this.svc.listUsersWithHistoryByScope({
        ...base,
        uniteId: this.selectedUniteId ?? (this.selectedSubUniteId ? 0 : null),
        subUniteId: this.selectedSubUniteId ?? (this.selectedUniteId ? 0 : null),
        unpaged: false,
      })
      : this.svc.listUsersWithHistory({ ...base, unpaged: false });

    call$.subscribe({
      next: (page) => {
        const rows = (page.content || []).map(this.mapHistoryApiToRow);
        this.dataSourceHist.data = rows;
        this.totalElementsHist = page.totalElements ?? rows.length;
        this.pageIndexHist = page.page ?? 0;
        this.pageSizeHist = page.size ?? this.pageSizeHist;
        this.applySortByKeyHist(this.selectedSortHist);
      },
      error: () => this.errorMsg.set('تعذر تحميل بيانات سجل/حالة الربط.'),
      complete: () => this.loading.set(false),
    });
  }

  getLinkedBadgeClass(state: 'LINKED' | 'UNLINKED') {
    return state === 'LINKED' ? 'status-done' : 'status-rejected';
  }
  chooseIdHist(row: UserHistoryRow) {
    return row.isExternal ? (row.externalEmpId || row.empNo) : (row.empNo || row.externalEmpId);
  }
  buildIdTooltipHist(row: UserHistoryRow) {
    const emp = row.empNo ? `رقم الموظف: ${row.empNo}` : null;
    const ext = row.externalEmpId ? `المعرّف الخارجي: ${row.externalEmpId}` : null;
    return [emp, ext].filter(Boolean).join(' — ') || 'لا توجد بيانات معرّف';
  }
  openHistoryView(row: { username: string }) {
    this.dialog.open(UserDetailsDialog, {
      direction: 'rtl',
      width: '980px',
      maxWidth: '95vw',
      data: { username: row.username }
    });
  }

  dataSourceUnlinked = new MatTableDataSource<UnlinkedRow>([]);
  @ViewChild('paginatorUnlinked') paginatorUnlinked!: MatPaginator;
  @ViewChild('sortUnlinked') sortUnlinked!: MatSort;

  totalElementsUnlinked = 0;
  pageIndexUnlinked = 0;
  pageSizeUnlinked = 10;

  searchTextUnlinked = '';
  selectedSortUnlinked = 'nameAsc';

  sourceFilterUnlinked: 'any' | 'INTERNAL' | 'EXTERNAL' = 'any';
  sourceFilterOptionsUnlinked = [
    { label: 'الكل', value: 'any' },
    { label: 'داخلي', value: 'INTERNAL' },
    { label: 'خارجي', value: 'EXTERNAL' },
  ];

  displayedColumnsUnlinked = [
    'actions', 'fullNameAr', 'idSmart', 'jobTitle', 'department',
    'unit', 'isExternal', 'email', 'managerNo', 'hireDate', 'startDate',
  ];

  private mapUnlinkedApiToRow = (api: UnifiedPersonDetailsDto): UnlinkedRow => ({
    isExternal: api.sourceType === 'EXTERNAL',
    empNo: api.empNo || undefined,
    extEmpId: api.extEmpId || undefined,
    fullNameAr: api.fullNameAr || '—',
    jobTitle: api.jobTitle || undefined,
    department: api.unite?.name || undefined,
    unit: api.subUnite?.name || undefined,
    email: api.email || undefined,
    managerNo: api.managerNo ?? null,
    hireDate: api.hireDate || api.externalStartDate || null,
    startDate: api.startDate || null,
  });

  chooseIdUnlinked(row: UnlinkedRow) {
    return row.isExternal ? (row.extEmpId || row.empNo) : (row.empNo || row.extEmpId);
  }
  buildIdTooltipUnlinked(row: UnlinkedRow) {
    const emp = row.empNo ? `رقم الموظف: ${row.empNo}` : null;
    const ext = row.extEmpId ? `المعرّف الخارجي: ${row.extEmpId}` : null;
    return [emp, ext].filter(Boolean).join(' — ') || 'لا توجد بيانات معرّف';
  }
  getExternalBadgeClass(isExternal: boolean): string {
    return isExternal ? 'status-pending' : 'status-done';
  }

  private classifyQueryUnlinked(raw: string) {
    const m = raw.match(/^(user|u|emp|id|name|n|unit|uunit|dept|sub|su|section)\s*:\s*(.+)$/i);
    if (m) {
      const key = m[1].toLowerCase();
      const val = m[2].trim();
      return {
        q: (key === 'emp' || key === 'id') ? val : null,
        fullNameAr: (key === 'name' || key === 'n') ? val : null,
        uniteName: (key === 'unit' || key === 'uunit' || key === 'dept') ? val : null,
        subUniteName: (key === 'sub' || key === 'su' || key === 'section') ? val : null,
      };
    }
    const onlyDigits = /^\d+$/.test(raw);
    const hasArabic = /[\u0600-\u06FF]/.test(raw);
    if (onlyDigits) return { q: raw, fullNameAr: null, uniteName: null, subUniteName: null };
    if (hasArabic) return { q: null, fullNameAr: raw, uniteName: null, subUniteName: null };
    return { q: null, fullNameAr: raw, uniteName: null, subUniteName: null };
  }

  private buildUnlinkedParams() {
    const raw = (this.searchTextUnlinked || '').trim();
    const base = raw ? this.classifyQueryUnlinked(raw)
      : { q: null, fullNameAr: null, uniteName: null, subUniteName: null };
    return {
      ...base,
      page: this.pageIndexUnlinked,
      size: this.pageSizeUnlinked,
      unpaged: false
    };
  }

  private applySortByKeyUnlinked(key: string) {
    const ds = [...this.dataSourceUnlinked.data];
    switch (key) {
      case 'nameAsc': ds.sort((a, b) => (a.fullNameAr || '').localeCompare(b.fullNameAr || '', 'ar')); break;
      case 'nameDesc': ds.sort((a, b) => (b.fullNameAr || '').localeCompare(a.fullNameAr || '', 'ar')); break;
      case 'jobAsc': ds.sort((a, b) => (a.jobTitle || '').localeCompare(b.jobTitle || '', 'ar')); break;
      case 'jobDesc': ds.sort((a, b) => (b.jobTitle || '').localeCompare(a.jobTitle || '', 'ar')); break;
    }
    this.dataSourceUnlinked.data = ds;
  }

  onSourceFilterChangeUnlinked(v: typeof this.sourceFilterUnlinked) {
    this.sourceFilterUnlinked = v;
    this.pageIndexUnlinked = 0;
    this.fetchUnlinkedPeople();
  }
  applyFilterUnlinked(evt: Event) {
    const v = (evt.target as HTMLInputElement).value?.trim() ?? '';
    this.searchTextUnlinked = v;
    this.pageIndexUnlinked = 0;
    this.fetchUnlinkedPeople();
  }
  onPageUnlinked(e: PageEvent) {
    this.pageIndexUnlinked = e.pageIndex;
    this.pageSizeUnlinked = e.pageSize;
    this.fetchUnlinkedPeople();
  }
  sortChangedUnlinked(key: string) {
    this.selectedSortUnlinked = key;
    this.fetchUnlinkedPeople();
  }

  public fetchUnlinkedPeople() {
    this.loading.set(true);
    this.errorMsg.set(null);

    const baseParams = this.buildUnlinkedParams();
    const scoped = this.isScopeReady();

    const callUniteId = this.selectedUniteId ?? (this.selectedSubUniteId ? 0 : null);
    const callSubUniteId = this.selectedSubUniteId ?? (this.selectedUniteId ? 0 : null);

    const call$ = scoped
      ? this.svc.listAllPeopleWithoutUserByScope({
        ...baseParams,
        uniteId: callUniteId,
        subUniteId: callSubUniteId,
        unpaged: false
      })
      : this.svc.listAllPeopleWithoutUser({
        ...baseParams,
        unpaged: false
      });

    call$.subscribe({
      next: (page) => {
        let rows = (page.content || []).map(this.mapUnlinkedApiToRow);
        if (this.sourceFilterUnlinked !== 'any') {
          const wantExternal = this.sourceFilterUnlinked === 'EXTERNAL';
          rows = rows.filter(r => r.isExternal === wantExternal);
        }
        this.dataSourceUnlinked.data = rows;
        this.totalElementsUnlinked = page.totalElements ?? rows.length;
        this.pageIndexUnlinked = page.page ?? 0;
        this.pageSizeUnlinked = page.size ?? this.pageSizeUnlinked;
        this.applySortByKeyUnlinked(this.selectedSortUnlinked);
      },
      error: () => this.errorMsg.set('تعذر تحميل الأشخاص بدون حساب.'),
      complete: () => this.loading.set(false),
    });
  }

  openUnlinkedView(row: UnlinkedRow) {
    if (row.isExternal) {
      if (!row.extEmpId) { alert('لا يوجد معرّف خارجي.'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'EXTERNAL', extEmpId: row.extEmpId }
      });
    } else {
      if (!row.empNo) { alert('لا يوجد رقم وظيفي.'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'INTERNAL', empNo: row.empNo }
      });
    }
  }

  dataSourceDeleg = new MatTableDataSource<DelegationRow>([]);
  @ViewChild('paginatorDeleg') paginatorDeleg!: MatPaginator;
  @ViewChild('sortDeleg') sortDeleg!: MatSort;

  displayedColumnsDeleg = [
    'actions', 'delegationId', 'status', 'activeNow', 'delegator',
    'delegatee', 'scopeType', 'window', 'actionsAll', 'sessions', 'createdAt',
  ];

  searchDelegActive = false;
  searchTextDeleg = '';

  delegStatusFilter: 'ANY' | DelegationStatus = 'ANY';
  delegStatusOptions = [
    { label: 'الكل', value: 'ANY' },
    { label: 'بانتظار', value: 'PENDING' },
    { label: 'نشِط', value: 'ACTIVE' },
    { label: 'مرفوض', value: 'REJECTED' },
    { label: 'مسحوب', value: 'REVOKED' },
    { label: 'منتهي', value: 'EXPIRED' },
  ];

  delegatorEmpNo: string = '';
  delegateeEmpNo: string = '';
  creatorEmpNo: string = '';

  readonly sortOptionsDeleg = [
    { label: 'الأحدث إنشاءً', value: 'createdDesc' },
    { label: 'الأقدم إنشاءً', value: 'createdAsc' },
    { label: 'المفوِّض (أ-ي)', value: 'delegatorAsc' },
    { label: 'المفوِّض (ي-أ)', value: 'delegatorDesc' },
    { label: 'المفوَّض له (أ-ي)', value: 'delegateeAsc' },
    { label: 'المفوَّض له (ي-أ)', value: 'delegateeDesc' },
  ] as const;
  selectedSortDeleg = 'createdDesc';

  totalElementsDeleg = 0;
  pageIndexDeleg = 0;
  pageSizeDeleg = 10;

  private classifyDelegQuery(raw: string) {
    const m = raw.match(/^(from|to|creator|status)\s*:\s*([^\s]+)$/i);
    if (!m) return { creatorEmpNo: null, delegatorEmpNo: null, delegateeEmpNo: null, status: null as DelegationStatus | null };
    const key = m[1].toLowerCase();
    const val = m[2].trim();
    if (key === 'from') return { creatorEmpNo: null, delegatorEmpNo: val, delegateeEmpNo: null, status: null };
    if (key === 'to') return { creatorEmpNo: null, delegatorEmpNo: null, delegateeEmpNo: val, status: null };
    if (key === 'creator') return { creatorEmpNo: val, delegatorEmpNo: null, delegateeEmpNo: null, status: null };
    if (key === 'status') return { creatorEmpNo: null, delegatorEmpNo: null, delegateeEmpNo: null, status: val.toUpperCase() as DelegationStatus };
    return { creatorEmpNo: null, delegatorEmpNo: null, delegateeEmpNo: null, status: null };
  }

  private buildDelegParams() {
    let creator = (this.creatorEmpNo || '').trim() || null;
    let delegor = (this.delegatorEmpNo || '').trim() || null;
    let delegue = (this.delegateeEmpNo || '').trim() || null;
    let status: DelegationStatus | null =
      (this.delegStatusFilter === 'ANY') ? null : this.delegStatusFilter;

    const raw = (this.searchTextDeleg || '').trim();
    if (raw) {
      const pick = this.classifyDelegQuery(raw);
      if (pick.creatorEmpNo) creator = pick.creatorEmpNo;
      if (pick.delegatorEmpNo) delegor = pick.delegatorEmpNo;
      if (pick.delegateeEmpNo) delegue = pick.delegateeEmpNo;
      if (pick.status) status = pick.status as DelegationStatus;
    }

    return {
      creatorEmpNo: creator,
      delegatorEmpNo: delegor,
      delegateeEmpNo: delegue,
      status
    };
  }

  private mapDelegApiToRow = (d: DelegationFullDetailsDto): DelegationRow => {
    const actions = (d.actionsAll || []) as string[];
    const actionsShort =
      (actions?.length || 0) === 0 ? '—'
        : actions.length <= 3 ? actions.join(', ')
          : actions.slice(0, 3).join(', ') + '…';

    const win =
      d.noExpiry ? 'بدون انتهاء'
        : (d.startAt
          ? (d.endAt
            ? `${d.startAt.slice(0, 16).replace('T', ' ')} → ${d.endAt.slice(0, 16).replace('T', ' ')}`
            : `${d.startAt.slice(0, 16).replace('T', ' ')} → —`)
          : '—');

    const sessions = `${(d.activeSessionsCount ?? 0)} / ${(d.totalSessionsCount ?? 0)}`;

    return {
      delegationId: d.delegationId,
      status: d.status,
      activeNow: !!d.activeNow,
      delegatorEmpNo: d.delegatorEmpNo,
      delegatorName: d.delegatorFullNameAr || d.delegatorUsername || d.delegatorEmpNo,
      delegateeEmpNo: d.delegateeEmpNo,
      delegateeName: d.delegateeFullNameAr || d.delegateeUsername || d.delegateeEmpNo,
      scopeType: d.scopeType,
      window: win,
      actionsAllShort: actionsShort,
      sessionsSummary: sessions,
      createdAt: d.createdAt
    };
  };

  onDelegStatusChange(_: any) {
    this.pageIndexDeleg = 0;
    this.fetchDelegations();
  }
  applyFilterDeleg(evt: Event) {
    const v = (evt.target as HTMLInputElement).value?.trim() ?? '';
    this.searchTextDeleg = v;
    this.pageIndexDeleg = 0;
    this.fetchDelegations();
  }
  sortChangedDeleg(key: string) {
    this.selectedSortDeleg = key;
    this.applySortDeleg();
  }
  onPageDeleg(e: PageEvent) {
    this.pageIndexDeleg = e.pageIndex;
    this.pageSizeDeleg = e.pageSize;
    this.slicePageDeleg();
  }

  private applySortDeleg() {
    const ds = [...(this._delegAllRows || [])];
    switch (this.selectedSortDeleg) {
      case 'createdDesc': ds.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)); break;
      case 'createdAsc': ds.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)); break;
      case 'delegatorAsc': ds.sort((a, b) => (a.delegatorName || '').localeCompare(b.delegatorName || '', 'ar')); break;
      case 'delegatorDesc': ds.sort((a, b) => (b.delegatorName || '').localeCompare(a.delegatorName || '', 'ar')); break;
      case 'delegateeAsc': ds.sort((a, b) => (a.delegateeName || '').localeCompare(b.delegateeName || '', 'ar')); break;
      case 'delegateeDesc': ds.sort((a, b) => (b.delegateeName || '').localeCompare(a.delegateeName || '', 'ar')); break;
    }
    this._delegAllRows = ds;
    this.slicePageDeleg();
  }

  private slicePageDeleg() {
    const all = (this._delegAllRows || []) as DelegationRow[];
    this.totalElementsDeleg = all.length;
    const start = this.pageIndexDeleg * this.pageSizeDeleg;
    const end = start + this.pageSizeDeleg;
    this.dataSourceDeleg.data = all.slice(start, end);
  }

  private _delegAllRows: DelegationRow[] = [];

  public fetchDelegations() {
    if (this.isScopeEnforced && !this.isScopeReady()) return;

    this.loading.set(true);
    this.errorMsg.set(null);

    const params = this.buildDelegParams();
    const scoped = this.isScopeEnforced && (this.selectedUniteId != null || this.selectedSubUniteId != null);

    const callUniteId = this.selectedUniteId ?? (this.selectedSubUniteId ? 0 : null);
    const callSubUniteId = this.selectedSubUniteId ?? (this.selectedUniteId ? 0 : null);

    const call$ = scoped
      ? this.delegSvc.allFullFilteredByScope({
        uniteId: callUniteId,
        subUniteId: callSubUniteId,
        creatorEmpNo: params.creatorEmpNo || null,
        delegatorEmpNo: params.delegatorEmpNo || null,
        delegateeEmpNo: params.delegateeEmpNo || null,
        status: params.status || null,
      })
      : this.delegSvc.searchAllFullFiltered({
        creatorEmpNo: params.creatorEmpNo || null,
        delegatorEmpNo: params.delegatorEmpNo || null,
        delegateeEmpNo: params.delegateeEmpNo || null,
        status: params.status || null
      });

    call$.subscribe({
      next: (list: any[]) => {
        const rows = (list || []).map(this.mapDelegApiToRow);
        this._delegAllRows = rows;
        this.applySortDeleg(); 
      },
      error: () => {
        this.errorMsg.set('تعذر تحميل بيانات التفويضات.');
        this._delegAllRows = [];
        this.dataSourceDeleg.data = [];
        this.totalElementsDeleg = 0;
      },
      complete: () => this.loading.set(false),
    });
  }

  getDelegStatusBadge(st: DelegationStatus) {
    const s = (st || '').toString().toLowerCase();
    if (s === 'active') return 'status-done';
    if (s === 'pending') return 'status-pending';
    if (s === 'rejected') return 'status-rejected';
    if (s === 'revoked') return 'status-rejected';
    if (s === 'expired') return 'status-rejected';
    return 'status-pending';
  }

  openDelegationDetails(row: DelegationRow) {
    this.dialog.open(DelegationDetailsDialog, {
      direction: 'rtl',
      width: '1000px',
      maxWidth: '95vw',
      data: { delegationId: row.delegationId }
    });
  }

  openLinkUnlinkDialog(row: any, context: 'FROM_USER' | 'FROM_EMPLOYEE') {
    const isLinkedNow = !!(row?.username && (row?.empNo || row?.extEmpId));
    this.dialog.open(LinkUnlinkUserDialog, {
      direction: 'rtl',
      width: '980px',
      maxWidth: '95vw',
      data: {
        context,
        username: row?.username ?? null,
        linkedState: isLinkedNow ? 'LINKED' : 'UNLINKED',
        empNo: row?.empNo ?? null,
        extEmpId: row?.extEmpId ?? null
      }
    }).afterClosed().subscribe(ok => {
      if (ok) {
        this.fetchAllPeople?.();
        this.fetchUsersHistory?.();
        this.fetchUnlinkedPeople?.();
      }
    });
  }


  dataSourceReg = new MatTableDataSource<RegistrationRow>([]);
  @ViewChild('paginatorReg') paginatorReg!: MatPaginator;
  @ViewChild('sortReg') sortReg!: MatSort;

displayedColumnsReg = [
  'id', 'parentRequestId', 'createdAt', 'currentStage', 'stageStatus',
  'employeeType', 'username', 'empNo', 'fullNameAr',
  'regionName', 'uniteName', 'subUniteName',
  'actions'
];


  totalElementsReg = 0;
  pageIndexReg = 0;
  pageSizeReg = 10;

  searchTextReg = '';
  searchRegActive = false;
  stageFilterReg: 'ANY' | 'PENDING' | 'APPROVED' | 'REJECTED' = 'ANY';
  typeFilterReg: 'ANY' | 'INTERNAL' | 'EXTERNAL' = 'ANY';
  selectedSortReg: 'newest' | 'oldest' | 'userAsc' | 'userDesc' = 'newest';

  private mapRegApiToRow = (d: any): RegistrationRow => {

  const parentRequestId =
    d.parentRequestId ??
    d.parent_id ??
    d.parentId ??
    (d.parentRequest && d.parentRequest.id) ??
    null;

  return {
    id: d.id,
    parentRequestId,

    createdAt: d.createdAt,
    currentStage: d.currentStage,
    stageStatus: d.stageStatus,
    employeeType: d.employeeType,

    username: d.username,
    empNo: d.empNo,
    fullNameAr: d.fullNameAr,
    regionName: d.regionName,
    uniteName: d.uniteName,
    subUniteName: d.subUniteName,

    waitingForEmpNo: d.waitingForEmpNo ?? null,
    userStatus: d.userStatus,
    regionId: d.regionId,
    uniteId: d.uniteId,
    subUniteId: d.subUniteId,
  };
};


 





  private classifyRegQuery(raw: string) {
    const m = raw.match(/^(user|u|id|emp)\s*:\s*(.+)$/i);
    if (m) {
      const k = m[1].toLowerCase(), v = m[2].trim();
      return {
        username: (k === 'user' || k === 'u') ? v : null,
        empNo: (k === 'id' || k === 'emp') ? v : null
      };
    }
    const onlyDigits = /^\d+$/.test(raw);
    const hasAr = /[\u0600-\u06FF]/.test(raw);
    if (onlyDigits) return { username: null, empNo: raw };
    if (hasAr) return { username: null, empNo: null, fullNameAr: raw as any };
    return { username: raw, empNo: null };
  }

  private buildRegParams() {
    const raw = (this.searchTextReg || '').trim();
    let username: string | null = null;
    let empNo: string | null = null;

    if (raw) {
      const p = this.classifyRegQuery(raw) as any;
      username = p.username ?? null;
      empNo = p.empNo ?? null;
    }

    const stageStatus = this.stageFilterReg === 'ANY' ? null : this.stageFilterReg;

    return {
      username,
      stageStatus: stageStatus as ('PENDING' | 'APPROVED' | 'REJECTED' | null),
      page: this.pageIndexReg,
      size: this.pageSizeReg
    };
  }

  private sortRowsReg(rows: RegistrationRow[]): RegistrationRow[] {
    const ds = [...rows];
    switch (this.selectedSortReg) {
      case 'newest': ds.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)); break;
      case 'oldest': ds.sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt)); break;
      case 'userAsc': ds.sort((a, b) => (a.username || '').localeCompare(b.username || '', 'ar')); break;
      case 'userDesc': ds.sort((a, b) => (b.username || '').localeCompare(a.username || '', 'ar')); break;
    }
    return ds;
  }

  public fetchRegistrationRequests() {
  this.loading.set(true);
  this.errorMsg.set(null);

  const base = this.buildRegParams();
  const scoped = this.isScopeEnforced && (this.selectedUniteId != null || this.selectedSubUniteId != null);

  const call$ = scoped
    ? this.svc.searchRegistrationRequestsByScope({
        ...base,
        uniteId: this.selectedUniteId ?? (this.selectedSubUniteId ? 0 : null),
        subUniteId: this.selectedSubUniteId ?? (this.selectedUniteId ? 0 : null),
      })
    : this.svc.searchRegistrationRequests(base);

  call$.subscribe({
    next: (page: PageResponse<UserRegistrationRequestSummaryDto>) => {
      const allRows = (page.content || []).map(this.mapRegApiToRow);
      let rows = this.mergeParentChildRegs(allRows);

      if (this.typeFilterReg !== 'ANY') {
        rows = rows.filter(r => r.employeeType === this.typeFilterReg);
      }

      rows = this.sortRowsReg(rows);

      this.dataSourceReg.data = rows;
      this.totalElementsReg = rows.length; 
      this.pageIndexReg = page.page ?? 0;
      this.pageSizeReg = page.size ?? this.pageSizeReg;
    },
    error: () => {
      this.errorMsg.set('تعذر تحميل بيانات الطلبات.');
      this.dataSourceReg.data = [];
      this.totalElementsReg = 0;
    },
    complete: () => this.loading.set(false),
  });
}



private mergeParentChildRegs(all: RegistrationRow[]): RegistrationRow[] {
  const parents = all.filter(r => !r.parentRequestId);

  return parents.map(parent => {
    const child = all.find(c => c.parentRequestId === parent.id);

    if (!child) {
      return parent;
    }

    return {
      ...parent,
      currentStage: child.currentStage,
      stageStatus: child.stageStatus,
      waitingForEmpNo: child.waitingForEmpNo ?? parent.waitingForEmpNo,
      userStatus: child.userStatus ?? parent.userStatus,
      regionId: child.regionId ?? parent.regionId,
      uniteId: child.uniteId ?? parent.uniteId,
      subUniteId: child.subUniteId ?? parent.subUniteId,
    };
  });
}


  applyFilterReg(e: Event) {
    this.searchTextReg = (e.target as HTMLInputElement).value?.trim() ?? '';
    this.pageIndexReg = 0;
    this.fetchRegistrationRequests();
  }
  onStageFilterChangeReg(v: typeof this.stageFilterReg) {
    this.stageFilterReg = v;
    this.pageIndexReg = 0;
    this.fetchRegistrationRequests();
  }
  onTypeFilterChangeReg(v: typeof this.typeFilterReg) {
    this.typeFilterReg = v;
    this.pageIndexReg = 0;
    this.fetchRegistrationRequests();
  }
  sortChangedReg(v: typeof this.selectedSortReg) {
    this.selectedSortReg = v;
    this.dataSourceReg.data = this.sortRowsReg(this.dataSourceReg.data);
  }
  onPageReg(e: PageEvent) {
    this.pageIndexReg = e.pageIndex;
    this.pageSizeReg = e.pageSize;
    this.fetchRegistrationRequests();
  }

 openRequestDetails(row: RegistrationRow) {
    this.dialog.open(DetailsOfAccountCreationRequests, {
      direction: 'rtl',
      width: '1000px',
      maxWidth: '95vw',
      data: { row }   
    });
  }

openRequestDialog(r: RegistrationRow) {
  const dlg = this.dialog.open(TakeActionOnAccountRequest, {
    width: '900px',
    maxWidth: '95vw',
    data: {
      id: r.id,
      username: r.username,
      empNo: r.empNo,
      fullNameAr: r.fullNameAr,
      employeeType: r.employeeType,     // INTERNAL / EXTERNAL
      currentStage: r.currentStage,     // ADMIN_REVIEW / ...
      stageStatus: r.stageStatus        // PENDING / APPROVED / REJECTED
    }
  });

  dlg.afterClosed().subscribe(result => {
    if (result === 'APPROVED' || result === 'REJECTED') {
      this.fetchRegistrationRequests(); 
    }
  });
}

getStageLabelReg(stage: RegistrationRow['currentStage']): string {
  switch (stage) {
    case 'ADMIN_REVIEW':
      return 'مراجعة الإدارة';
    case 'SECURITY_REVIEW':
      return 'مراجعة الأمن';
    case 'USER_TERMS':
      return 'انتظار موافقة المستخدم';
    default:
      return stage;
  }
}

getStageStatusLabelReg(r: RegistrationRow): string {
  if (r.currentStage === 'USER_TERMS' && r.stageStatus === 'PENDING') {
    return 'بانتظار موافقة المستخدم';
  }

  switch (r.stageStatus) {
    case 'PENDING':
      return 'بانتظار';
    case 'APPROVED':
      return 'معتمد';
    case 'REJECTED':
      return 'مرفوض';
    default:
      return r.stageStatus;
  }
}


isRegActionDisabled(r: RegistrationRow): boolean {
  return r.currentStage === 'USER_TERMS' && r.stageStatus === 'PENDING';
}




/*   approveRequest(row: RegistrationRow) {
    this.svc.approveRegistrationRequest?.(row.id).subscribe({
      next: () => this.fetchRegistrationRequests(),
      error: () => alert('فشل اعتماد الطلب'),
    });
  }
  rejectRequest(row: RegistrationRow) {
    this.svc.rejectRegistrationRequest?.(row.id).subscribe({
      next: () => this.fetchRegistrationRequests(),
      error: () => alert('فشل رفض الطلب'),
    });
  } */
}

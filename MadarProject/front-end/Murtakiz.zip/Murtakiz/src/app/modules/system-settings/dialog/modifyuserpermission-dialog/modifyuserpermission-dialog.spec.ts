import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyuserpermissionDialog } from './modifyuserpermission-dialog';

describe('ModifyuserpermissionDialog', () => {
  let component: ModifyuserpermissionDialog;
  let fixture: ComponentFixture<ModifyuserpermissionDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModifyuserpermissionDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModifyuserpermissionDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';  

import { UserManagementService } from '../../services/user-management/user-management-service';
import { UserStatusResult } from '../../models/employee-directory.models';

export interface ModifyUserStatusDialogData {
  empNo: string;
  fullName?: string;
  username?: string;
  currentStatus?: 'Active' | 'Inactive';
}

@Component({
  selector: 'app-modifyuserstatus-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatSnackBarModule 
  ],
  templateUrl: './modifyuserstatus-dialog.html',
  styleUrl: './modifyuserstatus-dialog.css'
})
export class ModifyuserstatusDialog implements OnInit {

  userStatusOptions: Array<{ value: 'Active' | 'Inactive'; label: string }> = [];
  selectedStatus: 'Active' | 'Inactive' | '' = '';
  selectedUser = {
    employeeNumber: '-',
    fullName: '-',
    username: '-',
    status: '-'
  };

  loading = false;

  constructor(
    private api: UserManagementService,
    private dialogRef: MatDialogRef<ModifyuserstatusDialog, UserStatusResult | null>,
    @Inject(MAT_DIALOG_DATA) public data: ModifyUserStatusDialogData,
    private snack: MatSnackBar  
  ) {}

  ngOnInit(): void {
    const current = (this.data.currentStatus === 'Active' || this.data.currentStatus === 'Inactive')
      ? this.data.currentStatus
      : 'Inactive';

    this.computeOptions(current);

    this.selectedUser = {
      employeeNumber: this.data.empNo || '-',
      fullName: this.data.fullName || '-',
      username: this.data.username || '-',
      status: this.data.currentStatus || '-',
    };
  }

  private computeOptions(current: 'Active' | 'Inactive') {
    this.userStatusOptions =
      current === 'Active'
        ? [{ value: 'Inactive', label: 'تعطيل الحساب' }]
        : [{ value: 'Active', label: 'تنشيط الحساب' }];

    this.selectedStatus = this.userStatusOptions[0].value;
  }

  closeConfirmDialog(): void {
    this.dialogRef.close(null);
  }

  confirmUserStatus(): void {
  if (!this.data.username || this.selectedStatus === '') {
    this.snack.open('لا يوجد اسم مستخدم صالح.', 'موافق', {
      duration: 2500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
    });
    return;
  }

  this.loading = true;


  const revokeAllSessions = false; 
  this.api.toggleStatusByUsername(this.data.username, revokeAllSessions).subscribe({
    next: (res: UserStatusResult) => {
      this.loading = false;

      const msg =
          res.newStatus === 'Active' ? '✅ تم تنشيط الحساب بنجاح' : '⛔ تم تعطيل الحساب';
        this.snack.open(msg, 'إغلاق', { duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl' });

        this.dialogRef.close(res);
    },
    error: () => {
      this.loading = false;
      this.snack.open('حدث خطأ أثناء تنفيذ الطلب ❗', 'موافق', {
        duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl'
      });
    }
  });
}


/*   confirmUserStatus(): void {
    if (!this.data.empNo || this.selectedStatus === '') return;

    this.loading = true;
    this.api.toggleStatusByEmpNo(this.data.empNo, false).subscribe({
      next: (res) => {
        this.loading = false;

        const msg =
          res.newStatus === 'Active' ? '✅ تم تنشيط الحساب بنجاح' : '⛔ تم تعطيل الحساب';
        this.snack.open(msg, 'إغلاق', { duration: 3000, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl' });

        this.dialogRef.close(res);
      },
      error: () => {
        this.loading = false;
        this.snack.open('حدث خطأ أثناء تنفيذ الطلب ❗', 'موافق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
        });
      }
    });
  } */
}

import { MatPaginatorIntl } from '@angular/material/paginator';

export function getArabicPaginatorIntl(): MatPaginatorIntl {
  const intl = new MatPaginatorIntl();
  intl.itemsPerPageLabel = 'عدد العناصر في الصفحة:';
  intl.nextPageLabel     = 'الصفحة التالية';
  intl.previousPageLabel = 'الصفحة السابقة';
  intl.firstPageLabel    = 'الأولى';
  intl.lastPageLabel     = 'الأخيرة';

  intl.getRangeLabel = (page: number, pageSize: number, length: number) => {
    if (length === 0 || pageSize === 0) {
      return '0 من 0';
    }
    const startIndex = page * pageSize;
    const endIndex = Math.min(startIndex + pageSize, length);
    return `${startIndex + 1}–${endIndex} من ${length}`;
  };

  return intl;
}

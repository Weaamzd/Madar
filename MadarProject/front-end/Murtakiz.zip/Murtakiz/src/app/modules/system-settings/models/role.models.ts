export interface RoleItemDto {
  id: number;
  name: string;
}

export interface AssignRolesRequest {
  roles: string[];
}

export interface RemoveRolesRequest {
  roles: string[];
}

export interface RolesMutationResult {
  userId: number;
  empNo: string;
  added: string[];
  skipped: string[];
  notFoundRoles: string[];
  deletedCount: number;
  at: string; 
}



export interface RoleOptionsDto {
  assigned: RoleItemDto[];
  available: RoleItemDto[];
}

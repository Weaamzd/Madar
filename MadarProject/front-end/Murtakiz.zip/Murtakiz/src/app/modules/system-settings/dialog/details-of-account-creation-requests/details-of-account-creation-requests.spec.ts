import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsOfAccountCreationRequests } from './details-of-account-creation-requests';

describe('DetailsOfAccountCreationRequests', () => {
  let component: DetailsOfAccountCreationRequests;
  let fixture: ComponentFixture<DetailsOfAccountCreationRequests>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailsOfAccountCreationRequests]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DetailsOfAccountCreationRequests);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';

import { UserManagementService } from '../../services/user-management/user-management-service';


export interface AccountRequestDialogData {
  id: number;
  username: string;
  empNo?: string;
  fullNameAr?: string;
  employeeType?: 'INTERNAL' | 'EXTERNAL';
  currentStage?: string;     // ADMIN_REVIEW / SECURITY_REVIEW / USER_TERMS ...
  stageStatus?: string;      // PENDING / APPROVED / REJECTED ...
}

@Component({
  selector: 'app-take-action-on-account-request',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
    MatIconModule
  ],
  templateUrl: './take-action-on-account-request.html',
  styleUrl: './take-action-on-account-request.css',
})
export class TakeActionOnAccountRequest {


  selectedAction: 'APPROVE' | 'REJECT' = 'APPROVE';
  notes: string = '';
  loading = false;

  constructor(
    private api: UserManagementService,
    private dialogRef: MatDialogRef<TakeActionOnAccountRequest, 'APPROVED' | 'REJECTED' | null>,
    @Inject(MAT_DIALOG_DATA) public data: AccountRequestDialogData,
    private snack: MatSnackBar
  ) {}


  get avatarLetters(): string {
    return (this.data.username || '-').slice(0, 2);
  }

  get employeeTypeLabel(): string {
    if (this.data.employeeType === 'INTERNAL') return 'موظف داخلي';
    if (this.data.employeeType === 'EXTERNAL') return 'متعاون / خارجي';
    return 'غير محدد';
  }

  getStageLabel(): string {
    switch (this.data.currentStage) {
      case 'ADMIN_REVIEW':    return 'مراجعة الإدارة';
      case 'SECURITY_REVIEW': return 'مراجعة أمنية';
      case 'USER_TERMS':      return 'قبول الشروط';
      default:                return this.data.currentStage || 'غير معروفة';
    }
  }

  getStatusLabel(): string {
    switch (this.data.stageStatus) {
      case 'PENDING':  return 'قيد المعالجة';
      case 'APPROVED': return 'مُعتمد';
      case 'REJECTED': return 'مرفوض';
      default:         return this.data.stageStatus || 'غير معروفة';
    }
  }

  getStatusChipClass(): string {
    const s = (this.data.stageStatus || '').toUpperCase();
    if (s === 'PENDING')  return 'chip-pending';
    if (s === 'APPROVED') return 'chip-success';
    if (s === 'REJECTED') return 'chip-danger';
    return 'chip-muted';
  }


  close(): void {
    this.dialogRef.close(null);
  }


  confirm(): void {

    if (this.selectedAction === 'REJECT' && !this.notes.trim()) {
      this.snack.open('الرجاء إدخال سبب رفض الطلب.', 'موافق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl'
      });
      return;
    }

    this.loading = true;

    const approved = this.selectedAction === 'APPROVE';
    const notesToSend = this.notes.trim() || undefined;

    this.api.approveAdminRegistration(this.data.id, approved, notesToSend).subscribe({
      next: () => {
        this.loading = false;

        const msg = approved
          ? '✅ تم اعتماد طلب إنشاء الحساب بنجاح'
          : '⛔ تم رفض طلب إنشاء الحساب';

        this.snack.open(msg, 'إغلاق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl'
        });

        this.dialogRef.close(approved ? 'APPROVED' : 'REJECTED');
      },
      error: () => {
        this.loading = false;
        this.snack.open('حدث خطأ أثناء تنفيذ الإجراء على الطلب ❗', 'موافق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl'
        });
      }
    });
  }
}

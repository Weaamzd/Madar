import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { RoleManagement } from '../../services/role/role-management';
import { RoleItemDto, RoleOptionsDto, RolesMutationResult } from '../../models/role.models';

export interface ModifyUserPermissionDialogData {
  empNo: string;
  fullName?: string;
  username?: string;
  currentRoles?: string[]; 
}

@Component({
  selector: 'app-modifyuserpermission-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatSnackBarModule
  ],
  templateUrl: './modifyuserpermission-dialog.html',
  styleUrls: ['./modifyuserpermission-dialog.css']
})
export class ModifyuserpermissionDialog implements OnInit {


  selectedUser = {
    employeeNumber: '-',
    fullName: '-',
    username: '-',
    roles: [] as string[],
  };


  mode: 'add' | 'remove' = 'add';


  options: RoleOptionsDto | null = null;


  selectedRoleNames: string[] = [];

  loading = false;

  constructor(
    private rolesApi: RoleManagement,
    private dialogRef: MatDialogRef<ModifyuserpermissionDialog, { updatedRoles: string[] } | null>,
    @Inject(MAT_DIALOG_DATA) public data: ModifyUserPermissionDialogData,
    private snack: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.selectedUser = {
      employeeNumber: this.data.empNo || '-',
      fullName: this.data.fullName || '-',
      username: this.data.username || '-',
      roles: this.data.currentRoles || [],
    };

    this.fetchOptions();
  }

  private fetchOptions() {
    if (!this.data.empNo) return;
    this.loading = true;
    this.rolesApi.getOptions(this.data.empNo).subscribe({
      next: (opts) => {
        opts.assigned  = [...opts.assigned].sort((a,b)=> a.name.localeCompare(b.name, 'en'));
        opts.available = [...opts.available].sort((a,b)=> a.name.localeCompare(b.name, 'en'));
        this.options = opts;

        const firstList = this.mode === 'add' ? opts.available : opts.assigned;
        this.selectedRoleNames = firstList.length ? [firstList[0].name] : [];
      },
      error: () => {
        this.snack.open('تعذر تحميل قائمة الأدوار ❗', 'موافق', { duration: 3000, horizontalPosition: 'center', verticalPosition: 'top' });
      },
      complete: () => { this.loading = false; }
    });
  }

  onModeChange() {
    if (!this.options) return;
    const list = this.mode === 'add' ? this.options.available : this.options.assigned;
    this.selectedRoleNames = list.length ? [list[0].name] : [];
  }

  close(): void {
    this.dialogRef.close(null);
  }

  confirm(): void {
    if (!this.data.empNo || !this.selectedRoleNames.length) return;

    this.loading = true;
    if (this.mode === 'add') {
      this.rolesApi.addRoles(this.data.empNo, this.selectedRoleNames).subscribe({
        next: (res: RolesMutationResult) => {
          this.loading = false;
          const added = res.added?.length ? `✅ تمت إضافة: ${res.added.join(', ')}` : 'لم تُضف أدوار جديدة.';
          const skipped = res.skipped?.length ? ` | موجودة مسبقًا: ${res.skipped.join(', ')}` : '';
          const notFound = res.notFoundRoles?.length ? ` | غير موجودة: ${res.notFoundRoles.join(', ')}` : '';
          this.snack.open(`${added}${skipped}${notFound}`, 'إغلاق', { duration: 3500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl' });

          const updated = Array.from(new Set([...(this.selectedUser.roles ?? []), ...(res.added ?? [])])).sort();
          this.dialogRef.close({ updatedRoles: updated });
        },
        error: () => {
          this.loading = false;
          this.snack.open('حدث خطأ أثناء إضافة الصلاحيات ❗', 'موافق', { duration: 3000, horizontalPosition: 'center', verticalPosition: 'top' });
        }
      });
    } else {

      this.rolesApi.removeRoles(this.data.empNo, this.selectedRoleNames).subscribe({
        next: (res: RolesMutationResult) => {
          this.loading = false;
          const del = res.deletedCount ? `🗑️ تم حذف ${res.deletedCount} دور/أدوار.` : 'لم يتم حذف أي دور.';
          const notFound = res.notFoundRoles?.length ? ` | غير موجودة: ${res.notFoundRoles.join(', ')}` : '';
          this.snack.open(`${del}${notFound}`, 'إغلاق', { duration: 3500, horizontalPosition: 'center', verticalPosition: 'top', direction: 'rtl' });


          const toRemove = new Set(this.selectedRoleNames);
          const updated = (this.selectedUser.roles ?? []).filter(r => !toRemove.has(r)).sort();
          this.dialogRef.close({ updatedRoles: updated });
        },
        error: () => {
          this.loading = false;
          this.snack.open('حدث خطأ أثناء حذف الصلاحيات ❗', 'موافق', { duration: 3000, horizontalPosition: 'center', verticalPosition: 'top' });
        }
      });
    }
  }


  get currentList(): RoleItemDto[] {
    if (!this.options) return [];
    return this.mode === 'add' ? this.options.available : this.options.assigned;
  }
}

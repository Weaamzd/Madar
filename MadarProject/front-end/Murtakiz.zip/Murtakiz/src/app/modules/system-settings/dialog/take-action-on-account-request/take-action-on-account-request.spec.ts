import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TakeActionOnAccountRequest } from './take-action-on-account-request';

describe('TakeActionOnAccountRequest', () => {
  let component: TakeActionOnAccountRequest;
  let fixture: ComponentFixture<TakeActionOnAccountRequest>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TakeActionOnAccountRequest]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TakeActionOnAccountRequest);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserManagement } from './pages/user-management/user-management';
import { RequestCreateAccount } from './pages/createuser/createuser';

const routes: Routes = [
  { path: 'user-management', component: UserManagement },
  { path: 'request-create-account', component: RequestCreateAccount }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SystemSettingsRoutingModule { }

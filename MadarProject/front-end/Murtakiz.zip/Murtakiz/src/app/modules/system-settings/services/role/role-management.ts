import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RoleItemDto,RolesMutationResult,AssignRolesRequest,RemoveRolesRequest,RoleOptionsDto } from '../../models/role.models';


@Injectable({
  providedIn: 'root'
})
export class RoleManagement {
  private readonly apiRoot  = 'http://localhost:9090/api/v1/murtakiz';
  private readonly baseUrl  = `${this.apiRoot}/org/roles`; 

  constructor(private http: HttpClient) {}

  /** جلب كل الأدوار */
  listAll(): Observable<RoleItemDto[]> {
    return this.http.get<RoleItemDto[]>(this.baseUrl);
  }

   getOptions(empNo: string): Observable<RoleOptionsDto> {
    return this.http.get<RoleOptionsDto>(`${this.baseUrl}/options/${encodeURIComponent(empNo)}`);
  }

  /** إضافة أدوار لمستخدم عبر EMP_NO */
  addRoles(empNo: string, roles: string[]): Observable<RolesMutationResult> {
    const body: AssignRolesRequest = { roles };
    return this.http.post<RolesMutationResult>(`${this.baseUrl}/${encodeURIComponent(empNo)}/roles`, body);
  }

  /** حذف أدوار لمستخدم عبر EMP_NO */
  removeRoles(empNo: string, roles: string[]): Observable<RolesMutationResult> {
    const body: RemoveRolesRequest = { roles };
    return this.http.request<RolesMutationResult>(
      'DELETE',
      `${this.baseUrl}/del/${encodeURIComponent(empNo)}/roles`,
      { body }
    );
  }
}

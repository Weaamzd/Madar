export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  page?: number | null;
  size?: number | null;
  last: boolean;
}

export type LinkState = 'LINKED' | 'UNLINKED';
export type StatusFilter = 'any' | 'active' | 'inactive' | 'suspended';

export type LoginFilter  = 'any' | 'online' | 'offline';

export type PersonSourceType = 'INTERNAL' | 'EXTERNAL';

export interface UnifiedPersonApi {
  sourceType: PersonSourceType;


  empNo?: string | null;
  extEmpId?: string | null;


  fullNameAr?: string | null;
  fullNameEn?: string | null;
  email?: string | null;
  phone?: string | null;
  jobTitle?: string | null;

  hireDate?: string | null;   // ISO
  startDate?: string | null;  // ISO
  managerNo?: string | null;


  organizationName?: string | null;
  collaborationType?: string | null;
  externalStartDate?: string | null;
  externalEndDate?: string | null;
  externalStatus?: string | null;


  subUnite?: { id: number; code?: string; name?: string } | null;
  unite?:    { id: number; code?: string; name?: string } | null;


  user?: {
    id: number;              
    username: string;
    status?: string | null;
    lastLoginAt?: string | null;
    regionId?: number | null;
  } | null;

  regionCode?: string | null;
  regionDbKey?: string | null;

  roles?: string[];
  loggedIn: boolean;
}

export interface PersonRow {
  id: string;
  username: string;
  isExternal: boolean;
  fullNameAr?: string;
  empNo?: string;
  extEmpId?: string;
  email?: string;
  jobTitle?: string;
  department?: string;
  unit?: string;
  regionCode?: string;
  status?: string;
  lastLoginAt: string | null;
  loggedIn: boolean;
  roles: string[];
  hireDate?: string | null;
  startDate?: string | null;


  linkedState: LinkState;   // 'LINKED' | 'UNLINKED'
}


export interface EmployeeOrgInfo {
  empNo: string;
  fullNameAr?: string;
  uniteId?: number | null;
  uniteName?: string | null;
  subUniteId?: number | null;
  subUniteName?: string | null;
  regionCode?: string | null;
  regionDbKey?: string | null;
}


export interface ManagerSummaryDto {
  empNo: string;
  fullNameAr: string;
  subUniteId?: number | null;
  subUniteName?: string | null;
}

export interface EmployeeOrgWithManagersDto {
  empNo: string;
  fullNameAr: string;
  uniteId?: number | null;
  uniteName?: string | null;
  subUniteId?: number | null;
  subUniteName?: string | null;
  manager: boolean;
  managerLevel?: 'NONE' | 'MAIN_UNIT_MANAGER' | 'SUB_UNIT_MANAGER' | string;
  directReportsCount?: number;
  subordinateManagers?: ManagerSummaryDto[];
}

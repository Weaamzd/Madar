

export type RegistrationStage =
  | 'ADMIN_REVIEW'
  | 'SECURITY_REVIEW'
  | 'USER_TERMS';

export type RegistrationStageStatus =
  | 'PENDING'
  | 'APPROVED'
  | 'REJECTED';

export type EmployeeType = 'INTERNAL' | 'EXTERNAL';

export interface UserRegistrationRequestSummaryDto {
  id: number;
  parentRequestId?: number | null;

  currentStage: RegistrationStage;
  stageStatus: RegistrationStageStatus;
  waitingForEmpNo: string | null;
  createdAt: string;

  userId: number;
  username: string;
  userStatus: 'Active' | 'Inactive' | 'Suspended';

  employeeType: EmployeeType;
  empNo: string;
  fullNameAr: string;

  regionId: number;
  regionName: string;

  uniteId: number;
  uniteName: string;
  subUniteId: number;
  subUniteName: string;
}

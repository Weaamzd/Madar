import { ComponentFixture, TestBed } from '@angular/core/testing';

import {RequestCreateAccount } from './createuser';

describe('Createuser', () => {
  let component: RequestCreateAccount;
  let fixture: ComponentFixture<RequestCreateAccount>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RequestCreateAccount]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RequestCreateAccount);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserManagementService } from '../../services/user-management/user-management-service';
import { CreateUserForExistingEmployeeRequest, EmployeeForUserCreationDto, ManagerNameDto } from '../../models/employee-directory.models';
import { FormsModule } from '@angular/forms';
import { UniteMiniDto, SubUniteDto, CurrentRegionDto } from '../../models/org.models';
import { OrgLookup } from '../../services/org/org-lookup';
import { RoleManagement } from '../../services/role/role-management';
import { CreateUserRequest, UserSummaryDto } from '../../models/employee-directory.models';
import { CreateUser } from '../../models/user-admin.models';
import { CreateExternalUserRequest } from '../../models/external-user.models';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule }      from '@angular/material/input';
import { MatDatepickerInputEvent, MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core'; 
import { FlatpickrModule } from 'angularx-flatpickr';
import { Arabic } from 'flatpickr/dist/l10n/ar';
import monthSelectPlugin from 'flatpickr/dist/plugins/monthSelect/index';

import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE, NativeDateAdapter } from '@angular/material/core';

export class ArabicNativeDateAdapter extends NativeDateAdapter {
  override getFirstDayOfWeek(): number { return 6; } 
  override format(date: Date, displayFormat: any): string {
    if (displayFormat === 'input') {
      const dd = String(date.getDate()).padStart(2,'0');
      const mm = String(date.getMonth()+1).padStart(2,'0');
      const yyyy = date.getFullYear();
      return `${dd}/${mm}/${yyyy}`;                 
    }
    return super.format(date, displayFormat);
  }
}

export const AR_DATE_FORMATS = {
  parse:   { dateInput: 'input' },
  display: {
    dateInput: 'input',
    monthYearLabel: 'MMM yyyy',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM yyyy',
  },
};




  Arabic.weekdays.shorthand = ['سبت','أحد','اثن','ثلا','أرب','خمس','جمع'];
type CreatedView = {
  isExternal: boolean;
  empIdLabel: string;
  empIdValue: string | null;
  name: string | null;
  email: string | null;
  jobTitle: string | null;
  orgName: string | null;
  collaborationType: string | null;
  startDate: string | null;
  endDate: string | null;
  subUniteText: string | null;
  lastLoginAt: string | null;
  username: string | null;
  status: 'Active' | 'Inactive' | null;
  regionCode: string | null;
  regionDbKey: string | null;
  roles?: string[];

};




type UserType = 'INTERNAL' | 'EXTERNAL';
interface Manager { no: string; name: string; }
interface SubUnite { id: number; code: string; name: string; }
interface Region { id: number; code: string; name: string; dbKey?: string; }
interface CreateUserPayload {
  username: string;
  password: string;
  status: 'Active' | 'Inactive';
  currentRegionId: number;
  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   // YYYY-MM-DD
  startDate: string;  // YYYY-MM-DD
  managerNo: string;
  subUniteId: number;
  rolesNames: string[];
}

@Component({
  selector: 'app-request-create-account',
  providers: [
    { provide: MAT_DATE_LOCALE, useValue: 'ar-SA' },      
    { provide: DateAdapter, useClass: ArabicNativeDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: AR_DATE_FORMATS },
  ],
  standalone: true,
   imports: [
    CommonModule, ReactiveFormsModule, FormsModule, MatSnackBarModule,
    MatFormFieldModule, MatInputModule, MatDatepickerModule, MatNativeDateModule,FlatpickrModule, 
  ],
  templateUrl: './createuser.html',
  styleUrls: ['./createuser.css']
})
export class RequestCreateAccount implements OnInit {


onMatDate(evt: MatDatepickerInputEvent<Date>, ctrl: 'hireDate'|'startDate') {
  const d = evt.value;
  this.form.get(ctrl)?.setValue(d ? this.toIsoDate(d) : '');
}


private toIsoDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth()+1).padStart(2,'0');
  const day = String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`; 
}
   public Arabic = Arabic; 

 monthPlugins = [
    monthSelectPlugin({
      shorthand: true,       
      dateFormat: "Y-m",     
      altFormat: "F Y",    
      theme: "material-green"
    })
  ];

dateOpts = {
  locale: Arabic,
  altInput: true,
  altFormat: 'd/m/Y',
  dateFormat: 'Y-m-d',
  allowInput: true,
  disableMobile: false,

  onReady: (sel: any, str: string, fp: any) => {
    const cal = fp.calendarContainer as HTMLElement;
    if (!cal) return;


    const monthLabel = cal.querySelector('.flatpickr-current-month .cur-month') as HTMLElement;
    if (!monthLabel) return;
    monthLabel.style.cursor = 'pointer';


    if (cal.querySelector('.month-scroll-menu')) return;

    const menu = document.createElement('div');
    menu.className = 'month-scroll-menu';
    menu.innerHTML = [
      'يناير','فبراير','مارس','أبريل','مايو','يونيو',
      'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'
    ].map((m, i) => `<button type="button" data-i="${i}" class="m-item">${m}</button>`).join('');


    let open = false;
    const toggle = () => {
      open = !open;
      menu.style.display = open ? 'block' : 'none';
    };
    monthLabel.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });

    menu.addEventListener('click', (e: any) => {
      const btn = e.target?.closest('.m-item');
      if (!btn) return;
      const i = Number(btn.getAttribute('data-i'));
      const cur = fp.selectedDates?.[0] || new Date(fp.currentYear, fp.currentMonth, 1);
      fp.setDate(new Date(fp.currentYear, i, cur.getDate() || 1), false);
      fp.changeMonth(i - fp.currentMonth);
      toggle();
    });

    document.addEventListener('click', (evt) => {
      if (!open) return;
      if (!cal.contains(evt.target as Node) && evt.target !== monthLabel) toggle();
    });

    (cal.querySelector('.flatpickr-months') as HTMLElement)?.appendChild(menu);
  }
};

shrinkNativeMonthList(evt: any) {
  const instance = evt?.[2];
  const sel = instance?.monthElements?.[0] as HTMLSelectElement | undefined;
  if (!sel) return;

  sel.setAttribute('size', '6');

  const reset = () => sel.removeAttribute('size');
  sel.addEventListener('blur', reset, { once: true });
}

  candidateLoading = false;
  candidateStatus: 'IDLE' | 'ELIGIBLE' | 'HAS_USER' | 'NOT_FOUND' = 'IDLE';
  candidateDto: EmployeeForUserCreationDto | null = null;

  get isCandidateEligible(): boolean { return this.candidateStatus === 'ELIGIBLE'; }
  get isCandidateHasUser(): boolean { return this.candidateStatus === 'HAS_USER'; }
  get isCandidateNotFound(): boolean { return this.candidateStatus === 'NOT_FOUND'; }



  private runAdvancedEmpCandidateCheck(empNoRaw: string): void {
    const empNo = (empNoRaw || '').trim();
    if (!empNo || this.isExternal) {
      this.resetCandidateState();
      return;
    }

    this.candidateLoading = true;
    this.candidateStatus = 'IDLE';
    this.candidateDto = null;


    this.userService.precheck({ empNo }).subscribe({
      next: dto => {
        const employeeExists = !!dto.employeeExists;
        const userExists = !!dto.userExists;

        if (employeeExists && !userExists) {
 
          this.userService.precheckCandidateByEmpNo(empNo).subscribe({
            next: (full: EmployeeForUserCreationDto | null) => {
              if (full) {
                this.candidateDto = full;
                this.candidateStatus = 'ELIGIBLE';
                this.applyCandidateToForm(full);     
              } else {

                this.candidateStatus = 'NOT_FOUND';
                this.unlockEmployeeFields();         
              }
            },
            error: _ => {
              this.candidateStatus = 'NOT_FOUND';
              this.unlockEmployeeFields();
            },
            complete: () => this.candidateLoading = false
          });
          return;
        }

        if (employeeExists && userExists) {
          this.candidateStatus = 'HAS_USER';
          this.candidateDto = null;
          this.unlockEmployeeFields();              
          this.candidateLoading = false;
          return;
        }

        this.candidateStatus = 'NOT_FOUND';
        this.candidateDto = null;
        this.unlockEmployeeFields();
        this.candidateLoading = false;
      },
      error: _ => {
        this.candidateStatus = 'NOT_FOUND';
        this.candidateDto = null;
        this.unlockEmployeeFields();
        this.candidateLoading = false;
      }
    });
  }

  private resetCandidateState(): void {
    this.candidateLoading = false;
    this.candidateStatus = 'IDLE';
    this.candidateDto = null;
  }

  private applyCandidateToForm(dto: EmployeeForUserCreationDto): void {
    const jt = (dto.jobTitle ?? '').trim();
    this.upsertJobTitle(jt);

this.form.patchValue({
  fullNameAr: dto.fullNameAr ?? '',
  email: dto.email ?? '',
  jobTitle: jt,
  hireDate: dto.hireDate ?? '',
  startDate: dto.startDate ?? '',
  managerNo: dto.managerNo ?? '',
  subUniteId: dto.subUniteId ?? null
}, { emitEvent: false });

this.hydrateOrgFromPrecheck({
  employeeExists: true,
  uniteId: dto.uniteId,
  subUniteId: dto.subUniteId,
  managerNo: dto.managerNo
});

this.lockEmployeeFields();
this.updateManagerNoValidators();
this.updateSubUniteValidators();


  }


  private lockEmployeeFields(): void {
    ['fullNameAr', 'email', 'jobTitle', 'hireDate', 'startDate', 'managerNo', 'subUniteId']
  .forEach(n => this.form.get(n)?.disable({ emitEvent: false }));

  }
  private unlockEmployeeFields(): void {
    ['fullNameAr', 'email', 'jobTitle', 'hireDate', 'startDate', 'managerNo', 'subUniteId']
      .forEach(n => this.form.get(n)?.enable({ emitEvent: false }));
  }


  precheckQuery: string = '';

  precheckLoading = false;
  precheckState: { checked: boolean; userExists: boolean; employeeExists: boolean } | null = null;
  precheckedUsername: string | null = null; 


  startNew() {
    this.form.reset({
      userType: 'INTERNAL',
      isManager: false,
      rolesNames: []
    });
    this.step = 1;
    this.createdResponse = null;
    this.selectedUniteId = this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level1List = this.level2List = this.level3List = this.level4List = [];
    this.currentRegion = null;
    this.regions = [];
    this.updateValidatorsByUserType();
    this.resetCandidateState();
    this.unlockEmployeeFields();

  }
get raw() {
  return this.form.getRawValue() as any;
}


public get createdView(): CreatedView | null {
  const r = this.createdResponse;
  if (!r) return null;

  const f = this.form.getRawValue(); 

  const isExt = 'extEmpId' in r;

  const rawStatus = (r.status ?? f.statusDisplay ?? '').toString().trim().toLowerCase();
  const normalizedStatus: 'Active' | 'Inactive' | null =
    rawStatus === 'active' || rawStatus === 'نشط' ? 'Active' :
    rawStatus === 'inactive' || rawStatus === 'غير نشط' ? 'Inactive' : null;

  const regionId = (r.currentRegionId ?? f.currentRegionId) as number | null | undefined;
  const pickedRegion = this.regions.find(x => x.id === Number(regionId));
  const regionCode = r.regionCode ?? pickedRegion?.code ?? null;
  const regionDbKey = r.regionDbKey ?? pickedRegion?.dbKey ?? null;


  const name =
    (isExt ? (r.fullNameAr ?? f.fullNameAr) : (r.fullName ?? r.fullNameAr ?? f.fullNameAr)) ?? null;

  const subUniteIdFinal =
    (r.subUniteId ?? f.subUniteId) as number | null | undefined;
  const subUniteText =
    (isExt
      ? (r.subUniteName ?? null)
      : (r.subUniteCode && r.subUniteName
          ? `${r.subUniteCode} — ${r.subUniteName}`
          : this.subUnitText(subUniteIdFinal))) ?? null;

  return {
    isExternal: isExt,

    empIdLabel: isExt ? 'extEmpId' : 'EMP_NO',
    empIdValue: (isExt ? (r.extEmpId ?? f.personId) : (r.empNo ?? f.personId)) ?? null,

    name,
    email: (r.email ?? f.email ?? null),
    jobTitle: (r.jobTitle ?? f.jobTitle ?? null),
    orgName: isExt ? (r.organizationName ?? f.organizationName ?? null) : null,
    collaborationType: isExt ? (r.collaborationType ?? f.collaborationType ?? null) : null,
    startDate: (r.startDate ?? f.startDate ?? null),
    endDate: isExt ? (r.endDate ?? f.endDate ?? null) : null,
    subUniteText,

    lastLoginAt: isExt ? null : (r.lastLoginAt ?? null),

    username: (r.username ?? f.username ?? null),
    status: normalizedStatus,
    regionCode,
    regionDbKey,

    roles: (r.roles ?? r.rolesNames ?? f.rolesNames ?? []) as string[],
  };
}



  private allSubs = new Map<number, SubUniteDto>();
  private upsertSubs(list: SubUniteDto[] | null | undefined) {
    (list || []).forEach(s => this.allSubs.set(s.id, s));
  }

  showRaw = false;
  step: number = 1;

  jobTitles: string[] = [
    'محاسب', 'محلل نظم', 'مطوّر واجهات', 'مهندس بيانات', 'أخصائي موارد بشرية', 'مدير مشروع'
  ];

  managers: Manager[] = [];
  managersLoading = false;

  subUnites: SubUnite[] = [];
  regions: Region[] = [];
  currentRegion: CurrentRegionDto | null = null;
  regionLoading = false;

  roles: string[] = [];
  rolesLoading = false;
  isSubmitting = false;

  createdResponse: any = null;

  unitesMini: UniteMiniDto[] = [];

  selectedUniteId: number | null = null;
  selectedLevel1Id: number | null = null;
  selectedLevel2Id: number | null = null;
  selectedLevel3Id: number | null = null;
  selectedLevel4Id: number | null = null;

  level1List: SubUniteDto[] = [];
  level2List: SubUniteDto[] = [];
  level3List: SubUniteDto[] = [];
  level4List: SubUniteDto[] = [];

  form = new FormGroup({
    userType: new FormControl<UserType>('INTERNAL', { nonNullable: true }),

    personId: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),

    fullNameAr: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    email: new FormControl<string>('', { nonNullable: true, validators: [Validators.required, Validators.email] }),
    jobTitle: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    hireDate: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    startDate: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),

    managerNo: new FormControl<string>('', { nonNullable: true }),
    managerEmpNo: new FormControl<string>('', { nonNullable: true }),

    subUniteId: new FormControl<number | null>(null),


    username: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    password: new FormControl<string>('', { nonNullable: true, validators: [Validators.required, Validators.minLength(8)] }),
    statusDisplay: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] }),
    currentRegionId: new FormControl<number | null>(null, { validators: [Validators.required] }),
    rolesNames: new FormControl<string[]>([], { nonNullable: true, validators: [Validators.required] }),


    fullNameEn: new FormControl<string | null>(null),
    phone: new FormControl<string | null>(null),
    organizationName: new FormControl<string>('', { nonNullable: true }),
    collaborationType: new FormControl<string>('', { nonNullable: true }),
    notes: new FormControl<string | null>(null),
    endDate: new FormControl<string | null>(null),

    isManager: new FormControl<boolean>(false, { nonNullable: true }),
    managerScopeType: new FormControl<string>('', { nonNullable: true }),
    managerTargetId: new FormControl<number | null>(null)
  });

private updateManagerNoValidators(): void {
  const ctrlName = this.isExternal ? 'managerEmpNo' : 'managerNo';
  const otherCtrlName = this.isExternal ? 'managerNo' : 'managerEmpNo';
  const ctrl  = this.form.get(ctrlName);
  const other = this.form.get(otherCtrlName);
  if (!ctrl) return;


  if (other) {
    other.clearValidators();
    other.setValue('', { emitEvent: false });
    other.updateValueAndValidity({ onlySelf: true });
  }


  if (!this.isExternal && this.showManagerSelector) {
    ctrl.setValidators([Validators.required]);
  } else {
    ctrl.clearValidators();
  }
  ctrl.updateValueAndValidity({ onlySelf: true });
}

  get isCreatedExternal(): boolean {
    return !!this.createdResponse && 'extEmpId' in this.createdResponse;
  }

  

  private updateSubUniteValidators(): void {
    const ctrl = this.form.get('subUniteId');
    if (!ctrl) return;

    const hasAnySubLevels =
      (this.level1List?.length || 0) > 0 ||
      (this.level2List?.length || 0) > 0 ||
      (this.level3List?.length || 0) > 0 ||
      (this.level4List?.length || 0) > 0;

    if (hasAnySubLevels) ctrl.setValidators([Validators.required]);
    else ctrl.clearValidators();

    ctrl.updateValueAndValidity({ onlySelf: true });
  }

  toggleIsManager(checked: boolean): void {
    this.form.get('isManager')?.setValue(checked);

    const scopeCtrl = this.form.get('managerScopeType');
    const targetCtrl = this.form.get('managerTargetId');

    if (checked) {
      scopeCtrl?.addValidators([Validators.required]);
      targetCtrl?.addValidators([Validators.required]);
      scopeCtrl?.updateValueAndValidity();
      targetCtrl?.updateValueAndValidity();
      this.syncManagerTarget();
    } else {
      scopeCtrl?.setValue('');
      targetCtrl?.setValue(null);
      scopeCtrl?.clearValidators();
      targetCtrl?.clearValidators();
      scopeCtrl?.updateValueAndValidity();
      targetCtrl?.updateValueAndValidity();
    }

    this.updateManagersByContext();
    this.updateManagerNoValidators();
    this.updateSubUniteValidators();
  }

  private pruneSelectionsByScope(): void {
    const scope = this.scope;

    if (scope === 'SUB_L1') {
      this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level2List = this.level3List = this.level4List = [];
      if (this.selectedUniteId && !this.level1List.length) {
        this.orgApi.listDirectUnderUnite(this.selectedUniteId).subscribe({
          next: list => this.level1List = list || [],
          error: () => this.level1List = []
        });
      }
      return;
    }

    if (scope === 'SUB_L2') {
      this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level3List = this.level4List = [];
      return;
    }

    if (scope === 'SUB_L3') {
      this.selectedLevel4Id = null;
      this.level4List = [];
      return;
    }
  }

  onManagerScopeTypeChanged(): void {
    if (!this.form.get('isManager')?.value) return;
    this.syncManagerTarget();

    this.pruneSelectionsByScope();
    this.syncDeepestSelection();
    this.syncManagerTarget();

    this.updateManagersByContext();
    this.updateManagerNoValidators();
  }

  private syncManagerTarget(): void {
    if (!this.form.get('isManager')?.value) {
      this.form.get('managerTargetId')?.setValue(null);
      return;
    }

    const scope = this.form.get('managerScopeType')?.value as string | null;
    let candidate: number | null = null;

    if (scope === 'SUB_L1') candidate = this.selectedLevel1Id ?? null;
    else if (scope === 'SUB_L2') candidate = this.selectedLevel2Id ?? null;
    else if (scope === 'SUB_L3') candidate = this.selectedLevel3Id ?? null;
    else if (scope === 'SUB_L4') candidate = this.selectedLevel4Id ?? null;

    this.form.get('managerTargetId')?.setValue(candidate);
    if (candidate == null) this.form.get('managerTargetId')?.markAsTouched();
  }

  constructor(
    private userService: UserManagementService,
    private orgApi: OrgLookup,
    private rolesApi: RoleManagement,
    private snack: MatSnackBar,    
  ) { }

  private toast(msg: string, cls: 'ok'|'warn'|'err' = 'warn') {
  this.snack.open(msg, 'حسناً', {
    duration: 3500,
    horizontalPosition: 'center',
    verticalPosition: 'top',
    direction: 'rtl',
    panelClass: cls === 'ok' ? ['snack-ok']
               : cls === 'err' ? ['snack-error']
               : ['snack-warn']
  });
}

  private resetPrecheck() {
    this.precheckLoading = false;
    this.precheckState = null;
    this.precheckedUsername = null;
  }

  private buildPrecheckArgs(input: string): { empNo?: string; username?: string } {
    const raw = (input || '').trim();
    const onlyDigits = /^\d+$/.test(raw);
    const empLike = /^(?:E|EMP|EM|X|EXT)?\d+$/i.test(raw);
    const looksUser = /^[a-zA-Z][\w.\-@]*$/.test(raw);
    if (onlyDigits || empLike) return { empNo: raw };
    if (looksUser) return { username: raw };
    return { username: raw };
  }

  private runInternalPrecheck(input: string): void {
    const args = this.buildPrecheckArgs(input);
    this.precheckLoading = true;
    this.precheckState = null;

    this.userService.precheck(args).subscribe({
      next: dto => {
        this.precheckLoading = false;
        this.precheckState = {
          checked: true,
          userExists: !!dto.userExists,
          employeeExists: !!dto.employeeExists
        };

        this.fillFormFromPrecheck(dto);

        this.hydrateOrgFromPrecheck(dto);

        if (dto.username) {
          this.precheckedUsername = dto.username;
          this.form.get('username')?.setValue(dto.username, { emitEvent: false });
        }


        if (dto.roles && dto.roles.length) {
          const rCtrl = this.form.get('rolesNames');
          rCtrl?.setValue(dto.roles, { emitEvent: false });
          rCtrl?.markAsDirty();
        }


        if (dto.status) {
          const display = dto.status.trim().toLowerCase() === 'active' ? 'نشط'
            : dto.status.trim().toLowerCase() === 'inactive' ? 'غير نشط'
              : '';
          if (display) this.form.get('statusDisplay')?.setValue(display, { emitEvent: false });
        }

        if (dto.currentRegionId != null) {
          this.form.get('currentRegionId')?.setValue(dto.currentRegionId, { emitEvent: false });
        }
      },
      error: _ => {
        this.precheckLoading = false;
        this.precheckState = { checked: true, userExists: false, employeeExists: false };
      }
    });
  }


  private hydrateOrgFromPrecheck(dto: any): void {
    const uniteId = Number(dto?.uniteId);
    const targetSubId = Number(dto?.subUniteId);
    if (!Number.isFinite(uniteId) || !Number.isFinite(targetSubId)) return;

    this.selectedUniteId = uniteId;

    this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level1List = this.level2List = this.level3List = this.level4List = [];

    const regionCtrl = this.form.get('currentRegionId');
    this.regionLoading = true;
    this.orgApi.getCurrentRegion(uniteId).subscribe({
      next: (cr) => {
        this.currentRegion = cr;
        const idNum = Number(cr?.id);
        if (Number.isFinite(idNum)) {
          const region: Region = {
            id: idNum,
            code: cr.regionCode,
            name: cr.uniteName || cr.uniteCode || 'Current Region',
            dbKey: cr.regionDbKey
          };
          this.regions = [region];
          regionCtrl?.setValue(idNum, { emitEvent: true });
        } else {
          this.regions = [];
          regionCtrl?.setValue(null, { emitEvent: true });
        }
        this.regionLoading = false;
      },
      error: () => {
        this.currentRegion = null;
        this.regions = [];
        regionCtrl?.setValue(null, { emitEvent: true });
        this.regionLoading = false;
      }
    });

    const applyManagerFromDto = () => {
      if (!dto?.employeeExists) return;

const isMgr = this.isBlank(dto.managerNo); 
if (isMgr) {
  this.form.patchValue({
    isManager: true,
    managerScopeType: 'SUB_L1',
    managerTargetId: this.selectedLevel1Id ?? null
  }, { emitEvent: false });

  this.form.get('managerNo')?.setValue('', { emitEvent: false }); 
} else {
  this.form.patchValue({ isManager: false }, { emitEvent: false });
  this.form.get('managerNo')?.setValue(dto.managerNo, { emitEvent: false });
}


      this.updateManagersByContext();
      this.updateManagerNoValidators();
      this.updateSubUniteValidators();
    };

    this.orgApi.listDirectUnderUnite(uniteId).subscribe({
      next: (lvl1) => {
        this.level1List = lvl1 || [];
        this.upsertSubs(this.level1List);

        const hitL1 = this.level1List.find(s => s.id === targetSubId);
        if (hitL1) {
          this.selectedLevel1Id = targetSubId;
          this.form.get('subUniteId')?.setValue(targetSubId, { emitEvent: false });
          this.finishHydrationUi(applyManagerFromDto); 
          return;
        }

        this.tryFindInChildren(this.level1List, 2, targetSubId, applyManagerFromDto); 
      },
      error: () => { this.level1List = []; }
    });
  }



  private isBlank(x: any): boolean {
    return x == null || (typeof x === 'string' && x.trim() === '');
  }

  private tryFindInChildren(
    parents: SubUniteDto[],
    targetLevel: 2 | 3 | 4,
    targetSubId: number,
    after?: () => void
  ): void {
    const searchIndex = (idx: number) => {
      if (idx >= parents.length) {
        if (targetLevel === 2) this.level2List = this.level2List || [];
        if (targetLevel === 3) this.level3List = this.level3List || [];
        if (targetLevel === 4) this.level4List = this.level4List || [];
        return;
      }

      const parent = parents[idx];
      this.orgApi.listDirectChildren(parent.id).subscribe({
        next: (kids) => {
          const list = kids || [];
          this.upsertSubs(list);

          if (targetLevel === 2) this.level2List = [...(this.level2List || []), ...list];
          if (targetLevel === 3) this.level3List = [...(this.level3List || []), ...list];
          if (targetLevel === 4) this.level4List = [...(this.level4List || []), ...list];

          const hit = list.find(s => s.id === targetSubId);
          if (hit) {
            if (targetLevel === 2) this.selectedLevel1Id = parent.id;
            else if (targetLevel === 3) this.selectedLevel2Id = parent.id;
            else if (targetLevel === 4) this.selectedLevel3Id = parent.id;

            if (targetLevel === 2) this.selectedLevel2Id = targetSubId;
            if (targetLevel === 3) this.selectedLevel3Id = targetSubId;
            if (targetLevel === 4) this.selectedLevel4Id = targetSubId;

            this.form.get('subUniteId')?.setValue(targetSubId, { emitEvent: false });
            this.finishHydrationUi(after);
            return;
          }

          if (targetLevel < 4 && list.length) {
            this.tryFindInChildren(list, (targetLevel + 1) as 3 | 4, targetSubId, () => {
              if (this.form.get('subUniteId')?.value !== targetSubId) {
                searchIndex(idx + 1); 
              }
            });
          } else {
            searchIndex(idx + 1);
          }
        },
        error: () => searchIndex(idx + 1)
      });
    };

    searchIndex(0);
  }


  private finishHydrationUi(after?: () => void): void {
    this.syncDeepestSelection();
    this.syncManagerTarget();
    this.updateManagersByContext();
    this.updateManagerNoValidators();
    this.updateSubUniteValidators();

    if (after) after();
  }

  private fillFormFromPrecheck(dto: any) {

    if (dto.employeeExists) {
      if (dto.fullNameAr) this.form.get('fullNameAr')?.setValue(dto.fullNameAr, { emitEvent: false });
      if (dto.email) this.form.get('email')?.setValue(dto.email, { emitEvent: false });
      if (dto.jobTitle) {
        const jt = (dto.jobTitle || '').trim();   
        this.upsertJobTitle(jt);
        this.form.get('jobTitle')?.setValue(jt, { emitEvent: false });
      }
      if (dto.hireDate) this.form.get('hireDate')?.setValue(dto.hireDate, { emitEvent: false });
      if (dto.startDate) this.form.get('startDate')?.setValue(dto.startDate, { emitEvent: false });
      if (dto.managerNo) this.form.get('managerNo')?.setValue(dto.managerNo, { emitEvent: false });


      if (dto.subUniteId != null) {
        this.form.get('subUniteId')?.setValue(dto.subUniteId, { emitEvent: false });
      }
    }

    if (dto.userExists) {
      if (dto.username) this.form.get('username')?.setValue(dto.username, { emitEvent: false });
    }


  }


  ngOnInit(): void {
    const personIdCtrl = this.form.get('personId') as FormControl<string>;
    const usernameCtrl = this.form.get('username') as FormControl<string>;
    personIdCtrl.valueChanges.subscribe((v: string) => {
      const cleaned = (v || '').toString().trim().replace(/\s+/g, '');
      usernameCtrl.setValue(cleaned, { emitEvent: false });
    });

    this.form.get('personId')!.valueChanges
      .pipe(
        map(v => (v || '').toString().trim()),
        debounceTime(400),
        distinctUntilChanged(),
        filter(() => this.form.get('userType')!.value === 'INTERNAL'),
        filter(v => v.length >= 2)
      )
      .subscribe(val => this.runInternalPrecheck(val));

    this.form.get('userType')!.valueChanges.subscribe(() => {
      this.resetPrecheck();
    });

    this.form.get('personId')!.valueChanges
      .pipe(
        map(v => (v || '').toString().trim()),
        debounceTime(400),
        distinctUntilChanged(),
        filter(() => this.form.get('userType')!.value === 'INTERNAL'),
        filter(v => v.length >= 2)
      )
      .subscribe(empNo => this.runAdvancedEmpCandidateCheck(empNo));


    this.loadUnitesMini();
    this.loadRolesFromServer();
    this.updateManagerNoValidators();
    this.updateManagersByContext();
    this.updateSubUniteValidators();

    this.form.get('userType')!.valueChanges.subscribe(() => this.updateValidatorsByUserType());
    this.updateValidatorsByUserType();

    (this.form.get('personId')!).valueChanges.subscribe(() => this.runPrecheck());
    (this.form.get('username')!).valueChanges.subscribe(() => this.runPrecheck());
  }

  get isExternal(): boolean {
    return this.form.get('userType')!.value === 'EXTERNAL';
  }

  private updateValidatorsByUserType(): void {

    this.setRequired('personId', true);


    this.setRequired('hireDate', !this.isExternal);
    this.setRequired('managerNo', !this.isExternal);


    this.setRequired('organizationName', this.isExternal);
    this.setRequired('collaborationType', this.isExternal);

    this.setRequired('startDate', true);


    const mExt = this.form.get('managerEmpNo')!;
    mExt.clearValidators();
    mExt.updateValueAndValidity();


    if (this.isExternal) {
      this.form.get('isManager')?.setValue(false, { emitEvent: false });
      this.form.get('managerScopeType')?.setValue('', { emitEvent: false });
      this.form.get('managerTargetId')?.setValue(null, { emitEvent: false });
      this.form.get('managerNo')?.setValue('', { emitEvent: false });
    }

    this.updateSubUniteValidators();
    this.updateManagerNoValidators();
  }

  private setRequired(ctrlName: string, on: boolean) {
    const c = this.form.get(ctrlName);
    if (!c) return;
    if (on) c.setValidators([Validators.required]);
    else c.clearValidators();
    c.updateValueAndValidity({ onlySelf: true });
  }


  touched(ctrl: string): boolean {
    const c = this.form.get(ctrl);
    return !!c && (c.touched || c.dirty);
  }
  hasError(ctrl: string, err: string): boolean {
    const c = this.form.get(ctrl);
    return !!c && !!c.errors?.[err];
  }

  subUnitText(id: number | string | null | undefined): string {
    if (id == null) return '';
    const num = typeof id === 'string' ? Number(id) : id;
    if (!Number.isFinite(num)) return '';
    const s = this.allSubs.get(num);
    return s ? `${s.code} — ${s.name}` : '';
  }

  regionText(id: number | string | null | undefined): string {
    if (id == null) return '';
    const num = typeof id === 'string' ? Number(id) : id;
    if (Number.isNaN(num)) return '';
    const r = this.regions.find(x => x.id === num);
    return r ? `${r.code} — ${r.name}` : '';
  }

  get internalStepValid(): boolean {
    return !this.isExternal &&
      this.form.get('personId')!.valid &&
      this.form.get('fullNameAr')!.valid &&
      this.form.get('email')!.valid &&
      this.form.get('jobTitle')!.valid &&
      this.form.get('hireDate')!.valid &&
      this.form.get('startDate')!.valid &&
      this.form.get('managerNo')!.valid &&
      this.form.get('subUniteId')!.valid;
  }

  get externalStepValid(): boolean {
    return this.isExternal &&
      this.form.get('personId')!.valid &&
      this.form.get('fullNameAr')!.valid &&
      this.form.get('organizationName')!.valid &&
      this.form.get('collaborationType')!.valid &&
      this.form.get('startDate')!.valid &&
      this.form.get('subUniteId')!.valid;
  }

  get accountStepValid(): boolean {
    const rolesVal = this.form.get('rolesNames')!.value as string[] | null | undefined;
    return this.form.get('username')!.valid &&
      this.form.get('password')!.valid &&
      this.form.get('statusDisplay')!.valid &&
      this.form.get('currentRegionId')!.valid &&
      ((rolesVal?.length || 0) > 0);
  }

  get employeeStepValid(): boolean {
    if (this.isCandidateEligible) return true;             
    return this.isExternal ? this.externalStepValid : this.internalStepValid;
  }


goNext(): void {
  if (this.isCandidateHasUser) {
    this.toast('الموظف مرتبط بحساب قائم. إيقاف الإجراء.', 'err');
    return;
  }
  if (this.step === 1 && !this.employeeStepValid) { this.touchEmployeeStep(); return; }
  if (this.step === 2 && !this.accountStepValid) { this.touchAccountStep(); return; }
  if (this.step < 3) this.step++;
}



  goPrev(): void {
    if (this.step > 1) this.step--;
  }

  touchEmployeeStep(): void {
    if (this.isExternal) {
      ['personId', 'fullNameAr', 'organizationName', 'collaborationType', 'startDate', 'subUniteId']
        .forEach(n => this.form.get(n)?.markAsTouched());
    } else {
      ['personId', 'fullNameAr', 'email', 'jobTitle', 'hireDate', 'startDate', 'managerNo', 'subUniteId']
        .forEach(n => this.form.get(n)?.markAsTouched());
    }
  }

  touchAccountStep(): void {
    ['username', 'password', 'statusDisplay', 'currentRegionId', 'rolesNames']
      .forEach(n => this.form.get(n)?.markAsTouched());
  }


  private runPrecheck() {
    if (this.isExternal) {
      this.precheckState = null;
      return;
    }

    const empNo = (this.form.value.personId || '').trim();
    const username = (this.form.value.username || '').trim();
    if (!empNo && !username) return;

    this.precheckLoading = true;
    this.precheckState = null;

    this.userService.precheck({ empNo, username }).subscribe({
      next: dto => {
        this.precheckState = {
          checked: true,
          userExists: !!dto.userExists,
          employeeExists: !!dto.employeeExists
        };

        if (dto.employeeExists) {
          if (dto.jobTitle) this.upsertJobTitle(dto.jobTitle);
          this.form.patchValue({
            fullNameAr: dto.fullNameAr ?? this.form.value.fullNameAr,
            email: dto.email ?? this.form.value.email,
            jobTitle: dto.jobTitle ?? this.form.value.jobTitle,
            hireDate: dto.hireDate ?? this.form.value.hireDate,
            startDate: dto.startDate ?? this.form.value.startDate,
            managerNo: dto.managerNo ?? this.form.value.managerNo,
            subUniteId: dto.subUniteId ?? this.form.value.subUniteId,
            currentRegionId: (dto.currentRegionId ?? this.form.value.currentRegionId) as any,
          }, { emitEvent: true });
        }

        if (dto.userExists) {
          this.form.patchValue({
            statusDisplay: (dto.status?.toLowerCase() === 'active') ? 'نشط' : 'غير نشط',
            rolesNames: dto.roles ?? this.form.value.rolesNames
          }, { emitEvent: true });
        }
      },
      error: () => {
        this.precheckState = { checked: true, userExists: false, employeeExists: false };
      },
      complete: () => this.precheckLoading = false
    });
  }




  onCreate(): void {
    if (this.isExternal) {
      if (!this.externalStepValid) { this.touchEmployeeStep(); this.touchAccountStep(); return; }
      this.isSubmitting = true;
      this.userService.createExternalUser(this.buildPayload() as CreateExternalUserRequest)
        .subscribe({
          next: (res) => { this.createdResponse = res; this.step = 3; this.isSubmitting = false; },
          error: (err) => { alert(err?.error?.message || 'فشل إنشاء المستخدم الخارجي'); this.isSubmitting = false; }
        });
      return;
    }

    // INTERNAL:
    if (!this.accountStepValid) { this.touchAccountStep(); }
    if (!this.internalStepValid && this.candidateStatus !== 'ELIGIBLE') {
      this.touchEmployeeStep();
      return;
    }

    if (this.isCandidateHasUser) {
      this.toast('هذا الموظف لديه حساب مستخدم بالفعل — لا يمكنك إنشاء حساب جديد.', 'err');
  return;
    }

    this.isSubmitting = true;

    if (this.isCandidateEligible && this.candidateDto) {

      const status: 'Active' | 'Inactive' = (this.form.value.statusDisplay === 'نشط') ? 'Active' : 'Inactive';
      const rawRegionId = this.form.value.currentRegionId;
      const currentRegionId = (rawRegionId == null || rawRegionId === -1) ? null : Number(rawRegionId);

      const req: CreateUserForExistingEmployeeRequest = {
        empNo: this.candidateDto.empNo,
        username: this.form.value.username!,
        password: this.form.value.password!,
        status,
        currentRegionId,
        rolesNames: this.form.value.rolesNames || []
      };

      this.userService.createUserForExistingEmployee(req).subscribe({
        next: (res) => { this.createdResponse = res; this.step = 3; this.isSubmitting = false; },
        error: (err) => { this.toast(err?.error?.message || 'فشل إصدار حساب للموظف', 'err'); this.isSubmitting = false; }
      });
      return;
    }

    const payload = this.buildPayload() as CreateUser;
    this.userService.createUser(payload).subscribe({
      next: (res) => { this.createdResponse = res; this.step = 3; this.isSubmitting = false; },
      error: (err) => { this.toast(err?.error?.message || 'فشل إنشاء المستخدم', 'err');this.isSubmitting = false; }
    });
  }

  


  private onCreateInternal(): void {
    if (!this.employeeStepValid || !this.accountStepValid) {
      this.touchEmployeeStep(); this.touchAccountStep(); return;
    }

    const status: 'Active' | 'Inactive' = (this.form.value.statusDisplay === 'نشط') ? 'Active' : 'Inactive';
    const currentRegionId = this.form.value.currentRegionId == null ? null : Number(this.form.value.currentRegionId);
    const managerNo = (this.form.value.managerNo || '').trim() || null;

    const req: CreateUser = {
      username: this.form.value.username!,
      password: this.form.value.password!,
      status,
      currentRegionId,
      empNo: this.form.value.personId!,         
      fullNameAr: this.form.value.fullNameAr!,
      email: this.form.value.email!,
      jobTitle: this.form.value.jobTitle!,
      hireDate: this.form.value.hireDate!,
      startDate: this.form.value.startDate!,
      managerNo,
      subUniteId: Number(this.form.value.subUniteId),
      rolesNames: this.form.value.rolesNames || []
    };

    this.isSubmitting = true;
    this.userService.createUser(req).subscribe({
      next: (res) => { this.createdResponse = res; this.step = 3; this.isSubmitting = false; },
      error: (err) => { alert(err?.error?.message || 'فشل إنشاء المستخدم'); this.isSubmitting = false; }
    });
  }

  private onCreateExternal(): void {
    if (!this.accountStepValid || !this.form.get('subUniteId')!.valid || !this.form.get('personId')!.valid || !this.form.get('organizationName')!.valid || !this.form.get('collaborationType')!.valid) {
      this.touchEmployeeStep(); this.touchAccountStep(); return;
    }

    const status: 'Active' | 'Inactive' = (this.form.value.statusDisplay === 'نشط') ? 'Active' : 'Inactive';
    const currentRegionId = this.form.value.currentRegionId == null ? null : Number(this.form.value.currentRegionId);

    const req: CreateExternalUserRequest = {
      extEmpId: this.form.value.personId!,       
      username: this.form.value.username!,
      password: this.form.value.password!,
      status,
      currentRegionId,

      fullNameAr: this.form.value.fullNameAr!,
      fullNameEn: this.form.value.fullNameEn || null,
      email: this.form.value.email || null,
      phone: this.form.value.phone || null,
      organizationName: this.form.value.organizationName!,
      jobTitle: this.form.value.jobTitle || null,
      collaborationType: this.form.value.collaborationType!,
      startDate: this.form.value.startDate!,
      endDate: this.form.value.endDate || null,
      notes: this.form.value.notes || null,

      managerEmpNo: (this.form.value.managerEmpNo || '').trim() || null,
      subUniteId: Number(this.form.value.subUniteId),

      rolesNames: this.form.value.rolesNames || []
    };

    this.isSubmitting = true;
    this.userService.createExternalUser(req).subscribe({
      next: (res) => { this.createdResponse = res; this.step = 3; this.isSubmitting = false; },
      error: (err) => { alert(err?.error?.message || 'فشل إنشاء المستخدم الخارجي'); this.isSubmitting = false; }
    });
  }

  private loadUnitesMini(): void {
    this.orgApi.listAllUnitesMini().subscribe({
      next: data => this.unitesMini = data || [],
      error: () => this.unitesMini = []
    });
  }

  onUniteChanged(uniteIdRaw: any): void {
    const uniteId = Number(uniteIdRaw);
    this.selectedUniteId = Number.isFinite(uniteId) ? uniteId : null;

    this.selectedLevel1Id = this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
    this.level1List = this.level2List = this.level3List = this.level4List = [];
    this.currentRegion = null;
    this.regions = [];

    const regionCtrl = this.form.get('currentRegionId');
    regionCtrl?.setValue(null, { emitEvent: false });
    regionCtrl?.updateValueAndValidity({ onlySelf: true });

    if (!this.selectedUniteId) {
      this.form.get('subUniteId')?.setValue(null);
      this.updateManagersByContext();
      this.updateSubUniteValidators();
      return;
    }


    this.orgApi.listDirectUnderUnite(this.selectedUniteId).subscribe({
      next: list => { this.level1List = list || []; this.syncDeepestSelection(); },
      error: () => { this.level1List = []; this.syncDeepestSelection(); }
    });

    this.regionLoading = true;
    this.orgApi.getCurrentRegion(this.selectedUniteId).subscribe({
      next: (cr) => {
        this.currentRegion = cr;
        const idNum = Number(cr?.id);
        const safeRegionId = Number.isFinite(idNum) ? idNum : null;

        if (safeRegionId != null) {
          const region: Region = {
            id: safeRegionId,
            code: cr.regionCode,
            name: cr.uniteName || cr.uniteCode || 'Current Region',
            dbKey: cr.regionDbKey
          };
          this.regions = [region];
          regionCtrl?.setValue(safeRegionId, { emitEvent: true });
          regionCtrl?.updateValueAndValidity({ onlySelf: true });
        } else {
          this.regions = [];
          regionCtrl?.setValue(null, { emitEvent: true });
          regionCtrl?.updateValueAndValidity({ onlySelf: true });
        }
        this.regionLoading = false;
      },
      error: () => {
        this.currentRegion = null;
        this.regions = [];
        regionCtrl?.setValue(null, { emitEvent: true });
        this.regionLoading = false;
      }
    });

    this.orgApi.listDirectUnderUnite(this.selectedUniteId).subscribe({
      next: list => {
        this.level1List = list || [];
        this.upsertSubs(this.level1List);
        this.syncDeepestSelection();
      },
      error: () => {
        this.level1List = [];
        this.syncDeepestSelection();
      }
    });

    this.syncManagerTarget();
    this.updateManagersByContext();
    this.updateManagerNoValidators();
    this.updateSubUniteValidators();
  }

  onLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
    const subId = Number(subIdRaw);

    if (level === 1) {
      this.selectedLevel1Id = Number.isFinite(subId) ? subId : null;
      this.selectedLevel2Id = this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level2List = this.level3List = this.level4List = [];
      if (this.selectedLevel1Id) this.loadChildren(this.selectedLevel1Id, 2);
    } else if (level === 2) {
      this.selectedLevel2Id = Number.isFinite(subId) ? subId : null;
      this.selectedLevel3Id = this.selectedLevel4Id = null;
      this.level3List = this.level4List = [];
      if (this.selectedLevel2Id) this.loadChildren(this.selectedLevel2Id, 3);
    } else if (level === 3) {
      this.selectedLevel3Id = Number.isFinite(subId) ? subId : null;
      this.selectedLevel4Id = null;
      this.level4List = [];
      if (this.selectedLevel3Id) this.loadChildren(this.selectedLevel3Id, 4);
    } else {
      this.selectedLevel4Id = Number.isFinite(subId) ? subId : null;
    }

    this.syncDeepestSelection();
    this.syncManagerTarget();

    this.updateManagersByContext();
    this.updateManagerNoValidators();
    this.updateSubUniteValidators();
  }

  private loadChildren(parentSubUniteId: number, targetLevel: 2 | 3 | 4): void {
    this.orgApi.listDirectChildren(parentSubUniteId).subscribe({
      next: (kids) => {
        if (targetLevel === 2) this.level2List = kids || [];
        if (targetLevel === 3) this.level3List = kids || [];
        if (targetLevel === 4) this.level4List = kids || [];
        this.upsertSubs(kids);
        this.syncDeepestSelection();
      },
      error: () => {
        if (targetLevel === 2) this.level2List = [];
        if (targetLevel === 3) this.level3List = [];
        if (targetLevel === 4) this.level4List = [];
        this.syncDeepestSelection();
      }
    });
  }

  private syncDeepestSelection(): void {
    const ctrl = this.form.get('subUniteId');
    const deepest =
      this.selectedLevel4Id ??
      this.selectedLevel3Id ??
      this.selectedLevel2Id ??
      this.selectedLevel1Id ??
      null;

    ctrl?.setValue(deepest);
  }

  loadRegions(): void {
    this.regions = [
      { id: 1, code: 'ENG-CENTRAL', name: 'الهندسية - الوسطى', dbKey: 'db1' },
      { id: 2, code: 'ENG-EAST', name: 'الهندسية - الشرقية', dbKey: 'db2' },
      { id: 3, code: 'ENG-WEST', name: 'الهندسية - الغربية', dbKey: 'db3' }
    ];
  }

  private loadRolesFromServer(): void {
    this.rolesLoading = true;
    this.rolesApi.listAll().subscribe({
      next: (items) => {
        this.roles = (items || []).map((r: any) => r.name || r.code || r.roleName).filter(Boolean);
        this.rolesLoading = false;
      },
      error: () => {
        this.roles = [];
        this.rolesLoading = false;
      }
    });
  }

  isRoleSelected(role: string): boolean {
    const val = (this.form.get('rolesNames')?.value as string[]) || [];
    return val.includes(role);
  }

  toggleRole(role: string, checked: boolean): void {
    const ctrl = this.form.get('rolesNames') as FormControl<string[]>;
    const current = ctrl.value || [];
    const next = checked
      ? Array.from(new Set([...current, role]))
      : current.filter(r => r !== role);

    ctrl.setValue(next);
    ctrl.markAsDirty();
    ctrl.updateValueAndValidity();
  }

  showReviewJson = false;

  private buildPayload(): CreateUser | CreateExternalUserRequest {
    const status: 'Active' | 'Inactive' = (this.form.value.statusDisplay === 'نشط') ? 'Active' : 'Inactive';
    const rawRegionId = this.form.value.currentRegionId;
    const currentRegionId = (rawRegionId == null || rawRegionId === -1) ? null : Number(rawRegionId);

    if (this.isExternal) {
      const req: CreateExternalUserRequest = {
        extEmpId: this.form.value.personId!,           
        username: this.form.value.username!,
        password: this.form.value.password!,
        status,
        currentRegionId,

        fullNameAr: this.form.value.fullNameAr!,
        fullNameEn: this.form.value.fullNameEn || null,
        email: this.form.value.email || null,
        phone: this.form.value.phone || null,
        organizationName: this.form.value.organizationName!,
        jobTitle: this.form.value.jobTitle || null,
        collaborationType: this.form.value.collaborationType!,
        startDate: this.form.value.startDate!,
        endDate: this.form.value.endDate || null,
        notes: this.form.value.notes || null,

        managerEmpNo: (this.form.value.managerEmpNo || '').trim() || null,
        subUniteId: Number(this.form.value.subUniteId),
        rolesNames: this.form.value.rolesNames || []
      };
      return req;
    }

    const managerNoRaw = (this.form.value.managerNo as string) ?? '';
    const managerNo = managerNoRaw.trim() === '' ? null : managerNoRaw.trim();

    const req: CreateUser = {
      username: this.form.value.username!,
      password: this.form.value.password!,
      status,
      currentRegionId,

      empNo: this.form.value.personId!,              
      fullNameAr: this.form.value.fullNameAr!,
      email: this.form.value.email!,
      jobTitle: this.form.value.jobTitle!,
      hireDate: this.form.value.hireDate!,
      startDate: this.form.value.startDate!,
      managerNo,
      subUniteId: Number(this.form.value.subUniteId),
      rolesNames: this.form.value.rolesNames || []
    };
    return req;
  }

  previewRequest() {
    return this.buildPayload();
  }

  get isMgr(): boolean {
    return !!this.form.get('isManager')?.value;
  }
  get scope(): string {
    return (this.form.get('managerScopeType')?.value as string) || '';
  }

  get showUnite(): boolean { return true; }

  get showL1(): boolean {
    if (!this.isMgr) return this.level1List.length > 0;
    return ['SUB_L1', 'SUB_L2', 'SUB_L3', 'SUB_L4'].includes(this.scope) && this.level1List.length > 0;
  }
  get showL2(): boolean {
    if (!this.isMgr) return this.level2List.length > 0;
    return ['SUB_L2', 'SUB_L3', 'SUB_L4'].includes(this.scope) && this.level2List.length > 0;
  }
  get showL3(): boolean {
    if (!this.isMgr) return this.level3List.length > 0;
    return ['SUB_L3', 'SUB_L4'].includes(this.scope) && this.level3List.length > 0;
  }
  get showL4(): boolean {
    if (!this.isMgr) return this.level4List.length > 0;
    return ['SUB_L4'].includes(this.scope) && this.level4List.length > 0;
  }

get deepestSelectionReached(): boolean {
  if (this.form.get('subUniteId')?.value) return true;

  if (!this.selectedUniteId) return false;
  if (this.level1List.length > 0 && !this.selectedLevel1Id) return false;
  if (this.level2List.length > 0 && !this.selectedLevel2Id) return false;
  if (this.level3List.length > 0 && !this.selectedLevel3Id) return false;
  if (this.level4List.length > 0 && !this.selectedLevel4Id) return false;
  return true;
}


get showManagerSelector(): boolean {
  return !this.isExternal && !this.form.get('isManager')?.value;
}



private updateManagersByContext(): void {
  const managerCtrlName = this.isExternal ? 'managerEmpNo' : 'managerNo';
  this.form.get(managerCtrlName)?.setValue('', { emitEvent: false });

  if (!this.isExternal && this.isMgr && this.scope === 'SUB_L1') {
    this.managers = [];
    this.managersLoading = false;
    return;
  }

  const uniteId = this.selectedUniteId ?? null;
  const l1 = this.selectedLevel1Id ?? null;
  const l2 = this.selectedLevel2Id ?? null;
  const l3 = this.selectedLevel3Id ?? null;
  const l4 = this.selectedLevel4Id ?? null;

  const formSubId = Number(this.form.get('subUniteId')?.value) || null;
  const candidateSubId = (this.isCandidateEligible && this.candidateDto)
    ? Number(this.candidateDto.subUniteId) || null
    : null;

  let query: { uniteId?: number | null; subUniteId?: number | null } = {};
  const deepest = l4 ?? l3 ?? l2 ?? l1 ?? formSubId ?? candidateSubId ?? null;
  query = deepest ? { subUniteId: deepest } : { uniteId };

  if (this.isMgr) {
    if (this.scope === 'SUB_L1')      query = { uniteId };
    else if (this.scope === 'SUB_L2') query = { subUniteId: l1 ?? formSubId ?? candidateSubId ?? null };
    else if (this.scope === 'SUB_L3') query = { subUniteId: l2 ?? formSubId ?? candidateSubId ?? null };
    else if (this.scope === 'SUB_L4') query = { subUniteId: l3 ?? formSubId ?? candidateSubId ?? null };
  }

  if ((query.uniteId ?? query.subUniteId ?? null) == null) {
    this.managers = [];
    this.managersLoading = false;
    return;
  }

  this.managersLoading = true;
  this.userService.listManagersByScope(query).subscribe({
    next: (rows: ManagerNameDto[]) => {
      this.managers = (rows || []).map(r => ({ no: r.empNo, name: r.fullNameAr }));

      if (this.managers.length === 1) {
        this.form.get(managerCtrlName)?.setValue(this.managers[0].no, { emitEvent: true });
      }

      const presetFromDto = this.isExternal
        ? (this.form.value.managerEmpNo || null)
        : (this.form.value.managerNo || this.candidateDto?.managerNo || null);

      if (presetFromDto && this.managers.some(m => m.no === presetFromDto)) {
        this.form.get(managerCtrlName)?.setValue(presetFromDto, { emitEvent: true });
      }
    },
    error: () => { this.managers = []; },
    complete: () => { this.managersLoading = false; }
  });
}


  private upsertJobTitle(title?: string | null): void {
    const t = (title ?? '').toString().trim();
    if (!t) return;
    if (!this.jobTitles.includes(t)) {
      this.jobTitles = [t, ...this.jobTitles];
    }
  }

  clearEmployeeStep(): void {
  const markClean = (names: string[]) => {
    names.forEach(n => {
      const c = this.form.get(n);
      if (!c) return;
      c.markAsPristine();
      c.markAsUntouched();
      c.updateValueAndValidity({ onlySelf: true });
    });
  };

  if (this.isExternal) {
    this.form.patchValue({
      personId: '', fullNameAr: '', fullNameEn: null, phone: null,
      organizationName: '', collaborationType: '', jobTitle: '',
      startDate: '', endDate: null, notes: null,
      subUniteId: null, managerEmpNo: ''
    }, { emitEvent: false });

    markClean([
      'personId','fullNameAr','fullNameEn','phone','organizationName','collaborationType',
      'jobTitle','startDate','endDate','notes','subUniteId','managerEmpNo'
    ]);
  } else {
    this.form.patchValue({
      personId: '', fullNameAr: '', email: '', jobTitle: '',
      hireDate: '', startDate: '', managerNo: '', subUniteId: null
    }, { emitEvent: false });

    markClean([
      'personId','fullNameAr','email','jobTitle','hireDate','startDate','managerNo','subUniteId'
    ]);
  }

  this.selectedUniteId = this.selectedLevel1Id = this.selectedLevel2Id =
    this.selectedLevel3Id = this.selectedLevel4Id = null;
  this.level1List = this.level2List = this.level3List = this.level4List = [];
  this.currentRegion = null; this.regions = [];
  this.form.get('currentRegionId')?.setValue(null, { emitEvent: false });
  markClean(['currentRegionId']);


  this.resetCandidateState();
  this.resetPrecheck?.();
  this.unlockEmployeeFields();

  this.form.patchValue({
    isManager: false,         
    managerScopeType: '',     
    managerTargetId: null,    
    managerNo: '',             
    managerEmpNo: ''          
  }, { emitEvent: true });      

  this.updateManagersByContext();
  this.updateManagerNoValidators();
  this.updateSubUniteValidators();
}


}

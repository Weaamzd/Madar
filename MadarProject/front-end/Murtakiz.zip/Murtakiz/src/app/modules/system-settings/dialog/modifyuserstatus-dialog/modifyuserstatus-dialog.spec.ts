import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyuserstatusDialog } from './modifyuserstatus-dialog';

describe('ModifyuserstatusDialog', () => {
  let component: ModifyuserstatusDialog;
  let fixture: ComponentFixture<ModifyuserstatusDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModifyuserstatusDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModifyuserstatusDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

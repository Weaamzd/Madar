import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  UniteDto, UniteMiniDto,
  SubUniteDto, SubUniteTreeDto, CurrentRegionDto
} from '../../models/org.models';

@Injectable({ providedIn: 'root' })
export class OrgLookup {
  private readonly apiRoot = 'http://localhost:9090/api/v1/murtakiz/org';

  constructor(private http: HttpClient) {}

  /** GET /sub-units/{id} */
getSubUnite(id: number): Observable<SubUniteDto> {
  return this.http.get<SubUniteDto>(`${this.apiRoot}/sub-units/${id}`);
}


  /** GET /unites/{id} */
  getUnite(id: number): Observable<UniteDto> {
    return this.http.get<UniteDto>(`${this.apiRoot}/unites/${id}`);
  }

  /** GET /unites/{uniteId}/sub-units  (مباشرة تحت الوحدة) */
  listDirectUnderUnite(uniteId: number): Observable<SubUniteDto[]> {
    return this.http.get<SubUniteDto[]>(`${this.apiRoot}/unites/${uniteId}/sub-units`);
  }

  /** GET /unites/{uniteId}/sub-units/tree?depth= */
  getUniteSubtree(uniteId: number, depth: number = 4): Observable<SubUniteTreeDto[]> {
    const params = new HttpParams().set('depth', String(depth));
    return this.http.get<SubUniteTreeDto[]>(`${this.apiRoot}/unites/${uniteId}/sub-units/tree`, { params });
  }

  /** GET /sub-units/{subUniteId}/children */
  listDirectChildren(subUniteId: number): Observable<SubUniteDto[]> {
    return this.http.get<SubUniteDto[]>(`${this.apiRoot}/sub-units/${subUniteId}/children`);
  }

  /** GET /sub-units/{subUniteId}/subtree?depth= */
  getSubUniteSubtree(subUniteId: number, depth: number = 4): Observable<SubUniteTreeDto> {
    const params = new HttpParams().set('depth', String(depth));
    return this.http.get<SubUniteTreeDto>(`${this.apiRoot}/sub-units/${subUniteId}/subtree`, { params });
  }

  /** GET /unites */
  listAllUnites(): Observable<UniteDto[]> {
    return this.http.get<UniteDto[]>(`${this.apiRoot}/unites`);
  }

  /** GET /unites/mini */
  listAllUnitesMini(): Observable<UniteMiniDto[]> {
    return this.http.get<UniteMiniDto[]>(`${this.apiRoot}/unites/mini`);
  }

   /** GET /unites/{uniteId}/current-region */
  getCurrentRegion(uniteId: number): Observable<CurrentRegionDto> {
    return this.http.get<CurrentRegionDto>(`${this.apiRoot}/unites/${uniteId}/current-region`);
  }
}

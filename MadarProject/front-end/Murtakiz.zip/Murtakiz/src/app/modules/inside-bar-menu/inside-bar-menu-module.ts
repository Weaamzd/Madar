import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InsideBarMenuRoutingModule } from './inside-bar-menu-routing-module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InsideBarMenuRoutingModule
  ]
})
export class InsideBarMenuModule { }

import { Component, Input, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../core/auth/authService';


export interface SubUniteMiniDto { id: number; code: string; name: string; }
export interface UniteMiniDto { id: number; code: string; name: string; }

export interface InternalEmployeeDetailsDto {
  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;
  startDate: string;
  managerNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}

export interface ExternalEmployeeDetailsDto {
  id: string;
  fullNameAr: string;
  fullNameEn: string;
  email: string;
  phone: string;
  organizationName: string;
  jobTitle: string;
  collaborationType: string;
  startDate: string;
  endDate: string | null;
  status: string;
  notes: string;
  managerEmpNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}

export interface UserMiniDto {
  userId: number;
  username: string;
  status: string;
  lastLoginAt: string;
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
}

export interface UserFullProfileDto {
  profileType: 'INTERNAL' | 'EXTERNAL' | 'UNLINKED';
  user: UserMiniDto;
  roles: string[];
  loggedIn: boolean;
  internalDetails: InternalEmployeeDetailsDto | null;
  externalDetails: ExternalEmployeeDetailsDto | null;
}


export interface UserSummary {
  userId: number;
  username: string;
  empNo: string;
  fullName: string;
  email: string;
  jobTitle: string;
  regionCode: string;
  regionDbKey: string;
  roles: string[];
}


export interface AboutItem { label: string; value: string; }
export interface UserCard {
  name: string;        
  title: string;       
  bio: string;         
  type: 'INTERNAL' | 'EXTERNAL' | 'UNLINKED';
  username: string;
  status: string;
  lastLoginAt: string | null;
  regionCode: string | null;
  regionDbKey: string | null;
  roles: string[];

  email?: string | null;

  empNo?: string | null;
  hireDate?: string | null;
  startDate?: string | null;
  subUnite?: string | null;
  unite?: string | null;


  externalId?: string | null;
  organizationName?: string | null;
  collaborationType?: string | null;
  managerEmpNo?: string | null;

  about: AboutItem[];
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './user-profile.html',
  styleUrls: ['./user-profile.css'],
})
export class UserProfile {

  private auth = inject(AuthService);


  @Input() user: UserCard | null = null;

  loading = signal(false);
  errorMsg = signal<string | null>(null);

  readonly profileSig = this.auth.profileSig;

  readonly cardFromProfile = computed<UserCard | null>(() => {
    const p = this.profileSig();
    if (!p) return null;
    return this.fromFullProfile(p);
  });

  ngOnInit() {
    if (this.user) return; 

    const p = this.profileSig();
    if (p) {
      this.user = this.fromFullProfile(p);
      return;
    }

    const cachedSummary = this.auth.userSig();
    if (cachedSummary) {
      this.user = this.fromUserSummary(cachedSummary);
    }

    this.loading.set(true);
    this.auth.ensureMe().subscribe({
      next: (u) => {
        this.loading.set(false);
        const freshProfile = this.profileSig();
        if (freshProfile) {
          this.user = this.fromFullProfile(freshProfile);
        } else if (u) {
          this.user = this.fromUserSummary(u);
        } else {
          this.errorMsg.set('لا توجد بيانات مستخدم.');
        }
      },
      error: () => {
        this.loading.set(false);
        this.errorMsg.set('تعذّر جلب الملف الشخصي.');
      }
    });
  }

  private fromFullProfile(p: UserFullProfileDto): UserCard {
    const t = p.profileType;
    const base = p.user;

    const isInternal = t === 'INTERNAL' && !!p.internalDetails;
    const isExternal = t === 'EXTERNAL' && !!p.externalDetails;

    const username  = base.username ?? '-';
    const status    = base.status ?? '-';
    const lastLogin = base.lastLoginAt ?? null;
    const region    = base.regionCode ?? null;
    const dbKey     = base.regionDbKey ?? null;
    const roles     = p.roles ?? [];

    const name = isInternal
      ? (p.internalDetails!.fullNameAr || username)
      : isExternal
        ? (p.externalDetails!.fullNameAr || username)
        : (username || '-');

    const title = isInternal
      ? (p.internalDetails!.jobTitle || '—')
      : isExternal
        ? (p.externalDetails!.jobTitle || '—')
        : '—';

    const email = isInternal
      ? (p.internalDetails!.email || null)
      : isExternal
        ? (p.externalDetails!.email || null)
        : null;

    const bioParts: string[] = [];
    bioParts.push(`@${username}`);
    if (isInternal && p.internalDetails!.empNo) bioParts.push(`موظف #${p.internalDetails!.empNo}`);
    if (isExternal && p.externalDetails!.id)    bioParts.push(`خارجي #${p.externalDetails!.id}`);
    if (region) bioParts.push(`منطقة ${region}`);
    const bio = bioParts.join(' • ');

    const empNo     = isInternal ? (p.internalDetails!.empNo ?? null) : null;
    const hireDate  = isInternal ? (p.internalDetails!.hireDate ?? null) : null;
    const startDate = isInternal ? (p.internalDetails!.startDate ?? null) : null;
    const subUnite  = isInternal && p.internalDetails!.subUnite
      ? `${p.internalDetails!.subUnite.name} (${p.internalDetails!.subUnite.code})`
      : isExternal && p.externalDetails!.subUnite
        ? `${p.externalDetails!.subUnite.name} (${p.externalDetails!.subUnite.code})`
        : null;
    const unite     = isInternal && p.internalDetails!.unite
      ? `${p.internalDetails!.unite.name} (${p.internalDetails!.unite.code})`
      : isExternal && p.externalDetails!.unite
        ? `${p.externalDetails!.unite.name} (${p.externalDetails!.unite.code})`
        : null;

    const externalId        = isExternal ? (p.externalDetails!.id ?? null) : null;
    const organizationName  = isExternal ? (p.externalDetails!.organizationName ?? null) : null;
    const collaborationType = isExternal ? (p.externalDetails!.collaborationType ?? null) : null;
    const managerEmpNo      = isExternal ? (p.externalDetails!.managerEmpNo ?? null) : null;

    const about: AboutItem[] = [];
    about.push({ label: 'نوع الملف', value: t });
    about.push({ label: 'اسم المستخدم', value: username || '—' });
    about.push({ label: 'الحالة', value: status || '—' });
    if (lastLogin) about.push({ label: 'آخر دخول', value: lastLogin });

    if (email) about.push({ label: 'البريد', value: email });
    if (region) about.push({ label: 'المنطقة', value: region });
    if (dbKey)  about.push({ label: 'قاعدة البيانات', value: dbKey });

    if (isInternal) {
      if (empNo)     about.push({ label: 'الرقم الوظيفي', value: empNo });
      if (hireDate)  about.push({ label: 'تاريخ التعيين', value: hireDate });
      if (startDate) about.push({ label: 'تاريخ المباشرة', value: startDate });
      if (subUnite)  about.push({ label: 'القسم', value: subUnite });
      if (unite)     about.push({ label: 'الوحدة', value: unite });
    }

    if (isExternal) {
      if (externalId)        about.push({ label: 'رقم الخارجي', value: externalId });
      if (organizationName)  about.push({ label: 'المنشأة', value: organizationName });
      if (collaborationType) about.push({ label: 'نوع التعاقد', value: collaborationType });
      if (managerEmpNo)      about.push({ label: 'رقم مديره', value: managerEmpNo });
      if (subUnite)          about.push({ label: 'القسم', value: subUnite });
      if (unite)             about.push({ label: 'الوحدة', value: unite });
    }

    return {
      name,
      title,
      bio,
      type: t,
      username,
      status,
      lastLoginAt: lastLogin,
      regionCode: region,
      regionDbKey: dbKey,
      roles,
      email,

      empNo,
      hireDate,
      startDate,
      subUnite,
      unite,

      externalId,
      organizationName,
      collaborationType,
      managerEmpNo,

      about,
    };
  }

  private fromUserSummary(u: UserSummary): UserCard {
    const enabledStr = localStorage.getItem('enabled');
    const enabled = enabledStr === 'true' ? 'Active' : enabledStr === 'false' ? 'Disabled' : (enabledStr ?? '-');

    const name = u.fullName || u.username || '-';
    const title = u.jobTitle || '—';
    const bioParts: string[] = [];
    bioParts.push(`@${u.username}`);
    if (u.empNo) bioParts.push(`موظف #${u.empNo}`);
    if (u.regionCode) bioParts.push(`منطقة ${u.regionCode}`);
    const bio = bioParts.join(' • ');

    const about: AboutItem[] = [
      { label: 'نوع الملف', value: '—' },
      { label: 'اسم المستخدم', value: u.username || '—' },
      { label: 'الحالة', value: enabled },
      { label: 'الاسم', value: u.fullName || '—' },
      { label: 'الرقم الوظيفي', value: u.empNo || '—' },
      { label: 'المسمى الوظيفي', value: u.jobTitle || '—' },
      { label: 'المنطقة', value: u.regionCode || '—' },
      { label: 'قاعدة البيانات', value: u.regionDbKey || '—' },
    ];

    return {
      name,
      title,
      bio,
      type: 'UNLINKED',
      username: u.username,
      status: enabled,
      lastLoginAt: null,
      regionCode: u.regionCode,
      regionDbKey: u.regionDbKey,
      roles: u.roles ?? [],
      email: null,
      about,
    };
  }
}

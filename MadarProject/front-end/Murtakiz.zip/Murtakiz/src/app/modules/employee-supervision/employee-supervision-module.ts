import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeSupervisionRoutingModule } from './employee-supervision-routing-module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EmployeeSupervisionRoutingModule
  ]
})
export class EmployeeSupervisionModule { }

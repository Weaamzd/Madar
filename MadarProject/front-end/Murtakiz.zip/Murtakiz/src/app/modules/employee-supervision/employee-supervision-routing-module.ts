import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeSupervision } from './pages/employee-supervision/employee-supervision';

const routes: Routes = [
  { path: 'supervision', component: EmployeeSupervision  },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeSupervisionRoutingModule { }

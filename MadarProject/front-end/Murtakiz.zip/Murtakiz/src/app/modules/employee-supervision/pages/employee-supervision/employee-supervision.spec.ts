import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeSupervision } from './employee-supervision';

describe('EmployeeSupervision', () => {
  let component: EmployeeSupervision;
  let fixture: ComponentFixture<EmployeeSupervision>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeSupervision]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployeeSupervision);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, ViewChild, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule, PageEvent, MatPaginatorIntl } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSortModule } from '@angular/material/sort';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SelectionModel } from '@angular/cdk/collections';
import { take } from 'rxjs';

import { UserManagementService } from '../../../system-settings/services/user-management/user-management-service';
import { DelegationFullDetailsDto, DelegationRow } from '../../../delegation/models/delegations.models';
import { Delegations } from '../../../delegation/services/delegations';
import { UnifiedPersonDetailsDto } from '../../../system-settings/models/employee-directory.models';
import { AuthService } from '../../../../core/auth/authService';
import { EmployeeOrgWithManagersDto } from '../../../system-settings/models/people-directory.models';

import { EmployeeDetailsDialog } from '../../../system-settings/dialog/employee-details-dialog/employee-details-dialog';
import { ModifyuserstatusDialog } from '../../../system-settings/dialog/modifyuserstatus-dialog/modifyuserstatus-dialog';
import { ModifyuserpermissionDialog } from '../../../system-settings/dialog/modifyuserpermission-dialog/modifyuserpermission-dialog';

import { DelegationDetailsDialog } from '../../../delegation/dialog/delegation-details-dialog/delegation-details-dialog';

@Component({
  selector: 'app-employee-supervision',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatTableModule, MatPaginatorModule, MatProgressSpinnerModule,
    MatIconModule, MatButtonModule, MatTooltipModule, MatSortModule, MatDialogModule,
    MatCheckboxModule
  ],
  templateUrl: './employee-supervision.html',
  styleUrls: ['./employee-supervision.css']
})
export class EmployeeSupervision implements OnInit {

  openMassAction() { /* TODO */ }
  exportEmployees() { /* TODO */ }


  orgManagers?: EmployeeOrgWithManagersDto | null = null;
  isManager = false;

  managerCards: Array<{
    empNo: string;
    fullNameAr: string;
    subUniteId: number | null;
    subUniteName: string;
  }> = [];

  managerNoFilter: string | null = null; 

  tab: 'employees' | 'byScope' = 'employees';
  loading = false;

  searchText = '';
  searchActive = false;

  readonly sortOptions = [
    { label: 'الأحدث تسجيل دخول', value: 'lastLoginDesc' },
    { label: 'الأقدم تسجيل دخول', value: 'lastLoginAsc' },
    { label: 'اسم المستخدم (أ-ي)', value: 'userAsc' },
    { label: 'اسم المستخدم (ي-أ)', value: 'userDesc' },
    { label: 'اسم الموظف (أ-ي)', value: 'nameAsc' },
    { label: 'اسم الموظف (ي-أ)', value: 'nameDesc' },
  ] as const;
  selectedSort = 'lastLoginDesc';

  statusFilterEmp: 'any' | 'active' | 'inactive' | 'suspended' = 'any';
  statusFilterOptionsEmp = [
    { label: 'الكل', value: 'any' },
    { label: 'نشط', value: 'active' },
    { label: 'غير نشط', value: 'inactive' },
    { label: 'موقوف', value: 'suspended' },
  ];

  linkedFilterEmp: 'ALL' | 'LINKED' | 'UNLINKED' = 'ALL';
  linkedFilterOptionsEmp = [
    { label: 'الكل (مرتبط/غير مرتبط)', value: 'ALL' },
    { label: 'مرتبط', value: 'LINKED' },
    { label: 'غير مرتبط', value: 'UNLINKED' },
  ];

  loginFilterEmp: 'any' | 'online' | 'offline' = 'any';
  loginFilterOptionsEmp = [
    { label: 'الكل', value: 'any' },
    { label: 'متصل الآن', value: 'online' },
    { label: 'غير متصل', value: 'offline' },
  ];


  unites: { id:number; name:string }[] = [];
  subUnites: { id:number; name:string }[] = [];
  selectedUniteId: number | null = null;
  selectedSubUniteId: number | null = null;

  dataSource: any[] = [];                
  private _pageRawRows: any[] = [];      
  displayedColumns = [
    'select',
    'username',
    'fullNameAr',
    'idSmart',
    'jobTitle',
    'department',
    'unit',
    'isExternal',
    'hasUser',
    'status',
    'online',
    'lastLoginAt',
    'actions'
  ];
  totalElements = 0;
  pageIndex = 0;
  pageSize = 10;

  selection = new SelectionModel<any>(true, []);

  get totalUsers(){ return this.totalElements; }
  get activeCount(){ return (this.dataSource || []).filter(x=> (x.status || '').toLowerCase() === 'active').length; }
  get loggedInCount(){ return (this.dataSource || []).filter(x=> x.loggedIn).length; }


  delegRows: DelegationRow[] = [];
  displayedColumnsDeleg = [
    'delegationId',
    'status',
    'delegatorName',
    'delegateeName',
    'window',
    'actions'
  ];

  searchTextDeleg = '';
  searchDelegActive = false;

  readonly sortOptionsDeleg = [
    { label: 'الأحدث إنشاءً', value: 'createdDesc' },
    { label: 'الأقدم إنشاءً', value: 'createdAsc' },
    { label: 'المفوِّض (أ-ي)', value: 'delegatorAsc' },
    { label: 'المفوِّض (ي-أ)', value: 'delegatorDesc' },
    { label: 'المفوَّض له (أ-ي)', value: 'delegateeAsc' },
    { label: 'المفوَّض له (ي-أ)', value: 'delegateeDesc' },
  ] as const;
  selectedSortDeleg: typeof this.sortOptionsDeleg[number]['value'] = 'createdDesc';

  totalElementsDeleg = 0;
  pageIndexDeleg = 0;
  pageSizeDeleg = 10;

  private _delegAllRows: DelegationRow[] = [];

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild('paginatorDeleg') paginatorDeleg!: MatPaginator;

  constructor(
    private svc: UserManagementService,
    private delegSvc: Delegations,
    private dialog: MatDialog,
    private auth: AuthService,
    paginatorIntl: MatPaginatorIntl
  ) {
    paginatorIntl.itemsPerPageLabel = 'عدد العناصر في الصفحة:';
    paginatorIntl.nextPageLabel = 'الصفحة التالية';
    paginatorIntl.previousPageLabel = 'الصفحة السابقة';
    paginatorIntl.firstPageLabel = 'الأولى';
    paginatorIntl.lastPageLabel = 'الأخيرة';
    paginatorIntl.getRangeLabel = (page, pageSize, length) => {
      if (length === 0 || pageSize === 0) return '0 من 0';
      const startIndex = page * pageSize;
      const endIndex = Math.min(startIndex + pageSize, length);
      return `${startIndex + 1}–${endIndex} من ${length}`;
    };
    paginatorIntl.changes.next();
  }

  ngOnInit(): void {
    this.loadUnitesAndSubUnites();

    const ctxEmp = this.auth.ctxEmpNo?.();
    if (ctxEmp) {
      this.loading = true;
      this.svc.getOrgByEmpNo(ctxEmp).pipe(take(1)).subscribe({
        next: (org) => {
          const uId = (org as any)?.uniteId ?? (org as any)?.unite?.id ?? null;
          const sId = (org as any)?.subUniteId ?? (org as any)?.subUnite?.id ?? null;

          this.selectedUniteId = uId;
          this.selectedSubUniteId = sId;

          this.fetchEmployeesWithScope(uId, sId);
          this.fetchDelegationsByScope();

          this.loadManagerCards(ctxEmp);
        },
        error: () => {
          this.fetchEmployees();
          this.fetchDelegationsByScope();
        },
        complete: () => { this.loading = false; }
      });
      return;
    }

    this.auth.ensureMe().pipe(take(1)).subscribe({
      next: (user) => {
        const empFromProfile = user?.empNo ?? null;
        if (empFromProfile) {
          this.loading = true;
          this.svc.getOrgByEmpNo(empFromProfile).pipe(take(1)).subscribe({
            next: (org) => {
              const uId = (org as any)?.uniteId ?? (org as any)?.unite?.id ?? null;
              const sId = (org as any)?.subUniteId ?? (org as any)?.subUnite?.id ?? null;

              this.selectedUniteId = uId;
              this.selectedSubUniteId = sId;

              this.fetchEmployeesWithScope(uId, sId);
              this.fetchDelegationsByScope();

              this.loadManagerCards(empFromProfile);
            },
            error: () => {
              this.fetchEmployees();
              this.fetchDelegationsByScope();
            },
            complete: () => { this.loading = false; }
          });
        } else {
          this.fetchEmployees();
          this.fetchDelegationsByScope();
        }
      },
      error: () => {
        this.fetchEmployees();
        this.fetchDelegationsByScope();
      }
    });
  }

  private loadManagerCards(myEmpNo: string) {
    this.svc.getOrgWithManagers(myEmpNo).pipe(take(1)).subscribe({
      next: (dto) => {
        this.orgManagers = dto;
        this.isManager = !!dto?.manager;

        const list = dto?.subordinateManagers || [];
        this.managerCards = list.map(m => ({
          empNo: m.empNo,
          fullNameAr: m.fullNameAr,
          subUniteId: m.subUniteId ?? null,
          subUniteName: m.subUniteName || '—'
        }));
      },
      error: () => {
        this.orgManagers = null;
        this.isManager = false;
        this.managerCards = [];
      }
    });
  }

  filterByManager(card: { empNo: string; subUniteId: number | null }) {
    this.managerNoFilter = card.empNo;

    if (card.subUniteId) {
      this.selectedSubUniteId = card.subUniteId;
      this.selectedUniteId = null;
    }

    this.pageIndex = 0;
    this.fetchEmployees();
  }

  clearManagerFilter() {
    this.managerNoFilter = null;
    this.pageIndex = 0;
    this.fetchEmployees();
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.length;
    return numSelected === numRows && numRows > 0;
  }
  masterToggle() {
    if (this.isAllSelected()) this.selection.clear();
    else this.selection.select(...this.dataSource);
  }
  checkboxLabel(row?: any): string {
    if (!row) return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.empNo || row.extEmpId || ''}`;
  }


  fetchEmployeesWithScope(uniteId: number | null, subUniteId: number | null) {
    this.loading = true;

    const uId = (uniteId !== null && uniteId !== undefined) ? uniteId : null;
    const sId = (subUniteId !== null && subUniteId !== undefined) ? subUniteId : null;

    if (uId === null && sId === null) { this.fetchEmployees(); return; }

    const callUniteId   = (uId === null && sId !== null) ? 0 : uId;
    const callSubUniteId= (sId === null && uId !== null) ? 0 : sId;

    this.svc.listPeople({
      uniteId: callUniteId,
      subUniteId: callSubUniteId,
      q: null,
      fullNameAr: null,
      username: null,
      managerNo: this.managerNoFilter ?? null, 
      page: this.pageIndex,
      size: this.pageSize
    }).pipe(take(1)).subscribe({
      next: (page) => {
        this._pageRawRows = (page.content || []).map((x:any)=> this.mapPerson(x));
        this.totalElements = page.totalElements ?? this._pageRawRows.length;
        this.selection.clear();
        this.applyEmployeesFrontFiltersAndSort();
      },
      error: (err)=> console.error('listPeople failed', err),
      complete: ()=> this.loading = false
    });
  }

  setTab(t: 'employees'|'byScope') { this.tab = t; }
  refreshAll(){ this.fetchEmployees(); if(this.tab==='byScope') this.fetchDelegationsByScope(); }

  loadUnitesAndSubUnites(){
    this.unites = [];
    this.subUnites = [];
  }

  fetchBySearch(){ this.pageIndex = 0; this.fetchEmployees(); }

  buildPeopleParams(){
    const p: any = {};
    const hasSelectedUnit = this.selectedUniteId !== null && this.selectedUniteId !== undefined;
    const hasSelectedSub  = this.selectedSubUniteId !== null && this.selectedSubUniteId !== undefined;

    if(!this.searchText?.trim()){
      if(hasSelectedUnit || hasSelectedSub){
        p.uniteId   = hasSelectedUnit ? this.selectedUniteId : (hasSelectedSub ? 0 : null);
        p.subUniteId= hasSelectedSub  ? this.selectedSubUniteId: (hasSelectedUnit ? 0 : null);
      }
    } else {
      const raw = this.searchText.trim();
      if(/^\d+$/.test(raw)) p.empNo = raw;
      else if(/^[a-zA-Z][\w.\-@]*$/.test(raw)) p.username = raw;
      else p.fullNameAr = raw;
    }

    if (this.managerNoFilter) {
      p.managerNo = this.managerNoFilter;
    }

    p.page = this.pageIndex; p.size = this.pageSize;
    return p;
  }

  fetchEmployees(){
    this.loading = true;
    const params = this.buildPeopleParams();

    this.svc.listPeople({
      uniteId: params.uniteId ?? null,
      subUniteId: params.subUniteId ?? null,
      q: params.empNo ?? null,
      fullNameAr: params.fullNameAr ?? null,
      username: params.username ?? null,
      managerNo: params.managerNo ?? null, 
      page: params.page, size: params.size
    }).pipe(take(1)).subscribe({
      next: (page) => {
        this._pageRawRows = (page.content || []).map((x:any)=> this.mapPerson(x));
        this.totalElements = page.totalElements ?? this._pageRawRows.length;
        this.selection.clear();
        this.applyEmployeesFrontFiltersAndSort();
      },
      error: (err)=> console.error(err),
      complete: ()=> this.loading = false
    });
  }

  mapPerson(api: UnifiedPersonDetailsDto){
    const isExternal = (api as any)?.sourceType === 'EXTERNAL';
    const hasUser = !!(api as any)?.hasUser || !!api.user;

    return {
      username: api.user?.username ?? '',
      fullNameAr: api.fullNameAr,
      empNo: api.empNo,
      extEmpId: api.extEmpId,
      jobTitle: api.jobTitle ?? '—',
      department: api.unite?.name ?? '',
      unit: api.subUnite?.name ?? '',
      status: api.user?.status ?? '—',
      loggedIn: !!api.loggedIn,
      isExternal,
      hasUser,
      lastLoginAt: api.user?.lastLoginAt ?? null
    } as any;
  }

  chooseId(r:any){ return r.isExternal ? (r.extEmpId || r.empNo) : (r.empNo || r.extEmpId); }

  getStatusBadgeClass(s?:string){
    const st=(s||'').toLowerCase();
    if(st==='active') return 'status-done';
    if(st==='inactive') return 'status-rejected';
    if(st==='suspended') return 'status-pending';
    return 'status-pending';
  }

  getOnlineBadgeClass(isOnline:boolean){
    return isOnline ? 'status-done' : 'status-rejected';
  }

  onPage(e: PageEvent){
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.fetchEmployees();
  }

  onStatusFilterChangeEmp(v: typeof this.statusFilterEmp){
    this.statusFilterEmp = v;
    this.applyEmployeesFrontFiltersAndSort();
  }
  onLinkedFilterChangeEmp(v: typeof this.linkedFilterEmp){
    this.linkedFilterEmp = v;
    this.applyEmployeesFrontFiltersAndSort();
  }
  onLoginFilterChangeEmp(v: typeof this.loginFilterEmp){
    this.loginFilterEmp = v;
    this.applyEmployeesFrontFiltersAndSort();
  }
  sortChangedEmp(key: string) {
    this.selectedSort = key;
    this.applyEmployeesFrontFiltersAndSort();
  }

  private applyEmployeesFrontFiltersAndSort() {

    let rows = [...this._pageRawRows];

    if (this.statusFilterEmp !== 'any') {
      const want = this.statusFilterEmp.toLowerCase();
      rows = rows.filter(r => (r.status || '').toString().toLowerCase() === want);
    }

    if (this.loginFilterEmp !== 'any') {
      const wantOnline = this.loginFilterEmp === 'online';
      rows = rows.filter(r => !!r.loggedIn === wantOnline);
    }

    switch (this.selectedSort) {
      case 'lastLoginDesc':
        rows.sort((a,b)=>(b.lastLoginAt?+new Date(b.lastLoginAt):0)-(a.lastLoginAt?+new Date(a.lastLoginAt):0)); break;
      case 'lastLoginAsc':
        rows.sort((a,b)=>(a.lastLoginAt?+new Date(a.lastLoginAt):0)-(b.lastLoginAt?+new Date(b.lastLoginAt):0)); break;
      case 'userAsc':
        rows.sort((a,b)=>(a.username||'').localeCompare(b.username||'','ar')); break;
      case 'userDesc':
        rows.sort((a,b)=>(b.username||'').localeCompare(a.username||'','ar')); break;
      case 'nameAsc':
        rows.sort((a,b)=>(a.fullNameAr||'').localeCompare(b.fullNameAr||'','ar')); break;
      case 'nameDesc':
        rows.sort((a,b)=>(b.fullNameAr||'').localeCompare(a.fullNameAr||'','ar')); break;
    }

    if (this.linkedFilterEmp === 'LINKED') {
      rows = rows.filter(r => !!r.hasUser === true);
    } else if (this.linkedFilterEmp === 'UNLINKED') {
      rows = rows.filter(r => !!r.hasUser === false);
    } else {
      rows.sort((a, b) => (b.hasUser ? 1 : 0) - (a.hasUser ? 1 : 0));
    }

    this.dataSource = rows;
  }

  onView(row: any) {
    const isExternal = !!row.isExternal;
    if (isExternal) {
      if (!row.extEmpId) { alert('لا يوجد معرّف خارجي (extEmpId).'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'EXTERNAL', extEmpId: row.extEmpId }
      });
    } else {
      if (!row.empNo) { alert('لا يوجد رقم وظيفي (empNo).'); return; }
      this.dialog.open(EmployeeDetailsDialog, {
        width: '990px',
        maxWidth: '95vw',
        direction: 'rtl',
        data: { sourceType: 'INTERNAL', empNo: row.empNo }
      });
    }
  }

  openModifyStatusDialog(row: any) {
    if (!row?.username) { alert('لا يوجد حساب مستخدم مرتبط.'); return; }
    const current = this.normalizeStatus(row.status);
    this.dialog.open(ModifyuserstatusDialog, {
      direction: 'rtl',
      width: '990px',
      maxWidth: '95vw',
      panelClass: 'custom-dialog-container',
      data: {
        empNo: row.empNo ?? null,
        extEmpId: row.extEmpId ?? null,
        fullName: row.fullNameAr,
        username: row.username,
        currentStatus: current
      },
    }).afterClosed().subscribe(result => {
      if (result && result.newStatus) {
        row.status = result.newStatus;
        this.applyEmployeesFrontFiltersAndSort();
      }
    });
  }

  openModifyPermissionDialog(row: any) {
    if (!row?.username) { alert('لا يوجد حساب مستخدم مرتبط.'); return; }
    this.dialog.open(ModifyuserpermissionDialog, {
      direction: 'rtl',
      width: '990px',
      maxWidth: '95vw',
      panelClass: 'custom-dialog-container',
      data: {
        empNo: row.empNo ?? null,
        extEmpId: row.extEmpId ?? null,
        fullName: row.fullNameAr,
        username: row.username,
        currentRoles: row.roles ?? []
      },
    }).afterClosed().subscribe(() => {
      this.applyEmployeesFrontFiltersAndSort();
    });
  }

  private normalizeStatus(s?: string): 'Active' | 'Inactive' | undefined {
    const v = (s || '').trim().toLowerCase();
    if (v === 'active' || v === 'نشط') return 'Active';
    if (v === 'inactive' || v === 'غير نشط') return 'Inactive';
    return undefined;
  }

  async onScopeChange(){
    await Promise.resolve();
    this.fetchEmployeesWithScope(this.selectedUniteId, this.selectedSubUniteId);
    this.fetchDelegationsByScope();
  }

  private buildDelegScopeParams(){
    const hasUnit = this.selectedUniteId !== null && this.selectedUniteId !== undefined;
    const hasSub  = this.selectedSubUniteId !== null && this.selectedSubUniteId !== undefined;

    const uniteId   = hasUnit ? this.selectedUniteId : (hasSub ? 0 : null);
    const subUniteId= hasSub  ? this.selectedSubUniteId: (hasUnit ? 0 : null);

    return { uniteId, subUniteId };
  }

  public fetchDelegationsByScope(){
    const scope = this.buildDelegScopeParams();

    this.loading = true;
    this.delegSvc.listByScopeFull({
      uniteId: scope.uniteId ?? null,
      subUniteId: scope.subUniteId ?? null,
      page: 0, size: 1000,
      unpaged: true as any
    } as any).pipe(take(1)).subscribe({
      next: (page) => {
        const raw = (page?.content || []) as DelegationFullDetailsDto[];
        const rows = raw.map(d => this.mapDelegApiToRow(d));
        this._delegAllRows = rows;
        this.applySortDeleg();
        this.applySearchDeleg();
      },
      error: (err)=> {
        console.error('listByScopeFull failed', err);
        this._delegAllRows = [];
        this.delegRows = [];
        this.totalElementsDeleg = 0;
      },
      complete: ()=> this.loading = false
    });
  }

  private mapDelegApiToRow(d: DelegationFullDetailsDto): DelegationRow {
    const win = d.noExpiry ? 'بدون انتهاء'
      : (d.startAt
          ? (d.endAt ? `${d.startAt.slice(0,16).replace('T',' ')} → ${d.endAt.slice(0,16).replace('T',' ')}`
                     : `${d.startAt.slice(0,16).replace('T',' ')} → —`)
          : '—');
    return {
      delegationId: d.delegationId,
      status: d.status,
      delegatorName: d.delegatorFullNameAr || d.delegatorUsername || d.delegatorEmpNo,
      delegateeName: d.delegateeFullNameAr || d.delegateeUsername || d.delegateeEmpNo,
      window: win,
      createdAt: d.createdAt ?? d.startAt ?? ''
    } as any;
  }

  getDelegStatusBadge(st:any){
    const s=(st||'').toLowerCase();
    if(s==='active') return 'status-done';
    if(s==='pending') return 'status-pending';
    if(s==='rejected' || s==='revoked' || s==='expired') return 'status-rejected';
    return 'status-pending';
  }

  private filteredCache: DelegationRow[] = [];

  private applySortDeleg() {
    const ds = [...this._delegAllRows];
    switch (this.selectedSortDeleg) {
      case 'createdDesc':
        ds.sort((a:any,b:any)=> +new Date(b.createdAt||0) - +new Date(a.createdAt||0)); break;
      case 'createdAsc':
        ds.sort((a:any,b:any)=> +new Date(a.createdAt||0) - +new Date(b.createdAt||0)); break;
      case 'delegatorAsc':
        ds.sort((a,b)=> (a.delegatorName||'').localeCompare(b.delegatorName||'', 'ar')); break;
      case 'delegatorDesc':
        ds.sort((a,b)=> (b.delegatorName||'').localeCompare(a.delegatorName||'', 'ar')); break;
      case 'delegateeAsc':
        ds.sort((a,b)=> (a.delegateeName||'').localeCompare(b.delegateeName||'', 'ar')); break;
      case 'delegateeDesc':
        ds.sort((a,b)=> (b.delegateeName||'').localeCompare(a.delegateeName||'', 'ar')); break;
    }
    this.filteredCache = ds;
  }

  private applySearchDeleg(){
    const q = (this.searchTextDeleg || '').trim().toLowerCase();
    let base = this.filteredCache;
    if (q) {
      base = base.filter(r => (
        `${r.delegationId||''} ${r.status||''} ${r.delegatorName||''} ${r.delegateeName||''} ${r.window||''}`
        .toLowerCase().includes(q)
      ));
    }
    this.totalElementsDeleg = base.length;
    const start = this.pageIndexDeleg * this.pageSizeDeleg;
    const end   = start + this.pageSizeDeleg;
    this.delegRows = base.slice(start, end);
  }

  applyFilterDeleg(evt: Event){
    this.searchTextDeleg = (evt.target as HTMLInputElement).value?.trim() ?? '';
    this.pageIndexDeleg = 0;
    this.applySortDeleg();
    this.applySearchDeleg();
  }

  sortChangedDeleg(key: typeof this.selectedSortDeleg){
    this.selectedSortDeleg = key;
    this.pageIndexDeleg = 0;
    this.applySortDeleg();
    this.applySearchDeleg();
  }

  onPageDeleg(e: PageEvent){
    this.pageIndexDeleg = e.pageIndex;
    this.pageSizeDeleg = e.pageSize;
    this.applySearchDeleg();
  }

  openDelegationDetails(row: DelegationRow) {
    this.dialog.open(DelegationDetailsDialog, {
      direction: 'rtl',
      width: '1000px',
      maxWidth: '95vw',
      data: { delegationId: row.delegationId }
    });
  }
}

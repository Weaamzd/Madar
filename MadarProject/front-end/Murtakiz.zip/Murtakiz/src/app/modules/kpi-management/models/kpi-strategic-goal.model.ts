export interface CreateKpiStrategicGoalRequest {
  code: string;
  nameAr: string;
  perspectiveCode: string;

  // نوع الهدف: مثلاً "STRATEGIC" أو "OPERATIONAL"
  goalType: string;

  ownerEmpNo?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;

  regionCode?: string | null;

  horizonFromYear: number;
  horizonToYear: number;


  parentGoalCode?: string | null;
}

export interface KpiStrategicGoalDto {
  id: number;
  code: string;
  nameAr: string;
  perspectiveCode: string;

  goalType: string;

  ownerEmpNo?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;
  regionCode?: string | null;

  horizonFromYear: number;
  horizonToYear: number;

  parentGoalCode?: string | null;

  statusCode?: string | null;
  progressPct?: number | null;
  kpiCount?: number | null;

  createdAt?: string | null;
  createdByEmpNo?: string | null;
  updatedAt?: string | null;
  updatedByEmpNo?: string | null;
}

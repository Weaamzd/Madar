import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  CreateKpiIndicatorRequest,
  KpiIndicatorDto
} from '../models/kpi-indicator.model';

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}


@Injectable({
  providedIn: 'root',
})
export class KpiIndicator {

  private baseUrl = 'http://localhost:9090/api/v1/murtakiz';
  private indicatorsUrl = `${this.baseUrl}/kpi/indicators`;

  constructor(private http: HttpClient) {}


  createIndicator(
    payload: CreateKpiIndicatorRequest
  ): Observable<KpiIndicatorDto> {
    return this.http.post<KpiIndicatorDto>(this.indicatorsUrl, payload);
  }

  

  searchIndicators(params?: {
    goalCode?: string;
    ownerUniteId?: number;
    ownerSubUniteId?: number;
    isMain?: string;
    isActive?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiIndicatorDto>> {
    return this.http.get<Page<KpiIndicatorDto>>(
      this.indicatorsUrl,
      { params }
    );
  }


  getMainByUnite(params: {
    ownerUniteId: number;  
    goalCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiIndicatorDto>> {
    return this.http.get<Page<KpiIndicatorDto>>(
      `${this.indicatorsUrl}/main/by-unite`,
      { params }
    );
  }

  getMainBySubUnite(params: {
    ownerSubUniteId: number; 
    goalCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiIndicatorDto>> {
    return this.http.get<Page<KpiIndicatorDto>>(
      `${this.indicatorsUrl}/main/by-sub-unite`,
      { params }
    );
  }


  getChildren(parentCode: string): Observable<KpiIndicatorDto[]> {
    return this.http.get<KpiIndicatorDto[]>(
      `${this.indicatorsUrl}/${encodeURIComponent(parentCode)}/children`
    );
  }

}

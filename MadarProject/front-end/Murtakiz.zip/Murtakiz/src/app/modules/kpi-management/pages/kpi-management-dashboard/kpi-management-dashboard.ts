import { CommonModule } from '@angular/common';
import { Component, TemplateRef, ViewChild } from '@angular/core';
import { KpiIndicator } from '../../services/kpi-indicator.service';
import { KpiStrategicGoal } from '../../services/kpi-strategic-goal';
import { forkJoin } from 'rxjs';
import { KpiIndicatorDto } from '../../models/kpi-indicator.model';
import { KpiStrategicGoalDto } from '../../models/kpi-strategic-goal.model';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { OrgLookup } from '../../../system-settings/services/org/org-lookup';

type PerspectiveCode = 'FINANCIAL' | 'CUSTOMER' | 'INTERNAL' | 'LEARNING';

interface StaleKpiRow {
  code: string;
  name: string;
  ownerLabel: string;

  ownerUniteId: number | null;     
  ownerSubUniteId: number | null;   

  unitLabel: string;              
  subUnitLabel: string;             
  lastUpdate?: string;
  daysSinceUpdate: number;
}


interface NewGoalRow {
  code: string;
  name: string;
  perspective: string;

  ownerLabel: string;

  ownerUniteId: number | null;
  ownerSubUniteId: number | null;

  unitLabel: string;
  subUnitLabel: string;

  period: string;
  createdAtLabel: string;


  goalType: string;       
  goalTypeLabel: string;   
}





interface CriticalKpiRow {
  code: string;
  name: string;
  ownerLabel: string;

  ownerUniteId: number | null;      
  ownerSubUniteId: number | null;   

  unitLabel: string;               
  subUnitLabel: string;             
  status: string;
  lastUpdate?: string;
  isStrategic: boolean;
}


interface PerspectiveStat {
  name: string;
  progress: number;
  status: string;
  tone: 'good' | 'warn' | 'mid' | 'bad';
}

interface UpcomingReview {
  kpi: string;
  owner: string;
  date: string;                 
  severity: 'high' | 'medium' | 'low';
}

interface StatsCard {
  title: string;
  value: number | string;
  subtitle: string;
  trend?: string;
  trendLabel?: string;
  tone: 'info' | 'good' | 'bad' | 'neutral';
  icon: string;
}

interface MainGoalCard {
  id: number;
  code: string;
  perspective: string;
  title: string;
  owner: string;
  period: string;
  kpiCount: number;
  progress: number;
  trendLabel: string;
}

interface GoalKpiCard {
  code: string;
  name: string;
  target: string;
  progress: number;
}

interface MainKpiCard {
  code: string;
  name: string;
  perspective: string;
  owner: string;
  status: string;        
  progress: number;      
  subCount: number;       
  lastUpdate?: string;   
  statusLabel?: string; 
}


interface SubKpiCard {
  code: string;
  name: string;
  target: string;
  progress: number;
}

@Component({
  selector: 'app-kpi-management-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule,],
  templateUrl: './kpi-management-dashboard.html',
  styleUrls: ['./kpi-management-dashboard.css'],
})
export class KpiManagementDashboard {


  staleKpis: StaleKpiRow[] = [];
  staleKpiUnitsCount = 0;
  @ViewChild('staleKpisDialog') staleKpisDialog!: TemplateRef<any>;
  private staleDialogRef?: MatDialogRef<any>;


  newGoals: NewGoalRow[] = [];
  readonly NEW_GOAL_DAYS_WINDOW = 7;
  @ViewChild('newGoalsDialog') newGoalsDialog!: TemplateRef<any>;
  private newGoalsDialogRef?: MatDialogRef<any>;

  openStaleKpisDialog(): void {
    if (!this.staleKpis.length) return;
    this.staleDialogRef = this.dialog.open(this.staleKpisDialog, {
      panelClass: 'goal-dialog-panel',
      width: '1100px',
      maxWidth: '95vw',
    });
  }

  closeStaleKpisDialog(): void {
    this.staleDialogRef?.close();
  }

  /** اسم المالك من بيانات الهدف الاستراتيجي */
  private buildOwnerLabelFromGoal(g: any): string {
    if (g.ownerEmpNo) {
      return `موظف رقم ${g.ownerEmpNo}`;
    }
    if (g.ownerSubUniteId) {
      return `وحدة فرعية رقم ${g.ownerSubUniteId}`;
    }
    if (g.ownerUniteId) {
      return `وحدة رقم ${g.ownerUniteId}`;
    }
    return 'غير محدد';
  }


  private mapStatusLabel(status?: string | null): string {
    switch (status) {
      case 'ON_TRACK':
        return 'على المسار';
      case 'AT_RISK':
        return 'في وضع تحذيري';
      case 'OFF_TRACK':
      case 'CRITICAL':
        return 'حرج';
      default:
        return 'قيد المتابعة';
    }
  }


  openNewGoalsDialog(): void {
    if (!this.newGoals.length) return;
    this.newGoalsDialogRef = this.dialog.open(this.newGoalsDialog, {
      panelClass: 'goal-dialog-panel',
      width: '1100px',
      maxWidth: '95vw',
    });
  }

  perspectiveDistribution: { name: string; total: number; sharePct: number }[] = [];


  alertStats: { type: 'critical' | 'warning' | 'info'; label: string; value: number }[] = [];

  maxAlertValue = 0;


  perspectives2 = [
    { name: 'المالي', value: 68 },
    { name: 'العميل', value: 74 },
    { name: 'العمليات الداخلية', value: 59 },
    { name: 'التعلم والنمو', value: 81 },
  ];

  kpiDistribution = {
    main: 35,
    sub: 65,
  };

  alertsCounts = {
    critical: 60,  
    warning: 40,
    info: 25,
  };

  closeNewGoalsDialog(): void {
    this.newGoalsDialogRef?.close();
  }

  private buildStaleKpisSection(indicators: KpiIndicatorDto[]): void {
    const now = new Date();
    const last30Days = new Date();
    last30Days.setDate(now.getDate() - 1); 

    const stale: StaleKpiRow[] = [];
    const units = new Set<number>();

    for (const k of indicators) {
      if (!k.lastUpdateDate) continue;
      const d = new Date(k.lastUpdateDate);
      if (isNaN(d.getTime())) continue;

      if (d >= last30Days) continue;

      const diffMs = now.getTime() - d.getTime();
      const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (k.ownerUniteId) {
        units.add(k.ownerUniteId);
      } else if (k.ownerSubUniteId) {
        units.add(k.ownerSubUniteId);
      }

      stale.push({
        code: k.code,
        name: k.nameAr,
        ownerLabel: this.buildOwnerLabelFromIndicator(k),

        ownerUniteId: k.ownerUniteId ?? null,
        ownerSubUniteId: k.ownerSubUniteId ?? null,

        unitLabel: '',    
        subUnitLabel: '',  

        lastUpdate: d.toLocaleDateString('ar-SA'),
        daysSinceUpdate: days,
      });
    }

    this.staleKpis = stale.sort((a, b) => b.daysSinceUpdate - a.daysSinceUpdate);
    this.staleKpiUnitsCount = units.size;

    this.staleKpis.forEach((card) => {
      if (card.ownerUniteId) {
        this.orgApi.getUnite(card.ownerUniteId).subscribe({
          next: (u) =>
            (card.unitLabel = u.name ?? `وحدة رقم ${card.ownerUniteId}`),
          error: () => (card.unitLabel = 'الوحدة غير معروفة'),
        });
      } else {
        card.unitLabel = '-';
      }

      if (card.ownerSubUniteId) {
        this.orgApi.getSubUnite(card.ownerSubUniteId).subscribe({
          next: (su) =>
          (card.subUnitLabel =
            su.name ?? `وحدة فرعية رقم ${card.ownerSubUniteId}`),
          error: () => (card.subUnitLabel = ''),
        });
      } else {
        card.subUnitLabel = '';
      }
    });
  }

  private buildNewGoalsSection(goals: KpiStrategicGoalDto[]): void {
    const now = new Date();
    const windowStart = new Date();
    windowStart.setDate(now.getDate() - this.NEW_GOAL_DAYS_WINDOW);

    const list: NewGoalRow[] = [];

    for (const g of goals) {
      const anyG = g as any;

      const rawDate =
        anyG.createdAt ?? anyG.createStamp ?? anyG.approvedAt ?? null;
      if (!rawDate) continue;

      const d = new Date(rawDate);
      if (isNaN(d.getTime())) continue;
      if (d < windowStart) continue;

      const ownerUniteId: number | null = anyG.ownerUniteId ?? null;
      const ownerSubUniteId: number | null = anyG.ownerSubUniteId ?? null;
      const goalType: string = anyG.goalType ?? 'STRATEGIC';
      const goalTypeLabel: string = this.mapGoalTypeLabel(goalType);

      list.push({
        code: g.code,
        name: g.nameAr,
        perspective: this.mapPerspectiveLabel(anyG.perspectiveCode),

        ownerLabel: this.buildOwnerLabelFromGoal(anyG),

        ownerUniteId,
        ownerSubUniteId,

        unitLabel: '',     
        subUnitLabel: '',  

        period: `${anyG.horizonFromYear}–${anyG.horizonToYear}`,
        createdAtLabel: d.toLocaleDateString('ar-SA', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
        }),

        goalType,
        goalTypeLabel,
      });
    }

    this.newGoals = list.sort((a, b) =>
      a.createdAtLabel.localeCompare(b.createdAtLabel, 'ar')
    );

    this.newGoals.forEach((card) => {
      if (card.ownerUniteId) {
        this.orgApi.getUnite(card.ownerUniteId).subscribe({
          next: (u) =>
          (card.unitLabel =
            u.name ?? `وحدة رقم ${card.ownerUniteId}`),
          error: () => (card.unitLabel = 'الوحدة غير معروفة'),
        });
      } else {
        card.unitLabel = '-';
      }

      if (card.ownerSubUniteId) {
        this.orgApi.getSubUnite(card.ownerSubUniteId).subscribe({
          next: (su) =>
          (card.subUnitLabel =
            su.name ?? `وحدة فرعية رقم ${card.ownerSubUniteId}`),
          error: () => (card.subUnitLabel = ''),
        });
      } else {
        card.subUnitLabel = '';
      }
    });
  }






  private mapGoalTypeLabel(type?: string | null): string {
    if (!type) return 'غير محدد';

    const t = type.toUpperCase();
    if (t === 'STRATEGIC') return 'استراتيجي';
    if (t === 'OPERATIONAL') return 'تشغيلي';

    return type; 
  }


  perspectives: PerspectiveStat[] = [];

  upcomingReviews: UpcomingReview[] = [];

  criticalKpis: CriticalKpiRow[] = [];

  @ViewChild('criticalKpisDialog') criticalKpisDialog!: TemplateRef<any>;
  private criticalDialogRef?: MatDialogRef<any>;

  private buildUnitLabel(uniteId?: number | null): string {
    if (!uniteId) return '-';
    return `وحدة رقم ${uniteId}`;
  }

  private buildSubUnitLabel(subUniteId?: number | null): string {
    if (!subUniteId) return '-';
    return `وحدة فرعية رقم ${subUniteId}`;
  }



  private buildCriticalKpisSection(indicators: KpiIndicatorDto[]): void {
    const criticalIndicators = indicators.filter(
      (k) => k.currentStatus === 'OFF_TRACK' || k.currentStatus === 'CRITICAL'
    );

    this.criticalKpis = criticalIndicators.map((k) => ({
      code: k.code,
      name: k.nameAr,
      ownerLabel: this.buildOwnerLabelFromIndicator(k),

      ownerUniteId: k.ownerUniteId ?? null,
      ownerSubUniteId: k.ownerSubUniteId ?? null,

      unitLabel: '',        
      subUnitLabel: '',     
      status: k.currentStatus ?? 'غير محدد',
      lastUpdate: k.lastUpdateDate
        ? new Date(k.lastUpdateDate).toLocaleDateString('ar-SA')
        : 'غير محدد',
      isStrategic: k.isMain === 'Y',
    }));

    this.criticalKpis.forEach((card) => {
      if (card.ownerUniteId) {
        this.orgApi.getUnite(card.ownerUniteId).subscribe({
          next: (u) =>
          (card.unitLabel =
            u.name ?? `وحدة رقم ${card.ownerUniteId}`),
          error: () => (card.unitLabel = 'الوحدة غير معروفة'),
        });
      } else {
        card.unitLabel = '-';
      }


      if (card.ownerSubUniteId) {
        this.orgApi.getSubUnite(card.ownerSubUniteId).subscribe({
          next: (su) =>
          (card.subUnitLabel =
            su.name ?? `وحدة فرعية رقم ${card.ownerSubUniteId}`),
          error: () => (card.subUnitLabel = ''),
        });
      } else {
        card.subUnitLabel = '';
      }
    });
  }








  openCriticalKpisDialog(): void {
    if (!this.criticalKpis.length) {
      return;
    }

    this.criticalDialogRef = this.dialog.open(this.criticalKpisDialog, {
      panelClass: 'critical-kpis-dialog-panel',
      width: '1100px',
      maxWidth: '95vw',
    });
  }



  closeCriticalKpisDialog(): void {
    this.criticalDialogRef?.close();
  }






  private buildPerspectiveStatus(progress: number): { status: string; tone: 'good' | 'warn' | 'mid' | 'bad' } {
    if (progress >= 80) {
      return { status: 'ممتاز', tone: 'good' };
    }
    if (progress >= 60) {
      return { status: 'جيد', tone: 'good' };
    }
    if (progress >= 40) {
      return { status: 'قابل للتحسين', tone: 'warn' };
    }
    if (progress > 0) {
      return { status: 'منخفض', tone: 'mid' };
    }
    return { status: 'لا توجد بيانات', tone: 'mid' };
  }





  private normalizePerspective(code?: string | null): PerspectiveCode | null {
    if (!code) return null;
    const c = code.toUpperCase();

    if (c === 'FINANCIAL' || c === 'FIN') return 'FINANCIAL';
    if (c === 'CUSTOMER' || c === 'CUST') return 'CUSTOMER';
    if (c === 'INTERNAL' || c === 'INT') return 'INTERNAL';
    if (c === 'LEARNING' || c === 'LEARN') return 'LEARNING';

    return null;
  }

  private buildPerspectivesSection(indicators: KpiIndicatorDto[]): void {

    const map: Record<PerspectiveCode, KpiIndicatorDto[]> = {
      FINANCIAL: [],
      CUSTOMER: [],
      INTERNAL: [],
      LEARNING: []
    };

    for (const k of indicators) {
      const norm = this.normalizePerspective(k.perspectiveCode);
      if (norm) {
        map[norm].push(k);
      }
    }

    const calcProgress = (items: KpiIndicatorDto[]) => {
      if (items.length === 0) return 0;
      const total = items.reduce(
        (sum, k) => sum + this.estimateKpiProgress(k),
        0
      );
      return Math.round(total / items.length);
    };

    const finProg = calcProgress(map.FINANCIAL);
    const custProg = calcProgress(map.CUSTOMER);
    const intProg = calcProgress(map.INTERNAL);
    const learnProg = calcProgress(map.LEARNING);

    const finStatus = this.buildPerspectiveStatus(finProg);
    const custStatus = this.buildPerspectiveStatus(custProg);
    const intStatus = this.buildPerspectiveStatus(intProg);
    const learnStatus = this.buildPerspectiveStatus(learnProg);

    this.perspectives = [
      {
        name: 'المالي',
        progress: finProg,
        status: finStatus.status,
        tone: finStatus.tone
      },
      {
        name: 'العملاء',
        progress: custProg,
        status: custStatus.status,
        tone: custStatus.tone
      },
      {
        name: 'العمليات الداخلية',
        progress: intProg,
        status: intStatus.status,
        tone: intStatus.tone
      },
      {
        name: 'التعلم والنمو',
        progress: learnProg,
        status: learnStatus.status,
        tone: learnStatus.tone
      }
    ];
  }





  private buildAlertStats(indicators: KpiIndicatorDto[]): void {
    let critical = 0;
    let warning = 0;
    let info = 0;

    for (const k of indicators) {
      switch (k.currentStatus) {
        case 'CRITICAL':
        case 'OFF_TRACK':
          critical++;
          break;
        case 'AT_RISK':
          warning++;
          break;
        case 'ON_TRACK':
          info++;
          break;
      }
    }

    this.alertStats = [
      { type: 'critical', label: 'حرجة', value: critical },
      { type: 'warning', label: 'تحذيرية', value: warning },
      { type: 'info', label: 'معلوماتية', value: info },
    ];

    this.maxAlertValue = Math.max(1, critical, warning, info);
  }


  private buildVisualDistributionSection(indicators: KpiIndicatorDto[]): void {
    const counts = {
      FINANCIAL: 0,
      CUSTOMER: 0,
      INTERNAL: 0,
      LEARNING: 0,
    };

    for (const k of indicators) {
      const norm = this.normalizePerspective(k.perspectiveCode);
      if (!norm) continue;

      if (norm === 'FINANCIAL') counts.FINANCIAL++;
      else if (norm === 'CUSTOMER') counts.CUSTOMER++;
      else if (norm === 'INTERNAL') counts.INTERNAL++;
      else if (norm === 'LEARNING') counts.LEARNING++;
    }

    const total =
      counts.FINANCIAL +
      counts.CUSTOMER +
      counts.INTERNAL +
      counts.LEARNING || 1;

    this.perspectiveDistribution = [
      {
        name: 'المالي',
        total: counts.FINANCIAL,
        sharePct: Math.round((counts.FINANCIAL / total) * 100),
      },
      {
        name: 'المستفيدين',
        total: counts.CUSTOMER,
        sharePct: Math.round((counts.CUSTOMER / total) * 100),
      },
      {
        name: 'العمليات الداخلية',
        total: counts.INTERNAL,
        sharePct: Math.round((counts.INTERNAL / total) * 100),
      },
      {
        name: 'التعلم والنمو',
        total: counts.LEARNING,
        sharePct: Math.round((counts.LEARNING / total) * 100),
      },
    ];
  }

  mainKpis: MainKpiCard[] = [];
  private kpiChildrenMap: { [parentCode: string]: SubKpiCard[] } = {};

  selectedMainKpi: MainKpiCard | null = null;
  selectedMainKpiSubs: SubKpiCard[] = [];

  @ViewChild('mainKpiDetailsDialog') mainKpiDetailsDialog!: TemplateRef<any>;
  private mainKpiDialogRef?: MatDialogRef<any>;

  statsCards: StatsCard[] = [];

  kpiTypeDistribution = {
    main: 0,
    sub: 0,
  };

  loadingSummary = false;
  summaryError?: string;

  mainGoals: MainGoalCard[] = [];

  private goalKpisMap: { [goalId: number]: GoalKpiCard[] } = {};

  selectedGoal: MainGoalCard | null = null;
  selectedGoalKpis: GoalKpiCard[] = [];

  //@ViewChild('goalDetailsDialog') goalDetailsDialog!: TemplateRef<any>;

  @ViewChild('goalDetailsDialog') goalDetailsDialog!: TemplateRef<any>;
  private goalDialogRef?: MatDialogRef<any>;


  constructor(
    private indicatorApi: KpiIndicator,
    private goalApi: KpiStrategicGoal,
    private dialog: MatDialog,
    private orgApi: OrgLookup 
  ) { }


  ngOnInit(): void {
    this.loadSummaryStats();
    this.selectedBarChartIndex = 0;
  }

  openGoalDialog(goal: MainGoalCard): void {
    this.selectedGoal = goal;
    this.selectedGoalKpis = this.goalKpisMap[goal.id] || [];

    this.goalDialogRef = this.dialog.open(this.goalDetailsDialog, {
      panelClass: 'goal-dialog-panel',
      width: '1100px',
      maxWidth: '95vw'
    });
  }

  closeGoalDialog(): void {
    this.goalDialogRef?.close();
  }




  private loadSummaryStats(): void {
    this.loadingSummary = true;
    this.summaryError = undefined;

    forkJoin({
      indicatorsPage: this.indicatorApi.searchIndicators({
        unpaged: true,
        page: 0,
        size: 1000, 
      }),
      goalsPage: this.goalApi.getAllGoals({
        unpaged: true,
        page: 0,
        size: 1000,
      }),
    }).subscribe({
      next: ({ indicatorsPage, goalsPage }) => {
        const indicators: KpiIndicatorDto[] = indicatorsPage.content ?? [];
        const goals: KpiStrategicGoalDto[] = goalsPage.content ?? [];

        const totalIndicators = indicators.length;

        const achievedIndicators = indicators.filter(
          (k) => k.currentStatus === 'ON_TRACK'
        ).length;

        const atRiskIndicators = indicators.filter(
          (k) => k.currentStatus === 'AT_RISK'
        ).length;

        const criticalIndicators = indicators.filter(
          (k) =>
            k.currentStatus === 'OFF_TRACK' || k.currentStatus === 'CRITICAL'
        ).length;

        const strategicGoals = goals.filter(
          (g) => g.goalType === 'STRATEGIC'
        ).length;

        const mainIndicators = indicators.filter(
          (k) => k.isMain === 'Y'
        ).length;
        const subIndicators = totalIndicators - mainIndicators;

        this.kpiTypeDistribution = {
          main: mainIndicators,
          sub: subIndicators,
        };

        const now = new Date();
        const last30Days = new Date();
        last30Days.setDate(now.getDate() - 30);

        const updatedInLast30Days = indicators.filter((k) => {
          if (!k.lastUpdateDate) return false;
          const d = new Date(k.lastUpdateDate);
          return d >= last30Days;
        }).length;

        const monthlyUpdateRatio =
          totalIndicators > 0
            ? Math.round((updatedInLast30Days / totalIndicators) * 100)
            : 0;

        const totalWithStatus =
          achievedIndicators + atRiskIndicators + criticalIndicators || 1;

        this.statusShare = {
          onTrackPct: Math.round(
            (achievedIndicators / totalWithStatus) * 100
          ),
          atRiskPct: Math.round(
            (atRiskIndicators / totalWithStatus) * 100
          ),
          offCritPct: Math.round(
            (criticalIndicators / totalWithStatus) * 100
          ),
        };

        const totalProgress = indicators.reduce(
          (sum, k) => sum + this.estimateKpiProgress(k),
          0
        );
        this.overallReadinessPct =
          totalIndicators > 0
            ? Math.round(totalProgress / totalIndicators)
            : 0;

        this.statsCards = [
          {
            title: 'إجمالي المؤشرات',
            value: totalIndicators,
            subtitle: 'عدد جميع مؤشرات الأداء المسجلة',
            trend: '',
            trendLabel: '',
            tone: 'info',
            icon: 'bi bi-grid-3x3-gap-fill',
          },
          {
            title: 'مؤشرات حققت الهدف',
            value: achievedIndicators,
            subtitle: 'تجاوزت أو حققت القيمة المستهدفة',
            trend: '',
            trendLabel: '',
            tone: 'good',
            icon: 'bi bi-check2-circle',
          },
          {
            title: 'المؤشرات الحرجة',
            value: criticalIndicators,
            subtitle: 'تحتاج تدخل فوري من الإدارة',
            trend: '',
            trendLabel: '',
            tone: 'bad',
            icon: 'bi bi-exclamation-triangle-fill',
          },
          {
            title: 'الأهداف الاستراتيجية',
            value: strategicGoals,
            subtitle: 'عدد الأهداف المفعّلة حاليًا',
            trend: '',
            trendLabel: '',
            tone: 'neutral',
            icon: 'bi bi-bullseye',
          },
          {
            title: 'نسبة التحديث الشهري',
            value: `${monthlyUpdateRatio}%`,
            subtitle: 'نسبة المؤشرات المحدثة في آخر 30 يوم',
            trend: '',
            trendLabel: '',
            tone: 'good',
            icon: 'bi bi-arrow-repeat',
          },
          {
            title: 'مؤشرات على المسار',
            value: 24,
            subtitle: 'من إجمالي المؤشرات الرئيسية',
            trend: '+5',
            trendLabel: 'تحسّن عن الفترة السابقة',
            tone: 'good',
            icon: 'bi bi-check2-circle',
          },
        ];

        this.buildMainGoalsSection(goals, indicators);
        this.buildMainKpisSection(indicators);

        this.buildBarChartsSection(indicators);

        this.buildPerspectivesSection(indicators);
        this.buildFreshnessByPerspective(indicators);

        this.buildAlertStats(indicators);
        this.buildRiskKpiDistribution(indicators);

        this.buildUpcomingReviews(indicators);
        this.buildCriticalKpisSection(indicators);

        this.buildStaleKpisSection(indicators);
        this.buildNewGoalsSection(goals);

        this.buildVisualDistributionSection(indicators);

        this.loadingSummary = false;
      },
      error: (err) => {
        console.error('Error loading summary stats', err);
        this.summaryError = 'تعذّر تحميل إحصائيات الملخص.';
        this.loadingSummary = false;
      },
    });
  }


  criticalTicker = [
    { code: 'KPI-ADMIN-TEST-01', name: 'جودة بيانات النظام', value: 64, delta: -12, tone: 'bad' },
    { code: 'KPI-ADMIN-03', name: 'رضا المستفيدين الداخليين', value: 82, delta: +3, tone: 'warn' },
    { code: 'KPI-ADMIN-05', name: 'نسبة استخدام الأنظمة الإلكترونية', value: 95, delta: +10, tone: 'good' },
  ];



  onAlertDetailsClick(index: number): void {
    if (index === 0) {
      this.openCriticalKpisDialog();
      return;
    }
    if (index === 1) {
      this.openStaleKpisDialog();
      return;
    }
    if (index === 2) {
      this.openNewGoalsDialog();
      return;
    }
  }


  private buildBarChartsSection(indicators: KpiIndicatorDto[]): void {
    const months = this.getLastMonths(7); 


    const chart1Counts: Record<string, { onTrack: number; atRisk: number; offCrit: number }> = {};
    const chart2Counts: Record<string, { main: number; sub: number; total: number }> = {};
    const chart3Counts: Record<string, { financial: number; customer: number; other: number }> = {};


    for (const m of months) {
      chart1Counts[m.key] = { onTrack: 0, atRisk: 0, offCrit: 0 };
      chart2Counts[m.key] = { main: 0, sub: 0, total: 0 };
      chart3Counts[m.key] = { financial: 0, customer: 0, other: 0 };
    }

    for (const k of indicators) {
      if (!k.lastUpdateDate) continue;

      const d = new Date(k.lastUpdateDate);
      if (isNaN(d.getTime())) continue;

      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;

      if (!chart1Counts[key]) continue;

      const status = k.currentStatus ?? 'UNKNOWN';
      if (status === 'ON_TRACK') {
        chart1Counts[key].onTrack++;
      } else if (status === 'AT_RISK') {
        chart1Counts[key].atRisk++;
      } else if (status === 'OFF_TRACK' || status === 'CRITICAL') {
        chart1Counts[key].offCrit++;
      }

      const isMain = k.isMain === 'Y';
      if (isMain) {
        chart2Counts[key].main++;
      } else {
        chart2Counts[key].sub++;
      }
      chart2Counts[key].total++;

      const p = k.perspectiveCode ?? '';
      if (p === 'FINANCIAL') {
        chart3Counts[key].financial++;
      } else if (p === 'CUSTOMER') {
        chart3Counts[key].customer++;
      } else {
        chart3Counts[key].other++;
      }
    }

    const buildChartData = (
      rows: { label: string; v1: number; v2: number; v3: number }[]
    ) => {
      const maxVal = Math.max(
        1,
        ...rows.flatMap((r) => [r.v1, r.v2, r.v3])
      );
      return rows.map((r) => ({
        label: r.label,
        s1: Math.round((r.v1 / maxVal) * 100),
        s2: Math.round((r.v2 / maxVal) * 100),
        s3: Math.round((r.v3 / maxVal) * 100),
      }));
    };


    const chart1Rows = months.map((m) => {
      const c = chart1Counts[m.key];
      return {
        label: m.label,
        v1: c.onTrack,
        v2: c.atRisk,
        v3: c.offCrit,
      };
    });


    const chart2Rows = months.map((m) => {
      const c = chart2Counts[m.key];
      return {
        label: m.label,
        v1: c.main,
        v2: c.sub,
        v3: c.total,
      };
    });


    const chart3Rows = months.map((m) => {
      const c = chart3Counts[m.key];
      return {
        label: m.label,
        v1: c.financial,
        v2: c.customer,
        v3: c.other,
      };
    });

    this.barCharts = [
      {
        title: 'تحديث المؤشرات حسب الحالة',
        subtitle: 'عدد المؤشرات المحدثة في كل شهر حسب الحالة الحالية.',
        seriesLabels: ['ON TRACK', 'AT RISK', 'OFF/CRITICAL'],
        data: buildChartData(chart1Rows),
      },
      {
        title: 'تحديث المؤشرات حسب نوعها',
        subtitle: 'مقارنة بين المؤشرات الرئيسية والفرعية في آخر الشهور.',
        seriesLabels: ['رئيسية', 'فرعية', 'الكل'],
        data: buildChartData(chart2Rows),
      },
      {
        title: 'تحديث المؤشرات حسب المحور',
        subtitle: 'توزيع المؤشرات على المحاور الرئيسية خلال الشهور الماضية.',
        seriesLabels: ['المالي', 'المستفيدين', 'محاور أخرى'],
        data: buildChartData(chart3Rows),
      },
    ];
  }


  private getLastMonths(n: number): { key: string; label: string }[] {
    const months: { key: string; label: string }[] = [];
    const arMonths = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];

    const now = new Date();
    for (let i = n - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const year = d.getFullYear();
      const month = d.getMonth(); 
      const key = `${year}-${String(month + 1).padStart(2, '0')}`;
      const label = arMonths[month];
      months.push({ key, label });
    }

    return months;
  }

  selectedBarChartIndex = 0;

  selectBarChart(index: number): void {
    this.selectedBarChartIndex = index;
  }



  private buildMainKpisSection(indicators: KpiIndicatorDto[]): void {
    const mainKpis: MainKpiCard[] = [];
    const kpiChildrenMap: { [parentCode: string]: SubKpiCard[] } = {};


    const mainIndicators = indicators.filter((k) => k.isMain === 'Y');

    for (const main of mainIndicators) {
      const children = indicators.filter(
        (k) => k.isMain !== 'Y' && k.parentKpiCode === main.code
      );

      kpiChildrenMap[main.code] = children.map((c) => ({
        code: c.code,
        name: c.nameAr,
        target: this.buildTargetLabel(c),
        progress: this.estimateKpiProgress(c),
      }));

      const subCount = children.length;

      mainKpis.push({
        code: main.code,
        name: main.nameAr,
        perspective: this.mapPerspectiveLabel(main.perspectiveCode),
        owner: main.ownerUniteId
          ? `وحدة رقم ${main.ownerUniteId}`
          : main.ownerSubUniteId
            ? `وحدة فرعية رقم ${main.ownerSubUniteId}`
            : 'غير محدد',
        status: main.currentStatus ?? 'UNKNOWN',
        progress: this.estimateKpiProgress(main),
        subCount,
        lastUpdate: main.lastUpdateDate
          ? new Date(main.lastUpdateDate).toLocaleDateString('ar-SA')
          : undefined,
        statusLabel: this.mapStatusLabel(main.currentStatus),
      });

    }


    this.mainKpis = mainKpis.sort((a, b) => b.progress - a.progress);
    this.kpiChildrenMap = kpiChildrenMap;

    this.mainKpiCards = this.mainKpis;

    if (this.mainKpis.length > 0) {
      this.selectedMainKpi = this.mainKpis[0];
      this.selectedMainKpiSubs =
        this.kpiChildrenMap[this.mainKpis[0].code] ?? [];
    }
  }

  openMainKpiDialog(kpi: MainKpiCard): void {
    this.selectedMainKpi = kpi;
    this.selectedMainKpiSubs = this.kpiChildrenMap[kpi.code] || [];

    this.mainKpiDialogRef = this.dialog.open(this.mainKpiDetailsDialog, {
      panelClass: 'goal-dialog-panel',
      width: '1100px',
      maxWidth: '95vw',
    });
  }

  closeMainKpiDialog(): void {
    this.mainKpiDialogRef?.close();
  }



  private buildMainGoalsSection(
    goals: KpiStrategicGoalDto[],
    indicators: KpiIndicatorDto[]
  ): void {
    const strategicGoals = goals.filter((g) => g.goalType === 'STRATEGIC');

    const mainGoals: MainGoalCard[] = [];
    const goalKpisMap: { [goalId: number]: GoalKpiCard[] } = {};

    for (const g of strategicGoals) {
      const goalIndicators = indicators.filter(
        (k) => k.goalCode === g.code && k.isMain === 'Y'
      );
      const kpiCount = (g as any).kpiCount ?? goalIndicators.length;
      const progress = (g as any).progressPct ?? 0;
      const trendLabel = this.mapTrendLabel(progress);
      const ownerLabel =
        (g as any).ownerUniteId != null
          ? `وحدة رقم ${(g as any).ownerUniteId}`
          : (g as any).ownerSubUniteId != null
            ? `وحدة فرعية رقم ${(g as any).ownerSubUniteId}`
            : 'غير محدد';


      const period = `${(g as any).horizonFromYear}–${(g as any).horizonToYear}`;


      mainGoals.push({
        id: g.id,
        code: g.code,
        perspective: this.mapPerspectiveLabel((g as any).perspectiveCode),
        title: g.nameAr,
        owner: ownerLabel,
        period,
        kpiCount,
        progress,
        trendLabel,
      });


      goalKpisMap[g.id] = goalIndicators.map((k) => ({
        code: k.code,
        name: k.nameAr,
        target: this.buildTargetLabel(k),
        progress: this.estimateKpiProgress(k),
      }));
    }


    this.mainGoals = mainGoals.sort((a, b) => b.progress - a.progress).slice(0, 6);

    this.goalKpisMap = goalKpisMap;


    if (this.mainGoals.length > 0) {
      this.selectedGoal = this.mainGoals[0];
      this.selectedGoalKpis = this.goalKpisMap[this.mainGoals[0].id] ?? [];
    }
  }

  /** تحويل كود المحور إلى نص عربي جميل */
  private mapPerspectiveLabel(code?: string | null): string {
    if (!code) return 'غير مصنّف';

    const map: Record<string, string> = {
      FINANCIAL: 'المالي',
      CUSTOMER: 'المستفيدين',
      INTERNAL: 'العمليات الداخلية',
      LEARNING: 'التعلم والنمو',
    };

    return map[code] ?? code;
  }


  private mapTrendLabel(progress: number): string {
    if (progress >= 80) return 'تحسن ممتاز';
    if (progress >= 60) return 'اتجاه إيجابي';
    if (progress >= 40) return 'قابل للتحسين';
    return 'منخفض يحتاج تدخل';
  }


  private buildTargetLabel(k: KpiIndicatorDto): string {
    if (k.targetValue == null) {
      return 'لا يوجد مستهدف مسجّل';
    }
    return k.measurementUnit
      ? `${k.targetValue} ${k.measurementUnit}`
      : `${k.targetValue}`;
  }

  private estimateKpiProgress(k: KpiIndicatorDto): number {
    switch (k.currentStatus) {
      case 'ON_TRACK':
        return 80;
      case 'AT_RISK':
        return 55;
      case 'OFF_TRACK':
      case 'CRITICAL':
        return 30;
      default:
        return 0;
    }
  }




  mainTab: 'kpis' | 'goals' = 'kpis';


  activeTab: 'kpi' | 'alerts' | 'config' = 'kpi';


  setTab(tab: 'kpi' | 'alerts' | 'config') {
    this.activeTab = tab;
  }


  /*  perspectives = [
     { name: 'المالي', progress: 72, status: 'جيد', tone: 'good' },
     { name: 'المستفيدين', progress: 64, status: 'قابل للتحسين', tone: 'warn' },
     { name: 'العمليات الداخلية', progress: 51, status: 'متحفّظ', tone: 'mid' },
     { name: 'التعلم والنمو', progress: 83, status: 'ممتاز', tone: 'good' },
   ]; */

  private buildOwnerLabelFromIndicator(k: KpiIndicatorDto): string {
    if (k.ownerEmpNo) {
      return `موظف رقم ${k.ownerEmpNo}`;
    }
    if (k.ownerSubUniteId) {
      return `وحدة فرعية رقم ${k.ownerSubUniteId}`;
    }
    if (k.ownerUniteId) {
      return `وحدة رقم ${k.ownerUniteId}`;
    }
    return 'غير محدد';
  }

  /** بناء قائمة أقرب مراجعات للمؤشرات من البيانات الحقيقية */
  private buildUpcomingReviews(indicators: KpiIndicatorDto[]): void {
    const now = new Date();

    const items: {
      kpi: string;
      owner: string;
      date: Date;
      severity: 'high' | 'medium' | 'low';
    }[] = [];

    for (const k of indicators) {
      const status = k.currentStatus ?? 'UNKNOWN';
      if (!['ON_TRACK', 'AT_RISK', 'OFF_TRACK', 'CRITICAL'].includes(status)) {
        continue;
      }

      const last = k.lastUpdateDate ? new Date(k.lastUpdateDate) : now;
      if (isNaN(last.getTime())) continue;

      let daysToAdd: number;
      let severity: 'high' | 'medium' | 'low';

      switch (status) {
        case 'CRITICAL':
        case 'OFF_TRACK':
          daysToAdd = 7;    
          severity = 'high';
          break;
        case 'AT_RISK':
          daysToAdd = 14;  
          severity = 'medium';
          break;
        case 'ON_TRACK':
        default:
          daysToAdd = 30;  
          severity = 'low';
          break;
      }

      const next = new Date(last);
      next.setDate(next.getDate() + daysToAdd);

      items.push({
        kpi: k.nameAr,
        owner: this.buildOwnerLabelFromIndicator(k),
        date: next,
        severity,
      });
    }

    items.sort((a, b) => a.date.getTime() - b.date.getTime());

    this.upcomingReviews = items.slice(0, 3).map((r) => ({
      kpi: r.kpi,
      owner: r.owner,
      date: r.date.toLocaleDateString('ar-SA', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
      }),
      severity: r.severity,
    }));

  
    const highCount = items.filter((i) => i.severity === 'high').length;
    const medCount = items.filter((i) => i.severity === 'medium').length;
    const lowCount = items.filter((i) => i.severity === 'low').length;

    this.reviewSeverityStats = [
      { severity: 'high', label: 'مرتفعة', value: highCount },
      { severity: 'medium', label: 'متوسطة', value: medCount },
      { severity: 'low', label: 'منخفضة', value: lowCount },
    ];

    this.maxReviewSeverityValue = Math.max(1, highCount, medCount, lowCount);
  }



  /* upcomingReviews = [
    {
      kpi: 'نسبة تنفيذ المشاريع المعتمدة',
      owner: 'إدارة المشاريع',
      date: 'الأربعاء، 10 ديسمبر',
      severity: 'high',
    },
    {
      kpi: 'رضا المستفيدين عن الخدمات الرقمية',
      owner: 'إدارة التحول الرقمي',
      date: 'الأحد، 14 ديسمبر',
      severity: 'medium',
    },
    {
      kpi: 'مؤشر الالتزام بالميزانية',
      owner: 'الإدارة المالية',
      date: 'الإثنين، 22 ديسمبر',
      severity: 'low',
    },
  ]; */

  alerts = [
    {
      type: 'critical',
      title: 'مؤشر حرج تحت الحد الأدنى',
      message:
        'مؤشر زمن إنجاز المعاملة تجاوز الحد المستهدف في ثلاث وحدات تنظيمية.',
      time: 'منذ ٣ ساعات',
      tag: 'عمليات',
    },
    {
      type: 'warning',
      title: 'تأخر في تحديث بيانات مؤشر',
      message: 'مؤشر رضا المستفيدين لم يتم تحديثه منذ أكثر من ٣٠ يومًا.',
      time: 'أمس',
      tag: 'خدمة المستفيدين',
    },
    {
      type: 'info',
      title: 'اعتماد هدف استراتيجي جديد',
      message: 'تم إضافة هدف استراتيجي جديد ضمن محور التعلم والنمو.',
      time: 'قبل ٣ أيام',
      tag: 'استراتيجية',
    },
  ];



  mainKpiCards: MainKpiCard[] = []; 


  scrollStrip(container: HTMLElement, direction: number): void {
    if (!container) return;

    const step = 260; 
    container.scrollBy({
      left: direction * step,
      behavior: 'smooth',
    });
  }

  selectGoal(goal: MainGoalCard): void {
    if (this.selectedGoal && this.selectedGoal.id === goal.id) {
      this.selectedGoal = null;
      this.selectedGoalKpis = [];
      return;
    }


    this.selectedGoal = goal;
    this.selectedGoalKpis = this.goalKpisMap[goal.id] || [];
  }


  /*   alertStats = [
      { type: 'critical', label: 'حرجة', value: 65 },
      { type: 'warning', label: 'تحذيرية', value: 45 },
      { type: 'info', label: 'معلوماتية', value: 30 },
    ]; */

  barCharts: {
    title: string;
    subtitle: string;
    seriesLabels: [string, string, string];
    data: { label: string; s1: number; s2: number; s3: number }[];
  }[] = [];



  freshnessByPerspective: {
    name: string;
    total: number;
    updated: number;
    pct: number;
  }[] = [];


  riskKpiTypeDistribution = {
    main: 0,
    sub: 0,
  };


  reviewSeverityStats: {
    severity: 'high' | 'medium' | 'low';
    label: string;
    value: number;
  }[] = [];

  maxReviewSeverityValue = 0;

  /** نسبة المؤشرات المحدثة خلال آخر 30 يوم في كل منظور */
  private buildFreshnessByPerspective(indicators: KpiIndicatorDto[]): void {
    const now = new Date();
    const last30 = new Date();
    last30.setDate(now.getDate() - 30);

    const bucket: Record<PerspectiveCode, { total: number; updated: number }> = {
      FINANCIAL: { total: 0, updated: 0 },
      CUSTOMER: { total: 0, updated: 0 },
      INTERNAL: { total: 0, updated: 0 },
      LEARNING: { total: 0, updated: 0 },
    };

    for (const k of indicators) {
      const norm = this.normalizePerspective(k.perspectiveCode);
      if (!norm) continue;

      bucket[norm].total++;

      if (k.lastUpdateDate) {
        const d = new Date(k.lastUpdateDate);
        if (!isNaN(d.getTime()) && d >= last30) {
          bucket[norm].updated++;
        }
      }
    }

    const toPct = (up: number, total: number) =>
      total > 0 ? Math.round((up / total) * 100) : 0;

    this.freshnessByPerspective = [
      {
        name: 'المالي',
        total: bucket.FINANCIAL.total,
        updated: bucket.FINANCIAL.updated,
        pct: toPct(bucket.FINANCIAL.updated, bucket.FINANCIAL.total),
      },
      {
        name: 'المستفيدين',
        total: bucket.CUSTOMER.total,
        updated: bucket.CUSTOMER.updated,
        pct: toPct(bucket.CUSTOMER.updated, bucket.CUSTOMER.total),
      },
      {
        name: 'العمليات الداخلية',
        total: bucket.INTERNAL.total,
        updated: bucket.INTERNAL.updated,
        pct: toPct(bucket.INTERNAL.updated, bucket.INTERNAL.total),
      },
      {
        name: 'التعلم والنمو',
        total: bucket.LEARNING.total,
        updated: bucket.LEARNING.updated,
        pct: toPct(bucket.LEARNING.updated, bucket.LEARNING.total),
      },
    ];
  }

  /** كم مؤشر "تحت الخطر" في الرئيسية مقابل الفرعية؟ */
  private buildRiskKpiDistribution(indicators: KpiIndicatorDto[]): void {
    let mainRisk = 0;
    let subRisk = 0;

    for (const k of indicators) {
      const status = k.currentStatus ?? 'UNKNOWN';
      const isRisk =
        status === 'CRITICAL' || status === 'OFF_TRACK' || status === 'AT_RISK';

      if (!isRisk) continue;

      if (k.isMain === 'Y') {
        mainRisk++;
      } else {
        subRisk++;
      }
    }

    this.riskKpiTypeDistribution = {
      main: mainRisk,
      sub: subRisk,
    };
  }


  overallReadinessPct = 0;


  statusShare = {
    onTrackPct: 0,
    atRiskPct: 0,
    offCritPct: 0,
  };


  /*  barCharts = [
     {
       title: 'أداء المؤشرات شهريًا',
       subtitle: 'مقارنة بين ثلاث مجموعات من المؤشرات على مدار سبعة أشهر.',
       seriesLabels: ['مجموعة 1', 'مجموعة 2', 'مجموعة 3'],
       data: [
         { label: 'يناير', s1: 81, s2: 96, s3: 12 },
         { label: 'فبراير', s1: 62, s2: 52, s3: 36 },
         { label: 'مارس', s1: 56, s2: 61, s3: 90 },
         { label: 'أبريل', s1: 82, s2: 18, s3: 57 },
         { label: 'مايو', s1: 11, s2: 88, s3: 60 },
         { label: 'يونيو', s1: 81, s2: 55, s3: 70 },
         { label: 'يوليو', s1: 64, s2: 95, s3: 75 },
       ],
     },
     {
       title: 'مستوى إنجاز المبادرات',
       subtitle: 'مقارنة بين ثلاث برامج استراتيجية.',
       seriesLabels: ['برنامج أ', 'برنامج ب', 'برنامج ج'],
       data: [
         { label: 'يناير', s1: 40, s2: 65, s3: 52 },
         { label: 'فبراير', s1: 55, s2: 72, s3: 61 },
         { label: 'مارس', s1: 60, s2: 80, s3: 70 },
         { label: 'أبريل', s1: 68, s2: 78, s3: 73 },
         { label: 'مايو', s1: 72, s2: 82, s3: 76 },
         { label: 'يونيو', s1: 75, s2: 85, s3: 79 },
         { label: 'يوليو', s1: 78, s2: 88, s3: 82 },
       ],
     },
     {
       title: 'استخدام الأنظمة الرقمية',
       subtitle: 'نسب الاستخدام في ثلاث منصات رئيسية.',
       seriesLabels: ['منصة 1', 'منصة 2', 'منصة 3'],
       data: [
         { label: 'يناير', s1: 30, s2: 45, s3: 55 },
         { label: 'فبراير', s1: 35, s2: 50, s3: 60 },
         { label: 'مارس', s1: 45, s2: 60, s3: 68 },
         { label: 'أبريل', s1: 55, s2: 70, s3: 72 },
         { label: 'مايو', s1: 65, s2: 78, s3: 80 },
         { label: 'يونيو', s1: 70, s2: 82, s3: 84 },
         { label: 'يوليو', s1: 75, s2: 86, s3: 88 },
       ],
     },
   ]; */
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiManagementDashboard } from './kpi-management-dashboard';

describe('KpiManagementDashboard', () => {
  let component: KpiManagementDashboard;
  let fixture: ComponentFixture<KpiManagementDashboard>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KpiManagementDashboard]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KpiManagementDashboard);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

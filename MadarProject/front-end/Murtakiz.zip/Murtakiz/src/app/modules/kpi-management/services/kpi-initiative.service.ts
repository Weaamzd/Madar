import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  CreateKpiInitiativeRequest,
  KpiInitiativeDto
} from '../models/kpi-initiative.model';

@Injectable({
  providedIn: 'root',
})
export class KpiInitiative {

  private baseUrl = 'http://localhost:9090/api/v1/murtakiz';
  private initiativesUrl = `${this.baseUrl}/kpi/initiatives`;

  constructor(private http: HttpClient) {}

  /** إنشاء مبادرة جديدة + ربطها بمؤشر (create-and-link) */
  createInitiativeAndLink(
    payload: CreateKpiInitiativeRequest
  ): Observable<KpiInitiativeDto> {
    return this.http.post<KpiInitiativeDto>(
      `${this.initiativesUrl}/create-and-link`,
      payload
    );
  }

  

  getInitiativesByKpiCode(kpiCode: string): Observable<KpiInitiativeDto[]> {
    return this.http.get<KpiInitiativeDto[]>(
      `${this.initiativesUrl}/kpi/${encodeURIComponent(kpiCode)}`
    );
  }
}

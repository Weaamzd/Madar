import { ComponentFixture, TestBed } from '@angular/core/testing';

import { KpiManagementHome } from './kpi-management-home';

describe('KpiManagementHome', () => {
  let component: KpiManagementHome;
  let fixture: ComponentFixture<KpiManagementHome>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [KpiManagementHome]
    })
    .compileComponents();

    fixture = TestBed.createComponent(KpiManagementHome);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

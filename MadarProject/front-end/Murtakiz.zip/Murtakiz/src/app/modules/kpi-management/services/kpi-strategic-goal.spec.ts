import { TestBed } from '@angular/core/testing';

import { KpiStrategicGoal } from './kpi-strategic-goal';

describe('KpiStrategicGoal', () => {
  let service: KpiStrategicGoal;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(KpiStrategicGoal);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

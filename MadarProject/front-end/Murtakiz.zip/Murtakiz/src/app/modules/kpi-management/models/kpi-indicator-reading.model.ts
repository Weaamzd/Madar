export interface CreateKpiIndicatorReadingRequest {
  kpiCode: string;

  periodStartDate: string;   
  periodEndDate: string;    
  periodLabel: string;      

  actualValue: number;
  statusCode: string;

  dataSourceName?: string | null;
  notes?: string | null;
}


export interface KpiIndicatorReadingDto {
  id: number;

  kpiCode: string;

  periodStartDate: string;   
  periodEndDate: string;     
  periodLabel: string;

  actualValue: number;
  statusCode: string;

  dataSourceName?: string | null;
  notes?: string | null;

  enteredAt?: string | null;   
  enteredByEmpNo?: string | null;

  isLocked?: string | null;    
}

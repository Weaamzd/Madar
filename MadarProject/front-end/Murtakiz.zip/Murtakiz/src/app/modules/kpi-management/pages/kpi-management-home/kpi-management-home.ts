import { CommonModule, NgIf, NgForOf } from '@angular/common';
import {
  Component,
  OnInit,
  AfterViewInit,
  ViewChild,
  TemplateRef,
  ElementRef,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorIntl, MatPaginatorModule } from '@angular/material/paginator';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { KpiStrategicGoal } from '../../services/kpi-strategic-goal';
import { CreateKpiStrategicGoalRequest, KpiStrategicGoalDto } from '../../models/kpi-strategic-goal.model';
import { OrgLookup } from '../../../system-settings/services/org/org-lookup';
import { SubUniteDto, UniteMiniDto } from '../../../system-settings/models/org.models';
import { KpiIndicator, Page } from '../../services/kpi-indicator.service';
import { CreateKpiIndicatorRequest, KpiIndicatorDto } from '../../models/kpi-indicator.model';
import { AuthService } from '../../../../core/auth/authService';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { KpiIndicatorReading } from '../../services/kpi-indicator-reading.service';
import { CreateKpiIndicatorReadingRequest } from '../../models/kpi-indicator-reading.model';
import { KpiInitiative } from '../../services/kpi-initiative.service';
import { CreateKpiInitiativeRequest } from '../../models/kpi-initiative.model';

type FrequencyCode = '' | 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'YEARLY' | null;


/* interface KpiEntry {
  kpiId: number;     // id المؤشر
  code: string;      // كود المؤشر
  entryDate: string; // تاريخ الإدخال yyyy-MM-dd
  value: number;     // القيمة الفعلية لهذه الفترة
  note?: string;     // ملاحظة اختيارية
} */

interface KpiEntry {
  kpiId: number;
  code: string;
  entryDate: string;
  value: number;
  note?: string;
  dataSourceName?: string; 
}

interface MainKpiCard {
  row: KpiRow;              
  code: string;
  name: string;
  perspective: KpiRow['perspective'];
  target: number;
  actual: number;
  achievement: number;
  diff: number;
  lastUpdate: string;
  statusLabel: string;
  statusClass: string;
  diffClass: string;
  diffIcon: string;
}



interface KpiRow {
  id: number;
  perspective: 'المالي' | 'العملاء' | 'العمليات الداخلية' | 'التعلم والنمو';
  code: string;
  name: string;
  owner: string;
  unit: string;
  target: number;
  actual: number;
  status: 'ON_TRACK' | 'AT_RISK' | 'OFF_TRACK';
  lastUpdate: string;
  frequency: string;
  frequencyCode?: FrequencyCode;

  baseline?: number | null;
  polarity?:
    | 'HIGHER_BETTER'
    | 'LOWER_BETTER'
    | 'RANGE_BEST'
    | null;
  measurementMethod?: string | null;
  formula?: string | null;
  custodianAgency?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;

  isMain?: 'Y' | 'N';
}


interface StrategicGoalCard {
  code: string;
  title: string;
  owner: string;
  horizon: string;
  perspective: string;
  progress: number;
}

/* interface KpiInitiativeRow {
  code: string;
  name: string;
  owner: string;
  status: KpiRow['status'];
  progress: number; // نسبة التقدم %
} */

interface KpiInitiativeRow {
  code: string;
  name: string;
  owner: string; 
  status: 'ON_TRACK' | 'AT_RISK' | 'OFF_TRACK';
  progress: number;

  desc?: string;
  initiativeType: 'PLANNED' | 'CORRECTIVE';
  startDate: string;       // yyyy-MM-dd
  targetEndDate: string;   // yyyy-MM-dd
  budgetAmount?: number | null;
  linkType: 'PRIMARY' | 'CORRECTIVE' | 'SUPPORT';
}


interface OperationalGoalRow {
  id: number;
  code: string;
  name: string;

  owner: string;             
  unit: string;              

  ownerUniteId?: number | null;     
  ownerSubUniteId?: number | null;  

  goalType: 'إستراتيجي' | 'تشغيلي';
  perspective: 'المالي' | 'العملاء' | 'العمليات الداخلية' | 'التعلم والنمو';
  linkedKpis: number;
  status: KpiRow['status'];

  strategicGoalCode: StrategicGoalCard['code'];
}



function getArabicPaginatorIntl(): MatPaginatorIntl {
  const paginatorIntl = new MatPaginatorIntl();

  paginatorIntl.itemsPerPageLabel = 'عدد العناصر في الصفحة:';
  paginatorIntl.nextPageLabel = 'الصفحة التالية';
  paginatorIntl.previousPageLabel = 'الصفحة السابقة';
  paginatorIntl.firstPageLabel = 'الصفحة الأولى';
  paginatorIntl.lastPageLabel = 'الصفحة الأخيرة';

  paginatorIntl.getRangeLabel = (page, pageSize, length) => {
    if (length === 0 || pageSize === 0) {
      return `0 من ${length}`;
    }
    const startIndex = page * pageSize;
    const endIndex =
      startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} من ${length}`;
  };

  return paginatorIntl;
}


@Component({
  selector: 'app-kpi-management-home',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatIconModule,
    MatTooltipModule,
    MatButtonModule,
    MatDialogModule,
    MatSnackBarModule,
  ],
  templateUrl: './kpi-management-home.html',
  styleUrl: './kpi-management-home.css',
    providers: [
    { provide: MatPaginatorIntl, useFactory: getArabicPaginatorIntl }
  ],
})
export class KpiManagementHome implements OnInit, AfterViewInit {


kpiDialogInitiativesColumns: string[] = [
  'code',
  'name',
  'owner',
  'status',
  'progress',
  'actions',
];
kpiDialogInitiatives: KpiInitiativeRow[] = [];


kpiDialogEntriesColumns: string[] = ['entryDate', 'value', 'diff', 'note'];
kpiDialogEntries: KpiEntry[] = [];



  Math = Math;
  kpiOwnerUniteId: number | null = null;

  kpiOwnerLevel1List: SubUniteDto[] = [];
  kpiOwnerLevel2List: SubUniteDto[] = [];
  kpiOwnerLevel3List: SubUniteDto[] = [];
  kpiOwnerLevel4List: SubUniteDto[] = [];

  kpiOwnerLevel1Id: number | null = null;
  kpiOwnerLevel2Id: number | null = null;
  kpiOwnerLevel3Id: number | null = null;
  kpiOwnerLevel4Id: number | null = null;

  mainKpiCards: MainKpiCard[] = [];
  kpiOwnerSubUniteId: number | null = null;

  private buildMainKpiCards(): void {
  if (!this.allKpis || !this.allKpis.length) {
    this.mainKpiCards = [];
    return;
  }


  const mainOnly = this.allKpis.filter(r => r.isMain === 'Y');

  const source = mainOnly.length ? mainOnly : this.allKpis; 
  const sorted = [...source].sort(
    (a, b) => this.getAchievement(b) - this.getAchievement(a)
  );

  


  const top = sorted; 


  this.mainKpiCards = top.map(row => {
    const ach = this.getAchievement(row);
    const diff = (row.actual || 0) - (row.target || 0);

    let diffClass = 'mkpi-diff-zero';
    let diffIcon = 'bi-dash-lg';
    if (diff > 0) {
      diffClass = 'mkpi-diff-plus';
      diffIcon = 'bi-arrow-up-short';
    } else if (diff < 0) {
      diffClass = 'mkpi-diff-minus';
      diffIcon = 'bi-arrow-down-short';
    }

    return {
      row,
      code: row.code,
      name: row.name,
      perspective: row.perspective,
      target: row.target,
      actual: row.actual,
      achievement: ach,
      diff,
      lastUpdate: row.lastUpdate,
      statusLabel: this.getStatusLabel(row.status),
      statusClass: this.getStatusBadgeClass(row.status),
      diffClass,
      diffIcon,
    };
  });
}


  onKpiOwnerUniteChanged(uniteId: number | string | null): void {
    const idNum = Number(uniteId);
    this.kpiOwnerUniteId = Number.isFinite(idNum) ? idNum : null;

    this.kpiOwnerLevel1Id = this.kpiOwnerLevel2Id =
      this.kpiOwnerLevel3Id = this.kpiOwnerLevel4Id = null;

    this.kpiOwnerLevel1List = this.kpiOwnerLevel2List =
      this.kpiOwnerLevel3List = this.kpiOwnerLevel4List = [];

    this.kpiOwnerSubUniteId = null;
    this.newKpi.unit = '';
    this.newKpi.custodianAgency = '';

    if (!this.kpiOwnerUniteId) return;
    this.orgApi.listDirectUnderUnite(this.kpiOwnerUniteId).subscribe({
      next: (list) => {
        this.kpiOwnerLevel1List = list || [];
        this.syncKpiDeepestSelection();
      },
      error: () => {
        this.kpiOwnerLevel1List = [];
        this.syncKpiDeepestSelection();
      },
    });
  }

  
  /** جلب أبناء sub-unite لمستوى معيّن للمؤشر */
  private loadChildrenForKpiLevel(
    parentSubUniteId: number,
    targetLevel: 2 | 3 | 4
  ): void {
    this.orgApi.listDirectChildren(parentSubUniteId).subscribe({
      next: (kids) => {
        const list = kids || [];
        if (targetLevel === 2) this.kpiOwnerLevel2List = list;
        if (targetLevel === 3) this.kpiOwnerLevel3List = list;
        if (targetLevel === 4) this.kpiOwnerLevel4List = list;

        this.syncKpiDeepestSelection();
      },
      error: () => {
        if (targetLevel === 2) this.kpiOwnerLevel2List = [];
        if (targetLevel === 3) this.kpiOwnerLevel3List = [];
        if (targetLevel === 4) this.kpiOwnerLevel4List = [];
        this.syncKpiDeepestSelection();
      },
    });
  }


private loadGoalsForCurrentUser(): void {
  this.loading = true;

  let request$: Observable<Page<KpiStrategicGoalDto>> | null = null;

  if (this.auth.hasRole('SYSTEM_ADMIN') && this.auth.hasRole('PERFORMANCE_SPECIALIST_SUPER')) {
    request$ = this.goalsService.getAllGoals({
      unpaged: true,
    });

  } else if (this.auth.hasRole('PERFORMANCE_SPECIALIST_SUPER')) {
    const uniteId = this.auth.getCurrentInternalUniteId();
    if (!uniteId) {
      console.warn('لا يوجد uniteId للمستخدم الحالي (إدارة الأهداف).');
      this.operationalGoalsDataSource.data = [];
      this.refreshGoalsStats();
      this.loading = false;
      return;
    }

    request$ = this.goalsService.getGoalsByUnite({
      uniteId,
      goalType: undefined,   // نخليها فاضية عشان يرجع STRATEGIC + OPERATIONAL
      unpaged: true,
    });

  } else if (this.auth.hasRole('PERFORMANCE_SPECIALIST_SUP')) {
    const subUniteId = (this.auth as any).getCurrentInternalSubUniteId
      ? (this.auth as any).getCurrentInternalSubUniteId()
      : null;

    if (!subUniteId) {
      console.warn('لا يوجد subUniteId للمستخدم الحالي (إدارة الأهداف).');
      this.operationalGoalsDataSource.data = [];
      this.refreshGoalsStats();
      this.loading = false;
      return;
    }

    request$ = this.goalsService.getGoalsBySubUnite({
      subUniteId,
      goalType: undefined,
      unpaged: true,
    });

  } else {
    console.warn('المستخدم لا يملك أدوار إدارة الأهداف.');
    this.operationalGoalsDataSource.data = [];
    this.refreshGoalsStats();
    this.loading = false;
    return;
  }

  request$!.subscribe({
    next: (page) => {
      const list = page.content || [];

      const rows: OperationalGoalRow[] = list.map(dto =>
        this.mapGoalDtoToRow(dto)
      );

      this.operationalGoalsDataSource.data = rows;
      this.refreshGoalsStats();
      this.loading = false;
    },
    error: (err) => {
      console.error('خطأ في جلب الأهداف:', err);
      this.operationalGoalsDataSource.data = [];
      this.refreshGoalsStats();
      this.loading = false;
    },
  });
}



private mapGoalDtoToRow(dto: KpiStrategicGoalDto): OperationalGoalRow {
  const perspectiveLabel = this.getPerspectiveLabelFromCode(dto.perspectiveCode);

  let status: KpiRow['status'] = 'ON_TRACK';
  if (dto.statusCode === 'AT_RISK') status = 'AT_RISK';
  else if (dto.statusCode === 'OFF_TRACK') status = 'OFF_TRACK';
  const ownerName =
    dto.ownerUniteId != null ? this.getUniteNameById(dto.ownerUniteId) : '—';

  const unitName =
    dto.ownerSubUniteId != null
      ? (this.getSubUniteNameById(dto.ownerSubUniteId) || ownerName || '—')
      : (ownerName || '—');

  return {
    id: dto.id,
    code: dto.code,
    name: dto.nameAr,

    owner: ownerName,
    unit: unitName,
    ownerUniteId: dto.ownerUniteId ?? null,
    ownerSubUniteId: dto.ownerSubUniteId ?? null,

    goalType: dto.goalType === 'STRATEGIC' ? 'إستراتيجي' : 'تشغيلي',
    perspective: perspectiveLabel as OperationalGoalRow['perspective'],

    linkedKpis: dto.kpiCount ?? 0,
    status,

    strategicGoalCode: dto.parentGoalCode || dto.code,
  };
}



  /** عند اختيار مستوى (1/2/3/4) للوحدة المسؤولة */
  onKpiOwnerLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
    const subId = Number(subIdRaw);

    if (level === 1) {
      this.kpiOwnerLevel1Id = Number.isFinite(subId) ? subId : null;
      this.kpiOwnerLevel2Id = this.kpiOwnerLevel3Id = this.kpiOwnerLevel4Id = null;
      this.kpiOwnerLevel2List = this.kpiOwnerLevel3List = this.kpiOwnerLevel4List = [];

      if (this.kpiOwnerLevel1Id) {
        this.loadChildrenForKpiLevel(this.kpiOwnerLevel1Id, 2);
      }
    } else if (level === 2) {
      this.kpiOwnerLevel2Id = Number.isFinite(subId) ? subId : null;
      this.kpiOwnerLevel3Id = this.kpiOwnerLevel4Id = null;
      this.kpiOwnerLevel3List = this.kpiOwnerLevel4List = [];

      if (this.kpiOwnerLevel2Id) {
        this.loadChildrenForKpiLevel(this.kpiOwnerLevel2Id, 3);
      }
    } else if (level === 3) {
      this.kpiOwnerLevel3Id = Number.isFinite(subId) ? subId : null;
      this.kpiOwnerLevel4Id = null;
      this.kpiOwnerLevel4List = [];

      if (this.kpiOwnerLevel3Id) {
        this.loadChildrenForKpiLevel(this.kpiOwnerLevel3Id, 4);
      }
    } else {
      this.kpiOwnerLevel4Id = Number.isFinite(subId) ? subId : null;
    }

    this.syncKpiDeepestSelection();
  }


  private syncKpiDeepestSelection(): void {
    const deepestId =
      this.kpiOwnerLevel4Id ??
      this.kpiOwnerLevel3Id ??
      this.kpiOwnerLevel2Id ??
      this.kpiOwnerLevel1Id ??
      null;

    this.kpiOwnerSubUniteId = deepestId;

    if (this.newKpiMode === 'SUB' && this.kpiOwnerSubUniteId) {
      this.loadOperationalGoalsForSubUnite(this.kpiOwnerSubUniteId);
    }

    let deepestName: string | null = null;
    if (deepestId) {
      let found =
        this.kpiOwnerLevel4List.find(s => s.id === deepestId) ||
        this.kpiOwnerLevel3List.find(s => s.id === deepestId) ||
        this.kpiOwnerLevel2List.find(s => s.id === deepestId) ||
        this.kpiOwnerLevel1List.find(s => s.id === deepestId);

      if (found) deepestName = found.name;
    }

    this.newKpi.unit = deepestName || '';
    this.newKpi.custodianAgency = deepestName || '';
  }

  kpiEntries: KpiEntry[] = [];
  currentKpiEntry: KpiEntry | null = null;

  @ViewChild('kpiEntryDialog') kpiEntryDialogTpl!: TemplateRef<any>;

  openKpiEntryDialog(row: KpiRow) {
    this.currentKpiEntry = {
      kpiId: row.id,
      code: row.code,
      entryDate: new Date().toISOString().slice(0, 10), 
      value: row.actual || 0,
      note: '',
    };

    this.dialog.open(this.kpiEntryDialogTpl, {
      panelClass: 'goal-dialog-panel',
      width: '600px',
      maxWidth: '95vw',
    });
  }


  closeKpiEntryDialog() {
    this.dialog.closeAll();
  }


  saveKpiEntry() {
  if (!this.currentKpiEntry || this.currentKpiEntry.value == null || !this.currentKpiEntry.entryDate) {
    this.snack.open('❗ الرجاء اختيار تاريخ وإدخال القيمة الفعلية للمؤشر.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
    return;
  }

  const entry: KpiEntry = { ...this.currentKpiEntry };

  const kpiRow = this.allKpis.find(k => k.id === entry.kpiId);
  if (!kpiRow) {
    this.snack.open('❌ لم يتم العثور على المؤشر المرتبط بهذا الإدخال.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
    return;
  }

  const freqCode = kpiRow.frequencyCode || null;
  const period = this.getEntryPeriodDates(freqCode);
  const periodStartDate = period ? this.formatDate(period.from) : entry.entryDate;
  const periodEndDate   = period ? this.formatDate(period.to)   : entry.entryDate;

  const periodLabel = this.buildPeriodLabel(entry.entryDate, freqCode);

  const statusCode = this.buildStatusCodeForValue(entry.kpiId, entry.value);

  const payload: CreateKpiIndicatorReadingRequest = {
    kpiCode: entry.code,
    periodStartDate,
    periodEndDate,
    periodLabel,
    actualValue: entry.value,
    statusCode,
    dataSourceName: entry.dataSourceName || null,
    notes: entry.note || null,
  };

  this.loading = true;

  this.readingsApi.createReading(payload).subscribe({
  next: (reading) => {
  this.loading = false;

  if (kpiRow) {
    this.loadReadingsForKpi(kpiRow);
  }

  const idx = this.allKpis.findIndex(k => k.id === entry.kpiId);
  if (idx >= 0) {
    this.allKpis[idx] = {
      ...this.allKpis[idx],
      actual: entry.value,
      lastUpdate: entry.entryDate,
    };
  }

  this.refreshTable();
  this.closeKpiEntryDialog();

  this.snack.open('✅ تم حفظ قراءة المؤشر في النظام.', 'إغلاق', {
    duration: 3000,
    horizontalPosition: 'center',
    verticalPosition: 'top',
    direction: 'rtl',
    panelClass: ['snack-on-top'],
  });
},


    error: (err) => {
      this.loading = false;
      console.error('خطأ في حفظ القراءة:', err);
      this.snack.open(
        '❌ حدث خطأ أثناء حفظ قراءة المؤشر. الرجاء المحاولة لاحقاً.',
        'إغلاق',
        {
          duration: 4000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        }
      );
    },
  });
}


  getSelectedKpiName(id: number | undefined | null): string {
    if (!id) return '';
    const row = this.allKpis.find(k => k.id === id);
    return row ? row.name : '';
  }

  getSelectedKpiTarget(id: number | undefined | null): number {
    if (!id) return 0;
    const row = this.allKpis.find(k => k.id === id);
    return row ? row.target : 0;
  }


  ownerOptions: string[] = [
    'الإدارة المالية',
    'إدارة تجربة العميل',
    'إدارة التقنية والتطوير',
    'إدارة العمليات',
    'إدارة الموارد البشرية',
    'إدارة الجودة',
  ];

  unitOptions: string[] = [
    'وحدة التقارير والتحليلات',
    'وحدة البنية التحتية',
    'مكتب إدارة المشاريع',
    'وحدة قنوات الخدمة',
    'وحدة التدريب والتطوير',
    'وحدة المخاطر التشغيلية',
  ];

  custodianOptions: string[] = [
    'وكالة الشؤون المالية',
    'وكالة الشؤون الإدارية',
    'وكالة التحول الرقمي',
    'وكالة الخدمات الميدانية',
  ];

  frequencyOptions = [
    { code: 'MONTHLY', label: 'شهري' },
    { code: 'QUARTERLY', label: 'ربع سنوي' },
    { code: 'SEMI_ANNUAL', label: 'نصف سنوي' },
    { code: 'YEARLY', label: 'سنوي' },
  ];


  getFrequencyLabel(code: string | '' | null): string {
    const opt = this.frequencyOptions.find(o => o.code === code);
    return opt ? opt.label : '';
  }

  /** أي تبويب مفتوح الآن */
  tab: 'kpis' | 'goals' = 'kpis';

  /** كروت الأهداف الاستراتيجية الخمسة */
  strategicGoalsTop5: StrategicGoalCard[] = [];

  /** جدول الأهداف التشغيلية */
  operationalGoalsDisplayedColumns: string[] = [
    'code',
    'name',
    'owner',
    'unit',
    'goalType',
    'perspective',
    'operationalGoalsCount',
    'linkedKpis',
    'status',
    'actions',
  ];

  operationalGoalsDataSource = new MatTableDataSource<OperationalGoalRow>([]);

  /** عدد الأهداف التشغيلية تحت نفس الهدف الاستراتيجي */
  getOperationalGoalsCountForStrategicGroup(row: OperationalGoalRow): number {
    if (!this.operationalGoalsDataSource?.data) {
      return 0;
    }

    return this.operationalGoalsDataSource.data.filter(
      r => r.strategicGoalCode === row.strategicGoalCode
    ).length;
  }


  /** حالة واجهة المستخدم */
  loading = false;
  errorMsg = '';

  /** البحث والفلاتر */
  searchActive = false;
  searchText = '';
  selectedSort = 'achievement,desc';
  statusFilter = '';
  perspectiveFilter = '';

  /** إحصاءات الهيدر */
  totalKpis = 0;
  onTrackCount = 0;
  atRiskCount = 0;
  offTrackCount = 0;


  getKpiTypeLabel(isMain?: 'Y' | 'N'): string {
  return isMain === 'Y' ? 'مؤشر إستراتيجي' : 'مؤشر تشغيلي';
}


  /** الأعمدة */


displayedColumns: string[] = [
  'rank',
  'code',
  'name',
  'perspective',
  'type',       
  'owner',
  'unit',
  'target',
  'actual',
  'achievement',
  'status',
  'lastUpdate',
  'actions',
];


  /** البيانات */
  private allKpis: KpiRow[] = [];
  dataSource = new MatTableDataSource<KpiRow>([]);

  /** الهدف التشغيلي/الاستراتيجي المحدد للتفاصيل */
  selectedOperationalGoal: OperationalGoalRow | null = null;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  private _operationalPaginator!: MatPaginator;

@ViewChild('operationalPaginator') 
set operationalPaginator(p: MatPaginator) {
  if (p) {
    this._operationalPaginator = p;
    this.operationalGoalsDataSource.paginator = p;
  }
}

  @ViewChild('operationalGoalDetails') operationalGoalDetailsTpl!: TemplateRef<any>;

constructor(
  private dialog: MatDialog,
  private goalsService: KpiStrategicGoal,
  private orgApi: OrgLookup,
  private indicatorsApi: KpiIndicator,
  private auth: AuthService,
  private snack: MatSnackBar,
  private readingsApi: KpiIndicatorReading,
  private initiativesApi: KpiInitiative  
) { }


  private loadStrategicGoalsForCurrentUnite(): void {
    const uniteId = this.auth.getCurrentInternalUniteId();

    if (!uniteId) {
      console.warn('لا يوجد uniteId للمستخدم الحالي (ربما EXTERNAL أو بدون ربط).');
      this.strategicGoalsTop5 = [];
      return;
    }

    this.loading = true;

    this.goalsService.getGoalsByUnite({
      uniteId: uniteId,
      goalType: 'STRATEGIC', 
      unpaged: true,           
    }).subscribe({
      next: (page) => {
        const rows = page.content || [];

        this.strategicGoalsTop5 = rows.map((dto) => ({
          code: dto.code,
          title: dto.nameAr,
          owner: '—', 
          horizon: `${dto.horizonFromYear}–${dto.horizonToYear}`,
          perspective: this.getPerspectiveLabelFromCode(dto.perspectiveCode),
          progress: dto.progressPct ?? 0,
        }));

        this.loading = false;

        if (!this.newGoalStrategicCode && this.strategicGoalsTop5.length) {
          this.newGoalStrategicCode = this.strategicGoalsTop5[0].code;
          this.newGoalParentCode = this.newGoalStrategicCode;
        }
      },
      error: (err) => {
        console.error('خطأ في جلب الأهداف الاستراتيجية:', err);
        this.loading = false;
        this.strategicGoalsTop5 = [];
      }
    });
  }

private subUniteNameCache = new Map<number, string>();

freshnessByPerspective: {
  name: string;
  total: number;
  updated: number;
  pct: number;
}[] = [];

riskKpiTypeDistribution = {
  main: 0,
  sub: 0,
};

reviewSeverityStats: {
  severity: 'high' | 'medium' | 'low';
  label: string;
  value: number;
}[] = [];

maxReviewSeverityValue = 0;

perspectiveOptions = [
  /** المالي */
  { code: 'FINANCIAL', label: 'المالي' },
  { code: 'FIN',       label: 'المالي' },

  /** العملاء */
  { code: 'CUSTOMER',  label: 'العملاء' },
  { code: 'CUST',      label: 'العملاء' },

  /** العمليات الداخلية */
  { code: 'INTERNAL',  label: 'العمليات الداخلية' },
  { code: 'INT',       label: 'العمليات الداخلية' },

  /** التعلم والنمو */
  { code: 'LEARNING',  label: 'التعلم والنمو' },
  { code: 'LEARN',     label: 'التعلم والنمو' },
];


  unitesMini: UniteMiniDto[] = [];


  getUniteNameById(id: number | null | undefined): string {
    if (!id) return '';

    const unite = this.unitesMini.find(u => u.id === id);
    return unite ? unite.name : '';
  }


  ownerLevel1List: SubUniteDto[] = [];
  ownerLevel2List: SubUniteDto[] = [];
  ownerLevel3List: SubUniteDto[] = [];
  ownerLevel4List: SubUniteDto[] = [];


  selectedOwnerUniteId: number | null = null;
  selectedOwnerLevel1Id: number | null = null;
  selectedOwnerLevel2Id: number | null = null;
  selectedOwnerLevel3Id: number | null = null;
  selectedOwnerLevel4Id: number | null = null;

  selectedOwnerSubUniteId: number | null = null;


  get ownerShowL1(): boolean {
    return this.ownerLevel1List.length > 0;
  }
  get ownerShowL2(): boolean {
    return this.ownerLevel2List.length > 0;
  }
  get ownerShowL3(): boolean {
    return this.ownerLevel3List.length > 0;
  }
  get ownerShowL4(): boolean {
    return this.ownerLevel4List.length > 0;
  }



  private seedStrategicGoals() {
    this.strategicGoalsTop5 = [
      {
        code: 'SG-01',
        title: 'تعزيز الاستدامة المالية للمؤسسة',
        owner: 'الإدارة المالية',
        horizon: '2025–2027',
        perspective: 'المالي',
        progress: 68,
      },
      {
        code: 'SG-02',
        title: 'رفع رضا المستفيدين عن الخدمات المقدمة',
        owner: 'إدارة تجربة العميل',
        horizon: '2024–2026',
        perspective: 'العملاء',
        progress: 74,
      },
      {
        code: 'SG-03',
        title: 'تحسين كفاءة وموثوقية العمليات الداخلية',
        owner: 'إدارة العمليات',
        horizon: '2024–2027',
        perspective: 'العمليات الداخلية',
        progress: 59,
      },
      {
        code: 'SG-04',
        title: 'تعزيز القدرات الرقمية والتحول الذكي',
        owner: 'إدارة التقنية والتطوير',
        horizon: '2024–2028',
        perspective: 'العمليات الداخلية',
        progress: 63,
      },
      {
        code: 'SG-05',
        title: 'تنمية رأس المال البشري وبناء القيادات',
        owner: 'إدارة الموارد البشرية',
        horizon: '2025–2029',
        perspective: 'التعلم والنمو',
        progress: 71,
      },
    ];
  }

  private seedOperationalGoals() {
    const names = [
      'رفع جاهزية البنية التحتية التقنية',
      'تقليل زمن إنجاز الطلبات الرئيسية',
      'زيادة نسبة الأتمتة في العمليات الحرجة',
      'تحسين دقة بيانات المستفيدين',
      'تقليل عدد أعطال الأنظمة الرئيسية',
      'رفع نسبة الالتزام بإجراءات الجودة',
      'زيادة نسبة استخدام القنوات الرقمية',
      'تحسين استجابة مركز الاتصال',
      'زيادة نسبة تنفيذ خطط التدريب',
      'تحسين معدل الاحتفاظ بالموظفين الموهوبين',
    ];

    const owners = [
      'الإدارة المالية',
      'إدارة تجربة العميل',
      'إدارة التقنية والتطوير',
      'إدارة العمليات',
      'إدارة الموارد البشرية',
      'إدارة الجودة',
    ];

    const units = [
      'وحدة التقارير والتحليلات',
      'وحدة البنية التحتية',
      'مكتب إدارة المشاريع',
      'وحدة قنوات الخدمة',
      'وحدة التدريب والتطوير',
      'وحدة المخاطر التشغيلية',
    ];

    const perspectives: OperationalGoalRow['perspective'][] = [
      'المالي',
      'العملاء',
      'العمليات الداخلية',
      'التعلم والنمو',
    ];

    const statuses: KpiRow['status'][] = ['ON_TRACK', 'AT_RISK', 'OFF_TRACK'];


    const strategicCodes: StrategicGoalCard['code'][] = [
      'SG-01',
      'SG-02',
      'SG-03',
      'SG-04',
      'SG-05',
    ];

    const goals: OperationalGoalRow[] = [];
    let id = 1;


    for (let i = 0; i < 32; i++) {
      const name = names[i % names.length];
      const owner = owners[i % owners.length];
      const unit = units[i % units.length];
      const perspective = perspectives[i % perspectives.length];
      const status = statuses[i % statuses.length];

      const strategicGoalCode = strategicCodes[i % strategicCodes.length];

      goals.push({
        id,
        code: `OPG-${id.toString().padStart(3, '0')}`,
        name,
        owner,
        unit,
        goalType: i % 5 === 0 ? 'إستراتيجي' : 'تشغيلي', 
        perspective,
        linkedKpis: 1 + (i % 5), 
        status,
        strategicGoalCode,
      });

      id++;
    }


    this.operationalGoalsDataSource.data = goals;
    this.refreshGoalsStats();   

  }


  createStrategicGoal() {
    this.snack.open('ℹ سيتم لاحقًا فتح شاشة إضافة هدف إستراتيجي جديد.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
  }


  createOperationalKpi() {
    this.snack.open('ℹ سيتم لاحقًا فتح شاشة إضافة مؤشر/هدف تشغيلي جديد.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
  }


  /** فتح تفاصيل الهدف التشغيلي/الاستراتيجي في Dialog */
  viewOperationalGoalDetails(row: OperationalGoalRow) {
    this.selectedOperationalGoal = row;

    this.dialog.open(this.operationalGoalDetailsTpl, {
          panelClass: 'kpi-dialog-panel',
    width: '900px',
    maxWidth: '95vw',
    maxHeight: '90vh',
    });
  }

  @ViewChild('mainKpiContainer') mainKpiContainer!: ElementRef<HTMLDivElement>;

scrollMainKpi(direction: 'left' | 'right') {
  const el = this.mainKpiContainer.nativeElement;
  const cardWidth = 320;
  const gap = 16;
  const amount = cardWidth + gap;

  el.scrollBy({
    left: direction === 'left' ? amount : -amount,  // RTL
    behavior: 'smooth',
  });
}


  closeOperationalDetails() {
    this.dialog.closeAll();
  }


  getChildItems(goal: OperationalGoalRow) {
    const items: { code: string; name: string; type: string }[] = [];

    for (let i = 0; i < goal.linkedKpis; i++) {
      items.push({
        code: `${goal.code}-KPI-${(i + 1).toString().padStart(2, '0')}`,
        name: `مؤشر مرتبط رقم ${i + 1}`,
        type: goal.goalType === 'إستراتيجي' ? 'مؤشر إستراتيجي' : 'مؤشر تشغيلي',
      });
    }

    return items;
  }

  /** عدد الأهداف التشغيلية المرتبطة بكل هدف إستراتيجي */
  getOperationalGoalsCountForStrategicGoal(goalCode: string): number {
    if (!this.operationalGoalsDataSource?.data) {
      return 0;
    }
    return this.operationalGoalsDataSource.data.filter(
      (row) => row.strategicGoalCode === goalCode
    ).length;
  }

  /** (اختياري) فلترة جدول الأهداف التشغيلية حسب الهدف الإستراتيجي */
  filterOperationalByStrategicGoal(goalCode: string) {
    this.operationalGoalsDataSource.filterPredicate = (row, filter) =>
      row.strategicGoalCode === filter;

    this.operationalGoalsDataSource.filter = goalCode;

    if (this.operationalPaginator) {
      this.operationalPaginator.firstPage();
    }
  }

  /** تحميل كل الوحدات (mini) لاستخدامها في واجهة إضافة هدف */
private loadUnitesMiniForGoals(onDone?: () => void): void {
  this.orgApi.listAllUnitesMini().subscribe({
    next: (data) => {
      this.unitesMini = data || [];
      if (onDone) onDone();
    },
    error: () => {
      this.unitesMini = [];
      if (onDone) onDone();
    },
  });
}


  onOwnerUniteChanged(uniteId: number | string | null): void {
    const idNum = Number(uniteId);
    const safeId = Number.isFinite(idNum) ? idNum : null;

    this.newGoal.ownerUniteId = safeId;

    this.handleOwnerUniteChange(safeId);
  }
  private handleOwnerUniteChange(uniteId: number | null): void {
    const idNum = Number(uniteId);
    this.selectedOwnerUniteId = Number.isFinite(idNum) ? idNum : null;


    this.selectedOwnerLevel1Id = this.selectedOwnerLevel2Id =
      this.selectedOwnerLevel3Id = this.selectedOwnerLevel4Id = null;

    this.ownerLevel1List = this.ownerLevel2List =
      this.ownerLevel3List = this.ownerLevel4List = [];

    this.selectedOwnerSubUniteId = null;
    this.newGoal.ownerSubUniteId = null;

    if (!this.selectedOwnerUniteId) {
      return;
    }


    this.orgApi.listDirectUnderUnite(this.selectedOwnerUniteId).subscribe({
      next: (list) => {
        this.ownerLevel1List = list || [];
        this.syncOwnerDeepestSelection();
      },
      error: () => {
        this.ownerLevel1List = [];
        this.syncOwnerDeepestSelection();
      },
    });
  }
  /** جلب أبناء sub-unite لمستوى معيّن */
  private loadChildrenForOwnerLevel(
    parentSubUniteId: number,
    targetLevel: 2 | 3 | 4
  ): void {
    this.orgApi.listDirectChildren(parentSubUniteId).subscribe({
      next: (kids) => {
        const list = kids || [];
        if (targetLevel === 2) this.ownerLevel2List = list;
        if (targetLevel === 3) this.ownerLevel3List = list;
        if (targetLevel === 4) this.ownerLevel4List = list;

        this.syncOwnerDeepestSelection();
      },
      error: () => {
        if (targetLevel === 2) this.ownerLevel2List = [];
        if (targetLevel === 3) this.ownerLevel3List = [];
        if (targetLevel === 4) this.ownerLevel4List = [];
        this.syncOwnerDeepestSelection();
      },
    });
  }
  /** عند اختيار شعبة/وحدة فرعية في مستوى معين */
  onOwnerLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
    const subId = Number(subIdRaw);

    if (level === 1) {
      this.selectedOwnerLevel1Id = Number.isFinite(subId) ? subId : null;
      this.selectedOwnerLevel2Id = this.selectedOwnerLevel3Id = this.selectedOwnerLevel4Id = null;
      this.ownerLevel2List = this.ownerLevel3List = this.ownerLevel4List = [];

      if (this.selectedOwnerLevel1Id) {
        this.loadChildrenForOwnerLevel(this.selectedOwnerLevel1Id, 2);
      }
    } else if (level === 2) {
      this.selectedOwnerLevel2Id = Number.isFinite(subId) ? subId : null;
      this.selectedOwnerLevel3Id = this.selectedOwnerLevel4Id = null;
      this.ownerLevel3List = this.ownerLevel4List = [];

      if (this.selectedOwnerLevel2Id) {
        this.loadChildrenForOwnerLevel(this.selectedOwnerLevel2Id, 3);
      }
    } else if (level === 3) {
      this.selectedOwnerLevel3Id = Number.isFinite(subId) ? subId : null;
      this.selectedOwnerLevel4Id = null;
      this.ownerLevel4List = [];

      if (this.selectedOwnerLevel3Id) {
        this.loadChildrenForOwnerLevel(this.selectedOwnerLevel3Id, 4);
      }
    } else {
      this.selectedOwnerLevel4Id = Number.isFinite(subId) ? subId : null;
    }

    this.syncOwnerDeepestSelection();
  }
  /** حفظ أعمق subUniteId في newGoal.ownerSubUniteId */
  private syncOwnerDeepestSelection(): void {
    const deepest =
      this.selectedOwnerLevel4Id ??
      this.selectedOwnerLevel3Id ??
      this.selectedOwnerLevel2Id ??
      this.selectedOwnerLevel1Id ??
      null;

    this.selectedOwnerSubUniteId = deepest;
    this.newGoal.ownerSubUniteId = deepest;
  }


  private mapIndicatorDtoToRow(dto: KpiIndicatorDto): KpiRow {
  const perspectiveLabel = this.getPerspectiveLabelFromCode(dto.perspectiveCode);

  const ownerUnitName =
    dto.ownerUniteId != null ? this.getUniteNameById(dto.ownerUniteId) : '—';

  const responsibleUnitName =
    dto.ownerSubUniteId != null
      ? this.getSubUniteNameById(dto.ownerSubUniteId)
      : ownerUnitName || '—';

  return {
    id: dto.id,
    perspective: perspectiveLabel as any,
    code: dto.code,
    name: dto.nameAr,
    owner: ownerUnitName,
    unit: responsibleUnitName,
    ownerUniteId: dto.ownerUniteId ?? null,
    ownerSubUniteId: dto.ownerSubUniteId ?? null,
    target: dto.targetValue ?? 0,
    actual: 0,
    status: (dto.currentStatus as any) || 'ON_TRACK',
    lastUpdate: dto.lastUpdateDate || '',
    frequency: this.getFrequencyLabel(dto.frequencyCode || ''),
    frequencyCode: (dto.frequencyCode || this.newKpi.frequencyCode || null) as FrequencyCode,
    baseline: dto.baselineValue ?? null,
    polarity: (dto.polarityCode as any) || null,
    measurementMethod: dto.measurementMethod || null,
    formula: dto.formulaText || null,
    custodianAgency: null,

    isMain: (dto.isMain as 'Y' | 'N') ?? 'Y',
  };
}





private normalizeFrequencyCode(code: string | null | undefined): FrequencyCode {
  if (!code) return null;

  const allowed: FrequencyCode[] = [
    'MONTHLY',
    'QUARTERLY',
    'SEMI_ANNUAL',
    'YEARLY',
    '',
    null,
  ];

  return allowed.includes(code as FrequencyCode) ? (code as FrequencyCode) : null;
}

  



private loadKpisForCurrentUser(): void {
  this.loading = true;
  this.errorMsg = '';

  let request$: Observable<Page<KpiIndicatorDto>> | null = null;

  if (this.auth.hasRole('SYSTEM_ADMIN')) {
    request$ = this.indicatorsApi.searchIndicators({
      unpaged: true,         
    });


  } else if (this.auth.hasRole('PERFORMANCE_SPECIALIST_SUPER')) {
    const uniteId = this.auth.getCurrentInternalUniteId();
    if (!uniteId) {
      console.warn('لا يوجد uniteId للمستخدم الحالي.');
      this.allKpis = [];
      this.refreshTable();
      this.loading = false;
      return;
    }

    request$ = this.indicatorsApi.searchIndicators({
      ownerUniteId: uniteId,
      unpaged: true,
    });


  } else if (this.auth.hasRole('PERFORMANCE_SPECIALIST_SUP')) {
    const subUniteId = (this.auth as any).getCurrentInternalSubUniteId
      ? (this.auth as any).getCurrentInternalSubUniteId()
      : null;

    if (!subUniteId) {
      console.warn('لا يوجد subUniteId للمستخدم الحالي.');
      this.allKpis = [];
      this.refreshTable();
      this.loading = false;
      return;
    }

    request$ = this.indicatorsApi.searchIndicators({
      ownerSubUniteId: subUniteId,
      unpaged: true,
    });

  } else {
    console.warn('المستخدم لا يملك أدوار إدارة المؤشرات.');
    this.allKpis = [];
    this.refreshTable();
    this.loading = false;
    return;
  }

  request$!.subscribe({
    next: (page) => {
      const list = page.content || [];

      this.allKpis = list.map(dto => this.mapIndicatorDtoToRow(dto));

      this.refreshTable();

      this.allKpis.forEach(row => {
        this.loadReadingsForKpi(row);   
      });

      this.loading = false;
    },
    error: (err) => {
      console.error('خطأ في جلب المؤشرات:', err);
      this.errorMsg = 'حدث خطأ أثناء جلب بيانات المؤشرات من الخادم.';
      this.allKpis = [];
      this.refreshTable();
      this.loading = false;
    },
  });
}



ngOnInit(): void {

  this.loadUnitesMiniForGoals(() => {
    this.loadKpisForCurrentUser();
  });

  this.loadStrategicGoalsForCurrentUnite();

  this.loadMainKpisForCurrentUnite();

  this.loadOperationalGoalsForCurrentUnite();

  this.loadGoalsForCurrentUser();

  this.refreshTable();

  // this.seedOperationalGoals();
}



/* ngOnInit(): void {

  this.loadUnitesMiniForGoals(() => {
    this.loadKpisForCurrentUser();
  });

  this.loadStrategicGoalsForCurrentUnite();
  this.loadMainKpisForCurrentUnite();
  this.loadOperationalGoalsForCurrentUnite();
  this.seedOperationalGoals();
  this.refreshTable();
}
 */

/*   ngOnInit(): void {
    //is.seedData();
  this.loadKpisForCurrentUser();

    this.loadStrategicGoalsForCurrentUnite();


    this.loadMainKpisForCurrentUnite();


    this.loadOperationalGoalsForCurrentUnite();

    this.seedOperationalGoals();
    this.refreshTable();
    this.loadUnitesMiniForGoals();
  }
 */
  



  private loadOperationalGoalsForCurrentUnite(): void {
    const uniteId = this.auth.getCurrentInternalUniteId();
    if (!uniteId) {
      console.warn('لا يوجد uniteId للمستخدم الحالي للأهداف التشغيلية.');
      this.operationalGoalsForKpiOwner = [];
      return;
    }

    this.goalsService.getGoalsByUnite({
      uniteId: uniteId,
      goalType: 'OPERATIONAL',
      unpaged: true,
    }).subscribe({
      next: (page) => {
        this.operationalGoalsForKpiOwner = page.content || [];
      },
      error: (err) => {
        console.error('خطأ في جلب الأهداف التشغيلية بالوحدة:', err);
        this.operationalGoalsForKpiOwner = [];
      },
    });
  }

  private loadOperationalGoalsForSubUnite(subUniteId: number): void {
    this.goalsService.getGoalsBySubUnite({
      subUniteId: subUniteId,
      goalType: 'OPERATIONAL',
      unpaged: true,
    }).subscribe({
      next: (page) => {

        this.operationalGoalsForKpiOwner = page.content || [];
      },
      error: (err) => {
        console.error('خطأ في جلب الأهداف التشغيلية للوحدة الفرعية:', err);
        this.loadOperationalGoalsForCurrentUnite();
      },
    });
  }



ngAfterViewInit(): void {
  this.dataSource.paginator = this.paginator;

}


goalGaugeRadius = 46;
goalGaugeCircumference = 2 * Math.PI * this.goalGaugeRadius;


getGoalAchievement(g: any): number {
  const goals = this.getOperationalGoalsUnderSameStrategic(g) || [];
  if (!goals.length) {
    return 0;
  }

  const onTrack = goals.filter(x => x.status === 'ON_TRACK').length;
  return (onTrack / goals.length) * 100;
}

getOnTrackCount(g: any): number {
  const goals = this.getOperationalGoalsUnderSameStrategic(g) || [];
  return goals.filter(x => x.status === 'ON_TRACK').length;
}

getGoalGaugeDashOffset(g: any): number {
  const achievement = Math.max(0, Math.min(100, this.getGoalAchievement(g) || 0));
  return this.goalGaugeCircumference - (achievement / 100) * this.goalGaugeCircumference;
}

  setTab(tab: 'kpis' | 'goals') {
    this.tab = tab;
  }


  private seedData() {
    const rows: KpiRow[] = [
      {
        id: 1,
        perspective: 'المالي',
        code: 'FIN-001',
        name: 'نمو الإيرادات السنوية',
        owner: 'الإدارة المالية',
        unit: 'الإدارة العامة',
        target: 12,
        actual: 10.5,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-20',
        frequency: 'ربع سنوي',
      },
      {
        id: 2,
        perspective: 'المالي',
        code: 'FIN-002',
        name: 'خفض التكاليف التشغيلية',
        owner: 'الإدارة المالية',
        unit: 'وحدة التخطيط المالي',
        target: 8,
        actual: 5.2,
        status: 'AT_RISK',
        lastUpdate: '2025-11-18',
        frequency: 'شهري',
      },
      {
        id: 3,
        perspective: 'المالي',
        code: 'FIN-003',
        name: 'هامش الربحية الصافي',
        owner: 'الإدارة المالية',
        unit: 'قسم التقارير',
        target: 18,
        actual: 14.7,
        status: 'AT_RISK',
        lastUpdate: '2025-11-15',
        frequency: 'ربع سنوي',
      },
      {
        id: 4,
        perspective: 'المالي',
        code: 'FIN-004',
        name: 'نسبة الالتزام بالميزانية المعتمدة',
        owner: 'الإدارة المالية',
        unit: 'وحدة الميزانية',
        target: 95,
        actual: 97,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-10',
        frequency: 'شهري',
      },
      {
        id: 5,
        perspective: 'المالي',
        code: 'FIN-005',
        name: 'قيمة المشاريع المتعثرة',
        owner: 'الإدارة المالية',
        unit: 'وحدة متابعة المشاريع',
        target: 5,
        actual: 9,
        status: 'OFF_TRACK',
        lastUpdate: '2025-11-05',
        frequency: 'شهري',
      },

      {
        id: 6,
        perspective: 'العملاء',
        code: 'CUS-001',
        name: 'مستوى رضا المستفيدين عن الخدمات',
        owner: 'إدارة تجربة العميل',
        unit: 'وحدة استطلاعات الرأي',
        target: 90,
        actual: 88,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-21',
        frequency: 'ربع سنوي',
      },
      {
        id: 7,
        perspective: 'العملاء',
        code: 'CUS-002',
        name: 'نسبة الشكاوى المغلقة في الوقت المحدد',
        owner: 'إدارة تجربة العميل',
        unit: 'مركز الاتصال',
        target: 92,
        actual: 86,
        status: 'AT_RISK',
        lastUpdate: '2025-11-17',
        frequency: 'شهري',
      },
      {
        id: 8,
        perspective: 'العملاء',
        code: 'CUS-003',
        name: 'متوسط زمن الاستجابة للطلبات',
        owner: 'إدارة تجربة العميل',
        unit: 'قسم الدعم',
        target: 3,
        actual: 4.5,
        status: 'OFF_TRACK',
        lastUpdate: '2025-11-13',
        frequency: 'شهري',
      },
      {
        id: 9,
        perspective: 'العملاء',
        code: 'CUS-004',
        name: 'نسبة تبني الخدمات الرقمية',
        owner: 'إدارة التحول الرقمي',
        unit: 'منصة الخدمات الإلكترونية',
        target: 75,
        actual: 72,
        status: 'AT_RISK',
        lastUpdate: '2025-11-09',
        frequency: 'ربع سنوي',
      },
      {
        id: 10,
        perspective: 'العملاء',
        code: 'CUS-005',
        name: 'مؤشر ولاء العملاء',
        owner: 'إدارة تجربة العميل',
        unit: 'وحدة أبحاث السوق',
        target: 80,
        actual: 79,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-06',
        frequency: 'نصف سنوي',
      },

      {
        id: 11,
        perspective: 'العمليات الداخلية',
        code: 'PROC-001',
        name: 'نسبة إنجاز المشاريع في الوقت المحدد',
        owner: 'إدارة المشاريع',
        unit: 'مكتب إدارة المشاريع',
        target: 90,
        actual: 84,
        status: 'AT_RISK',
        lastUpdate: '2025-11-19',
        frequency: 'ربع سنوي',
      },
      {
        id: 12,
        perspective: 'العمليات الداخلية',
        code: 'PROC-002',
        name: 'نسبة العمليات المؤتمتة',
        owner: 'إدارة التقنية والتطوير',
        unit: 'فريق الأتمتة',
        target: 60,
        actual: 55,
        status: 'AT_RISK',
        lastUpdate: '2025-11-16',
        frequency: 'ربع سنوي',
      },
      {
        id: 13,
        perspective: 'العمليات الداخلية',
        code: 'PROC-003',
        name: 'نسبة الالتزام بإجراءات الجودة',
        owner: 'إدارة الجودة',
        unit: 'وحدة التدقيق الداخلي',
        target: 98,
        actual: 97.5,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-12',
        frequency: 'شهري',
      },
      {
        id: 14,
        perspective: 'العمليات الداخلية',
        code: 'PROC-004',
        name: 'متوسط زمن دورة الإجراء الرئيسية',
        owner: 'إدارة الإجراءات',
        unit: 'وحدة تحسين العمليات',
        target: 7,
        actual: 9,
        status: 'OFF_TRACK',
        lastUpdate: '2025-11-08',
        frequency: 'شهري',
      },
      {
        id: 15,
        perspective: 'العمليات الداخلية',
        code: 'PROC-005',
        name: 'عدد الحوادث التشغيلية الحرجة',
        owner: 'إدارة المخاطر',
        unit: 'وحدة المخاطر التشغيلية',
        target: 2,
        actual: 3,
        status: 'OFF_TRACK',
        lastUpdate: '2025-11-04',
        frequency: 'شهري',
      },


      {
        id: 16,
        perspective: 'التعلم والنمو',
        code: 'LG-001',
        name: 'نسبة تنفيذ خطة التدريب السنوية',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة التدريب والتطوير',
        target: 95,
        actual: 92,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-22',
        frequency: 'ربع سنوي',
      },
      {
        id: 17,
        perspective: 'التعلم والنمو',
        code: 'LG-002',
        name: 'نسبة الموظفين الذين يمتلكون مهارات رقمية أساسية',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة التطوير القيادي',
        target: 85,
        actual: 78,
        status: 'AT_RISK',
        lastUpdate: '2025-11-18',
        frequency: 'نصف سنوي',
      },
      {
        id: 18,
        perspective: 'التعلم والنمو',
        code: 'LG-003',
        name: 'معدل دوران الموظفين الموهوبين',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة تخطيط القوى العاملة',
        target: 5,
        actual: 7.5,
        status: 'OFF_TRACK',
        lastUpdate: '2025-11-14',
        frequency: 'سنوي',
      },
      {
        id: 19,
        perspective: 'التعلم والنمو',
        code: 'LG-004',
        name: 'نسبة الموظفين المشاركين في فرق التحسين',
        owner: 'إدارة الجودة',
        unit: 'فرق التحسين المستمر',
        target: 40,
        actual: 36,
        status: 'AT_RISK',
        lastUpdate: '2025-11-11',
        frequency: 'ربع سنوي',
      },
      {
        id: 20,
        perspective: 'التعلم والنمو',
        code: 'LG-005',
        name: 'معدل مشاركة الموظفين في استطلاعات الرأي الداخلية',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة ثقافة المؤسسة',
        target: 75,
        actual: 73,
        status: 'ON_TRACK',
        lastUpdate: '2025-11-07',
        frequency: 'سنوي',
      },


      {
        id: 21,
        perspective: 'المالي',
        code: 'FIN-006',
        name: 'نسبة التحصيل من الذمم المدينة',
        owner: 'الإدارة المالية',
        unit: 'وحدة التحصيل',
        target: 96,
        actual: 93,
        status: 'AT_RISK',
        lastUpdate: '2025-11-03',
        frequency: 'شهري',
      },
      {
        id: 22,
        perspective: 'العملاء',
        code: 'CUS-006',
        name: 'نسبة إعادة استخدام الخدمة من نفس المستفيد',
        owner: 'إدارة تجربة العميل',
        unit: 'وحدة التحليلات',
        target: 65,
        actual: 61,
        status: 'AT_RISK',
        lastUpdate: '2025-11-01',
        frequency: 'ربع سنوي',
      },
      {
        id: 23,
        perspective: 'العمليات الداخلية',
        code: 'PROC-006',
        name: 'نسبة الخدمات المقدمة آليًا بالكامل',
        owner: 'إدارة التقنية والتطوير',
        unit: 'منصة الخدمات',
        target: 55,
        actual: 52,
        status: 'AT_RISK',
        lastUpdate: '2025-10-29',
        frequency: 'ربع سنوي',
      },
      {
        id: 24,
        perspective: 'التعلم والنمو',
        code: 'LG-006',
        name: 'نسبة الوظائف الحرجة التي لديها بديل جاهز',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة التعاقب الوظيفي',
        target: 70,
        actual: 62,
        status: 'AT_RISK',
        lastUpdate: '2025-10-27',
        frequency: 'سنوي',
      },
      {
        id: 25,
        perspective: 'المالي',
        code: 'FIN-007',
        name: 'نسبة العائد على الاستثمار للمشاريع الرأسمالية',
        owner: 'الإدارة المالية',
        unit: 'وحدة دراسات الجدوى',
        target: 10,
        actual: 8.1,
        status: 'AT_RISK',
        lastUpdate: '2025-10-22',
        frequency: 'سنوي',
      },
      {
        id: 26,
        perspective: 'العملاء',
        code: 'CUS-007',
        name: 'عدد قنوات تقديم الخدمة الفعّالة',
        owner: 'إدارة تجربة العميل',
        unit: 'وحدة قنوات الخدمة',
        target: 6,
        actual: 5,
        status: 'ON_TRACK',
        lastUpdate: '2025-10-20',
        frequency: 'سنوي',
      },
      {
        id: 27,
        perspective: 'العمليات الداخلية',
        code: 'PROC-007',
        name: 'نسبة العمليات التي لديها نماذج موحّدة',
        owner: 'إدارة الإجراءات',
        unit: 'وحدة توحيد النماذج',
        target: 85,
        actual: 79,
        status: 'AT_RISK',
        lastUpdate: '2025-10-18',
        frequency: 'نصف سنوي',
      },
      {
        id: 28,
        perspective: 'التعلم والنمو',
        code: 'LG-007',
        name: 'مؤشر رضا الموظفين عن بيئة العمل',
        owner: 'إدارة الموارد البشرية',
        unit: 'وحدة ثقافة المؤسسة',
        target: 82,
        actual: 80,
        status: 'ON_TRACK',
        lastUpdate: '2025-10-15',
        frequency: 'سنوي',
      },
      {
        id: 29,
        perspective: 'المالي',
        code: 'FIN-008',
        name: 'نسبة المصروفات الإدارية من إجمالي المصروفات',
        owner: 'الإدارة المالية',
        unit: 'وحدة التحليل المالي',
        target: 18,
        actual: 21,
        status: 'OFF_TRACK',
        lastUpdate: '2025-10-10',
        frequency: 'سنوي',
      },
      {
        id: 30,
        perspective: 'العملاء',
        code: 'CUS-008',
        name: 'متوسط تقييم الخدمة في المنصات الرقمية',
        owner: 'إدارة تجربة العميل',
        unit: 'منصة التقييم',
        target: 4.5,
        actual: 4.3,
        status: 'ON_TRACK',
        lastUpdate: '2025-10-08',
        frequency: 'شهري',
      },
    ];

    this.allKpis = rows;
  }

  /** إعادة تحميل الجدول مع الفلاتر والفرز */
  refreshTable() {
    let data = [...this.allKpis];

    if (this.perspectiveFilter) {
      data = data.filter((r) => r.perspective === this.perspectiveFilter);
    }

    if (this.statusFilter) {
      data = data.filter((r) => r.status === this.statusFilter);
    }

    const search = this.searchText.trim().toLowerCase();
    if (search) {
      data = data.filter((r) => {
        return (
          r.code.toLowerCase().includes(search) ||
          r.name.toLowerCase().includes(search) ||
          r.owner.toLowerCase().includes(search) ||
          r.unit.toLowerCase().includes(search) ||
          r.perspective.toLowerCase().includes(search)
        );
      });
    }

    const [field, dir] = this.selectedSort.split(',');
    data.sort((a, b) => {
      let av: number | string = 0;
      let bv: number | string = 0;

      switch (field) {
        case 'achievement':
          av = this.getAchievement(a);
          bv = this.getAchievement(b);
          break;
        case 'lastUpdate':
          av = a.lastUpdate;
          bv = b.lastUpdate;
          break;
        case 'perspective':
          av = a.perspective;
          bv = b.perspective;
          break;
        default:
          av = a.id;
          bv = b.id;
      }

      if (typeof av === 'number' && typeof bv === 'number') {
        return dir === 'asc' ? av - bv : bv - av;
      } else {
        return dir === 'asc'
          ? String(av).localeCompare(String(bv))
          : String(bv).localeCompare(String(av));
      }
    });

    this.dataSource.data = data;

    this.totalKpis = this.allKpis.length;
    this.onTrackCount = this.allKpis.filter((r) => r.status === 'ON_TRACK').length;
    this.atRiskCount = this.allKpis.filter((r) => r.status === 'AT_RISK').length;
    this.offTrackCount = this.allKpis.filter((r) => r.status === 'OFF_TRACK').length;

    if (this.paginator) {
      this.dataSource.paginator = this.paginator;
    }

    this.buildMainKpiCards();
  }


 getAchievement(row: KpiRow): number {
  const target = row.target || 0;
  if (!target) {
    return 0;
  }

  // الآن الفعلي دائماً محدث من آخر قراءة (loadReadingsForKpi)
  return (row.actual / target) * 100;
}





  /** كلاس لون الحالة */
  getStatusBadgeClass(status: KpiRow['status']): string {
    switch (status) {
      case 'ON_TRACK':
        return 'status-done';
      case 'AT_RISK':
        return 'status-pending';
      case 'OFF_TRACK':
        return 'status-rejected';
      default:
        return '';
    }
  }

  /** ترجمة الحالة للعربي */
  getStatusLabel(status: KpiRow['status']): string {
    switch (status) {
      case 'ON_TRACK':
        return 'على المسار';
      case 'AT_RISK':
        return 'معرَّض للخطر';
      case 'OFF_TRACK':
        return 'متأخر عن المستهدف';
      default:
        return status;
    }
  }

  /** أحداث الواجهة */
  applyFilter(event: Event) {
    const value = (event.target as HTMLInputElement).value || '';
    this.searchText = value;
    this.refreshTable();
  }

  onSortChanged(value: string) {
    this.selectedSort = value;
    this.refreshTable();
  }

  onStatusFilterChange(value: string) {
    this.statusFilter = value;
    this.refreshTable();
  }

  onPerspectiveFilterChange(value: string) {
    this.perspectiveFilter = value;
    this.refreshTable();
  }

reloadData() {
  this.loadKpisForCurrentUser();
}


  openDetails(row: KpiRow) {
    console.log('تفاصيل المؤشر', row);
    this.snack.open(`ℹ تفاصيل المؤشر: ${row.code} - ${row.name}`, 'إغلاق', {
      duration: 4000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
  }



  getStrategicGoalForOperational(row: OperationalGoalRow): StrategicGoalCard | undefined {
    return this.strategicGoalsTop5.find(g => g.code === row.strategicGoalCode);
  }


  getOperationalGoalsUnderSameStrategic(row: OperationalGoalRow): OperationalGoalRow[] {
    if (!this.operationalGoalsDataSource?.data) {
      return [];
    }

    return this.operationalGoalsDataSource.data.filter(
      r => r.strategicGoalCode === row.strategicGoalCode
    );
  }


  newGoalType: 'إستراتيجي' | 'تشغيلي' | null = null;


  newGoalParentCode: string | null = null;

  newGoal: {
    nameAr: string;
    perspectiveCode: string | null;
    horizonFromYear: number | null;
    horizonToYear: number | null;

    ownerUniteId: number | null;
    ownerSubUniteId: number | null;
  } = {
      nameAr: '',
      perspectiveCode: null,
      horizonFromYear: new Date().getFullYear(),
      horizonToYear: new Date().getFullYear() + 3,
      ownerUniteId: null,
      ownerSubUniteId: null,
    };



  newGoalStrategicCode: string | null = null;

  @ViewChild('goalEditDialog') goalEditDialogTpl!: TemplateRef<any>;

  openAddGoalDialog(mode: 'strategic' | 'operational') {
    this.newGoalType = mode === 'strategic' ? 'إستراتيجي' : 'تشغيلي';

    this.newGoal = {
      nameAr: '',
      perspectiveCode: null,
      horizonFromYear: new Date().getFullYear(),
      horizonToYear: new Date().getFullYear() + 3,
      ownerUniteId: null,
      ownerSubUniteId: null,
    };

    this.newGoalParentCode = null;

    this.dialog.open(this.goalEditDialogTpl, {
      panelClass: 'goal-dialog-panel',
      width: '900px',
      maxWidth: '95vw',
      maxHeight: '90vh',
    });
  }

  closeGoalEditDialog() {
    this.dialog.closeAll();
  }

  setNewGoalType(type: 'إستراتيجي' | 'تشغيلي') {
    this.newGoalType = type;

    if (type === 'تشغيلي') {
      if (!this.newGoalStrategicCode && this.strategicGoalsTop5.length) {
        this.newGoalStrategicCode = this.strategicGoalsTop5[0].code;
      }
      this.newGoalParentCode = this.newGoalStrategicCode; 
    }

    if (type === 'إستراتيجي') {
      this.newGoalStrategicCode = null;
      this.newGoalParentCode = null;
    }
  }


  selectStrategicForNewGoal(code: string) {
    this.newGoalStrategicCode = code;
    this.newGoalParentCode = code;  
  }


  saveNewGoal() {
    if (!this.newGoalType) {
      this.snack.open('❗ الرجاء اختيار نوع الهدف (إستراتيجي / تشغيلي).', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }


    if (!this.newGoal.nameAr || !this.newGoal.perspectiveCode) {
      this.snack.open('❗ الرجاء تعبئة اسم الهدف واختيار المنظور.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }


    if (!this.newGoal.horizonFromYear || !this.newGoal.horizonToYear) {
      this.snack.open('❗ الرجاء إدخال أفق الفترة (من سنة / إلى سنة).', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }


    if (!this.newGoal.ownerUniteId && !this.newGoal.ownerSubUniteId) {
      this.snack.open('❗ الرجاء اختيار الإدارة أو الوحدة المسؤولة (أو الوحدة الفرعية).', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }


    if (this.newGoalType === 'تشغيلي' && !this.newGoalParentCode) {
      this.snack.open('❗ الرجاء اختيار الهدف الإستراتيجي أو الأعلى الذي يقع تحته هذا الهدف التشغيلي.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }


    const nextStrategicIndex = this.strategicGoalsTop5.length + 1;
    const generatedCode =
      this.newGoalType === 'إستراتيجي'
        ? `SG-${nextStrategicIndex.toString().padStart(2, '0')}`
        : `OPG-${(this.operationalGoalsDataSource.data.length + 1)
          .toString()
          .padStart(3, '0')}`;

    const payload: CreateKpiStrategicGoalRequest = {
      code: generatedCode,
      nameAr: this.newGoal.nameAr,
      perspectiveCode: this.newGoal.perspectiveCode,

      goalType: this.newGoalType === 'إستراتيجي' ? 'STRATEGIC' : 'OPERATIONAL',

      horizonFromYear: this.newGoal.horizonFromYear!,
      horizonToYear: this.newGoal.horizonToYear!,

      regionCode: null, 

      ownerEmpNo: null, 
      ownerUniteId: this.newGoal.ownerUniteId,
      ownerSubUniteId: this.newGoal.ownerSubUniteId,

      parentGoalCode: this.newGoalParentCode, 
    };

    this.loading = true;

    this.goalsService.createGoal(payload).subscribe({
      next: (dto) => {
        this.loading = false;

        this.afterGoalCreated(dto);
        this.closeGoalEditDialog();
        this.snack.open('✅ تم حفظ الهدف بنجاح.', 'إغلاق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        });

      },
      error: (err) => {
        this.loading = false;
        console.error(err);
        this.snack.open('❌ حدث خطأ أثناء حفظ الهدف. الرجاء المحاولة لاحقًا.', 'إغلاق', {
          duration: 4000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        });
      },

    });
  }

  private getPerspectiveLabelFromCode(code: string): OperationalGoalRow['perspective'] {
    const opt = this.perspectiveOptions.find(p => p.code === code);
    return (opt?.label || 'العمليات الداخلية') as any;
  }

  private afterGoalCreated(dto: KpiStrategicGoalDto) {
    const perspectiveLabel = this.getPerspectiveLabelFromCode(dto.perspectiveCode);

    if (dto.goalType === 'STRATEGIC') {
      const newCard: StrategicGoalCard = {
        code: dto.code,
        title: dto.nameAr,
        owner: '—', 
        horizon: `${dto.horizonFromYear}–${dto.horizonToYear}`,
        perspective: perspectiveLabel,
        progress: dto.progressPct ?? 0,
      };

      this.strategicGoalsTop5 = [...this.strategicGoalsTop5, newCard];
    }

const ownerName =
  dto.ownerUniteId != null ? this.getUniteNameById(dto.ownerUniteId) : '—';

const unitName =
  dto.ownerSubUniteId != null
    ? (this.getSubUniteNameById(dto.ownerSubUniteId) || ownerName || '—')
    : (ownerName || '—');

const newRow: OperationalGoalRow = {
  id: dto.id,
  code: dto.code,
  name: dto.nameAr,

  owner: ownerName,
  unit: unitName,
  ownerUniteId: dto.ownerUniteId ?? null,
  ownerSubUniteId: dto.ownerSubUniteId ?? null,

  goalType: dto.goalType === 'STRATEGIC' ? 'إستراتيجي' : 'تشغيلي',
  perspective: perspectiveLabel,
  linkedKpis: dto.kpiCount ?? 0,
  status: 'ON_TRACK',
  strategicGoalCode: dto.parentGoalCode || dto.code,
};


    this.operationalGoalsDataSource.data = [
      ...this.operationalGoalsDataSource.data,
      newRow,
    ];

    this.refreshGoalsStats();
  }




  getOperationalGoalsUnderStrategicCode(goalCode: string): OperationalGoalRow[] {
    if (!this.operationalGoalsDataSource?.data) {
      return [];
    }

    return this.operationalGoalsDataSource.data.filter(
      (row) => row.strategicGoalCode === goalCode && row.goalType === 'تشغيلي'
    );
  }

  @ViewChild('kpiEditDialog') kpiEditDialogTpl!: TemplateRef<any>;


  newKpiMode: 'MAIN' | 'SUB' = 'MAIN';

  newKpiParentLinkType: 'STRATEGIC' | 'OPERATIONAL' | null = null;

  selectedParentStrategicCode: string | null = null;
  selectedParentOperationalId: number | null = null;

  selectedParentKpiId: number | null = null;

  mainKpisForUnite: KpiIndicatorDto[] = [];

  private loadMainKpisForCurrentUnite(): void {
    const uniteId = this.auth.getCurrentInternalUniteId();

    if (!uniteId) {
      console.warn('لا يوجد uniteId للمستخدم الحالي (ربما EXTERNAL أو بدون ربط).');
      this.mainKpisForUnite = [];
      return;
    }

    this.indicatorsApi.getMainByUnite({
      ownerUniteId: uniteId,
      unpaged: true,       
    }).subscribe({
      next: (page) => {
        this.mainKpisForUnite = page.content || [];
      },
      error: (err) => {
        console.error('خطأ في جلب المؤشرات الرئيسية:', err);
        this.mainKpisForUnite = [];
      },
    });
  }


  newKpi: {
    code: string;
    name: string;
    desc: string;       
    owner: string;
    unit: string;
    perspective: KpiRow['perspective'] | null;
    target: number;
    actual: number;

    baseline: number | null;
    polarity:
    | 'HIGHER_BETTER'
    | 'LOWER_BETTER'
    | 'RANGE_BEST'
    | null;

    measurementMethod: string;
    formula: string;

    frequencyCode: 'MONTHLY' | 'QUARTERLY' | 'SEMI_ANNUAL' | 'YEARLY' | '';
    custodianAgency: string;

    entryDate: string;
  } = {
      code: '',
      name: '',
      desc: '',            
      owner: '',
      unit: '',
      perspective: null,
      target: 0,
      actual: 0,
      baseline: null,
      polarity: null,
      measurementMethod: '',
      formula: '',
      frequencyCode: '',
      custodianAgency: '',
      entryDate: '',
    };





  private getPerspectiveCodeFromLabel(label: KpiRow['perspective'] | null): string {
    const opt = this.perspectiveOptions.find(p => p.label === label);
    return opt?.code || 'INTERNAL'; 
  }


newInitiativeFormVisible = false;

newInitiative: KpiInitiativeRow = {
  code: '',
  name: '',
  owner: '',
  status: 'ON_TRACK',
  progress: 0,

  desc: '',
  initiativeType: 'PLANNED',
  startDate: new Date().toISOString().slice(0, 10),
  targetEndDate: new Date().toISOString().slice(0, 10),
  budgetAmount: null,
  linkType: 'PRIMARY',
};


toggleNewInitiativeForm() {
  if (this.newInitiativeFormVisible) {
    if (!this.selectedKpi) {
      this.snack.open('❗ لا يوجد مؤشر محدد لربط المبادرة به.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    if (!this.newInitiative.code || !this.newInitiative.name) {
      this.snack.open('❗ الرجاء إدخال كود واسم المبادرة على الأقل.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    if (!this.newInitiative.startDate || !this.newInitiative.targetEndDate) {
      this.snack.open('❗ الرجاء إدخال تاريخ البداية وتاريخ الانتهاء المستهدف.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    const payload: CreateKpiInitiativeRequest = {
  initiativeCode: this.newInitiative.code.trim(),
  nameAr: this.newInitiative.name.trim(),
  descAr: (this.newInitiative.desc || '').trim(),
  initiativeType: this.newInitiative.initiativeType || 'PLANNED',

  goalCode: null,

  ownerEmpNo: null,
  ownerUniteId: this.initiativeOwnerUniteId ?? this.selectedKpi.ownerUniteId ?? null,
  ownerSubUniteId: this.initiativeOwnerSubUniteId ?? this.selectedKpi.ownerSubUniteId ?? null,

  startDate: this.newInitiative.startDate,
  targetEndDate: this.newInitiative.targetEndDate,
  budgetAmount: this.newInitiative.budgetAmount ?? null,

  kpiCode: this.selectedKpi.code,
  linkType: this.newInitiative.linkType || 'PRIMARY',
};

   

    this.loading = true;

    this.initiativesApi.createInitiativeAndLink(payload).subscribe({
      next: (dto) => {
        this.loading = false;
        this.kpiDialogInitiatives = [
          ...this.kpiDialogInitiatives,
          {
            code: dto.code,
            name: dto.nameAr,
            owner: this.selectedKpi!.owner || this.newInitiative.owner,
            status: (dto.statusCode as any) || 'ON_TRACK',
            progress: dto.progressPct ?? 0,
            desc: dto.descAr,
            initiativeType: dto.initiativeType as any,
            startDate: dto.startDate || this.newInitiative.startDate,
            targetEndDate: dto.targetEndDate || this.newInitiative.targetEndDate,
            budgetAmount: dto.budgetAmount ?? this.newInitiative.budgetAmount ?? null,
            linkType: this.newInitiative.linkType,
          } as KpiInitiativeRow,
        ];

        this.newInitiative = {
          code: '',
          name: '',
          owner: '',
          status: 'ON_TRACK',
          progress: 0,
          desc: '',
          initiativeType: 'PLANNED',
          startDate: new Date().toISOString().slice(0, 10),
          targetEndDate: new Date().toISOString().slice(0, 10),
          budgetAmount: null,
          linkType: 'PRIMARY',
        };

        this.newInitiativeFormVisible = false;

        this.snack.open('✅ تم إنشاء المبادرة وربطها بالمؤشر بنجاح.', 'إغلاق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        });
      },
      error: (err) => {
        this.loading = false;
        console.error('خطأ في إنشاء المبادرة:', err);
        this.snack.open(
          '❌ حدث خطأ أثناء حفظ المبادرة. الرجاء المحاولة لاحقاً.',
          'إغلاق',
          {
            duration: 4000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
            direction: 'rtl',
            panelClass: ['snack-on-top'],
          }
        );
      },
    });

  } else {
    this.newInitiative = {
      code: '',
      name: '',
      owner: this.selectedKpi?.owner || '',
      status: 'ON_TRACK',
      progress: 0,
      desc: '',
      initiativeType: 'PLANNED',
      startDate: new Date().toISOString().slice(0, 10),
      targetEndDate: new Date().toISOString().slice(0, 10),
      budgetAmount: null,
      linkType: 'PRIMARY',
    };

    this.newInitiativeFormVisible = true;
  }
}


/** إلغاء إدخال المبادرة الجديدة */
cancelNewInitiative() {
  this.newInitiativeFormVisible = false;
  this.newInitiative = {
    code: '',
    name: '',
    owner: '',
    status: 'ON_TRACK',
    progress: 0,
    desc: '',
    initiativeType: 'PLANNED',
    startDate: new Date().toISOString().slice(0, 10),
    targetEndDate: new Date().toISOString().slice(0, 10),
    budgetAmount: null,
    linkType: 'PRIMARY',
  };
}

dataEntryFormVisible = false;

newDataEntry: KpiEntry = {
  kpiId: 0,
  code: '',
  entryDate: '',
  value: 0,
  note: '',
  dataSourceName: '',
};


toggleNewDataEntryForm() {
  if (this.dataEntryFormVisible) {
    if (!this.selectedKpi) {
      this.snack.open('❗ لا يوجد مؤشر محدد.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    if (!this.newDataEntry.entryDate || this.newDataEntry.value == null) {
      this.snack.open('❗ الرجاء إدخال التاريخ والقيمة الفعلية للمؤشر.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    this.newDataEntry.kpiId = this.selectedKpi.id;
    this.newDataEntry.code = this.selectedKpi.code;

    const freqCode = this.selectedKpi.frequencyCode || null;
    const period = this.getEntryPeriodDates(freqCode);
    const periodStartDate = period
      ? this.formatDate(period.from)
      : this.newDataEntry.entryDate;
    const periodEndDate = period
      ? this.formatDate(period.to)
      : this.newDataEntry.entryDate;

    const periodLabel = this.buildPeriodLabel(
      this.newDataEntry.entryDate,
      freqCode
    );

    const statusCode = this.buildStatusCodeForValue(
      this.selectedKpi.id,
      this.newDataEntry.value
    );

const payload: CreateKpiIndicatorReadingRequest = {
  kpiCode: this.selectedKpi.code,
  periodStartDate: periodStartDate,
  periodEndDate: periodEndDate,
  periodLabel: periodLabel,
  actualValue: this.newDataEntry.value,
  statusCode: statusCode,
  dataSourceName: this.newDataEntry.dataSourceName || null,
  notes: this.newDataEntry.note || null,
};


    this.loading = true;

    this.readingsApi.createReading(payload).subscribe({
      next: (reading) => {
        this.loading = false;

        this.kpiEntries = [
          ...this.kpiEntries,
          {
            kpiId: this.selectedKpi!.id,
            code: this.selectedKpi!.code,
            entryDate: this.newDataEntry.entryDate,
            value: this.newDataEntry.value,
            note: this.newDataEntry.note,
            dataSourceName: this.newDataEntry.dataSourceName,
          },
        ];

        const idx = this.allKpis.findIndex(
          (k) => k.id === this.selectedKpi!.id
        );
        if (idx >= 0) {
          this.allKpis[idx] = {
            ...this.allKpis[idx],
            actual: this.newDataEntry.value,
            lastUpdate: this.newDataEntry.entryDate,
          };
          this.selectedKpi = { ...this.allKpis[idx] };
        }

        this.refreshTable();

        this.newDataEntry = {
          kpiId: 0,
          code: '',
          entryDate: '',
          value: 0,
          note: '',
          dataSourceName: '',
        };
        this.dataEntryFormVisible = false;

        this.snack.open('✅ تم حفظ قراءة المؤشر في النظام.', 'إغلاق', {
          duration: 3000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        });
      },
      error: (err) => {
        this.loading = false;
        console.error('خطأ في حفظ القراءة:', err);
        this.snack.open(
          '❌ حدث خطأ أثناء حفظ قراءة المؤشر. الرجاء المحاولة لاحقاً.',
          'إغلاق',
          {
            duration: 4000,
            horizontalPosition: 'center',
            verticalPosition: 'top',
            direction: 'rtl',
            panelClass: ['snack-on-top'],
          }
        );
      },
    });
  } else {

    if (!this.selectedKpi) {
      this.snack.open('❗ لا يوجد مؤشر محدد.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
      return;
    }

    this.newDataEntry = {
      kpiId: this.selectedKpi.id,
      code: this.selectedKpi.code,
      entryDate: new Date().toISOString().slice(0, 10), 
      value: this.selectedKpi.actual || 0,
      note: '',
      dataSourceName: '',
    };

    this.dataEntryFormVisible = true;
  }
}


cancelNewDataEntry() {
  this.dataEntryFormVisible = false;
  this.newDataEntry = {
    kpiId: 0,
    code: '',
    entryDate: '',
    value: 0,
    note: '',
    dataSourceName: '',
  };
}


private buildPeriodLabel(dateStr: string, freq: FrequencyCode | null): string {
  if (!freq || !dateStr) return dateStr;

  const [y, m, d] = dateStr.split('-').map(Number);
  const month = m || 1;

  switch (freq) {
    case 'MONTHLY':
      return `${y}-${month.toString().padStart(2, '0')}`;  // 2025-03
    case 'QUARTERLY': {
      const q = Math.floor((month - 1) / 3) + 1;
      return `${y} Q${q}`;                                 // 2025 Q1
    }
    case 'SEMI_ANNUAL':
      return month <= 6 ? `${y} H1` : `${y} H2`;
    case 'YEARLY':
      return `${y}`;
    default:
      return dateStr;
  }
}

private buildStatusCodeForValue(kpiId: number, value: number): string {
  const target = this.getSelectedKpiTarget(kpiId);
  if (!target || target === 0) {
    return 'ON_TRACK';  
  }

  const achievement = (value / target) * 100;

  if (achievement >= 95) return 'ON_TRACK';
  if (achievement >= 80) return 'AT_RISK';
  return 'OFF_TRACK';
}



  openAddKpiDialog() {
  this.newKpiMode = 'MAIN';
  this.newKpiParentLinkType = null;
  this.selectedParentStrategicCode = null;
  this.selectedParentOperationalId = null;
  this.selectedParentKpiId = null;
  this.selectedSubOperationalGoalCode = null;

  this.newKpi = {
    code: '',
    name: '',
    desc: '',
    owner: '',
    unit: '',
    perspective: null,
    target: 0,
    actual: 0,
    baseline: null,
    polarity: null,
    measurementMethod: '',
    formula: '',
    frequencyCode: '',
    custodianAgency: '',
    entryDate: '',
  };

  this.kpiDialogActiveTab = 'INITIATIVES';


  /* this.kpiDialogInitiatives = [
    {
      code: 'INIT-001',
      name: 'مبادرة أتمتة العمليات الرئيسية',
      owner: 'إدارة التقنية والتطوير',
      status: 'ON_TRACK',
      progress: 65,
    },
    {
      code: 'INIT-002',
      name: 'برنامج تحسين تجربة المستفيد',
      owner: 'إدارة تجربة العميل',
      status: 'AT_RISK',
      progress: 40,
    },
  ]; */

  this.kpiDialogEntries = [
    {
      kpiId: 0,
      code: 'KPI-TEST',
      entryDate: '2025-01-01',
      value: 70,
      note: 'بيانات تجريبية للفترة الأولى',
    },
    {
      kpiId: 0,
      code: 'KPI-TEST',
      entryDate: '2025-04-01',
      value: 82,
      note: 'تحسن بعد تنفيذ جزء من المبادرات',
    },
  ];

  this.dialog.open(this.kpiEditDialogTpl, {
    panelClass: 'goal-dialog-panel',
    width: '900px',
    maxWidth: '95vw',
    maxHeight: '90vh',
  });
}


/** إضافة مبادرة تجريبية جديدة في الديلوج */
/* addFakeInitiative() {
  const idx = this.kpiDialogInitiatives.length + 1;
  this.kpiDialogInitiatives = [
    ...this.kpiDialogInitiatives,
    {
      code: `INIT-${(idx + 2).toString().padStart(3, '0')}`,
      name: `مبادرة تجريبية رقم ${idx + 2}`,
      owner: 'إدارة افتراضية',
      status: idx % 2 === 0 ? 'ON_TRACK' : 'AT_RISK',
      progress: Math.min(100, 30 + idx * 10),
    },
  ];
} */

/** إضافة إدخال فترة تجريبي */
addFakeEntry() {
  const today = new Date();
  const d = this.formatDate(today);

  this.kpiDialogEntries = [
    ...this.kpiDialogEntries,
    {
      kpiId: 0,
      code: 'KPI-TEST',
      entryDate: d,
      value: 75 + Math.random() * 10,
      note: 'إدخال تجريبي جديد من داخل الديلوج',
    },
  ];
}


  kpiDialogActiveTab: 'INITIATIVES' | 'DATA_ENTRIES' = 'INITIATIVES';


  closeKpiEditDialog() {
    this.dialog.closeAll();
  }

  operationalGoalsForKpiOwner: KpiStrategicGoalDto[] = [];
  selectedSubOperationalGoalCode: string | null = null;


saveNewKpi(debugOnly: boolean = false) {
  if (!this.newKpi.code || !this.newKpi.name) {
    this.snack.open('❗ الرجاء تعبئة كود واسم المؤشر على الأقل.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
    return;
  }


  let goalCode: string | null = null;
  let parentKpiCode: string | null = null;
  if (this.newKpiMode === 'MAIN') {
    if (this.newKpiParentLinkType === 'STRATEGIC' && this.selectedParentStrategicCode) {
      goalCode = this.selectedParentStrategicCode;
    }
    else if (this.newKpiParentLinkType === 'OPERATIONAL' && this.selectedParentOperationalId) {
      const opGoal = this.operationalGoalsForKpiOwner
        .find(g => g.id === this.selectedParentOperationalId);
      if (opGoal) {
        goalCode = opGoal.code;
      }
    }
  }

  if (this.newKpiMode === 'SUB') {
    if (this.selectedSubOperationalGoalCode) {
      goalCode = this.selectedSubOperationalGoalCode;
    }
    if (this.selectedParentKpiId) {
      const parentKpi = this.allKpis.find(k => k.id === this.selectedParentKpiId);
      if (parentKpi) {
        parentKpiCode = parentKpi.code;
      }
    }
  }

  if (!goalCode) {
    console.warn('⚠ لم يتم تحديد goalCode لهذا المؤشر الجديد.');
    // لو حابة تمنعي الحفظ بدون هدف:
    // this.snack.open('❗ الرجاء اختيار الهدف المرتبط بهذا المؤشر.', 'إغلاق', {...});
    // return;
  }

  const perspectiveCode = this.getPerspectiveCodeFromLabel(this.newKpi.perspective);

  const payload: CreateKpiIndicatorRequest = {
    code: this.newKpi.code.trim(),
    nameAr: this.newKpi.name.trim(),
    descAr: (this.newKpi.desc || '').trim(),

    goalCode: (goalCode || '').trim(),
    perspectiveCode: perspectiveCode,

    ownerEmpNo: null,
    ownerUniteId: this.kpiOwnerUniteId,
    ownerSubUniteId: this.kpiOwnerSubUniteId,

    targetValue: this.newKpi.target ?? null,
    targetSource: null,
    meansToAchieveTarget: null,

    baselineValue: this.newKpi.baseline ?? null,
    measurementUnit: null,

    polarityCode: this.newKpi.polarity || null,
    measurementMethod: this.newKpi.measurementMethod || null,
    formulaText: this.newKpi.formula || null,

    frequencyCode: this.newKpi.frequencyCode || null,
    currentStatus: 'ON_TRACK',

    isMain: this.newKpiMode === 'MAIN' ? 'Y' : 'N',
    parentKpiCode: this.newKpiMode === 'SUB' ? parentKpiCode : null,

    isActive: 'Y',
  };


  console.log('🟢 newKpiMode =', this.newKpiMode);
  console.log('🟢 newKpiParentLinkType =', this.newKpiParentLinkType);
  console.log('🟢 selectedParentStrategicCode =', this.selectedParentStrategicCode);
  console.log('🟢 selectedParentOperationalId =', this.selectedParentOperationalId);
  console.log('🟢 selectedParentKpiId =', this.selectedParentKpiId);
  console.log('🟢 kpiOwnerUniteId =', this.kpiOwnerUniteId);
  console.log('🟢 kpiOwnerSubUniteId =', this.kpiOwnerSubUniteId);
  console.log('🟢 goalCode =', goalCode);
  console.log('🟢 parentKpiCode =', parentKpiCode);
  console.log('🟢 payload المرسل للباك:', payload);


  if (debugOnly) {
    this.snack.open('✅ تم طباعة JSON في الـ Console بدون إرسال للباك.', 'إغلاق', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      direction: 'rtl',
      panelClass: ['snack-on-top'],
    });
    return;
  }


  this.loading = true;

  this.indicatorsApi.createIndicator(payload).subscribe({
    next: (dto: KpiIndicatorDto) => {
      this.loading = false;

      const perspectiveLabel = this.getPerspectiveLabelFromCode(dto.perspectiveCode);

      const newRow: KpiRow = {
        id: dto.id,
        perspective: perspectiveLabel as any,
        code: dto.code,
        name: dto.nameAr,
        owner: this.newKpi.owner || '—',
        unit: this.newKpi.unit || '—',
        target: dto.targetValue ?? this.newKpi.target,
        actual: this.newKpi.actual,
        status: (dto.currentStatus as any) || 'ON_TRACK',
        lastUpdate:
          dto.lastUpdateDate ||
          (this.newKpi.entryDate || new Date().toISOString().slice(0, 10)),
        frequency: this.getFrequencyLabel(
          dto.frequencyCode || this.newKpi.frequencyCode
        ),
        frequencyCode: (dto.frequencyCode || this.newKpi.frequencyCode || null) as FrequencyCode,

        baseline: dto.baselineValue ?? this.newKpi.baseline ?? null,
        polarity: (dto.polarityCode as any) || this.newKpi.polarity || null,
        measurementMethod: dto.measurementMethod || this.newKpi.measurementMethod,
        formula: dto.formulaText || this.newKpi.formula,
        custodianAgency: this.newKpi.custodianAgency || null,
      };

      this.allKpis = [...this.allKpis, newRow];
      this.refreshTable();
      this.closeKpiEditDialog();
      this.snack.open('✅ تم حفظ المؤشر بنجاح في النظام.', 'إغلاق', {
        duration: 3000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });

    },
    error: (err) => {
      this.loading = false;
      console.error(err);
      this.snack.open('❌ حدث خطأ أثناء حفظ المؤشر. الرجاء المحاولة لاحقًا.', 'إغلاق', {
        duration: 4000,
        horizontalPosition: 'center',
        verticalPosition: 'top',
        direction: 'rtl',
        panelClass: ['snack-on-top'],
      });
    },
  });
}




/** جلب القراءات الحقيقية من الباك لهذا المؤشر */
private loadReadingsForKpi(row: KpiRow): void {
  this.readingsApi.getReadingsByKpi(row.code).subscribe({
    next: (dtos) => {
      const others = this.kpiEntries.filter(e => e.kpiId !== row.id);

      const current: KpiEntry[] = (dtos || []).map(dto => ({
        kpiId: row.id,
        code: dto.kpiCode,
        entryDate: dto.periodStartDate,   
        value: dto.actualValue,
        note: dto.notes || undefined,
        dataSourceName: dto.dataSourceName || undefined,
      }));

      this.kpiEntries = [...others, ...current];

      if (dtos && dtos.length) {
        const sorted = [...dtos].sort((a, b) =>
          a.periodStartDate.localeCompare(b.periodStartDate)
        );
        const last = sorted[sorted.length - 1];

        const idx = this.allKpis.findIndex(k => k.id === row.id);
        if (idx >= 0) {
          this.allKpis[idx] = {
            ...this.allKpis[idx],
            actual: last.actualValue,
            lastUpdate: last.periodStartDate,   
          };
        }

        if (this.selectedKpi && this.selectedKpi.id === row.id && idx >= 0) {
          this.selectedKpi = { ...this.allKpis[idx] };
        }

        this.refreshTable();  
      }
    },
    error: (err) => {
      console.error('خطأ في جلب قراءات المؤشر:', err);
      this.snack.open(
        '❌ تعذر تحميل سجل الفترات لهذا المؤشر.',
        'إغلاق',
        {
          duration: 4000,
          horizontalPosition: 'center',
          verticalPosition: 'top',
          direction: 'rtl',
          panelClass: ['snack-on-top'],
        }
      );
    },
  });
}


  private formatDate(d: Date): string {
    const day = d.getDate().toString().padStart(2, '0');
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const year = d.getFullYear();
    return `${year}-${month}-${day}`;
  }


  private getEntryPeriodDates(code: string | '' | null): { from: Date; to: Date } | null {
    if (!code) return null;

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    let from: Date;
    let to: Date;

    switch (code) {
      case 'MONTHLY':
        from = new Date(year, month, 1);
        to = new Date(year, month + 1, 0);
        break;

      case 'QUARTERLY': {
        const q = Math.floor(month / 3);
        const startMonth = q * 3;
        from = new Date(year, startMonth, 1);
        to = new Date(year, startMonth + 3, 0);
        break;
      }

      case 'SEMI_ANNUAL':
        if (month < 6) {
          from = new Date(year, 0, 1);
          to = new Date(year, 6, 0);
        } else {
          from = new Date(year, 6, 1);
          to = new Date(year, 12, 0);
        }
        break;

      case 'YEARLY':
        from = new Date(year, 0, 1);
        to = new Date(year, 12, 0);
        break;

      default:
        return null;
    }

    return { from, to };
  }

  /** أقل تاريخ مسموح في الكلندر */
  getEntryMinDate(code: string | '' | null): string | null {
    const p = this.getEntryPeriodDates(code);
    return p ? this.formatDate(p.from) : null;
  }

  getEntryMaxDate(code: string | '' | null): string | null {
    const p = this.getEntryPeriodDates(code);
    return p ? this.formatDate(p.to) : null;
  }

  getEntryPeriodRange(code: string | '' | null): string {
    const p = this.getEntryPeriodDates(code);
    if (!p) return '';
    return `${this.formatDate(p.from)} إلى ${this.formatDate(p.to)}`;
  }

  totalGoals = 0;            
  goalsOnTrackCount = 0;     
  goalsAtRiskCount = 0;      
  goalsOffTrackCount = 0;    
  private refreshGoalsStats() {
    const rows = this.operationalGoalsDataSource?.data || [];

    this.totalGoals = rows.length;

    this.goalsOnTrackCount = rows.filter(r => r.status === 'ON_TRACK').length;
    this.goalsAtRiskCount = rows.filter(r => r.status === 'AT_RISK').length;
    this.goalsOffTrackCount = rows.filter(r => r.status === 'OFF_TRACK').length;
  }

  selectedKpi: KpiRow | null = null;

  @ViewChild('kpiDetailsDialog') kpiDetailsDialogTpl!: TemplateRef<any>;


openDetails2(row: KpiRow) {
  this.selectedKpi = row;

  this.loadReadingsForKpi(row);

  this.loadInitiativesForKpi(row);

  this.dialog.open(this.kpiDetailsDialogTpl, {
    panelClass: 'goal-dialog-panel',
    width: '900px',
    maxWidth: '95vw',
    maxHeight: '90vh',
  });
}


private loadInitiativesForKpi(row: KpiRow): void {
  this.initiativesApi.getInitiativesByKpiCode(row.code).subscribe({
    next: (list) => {
      this.kpiDialogInitiatives = (list || []).map(dto => ({
        code: dto.code,
        name: dto.nameAr,
        owner: row.owner,
        status: (dto.statusCode as any) || 'ON_TRACK',
        progress: dto.progressPct ?? 0,
        desc: dto.descAr,
        initiativeType: dto.initiativeType as any,
        startDate: dto.startDate ?? '',         
        targetEndDate: dto.targetEndDate ?? '', 
        budgetAmount: dto.budgetAmount ?? null,
        linkType: 'PRIMARY',
      }));
    },
    error: (err) => {
      console.error('خطأ في جلب مبادرات المؤشر:', err);
      this.kpiDialogInitiatives = [];
    },
  });
}


initiativeOwnerUniteId: number | null = null;

initiativeOwnerLevel1List: SubUniteDto[] = [];
initiativeOwnerLevel2List: SubUniteDto[] = [];
initiativeOwnerLevel3List: SubUniteDto[] = [];
initiativeOwnerLevel4List: SubUniteDto[] = [];

initiativeOwnerLevel1Id: number | null = null;
initiativeOwnerLevel2Id: number | null = null;
initiativeOwnerLevel3Id: number | null = null;
initiativeOwnerLevel4Id: number | null = null;

initiativeOwnerSubUniteId: number | null = null;


onInitiativeOwnerUniteChanged(uniteId: number | string | null): void {
  const idNum = Number(uniteId);
  this.initiativeOwnerUniteId = Number.isFinite(idNum) ? idNum : null;

  this.initiativeOwnerLevel1Id =
    this.initiativeOwnerLevel2Id =
    this.initiativeOwnerLevel3Id =
    this.initiativeOwnerLevel4Id =
      null;

  this.initiativeOwnerLevel1List =
    this.initiativeOwnerLevel2List =
    this.initiativeOwnerLevel3List =
    this.initiativeOwnerLevel4List =
      [];

  this.initiativeOwnerSubUniteId = null;
  this.newInitiative.owner = '';

  if (!this.initiativeOwnerUniteId) return;

  this.orgApi.listDirectUnderUnite(this.initiativeOwnerUniteId).subscribe({
    next: (list) => {
      this.initiativeOwnerLevel1List = list || [];
      this.syncInitiativeDeepestSelection();
    },
    error: () => {
      this.initiativeOwnerLevel1List = [];
      this.syncInitiativeDeepestSelection();
    },
  });
}

/** جلب أبناء sub-unite لمستوى معيّن لمالك المبادرة */
private loadChildrenForInitiativeLevel(
  parentSubUniteId: number,
  targetLevel: 2 | 3 | 4
): void {
  this.orgApi.listDirectChildren(parentSubUniteId).subscribe({
    next: (kids) => {
      const list = kids || [];
      if (targetLevel === 2) this.initiativeOwnerLevel2List = list;
      if (targetLevel === 3) this.initiativeOwnerLevel3List = list;
      if (targetLevel === 4) this.initiativeOwnerLevel4List = list;

      this.syncInitiativeDeepestSelection();
    },
    error: () => {
      if (targetLevel === 2) this.initiativeOwnerLevel2List = [];
      if (targetLevel === 3) this.initiativeOwnerLevel3List = [];
      if (targetLevel === 4) this.initiativeOwnerLevel4List = [];
      this.syncInitiativeDeepestSelection();
    },
  });
}

/** عند اختيار مستوى (1/2/3/4) لمالك المبادرة */
onInitiativeOwnerLevelChanged(level: 1 | 2 | 3 | 4, subIdRaw: any): void {
  const subId = Number(subIdRaw);

  if (level === 1) {
    this.initiativeOwnerLevel1Id = Number.isFinite(subId) ? subId : null;
    this.initiativeOwnerLevel2Id = this.initiativeOwnerLevel3Id = this.initiativeOwnerLevel4Id = null;
    this.initiativeOwnerLevel2List = this.initiativeOwnerLevel3List = this.initiativeOwnerLevel4List = [];

    if (this.initiativeOwnerLevel1Id) {
      this.loadChildrenForInitiativeLevel(this.initiativeOwnerLevel1Id, 2);
    }
  } else if (level === 2) {
    this.initiativeOwnerLevel2Id = Number.isFinite(subId) ? subId : null;
    this.initiativeOwnerLevel3Id = this.initiativeOwnerLevel4Id = null;
    this.initiativeOwnerLevel3List = this.initiativeOwnerLevel4List = [];

    if (this.initiativeOwnerLevel2Id) {
      this.loadChildrenForInitiativeLevel(this.initiativeOwnerLevel2Id, 3);
    }
  } else if (level === 3) {
    this.initiativeOwnerLevel3Id = Number.isFinite(subId) ? subId : null;
    this.initiativeOwnerLevel4Id = null;
    this.initiativeOwnerLevel4List = [];

    if (this.initiativeOwnerLevel3Id) {
      this.loadChildrenForInitiativeLevel(this.initiativeOwnerLevel3Id, 4);
    }
  } else {
    this.initiativeOwnerLevel4Id = Number.isFinite(subId) ? subId : null;
  }

  this.syncInitiativeDeepestSelection();
}

/** تحديد أعمق مستوى مختار وتعبئة اسم الجهة المالكة للمبادرة */
private syncInitiativeDeepestSelection(): void {
  const deepestId =
    this.initiativeOwnerLevel4Id ??
    this.initiativeOwnerLevel3Id ??
    this.initiativeOwnerLevel2Id ??
    this.initiativeOwnerLevel1Id ??
    null;

  this.initiativeOwnerSubUniteId = deepestId;

  let deepestName: string | null = null;
  if (deepestId) {
    let found =
      this.initiativeOwnerLevel4List.find(s => s.id === deepestId) ||
      this.initiativeOwnerLevel3List.find(s => s.id === deepestId) ||
      this.initiativeOwnerLevel2List.find(s => s.id === deepestId) ||
      this.initiativeOwnerLevel1List.find(s => s.id === deepestId);

    if (found) deepestName = found.name;
  }

  this.newInitiative.owner = deepestName || '';
}

  getEntriesForSelectedKpi(): KpiEntry[] {
    if (!this.selectedKpi) return [];
    return this.kpiEntries
      .filter(e => e.kpiId === this.selectedKpi!.id)
      .sort((a, b) => b.entryDate.localeCompare(a.entryDate));
  }

  getGoalInfoForSelectedKpi():
    | { parentType: 'هدف إستراتيجي' | 'هدف تشغيلي'; code: string; title: string }
    | null {
    if (!this.selectedKpi) return null;

    const sg =
      this.strategicGoalsTop5.find(g => g.perspective === this.selectedKpi!.perspective) ||
      this.strategicGoalsTop5[0];

    return {
      parentType: 'هدف إستراتيجي',
      code: sg.code,
      title: sg.title,
    };
  }

  isMainKpi(kpi: KpiRow | null): boolean {
    if (!kpi) return true;
    return kpi.id % 4 !== 0;
  }

  private seedKpiEntriesFor(row: KpiRow) {
    const today = new Date();

    const entries: KpiEntry[] = [];
    for (let i = 3; i >= 0; i--) {
      const d = new Date(today);
      d.setMonth(today.getMonth() - i);

      const noise = (Math.random() - 0.5) * 5;
      const val = Math.round((row.actual + noise) * 10) / 10;

      entries.push({
        kpiId: row.id,
        code: row.code,
        entryDate: this.formatDate(d),
        value: val,
        note: 'بيانات تجريبية لهذه الفترة',
      });
    }

    this.kpiEntries = [...this.kpiEntries, ...entries];
  }

  /** فارق القيمة عن المستهدف */
  getDiffFromTarget(entry: KpiEntry): number {
    const target = this.getSelectedKpiTarget(entry.kpiId);
    return entry.value - target;
  }





private subUniteLoading = new Set<number>();

private getSubUniteNameById(id: number | null | undefined): string {
  if (!id) return '';

  const cached = this.subUniteNameCache.get(id);
  if (cached) return cached;

  if (this.subUniteLoading.has(id)) {
    return '';
  }

  this.subUniteLoading.add(id);

  this.orgApi.getSubUnite(id).subscribe({
    next: (dto) => {
      this.subUniteNameCache.set(id, dto.name);
      this.subUniteLoading.delete(id);


      this.allKpis = this.allKpis.map(row =>
        row.ownerSubUniteId === id ? { ...row, unit: dto.name } : row
      );


      this.operationalGoalsDataSource.data =
        this.operationalGoalsDataSource.data.map(row =>
          row.ownerSubUniteId === id ? { ...row, unit: dto.name } : row
        );

      this.refreshTable();
      this.refreshGoalsStats();
    },
    error: () => {
      this.subUniteLoading.delete(id);
    },
  });

  return '';
}




gaugeRadius = 46;
gaugeCircumference = 2 * Math.PI * this.gaugeRadius;


getGaugeDashOffset(kpi: KpiRow | null): number {
  if (!kpi) return this.gaugeCircumference;

  const achievement = this.getAchievement(kpi); 

  const pct = Math.max(0, Math.min(achievement, 150)); 

  return this.gaugeCircumference * (1 - pct / 100);
}


statusOptions = [
  { value: '',          label: 'الكل' },
  { value: 'ON_TRACK',  label: 'على المسار (ON TRACK)' },
  { value: 'AT_RISK',   label: 'مُعرّضة للخطر (AT RISK)' },
  { value: 'OFF_TRACK', label: 'متأخرة عن المستهدف (OFF TRACK)' },
];

statusLabelMap: Record<string, string> = {
  ON_TRACK:  'على المسار',
  AT_RISK:   'مُعرّضة للخطر',
  OFF_TRACK: 'متأخرة عن المستهدف',
};

getStatsLabel(code: string | null | undefined): string {
  if (!code) return '';
  return this.statusLabelMap[code] ?? code;
}

}

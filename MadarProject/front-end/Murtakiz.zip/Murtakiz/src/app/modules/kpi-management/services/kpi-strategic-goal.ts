import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateKpiStrategicGoalRequest, KpiStrategicGoalDto } from '../models/kpi-strategic-goal.model';

type Page<T> = {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
  first: boolean;
  last: boolean;
  empty: boolean;
};


@Injectable({
  providedIn: 'root',
})
export class KpiStrategicGoal {

  private baseUrl = 'http://localhost:9090/api/v1/murtakiz';
  private goalsUrl = `${this.baseUrl}/kpi/goals`;

  constructor(private http: HttpClient) {}

  /** 1) إنشاء هدف جديد */
  createGoal(
    payload: CreateKpiStrategicGoalRequest
  ): Observable<KpiStrategicGoalDto> {
    return this.http.post<KpiStrategicGoalDto>(this.goalsUrl, payload);
  }

  /** ===============================
   * 2) الأهداف حسب الوحدة الرئيسية
   * =============================== */
  getGoalsByUnite(params: {
    uniteId: number;
    uniteName?: string;
    subUniteName?: string;
    code?: string;
    nameAr?: string;
    goalType?: string;
    perspectiveCode?: string;
    regionCode?: string;
    statusCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiStrategicGoalDto>> {
    return this.http.get<Page<KpiStrategicGoalDto>>(
      `${this.goalsUrl}/by-unite`,
      { params }
    );
  }

  /** ===============================
   * 3) الأهداف حسب الوحدة الفرعية
   * =============================== */
  getGoalsBySubUnite(params: {
    subUniteId: number;
    uniteName?: string;
    subUniteName?: string;
    code?: string;
    nameAr?: string;
    goalType?: string;
    perspectiveCode?: string;
    regionCode?: string;
    statusCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiStrategicGoalDto>> {
    return this.http.get<Page<KpiStrategicGoalDto>>(
      `${this.goalsUrl}/by-sub-unite`,
      { params }
    );
  }

  /** ===============================
   * 4) الحصول على جميع الأهداف
   * =============================== */
  getAllGoals(params?: {
    uniteName?: string;
    subUniteName?: string;
    code?: string;
    nameAr?: string;
    goalType?: string;
    perspectiveCode?: string;
    regionCode?: string;
    statusCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiStrategicGoalDto>> {
    return this.http.get<Page<KpiStrategicGoalDto>>(
      `${this.goalsUrl}/all`,
      { params }
    );
  }

  /** ===============================
   * 5) البحث المرن (حسب uniteId أو subUniteId)
   * =============================== */
  searchGoals(params?: {
    uniteId?: number;
    subUniteId?: number;
    uniteName?: string;
    subUniteName?: string;
    code?: string;
    nameAr?: string;
    goalType?: string;
    perspectiveCode?: string;
    regionCode?: string;
    statusCode?: string;
    page?: number;
    size?: number;
    unpaged?: boolean;
  }): Observable<Page<KpiStrategicGoalDto>> {
    return this.http.get<Page<KpiStrategicGoalDto>>(
      `${this.goalsUrl}/search`,
      { params }
    );
  }
}


import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KpiManagementHome } from './pages/kpi-management-home/kpi-management-home';
import { KpiManagementDashboard } from './pages/kpi-management-dashboard/kpi-management-dashboard';



const routes: Routes = [
  { path: 'dashboard', component: KpiManagementDashboard },          
  { path: 'managementKPI', component: KpiManagementHome },        
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class KpiManagementRoutingModule { }

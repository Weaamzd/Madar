
export interface CreateKpiInitiativeRequest {
  initiativeCode: string;    
  nameAr: string;
  descAr: string;
  initiativeType: string;    

  goalCode?: string | null;

  ownerEmpNo?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;

  startDate: string;       
  targetEndDate: string;     
  budgetAmount?: number | null;

  kpiCode: string;            
  linkType: string;           // PRIMARY / CORRECTIVE / SUPPORT
}


export interface KpiInitiativeDto {
  id: number;
  code: string;            
  nameAr: string;
  descAr: string;
  initiativeType: string;

  goalCode?: string | null;

  ownerEmpNo?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;

  startDate?: string | null;        // LocalDate → string
  targetEndDate?: string | null;    // LocalDate → string
  actualEndDate?: string | null;    // LocalDate → string
  statusCode?: string | null;
  progressPct?: number | null;

  budgetAmount?: number | null;
  actualCost?: number | null;

  createdAt?: string | null;        // LocalDateTime → string
  createdByEmpNo?: string | null;
  updatedAt?: string | null;
  updatedByEmpNo?: string | null;
}

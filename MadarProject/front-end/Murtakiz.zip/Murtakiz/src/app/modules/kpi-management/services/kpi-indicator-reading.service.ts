import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  CreateKpiIndicatorReadingRequest,
  KpiIndicatorReadingDto
} from '../models/kpi-indicator-reading.model';

@Injectable({
  providedIn: 'root',
})
export class KpiIndicatorReading {

  private baseUrl = 'http://localhost:9090/api/v1/murtakiz';
  private readingsUrl = `${this.baseUrl}/kpi/readings`;

  constructor(private http: HttpClient) {}

  /** إنشاء قراءة جديدة لمؤشر */
  createReading(
    payload: CreateKpiIndicatorReadingRequest
  ): Observable<KpiIndicatorReadingDto> {
    return this.http.post<KpiIndicatorReadingDto>(this.readingsUrl, payload);
  }

  /** جلب كل القراءات لمؤشر معيّن (by-kpi/{kpiCode}) */
  getReadingsByKpi(
    kpiCode: string
  ): Observable<KpiIndicatorReadingDto[]> {
    return this.http.get<KpiIndicatorReadingDto[]>(
      `${this.readingsUrl}/by-kpi/${encodeURIComponent(kpiCode)}`
    );
  }
}

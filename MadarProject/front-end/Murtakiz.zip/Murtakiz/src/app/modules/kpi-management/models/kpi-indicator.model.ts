export interface CreateKpiIndicatorRequest {
  code: string;          // KPI_CODE
  nameAr: string;        // KPI_NAME_AR
  descAr: string;        // KPI_DESC_AR

  goalCode: string;      

  perspectiveCode: string;   // PERSPECTIVE_CODE

  ownerEmpNo?: string | null;    
  ownerUniteId?: number | null;  
  ownerSubUniteId?: number | null; 

  targetValue?: number | null;           // TARGET_VALUE
  targetSource?: string | null;          // TARGET_SOURCE
  meansToAchieveTarget?: string | null;  // MEANS_TO_ACHIEVE_TARGET

  baselineValue?: number | null;         // BASELINE_VALUE
  measurementUnit?: string | null;       // MEASUREMENT_UNIT

  polarityCode?: string | null;          // POLARITY_CODE
  measurementMethod?: string | null;     // MEASUREMENT_METHOD
  formulaText?: string | null;           // FORMULA_TEXT

  frequencyCode?: string | null;         // FREQUENCY_CODE

  currentStatus?: string | null;         // CURRENT_STATUS (ON_TRACK / AT_RISK / OFF_TRACK...)

  isMain?: string | null;                // IS_MAIN ('Y' or 'N')
  parentKpiCode?: string | null;        

  isActive?: string | null;              // IS_ACTIVE ('Y' or 'N')
}


export interface KpiIndicatorDto {
  id: number;
  code: string;
  nameAr: string;
  descAr: string;

  goalCode: string;
  perspectiveCode: string;

  ownerEmpNo?: string | null;
  ownerUniteId?: number | null;
  ownerSubUniteId?: number | null;

  targetValue?: number | null;
  targetSource?: string | null;
  meansToAchieveTarget?: string | null;

  baselineValue?: number | null;
  measurementUnit?: string | null;

  polarityCode?: string | null;
  measurementMethod?: string | null;
  formulaText?: string | null;

  frequencyCode?: string | null;

  currentStatus?: string | null;
  lastUpdateDate?: string | null; 

  isMain?: string | null;
  parentKpiCode?: string | null;

  isActive?: string | null;

  createdAt?: string | null;      
  createdByEmpNo?: string | null;
  updatedAt?: string | null;
  updatedByEmpNo?: string | null;
}

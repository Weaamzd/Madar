import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SidebarStateService {
  isLeftSidebarCollapsed = signal<boolean>(false);
  isSubSidebarVisible = signal<boolean>(false); 

   selectedRegionId = signal<string | null>(null);
}

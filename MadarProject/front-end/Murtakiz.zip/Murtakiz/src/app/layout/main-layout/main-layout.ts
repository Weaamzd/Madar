import { Component, computed } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

import { CommonModule } from '@angular/common';
import { Sidebar } from '../sidebar/sidebar';
import { SidebarStateService } from '../sidebar-state.service';
import { Header } from "../header/header";

@Component({
  selector: 'app-main-layout',
  imports: [RouterOutlet, CommonModule, Sidebar, Header],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.css'
})
export class MainLayout {

  constructor(public router: Router, public sidebar: SidebarStateService) { }

  sizeClass = computed(() => {
  const isCollapsed = this.sidebar.isLeftSidebarCollapsed();
  const isSubVisible = this.sidebar.isSubSidebarVisible();

  if (!isCollapsed && isSubVisible) return 'body-expanded-with-sub';
  if (!isCollapsed && !isSubVisible) return 'body-expanded';
  if (isCollapsed && isSubVisible) return 'body-collapsed-with-sub';
  return 'body-collapsed';
});

}

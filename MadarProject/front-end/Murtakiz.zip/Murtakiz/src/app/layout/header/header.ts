import { Component, OnInit } from '@angular/core';
import { SidebarStateService } from '../sidebar-state.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class Header implements OnInit {

  constructor(public sidebar: SidebarStateService) {}

  
  timeOnly: string = '';
  ampm: string = '';
  currentDate: string = '';
  hijriDate: string = '';
  weekday: string = '';

  ngOnInit(): void {
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);
  }

updateClock() {
  const now = new Date();

  const hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();
  const ampm = hours >= 12 ? 'م' : 'ص';
  const hours12 = hours % 12 || 12;

  const timeStr = `${hours12.toString().padStart(2, '0')}:${minutes
    .toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  this.timeOnly = this.toArabicDigits(timeStr);
  this.ampm = ampm;

  const weekday = new Intl.DateTimeFormat('ar-SA', {
    weekday: 'long',
    timeZone: 'Asia/Riyadh'
  }).format(now);

  const hijriParts = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    timeZone: 'Asia/Riyadh'
  }).formatToParts(now);
  const y = hijriParts.find(p => p.type === 'year')?.value ?? '';
  const m = hijriParts.find(p => p.type === 'month')?.value ?? '';
  const d = hijriParts.find(p => p.type === 'day')?.value ?? '';
  this.hijriDate = this.toArabicDigits(`${y}/${m}/${d}`);

  const gregNoWeekday = new Intl.DateTimeFormat('ar-EG', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    timeZone: 'Asia/Riyadh'
  }).format(now);
  this.currentDate = this.toArabicDigits(gregNoWeekday);

  this.fullDate = `${weekday} - ${this.hijriDate} هـ - ${this.currentDate} م`;
}

fullDate: string = '';


private toArabicDigits(input: string | number): string {
  const map = '٠١٢٣٤٥٦٧٨٩';
  return input.toString().replace(/\d/g, (d) => map[+d]);
}


private pad2Arabic(n: number): string {
  const s = n.toString().padStart(2, '0'); 
  return this.toArabicDigits(s);          
}





private tz = 'Asia/Riyadh'; 


private getArabicTimeParts(date: Date) {
  const fmt = new Intl.DateTimeFormat('ar-SA', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
    numberingSystem: 'arab',
    timeZone: this.tz
  });

  const parts = fmt.formatToParts(date);
  const hh = parts.find(p => p.type === 'hour')?.value ?? '';
  const mm = parts.find(p => p.type === 'minute')?.value ?? '';
  const ss = parts.find(p => p.type === 'second')?.value ?? '';
  const dayPeriod = parts.find(p => p.type === 'dayPeriod')?.value ?? ''; 

  return { hh, mm, ss, dayPeriod };
}


private formatHijri(date: Date): string {
  const fmt = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    numberingSystem: 'arab',
    timeZone: this.tz
  });

  const parts = fmt.formatToParts(date);
  const y = parts.find(p => p.type === 'year')?.value ?? '';
  const m = parts.find(p => p.type === 'month')?.value ?? '';
  const d = parts.find(p => p.type === 'day')?.value ?? '';
  return `${y}-${m}-${d}`;
}


private formatHijriFull(date: Date): string {
  return new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    numberingSystem: 'arab',
    timeZone: this.tz
  }).format(date);
}




  toggleSidebar(): void {
    this.sidebar.isLeftSidebarCollapsed.set(!this.sidebar.isLeftSidebarCollapsed());
  }


}

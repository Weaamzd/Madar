import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, effect } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { finalize } from 'rxjs/operators';

import { SidebarStateService } from '../sidebar-state.service';
import { AuthService } from '../../core/auth/authService';
import { Delegations } from '../../../app/modules/delegation/services/delegations';

export enum PermissionAction {
  إضافة = 'إضافة',
  حذف = 'حذف',
  تعديل = 'تعديل',
  عرض = 'عرض',
  الكل = 'الكل'
}

export interface PermissionRow {
  system: string;
  expanded?: boolean;
  isChild?: boolean;
  children?: PermissionRow[];
  username?: string;
  sourceType?: 'ROLE' | 'DIRECT' | null;
  roleName?: string | null;
  [key: string]: any;
}



export const DATABASE_KEYS: Record<string, string> = {
  db1: 'منطقة فرع جدة',
  db2: 'منطقة فرع الرياض',
  db3: 'منطقة فرع الدمام'
};

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar implements OnChanges {

  toggleMainSidebar(): void {
    const collapsed = this.sidebarState.isLeftSidebarCollapsed();
    this.sidebarState.isLeftSidebarCollapsed.set(!collapsed);
  }
  @Input() isLeftSidebarCollapsed!: boolean;
  @Output() changeIsLeftSidebarCollapsed = new EventEmitter<boolean>();

  dropdownOpen = false;

  userImageUrl: string | null = '';
  roles: string[] = [];
  items: any[] = [];
  userName = 'اسم المستخدم';
  regionName = '';


  actingMenuOpen = false;
  actingLoading = false;
  actingError: string | null = null;
  actingContexts: Array<{
    delegationId: number;
    onBehalfEmpNo: string;
    onBehalfUsername: string;
    scopeType: 'ALL' | 'LIMITED' | string;
    uniteIds: number[];
    subUniteIds: number[];
    startAt: string;
    endAt: string | null;
  }> = [];
  private actingLoaded = false; 

  isLoggingOut = false;

  constructor(
    private router: Router,
    public sidebarState: SidebarStateService,
    private authService: AuthService,
    private delegations: Delegations
  ) {

    effect(() => {
      this.roles = this.authService.getRoles();
      this.items = this.visibleItems;
      this.userName = this.computeDisplayNameFromProfile();


      if (this.actingMenuOpen && this.canUseActing && !this.actingLoaded) {
        this.fetchActingContexts();
      }
    });

    try {
      const dbKey = localStorage.getItem('regionDbKey') || '';
      this.regionName = DATABASE_KEYS[dbKey] || '';
    } catch {
      this.regionName = '';
    }

    this.items = this.visibleItems;
  }

  /** هل المستخدم مسجل دخول؟ */
  get isAuth(): boolean {
    return this.authService.isAuthenticated();
  }

  /** هل المستخدم خارجي؟ */
  get isExternalUser(): boolean {
    const p = this.authService.profileSig();
    return p?.profileType === 'EXTERNAL';
  }

  /** متى نسمح بميزات التمثيل؟ */
  get canUseActing(): boolean {
    return this.isAuth && !this.isExternalUser;
  }

  /** العناصر الظاهرة حسب الأدوار */
  get visibleItems() {
    return this.allItems.filter(item =>
      item.allowedFor.includes('*') || this.authService.hasAnyRole(...item.allowedFor)
    );
  }

  allItems = [
  {
    icon: 'bi bi-grid-3x3-gap-fill',
    label: 'لوحة المعلومات',
    action: 'dashboard',
    routeLink: '/kpi-management/dashboard',
    allowedFor: [
      '*',
    ]
  },
  {
    icon: 'bi bi-person-badge-fill',
    label: 'صفحتي الوظيفية',
    action: 'my-profile',
    routeLink: '/my-profile',
    allowedFor: ['ADMIN', 'MANAGER', 'USER']
  },

  {
    icon: 'bi bi-bar-chart-line-fill',
    label: 'الأستراتيجيات والمؤشرات',
    action: 'kpi-management',
    routeLink: '/kpi-management/managementKPI',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'SECTION_MANAGER',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER'
    ]
  },

  {
    icon: 'bi bi-hdd-network-fill',
    label: 'مركز الإدارة',
    action: 'systems',
    routeLink: '/employee-supervision/supervision',
   allowedFor: [
      '*',
    ]
  },
  {
    icon: 'bi bi-sliders2-vertical',
    label: 'إعداد الواجهة',
    action: 'ui-settings',
    routeLink: '/ui-settings',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'SECTION_MANAGER',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER',
      'EMPLOYEE'
    ]
  },
  {
    icon: 'bi bi-life-preserver',
    label: 'طلب خدمة',
    action: 'service-request',
    routeLink: '/service-request/track-my-request',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'EMPLOYEE',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER'
    ]
  },
  {
    icon: 'bi bi-tools',
    label: 'الدعم الفني',
    action: 'support',
    routeLink: '',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'SECTION_MANAGER',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER'
    ]
  },
  {
    icon: 'bi bi-journal-bookmark-fill',
    label: 'المرجع المركزي',
    action: 'knowledge-base',
    routeLink: '',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'SECTION_MANAGER',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER'
    ]
  },
  {
    icon: 'bi bi-shield-lock-fill',
    label: 'الإدارة الأمنية',
    action: 'security-admin',
    routeLink: '/SystemSettings/user-management',
    allowedFor: [
      'SYSTEM_ADMIN',
      'DEPARTMENT_MANAGER',
      'SECTION_MANAGER',
      'OFFICE_MANAGER',
      'SUBUNIT_MANAGER'
    ]
  }
];




/*   allItems = [
    {
      icon: 'fa-solid fa-chart-line',
      label: 'لوحة المعلومات',
      action: 'dashboard',
      routeLink: ['delegationuser'],
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER','EMPLOYEE']
    },
    {
      icon: 'fa-solid fa-id-card',
      label: 'صفحتي الوظيفية',
      action: 'my-profile',
      routeLink: '/my-profile',
      allowedFor: ['ADMIN', 'MANAGER', 'USER']
    },
    {
      icon: 'fa-solid fa-layer-group',
      label: 'الأنظمة',
      action: 'systems',
      routeLink: '/systems',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER']
    },
    {
      icon: 'fa-solid fa-sliders',
      label: 'إعداد الواجهة',
      action: 'ui-settings',
      routeLink: '/ui-settings',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER','EMPLOYEE']
    },
    {
      icon: 'fa-solid fa-hand-holding-hand',
      label: 'طلب خدمة',
      action: 'service-request',
      routeLink: '/service-request/track-my-request',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','EMPLOYEE','OFFICE_MANAGER','SUBUNIT_MANAGER']
    },
    {
      icon: 'fa-solid fa-headset',
      label: 'الدعم الفني',
      action: 'support',
      routeLink: '/SystemSettings/user-management',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER']
    },
    {
      icon: 'fa-solid fa-book-open',
      label: 'المرجع المركزي',
      action: 'knowledge-base',
      routeLink: '/employee-supervision/supervision',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER']
    },
    {
      icon: 'fa-solid fa-shield-halved',
      label: 'الإدارة الأمنية',
      action: 'security-admin',
      routeLink: '/SystemSettings',
      allowedFor: ['SYSTEM_ADMIN','DEPARTMENT_MANAGER','SECTION_MANAGER','OFFICE_MANAGER','SUBUNIT_MANAGER']
    }
  ]; */

  ngOnInit() {
    this.updateClock();
    setInterval(() => this.updateClock(), 1000);

    this.items = this.visibleItems;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['isLeftSidebarCollapsed'] && changes['isLeftSidebarCollapsed'].currentValue === true) {
      this.dropdownOpen = false;
      this.sidebarState.isSubSidebarVisible.set(false);
    }
  }

private computeDisplayNameFromProfile(): string {
  try {
    if (this.authService.isActing()) {
      const actingAs = this.authService.onBehalfUsername();
      if (actingAs) return actingAs;
    }

    const p = this.authService.profileSig();
    if (p) {
      if (p.profileType === 'INTERNAL' && p.internalDetails) {
        const internal: any = p.internalDetails;
        const fullNameAr =
          internal.fullNameAr ||
          internal.employeeNameAr ||
          internal.employeeName ||
          internal.fullName ||
          null;

        if (fullNameAr) {
          return fullNameAr;
        }
      }


      if (p.profileType === 'EXTERNAL' && p.externalDetails) {
        const ext: any = p.externalDetails;
        const fullNameAr =
          ext.fullNameAr ||
          ext.fullName ||
          ext.nameAr ||
          null;

        if (fullNameAr) {
          return fullNameAr;
        }
      }

      return p.user?.username ?? (localStorage.getItem('username') || 'اسم المستخدم');
    }

    return localStorage.getItem('username') || 'اسم المستخدم';
  } catch {
    return 'اسم المستخدم';
  }
}


  toggleCollapse(): void {
    this.changeIsLeftSidebarCollapsed.emit(!this.isLeftSidebarCollapsed);
  }

  closeSidenav(): void {
    this.changeIsLeftSidebarCollapsed.emit(true);
  }

  dropdownItems = [
    { label: 'الملف الشخصي', action: 'profile', icon: 'fa-solid fa-user' },
    { label: 'الإعدادات', action: 'settings', icon: 'fa-solid fa-gear' },
    { label: 'divider' },
    { label: 'تسجيل الخروج', action: 'logout', icon: 'fa-solid fa-right-from-bracket' }
  ];

  isProductSidebarVisible = false;

  handleAction(action: string | undefined) {
    switch (action) {
      case 'profile':
        console.log('الملف الشخصي');
        break;
      case 'settings':
        console.log('الإعدادات');
        break;
      case 'logout': {
        this.isLoggingOut = true;
  this.authService.logoutAll()
    .pipe(finalize(() => this.isLoggingOut = false))
    .subscribe({ next: () => {}, error: () => {} });
  break;
      }
      default:
        console.warn('إجراء غير معروف أو غير معرف');
    }
    this.dropdownOpen = false;
  }

handleAction2(action: string | undefined) {
  switch (action) {
    case 'systems':
      this.sidebarState.isSubSidebarVisible.set(
        !this.sidebarState.isSubSidebarVisible()
      );
      break;

    default:
      this.sidebarState.isSubSidebarVisible.set(false);
  }

  this.dropdownOpen = false;
}


  timeOnly: string = '';
  ampm: string = '';
  currentDate: string = '';
  hijriDate: string = '';

  private tz = 'Asia/Riyadh';

  updateClock() {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    const ampm = hours >= 12 ? 'م' : 'ص';
    const hours12 = hours % 12 || 12;

    const timeStr = `${hours12.toString().padStart(2, '0')}:${minutes
      .toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    this.timeOnly = this.toArabicDigits(timeStr);
    this.ampm = ampm;

    const greg = new Intl.DateTimeFormat('ar-EG', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      timeZone: 'Asia/Riyadh'
    }).format(now);
    this.currentDate = this.toArabicDigits(greg);

    const hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      timeZone: 'Asia/Riyadh'
    }).format(now);
    this.hijriDate = this.toArabicDigits(hijri);
  }

  private toArabicDigits(input: string | number): string {
    const map = '٠١٢٣٤٥٦٧٨٩';
    return input.toString().replace(/\d/g, (d) => map[+d]);
  }

  /** جلب الحسابات التي فوّضتك — داخلي ومسجّل دخول فقط */
  private fetchActingContexts(): void {
    if (!this.canUseActing || this.actingLoaded) {
      return;
    }

    this.actingLoading = true;
    this.actingError = null;

    this.delegations.listActingContexts().pipe(
      finalize(() => this.actingLoading = false)
    ).subscribe({
      next: (rows) => {
        this.actingContexts = Array.isArray(rows) ? rows : [];
        this.actingLoaded = true;
      },
      error: () => {
        this.actingError = 'تعذّر تحميل حسابات التمثيل';
        this.actingContexts = [];
      }
    });
  }

  /** بدء التمثيل — داخلي فقط */
beginActing(delegationId: number): void {
    if (!this.canUseActing) return;

    this.delegations.startActing(delegationId).subscribe({
      next: (res) => {
        this.authService.saveCurrentTokenAsBase();
        this.authService.applyToken(res);

        if (this.authService.isAuthenticated()) {
          this.authService.fetchMe().subscribe({
            next: () => {
              this.items = this.visibleItems;
              const actingAs = this.authService.onBehalfUsername();
              this.userName = actingAs || this.computeDisplayNameFromProfile();
              location.reload();
            },
            error: () => location.reload()
          });
        } else {
          this.authService.forceLogoutToLogin();
        }
      },
      error: () => alert('فشل بدء التمثيل. حاول لاحقاً.')
    });
  }


stopActing(): void {
    if (!this.canUseActing) return;

    this.delegations.stopActing().subscribe({
      next: () => {
        const restored = this.authService.restoreBaseToken();


        localStorage.removeItem('act');
        localStorage.removeItem('ctx_emp_no');
        localStorage.removeItem('on_behalf_username');
        localStorage.removeItem('on_behalf_emp_no');

        if (restored && this.authService.isAuthenticated()) {

          this.authService.fetchMe().subscribe({
            complete: () => location.reload(),
            error: () => location.reload()
          });
        } else if (restored) {

          this.authService.forceLogoutToLogin();
        } else {

          this.authService.forceLogoutToLogin();
        }
      },
      error: () => alert('تعذّر الإنهاء الآن')
    });
  }


  onToggleActingMenu(evt?: Event): void {
    if (evt) evt.preventDefault();
    if (!this.canUseActing) return;

    this.actingMenuOpen = !this.actingMenuOpen;
    if (this.actingMenuOpen && !this.actingLoaded) {
      this.fetchActingContexts();
    }
  }
}

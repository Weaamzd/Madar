import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
import { throwError, EMPTY } from 'rxjs';  

const API_BASE = 'http://localhost:9090';
const API_PREFIX = '/api/v1/murtakiz';

const PUBLIC_PATHS = [
  `${API_PREFIX}/auth/login`,
];

function toUrl(input: string): URL {
  return new URL(input, API_BASE);
}
function isSameApi(u: URL): boolean {
  return u.origin === new URL(API_BASE).origin && u.pathname.startsWith(API_PREFIX);
}
function isPublic(u: URL): boolean {
  return PUBLIC_PATHS.some(p => u.pathname === p || u.pathname.startsWith(p));
}
function clearSessionAndGoLogin(router: Router) {
  localStorage.clear();
  router.navigate(['/auth/login'], { replaceUrl: true });
}

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  const url = toUrl(req.url);
  const token = localStorage.getItem('token');
  const type  = localStorage.getItem('tokenType') || 'Bearer';

  let forwardReq = req;

  if (token && isSameApi(url) && !isPublic(url)) {
    forwardReq = req.clone({ setHeaders: { Authorization: `${type} ${token}` } });
  }

  return next(forwardReq).pipe(
    catchError((err: HttpErrorResponse) => {
      const isLoginCall = isSameApi(url) && url.pathname === `${API_PREFIX}/auth/login`;

      if (!isLoginCall && (err.status === 401 || err.status === 403)) {
        clearSessionAndGoLogin(router);
        return EMPTY;                
      }

      return throwError(() => err);  
    })
  );
};

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, computed, signal } from '@angular/core';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { tap, switchMap, finalize, catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';

export interface SubUniteMiniDto {
  id: number;
  code: string;
  name: string;
}

export interface UniteMiniDto {
  id: number;
  code: string;
  name: string;
}

export interface InternalEmployeeDetailsDto {
  empNo: string;
  fullNameAr: string;
  email: string;
  jobTitle: string;
  hireDate: string;   
  startDate: string; 
  managerNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}

export interface ExternalEmployeeDetailsDto {
  id: string;
  fullNameAr: string;
  fullNameEn: string;
  email: string;
  phone: string;
  organizationName: string;
  jobTitle: string;
  collaborationType: string;
  startDate: string;      
  endDate: string | null; 
  status: string;
  notes: string;
  managerEmpNo: string | null;
  subUnite: SubUniteMiniDto | null;
  unite: UniteMiniDto | null;
}

export interface UserMiniDto {
  userId: number;
  username: string;
  status: string;
  lastLoginAt: string;         
  currentRegionId: number | null;
  regionCode: string | null;
  regionDbKey: string | null;
}

export interface UserFullProfileDto {
  profileType: 'INTERNAL' | 'EXTERNAL' | 'UNLINKED';
  user: UserMiniDto;
  roles: string[];
  loggedIn: boolean;
  internalDetails: InternalEmployeeDetailsDto | null;
  externalDetails: ExternalEmployeeDetailsDto | null;
}

export interface UserSummary {
  userId: number;
  username: string;
  empNo: string;
  fullName: string;
  email: string;
  jobTitle: string;
  regionCode: string;
  regionDbKey: string;
  roles: string[];
}

export interface ActingTokenResponse {
  accessToken: string;
  expiresAt: string;
  jti: string;
  actingSessionId: number;
  delegationId: number;
  tokenType?: string; 
}
export interface AuthResponse {
  tokenType: string;
  accessToken: string;
  expiresAt: string;
  jti: string;
}

export interface JwtClaims {
  iss?: string; sub?: string; iat?: number; exp?: number;
  roles?: string[];                    
  roles_effective?: string[];          
  permissions_effective?: string[];   
  empNo?: string;
  emp_no?: string;                    
  enabled?: boolean;
  username?: string;
  jti?: string;
  regionId?: number;
  act?: boolean;                       
  ctx_emp_no?: string;                
  on_behalf?: {                       
    user_id?: string;
    emp_no?: string;
    username?: string;
  };
  delegation?: any;
}


/* export interface JwtClaims {
  iss?: string;
  sub?: string;
  iat?: number;
  exp?: number;
  roles?: string[];
  empNo?: string;
  enabled?: boolean;
  username?: string;
  jti?: string;
  regionId?: number;
} */

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly apiRoot       = 'http://localhost:9090/api/v1/murtakiz';
  private readonly authBase      = `${this.apiRoot}/auth`;         
  private readonly loginUrl      = `${this.authBase}/login`;
  private readonly meUrl         = `${this.authBase}/me`;
  private readonly logoutUrl     = `${this.authBase}/logout`;
  private readonly logoutAllUrl  = `${this.authBase}/logout-all`;

  readonly profileSig = signal<UserFullProfileDto | null>(this.restoreProfile());


  readonly tokenSig = signal<string | null>(localStorage.getItem('token'));
  readonly userSig  = signal<UserSummary | null>(this.restoreUser());

  readonly isAuthenticated = computed(() => {
    const token = this.tokenSig();
    if (!token) return false;
    try {
      const { exp } = jwtDecode<JwtClaims>(token);
      const now = Math.floor(Date.now() / 1000);
      return !exp || exp > now;
    } catch {
      return false;
    }
  });

  constructor(private http: HttpClient, private router: Router) {}

login(credentials: { username: string; password: string }): Observable<any> {
  return this.http.post(`${this.apiRoot}/auth/login`, credentials).pipe(
    tap((res: any) => {
      this.clearSessionOnly();

      localStorage.setItem('token', res.accessToken);
      localStorage.setItem('tokenType', res.tokenType || 'Bearer');

      this.tokenSig.set(res.accessToken);
      this.userSig.set(res.user);
      this.profileSig.set(res.profile);

      localStorage.setItem('username', res.user?.username || '');
    })
  );
}

private clearSessionOnly() {
  localStorage.removeItem('token');
  localStorage.removeItem('tokenType');
  localStorage.removeItem('username');
  this.tokenSig.set(null);
  this.userSig.set(null);
  this.profileSig.set(null);
}


  private setProfile(p: UserFullProfileDto) {
  localStorage.setItem('profile', JSON.stringify(p));
  this.profileSig.set(p);
}

private restoreProfile(): UserFullProfileDto | null {
  try {
    const raw = localStorage.getItem('profile');
    return raw ? (JSON.parse(raw) as UserFullProfileDto) : null;
  } catch {
    return null;
  }
}


  loginAndFetchMe(credentials: { username: string; password: string }): Observable<UserSummary> {
    return this.login(credentials).pipe(
      switchMap(() => {
        if (!this.isAuthenticated()) {

          return of(null as any);
        }
        return this.fetchMe();
      })
    );
  }

  fetchMe(): Observable<UserSummary> {

    if (!this.isAuthenticated()) {
      return of(null as any);
    }

    return this.http.get<UserFullProfileDto>(this.meUrl).pipe(
      tap(p => this.setProfile(p)),
      switchMap(p => {
        const summary = this.buildUserSummaryFromProfile(p);
        this.setUser(summary);
        return of(summary);
      })
    );
  }

  ensureMe(): Observable<UserSummary | null> {
    if (!this.isAuthenticated()) return of(null);

    const cached = this.userSig();
    if (cached) return of(cached);


    const p = this.profileSig();
    if (p) {
      const summary = this.buildUserSummaryFromProfile(p);
      this.setUser(summary);
      return of(summary);
    }

    return this.fetchMe();
  }


/*   logoutBackend(): Observable<any> {
    return this.http.post(this.logoutUrl, {});
  } */

  logoutBackend(): Observable<any> {
  const savedToken = this.getToken();
  const savedType  = this.getTokenType() || 'Bearer';
  const headers = savedToken
    ? new HttpHeaders({ Authorization: `${savedType} ${savedToken}` })
    : undefined;

  return this.http.post(this.logoutUrl, {}, { headers });
}


  logoutAllBackend(): Observable<any> {
    return this.http.post(this.logoutAllUrl, {});
  }

  logout() {
    const savedToken = this.getToken();
    const savedType  = this.getTokenType() || 'Bearer';

    this.clearSessionAndGoLogin(true);

    if (savedToken) {
      const headers = new HttpHeaders({ Authorization: `${savedType} ${savedToken}` });
      this.http.post(this.logoutUrl, {}, { headers }).subscribe({ next: () => {}, error: () => {} });
    }
  }

logoutAll(): Observable<any> {
  const savedToken = this.getToken();
  const savedType  = this.getTokenType() || 'Bearer';

  if (savedToken) {
    const headers = new HttpHeaders({ Authorization: `${savedType} ${savedToken}` });
    return this.http.post(this.logoutAllUrl, {}, { headers }).pipe(
      finalize(() => this.clearSessionAndGoLogin(true)),
      catchError(() => of(null))
    );
  }

  this.clearSessionAndGoLogin(true);
  return of(null);
}


forceLogoutToLogin() {
  this.clearSessionOnly();
  localStorage.clear();
  this.router.navigateByUrl('/auth/login', { replaceUrl: true });
  setTimeout(() => location.reload(), 100); 
}

  private setSession(res: AuthResponse) {
  localStorage.setItem('tokenType', res.tokenType ?? 'Bearer');
  localStorage.setItem('token', res.accessToken);
  localStorage.setItem('tokenExpiresAt', res.expiresAt);
  localStorage.setItem('jti', res.jti ?? '');
  this.tokenSig.set(res.accessToken);

  try {
    const claims = jwtDecode<JwtClaims>(res.accessToken);

    const effectiveRoles = claims.roles_effective && claims.roles_effective.length
      ? claims.roles_effective
      : (claims.roles ?? []);

    localStorage.setItem('act', String(!!claims.act));
    if (claims.ctx_emp_no) localStorage.setItem('ctx_emp_no', claims.ctx_emp_no);
    if (claims.on_behalf?.username) localStorage.setItem('on_behalf_username', claims.on_behalf.username);
    if (claims.on_behalf?.emp_no)   localStorage.setItem('on_behalf_emp_no', claims.on_behalf.emp_no);

    const username = claims.username ?? '';
    const subject  = claims.sub ?? '';
    const empNo    = (claims.emp_no ?? claims.empNo ?? '') as string;

    localStorage.setItem('username', username || subject);
    localStorage.setItem('subject', subject);
    localStorage.setItem('roles', JSON.stringify(effectiveRoles));  
    localStorage.setItem('empNo', empNo);
    localStorage.setItem('enabled', String(claims.enabled ?? ''));
    if (claims.regionId != null) {
      localStorage.setItem('regionId', String(claims.regionId));
    }
  } catch {}
}

isActing(): boolean {
  try {
    const t = this.getToken();
    if (!t) return false;
    const { act } = jwtDecode<JwtClaims>(t);
    return !!act;
  } catch { return false; }
}

onBehalfUsername(): string | null {
  try {
    const t = this.getToken(); if (!t) return null;
    const { on_behalf } = jwtDecode<JwtClaims>(t);
    return on_behalf?.username ?? localStorage.getItem('on_behalf_username');
  } catch { return localStorage.getItem('on_behalf_username'); }
}

ctxEmpNo(): string | null {
  try {
    const t = this.getToken(); if (!t) return null;
    const { ctx_emp_no } = jwtDecode<JwtClaims>(t);
    return ctx_emp_no ?? localStorage.getItem('ctx_emp_no');
  } catch { return localStorage.getItem('ctx_emp_no'); }
}


  /* private setSession(res: AuthResponse) {
    localStorage.setItem('tokenType', res.tokenType ?? 'Bearer');
    localStorage.setItem('token', res.accessToken);
    localStorage.setItem('tokenExpiresAt', res.expiresAt);
    localStorage.setItem('jti', res.jti ?? '');
    this.tokenSig.set(res.accessToken);

    try {
      const claims = jwtDecode<JwtClaims>(res.accessToken);
      const username = claims.username ?? '';
      const subject  = claims.sub ?? '';
      const roles    = claims.roles ?? [];
      const empNo    = claims.empNo ?? '';

      localStorage.setItem('username', username || subject);
      localStorage.setItem('subject', subject);
      localStorage.setItem('roles', JSON.stringify(roles));
      localStorage.setItem('empNo', empNo);
      localStorage.setItem('enabled', String(claims.enabled ?? ''));
      if (claims.regionId != null) {
        localStorage.setItem('regionId', String(claims.regionId));
      }
    } catch {}
  } */

  private setUser(u: UserSummary) {
    localStorage.setItem('user', JSON.stringify(u));
    localStorage.setItem('userId', String(u.userId));
    localStorage.setItem('usernameProfile', u.username ?? '');
    localStorage.setItem('empNoProfile', u.empNo ?? '');
    localStorage.setItem('fullName', u.fullName ?? '');
    localStorage.setItem('email', u.email ?? '');
    localStorage.setItem('jobTitle', u.jobTitle ?? '');
    localStorage.setItem('regionCode', u.regionCode ?? '');
    localStorage.setItem('regionDbKey', u.regionDbKey ?? '');
    localStorage.setItem('roles', JSON.stringify(u.roles ?? []));
    this.userSig.set(u);
  }

  private restoreUser(): UserSummary | null {
    try {
      const raw = localStorage.getItem('user');
      return raw ? (JSON.parse(raw) as UserSummary) : null;
    } catch {
      return null;
    }
  }

private buildUserSummaryFromProfile(p: UserFullProfileDto): UserSummary {
  const base = p.user;
  const isInternal = p.profileType === 'INTERNAL' && p.internalDetails;
  const isExternal = p.profileType === 'EXTERNAL' && p.externalDetails;

  const empNo   = isInternal ? p.internalDetails!.empNo : (isExternal ? (p.externalDetails!.managerEmpNo ?? '') : '');
  const fullName= isInternal ? p.internalDetails!.fullNameAr : (isExternal ? p.externalDetails!.fullNameAr : base.username);
  const email   = isInternal ? p.internalDetails!.email : (isExternal ? p.externalDetails!.email : '');
  const jobTitle= isInternal ? p.internalDetails!.jobTitle : (isExternal ? p.externalDetails!.jobTitle : '');

  return {
    userId: base.userId,
    username: base.username,
    empNo: empNo ?? '',
    fullName: fullName ?? '',
    email: email ?? '',
    jobTitle: jobTitle ?? '',
    regionCode: base.regionCode ?? '',
    regionDbKey: base.regionDbKey ?? '',
    roles: p.roles ?? [],
  };
}


private clearSessionAndGoLogin(replace = false) {
  localStorage.clear();
  this.tokenSig.set(null);
  this.userSig.set(null);
  this.profileSig.set(null);
  this.router.navigate(['/auth/login'], { replaceUrl: replace }); 
}


  getToken(): string | null {
    return this.tokenSig();
  }

  getTokenType(): string {
    return localStorage.getItem('tokenType') || 'Bearer';
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated();
  }

   /** مصدر الحقيقة: userSig (من /auth/me). Fallback: claims داخل JWT */
/*   getRoles(): string[] {
    try {
      const user = this.userSig();
      if (user?.roles?.length) return user.roles;       

      const t = this.getToken();                        
      if (!t) return [];
      const { roles } = jwtDecode<JwtClaims>(t);
      return roles ?? [];
    } catch {
      return [];
    }
  } */

getRoles(): string[] {
  try {
    if (this.isActing()) {
      const t = this.getToken(); if (!t) return [];
      const c = jwtDecode<JwtClaims>(t);
      return (c.roles_effective && c.roles_effective.length)
        ? c.roles_effective
        : (c.roles ?? []);
    }


    const p = this.profileSig();
    if (p?.roles?.length) return p.roles;


    const user = this.userSig();
    if (user?.roles?.length) return user.roles;

 
    const t = this.getToken(); if (!t) return [];
    const c = jwtDecode<JwtClaims>(t);
    return (c.roles_effective && c.roles_effective.length)
      ? c.roles_effective
      : (c.roles ?? []);
  } catch {
    return [];
  }
}



  hasRole(role: string): boolean {
    const roles = this.getRoles();
    return roles.includes(role);
  }

  hasAnyRole(...required: string[]): boolean {
    const roles = this.getRoles();
    return required.some(r => roles.includes(r));
  }

  hasAllRoles(...required: string[]): boolean {
    const roles = this.getRoles();
    return required.every(r => roles.includes(r));
  }

  applyToken(res: { accessToken: string; expiresAt?: string; jti?: string; tokenType?: string }) {
    this['setSession']({
      tokenType: res.tokenType ?? 'Bearer',
      accessToken: res.accessToken,
      expiresAt: res.expiresAt ?? '',
      jti: res.jti ?? '',
    } as AuthResponse);
  }


  private readonly BASE_TOKEN_KEY = 'token_base';
  private readonly BASE_TOKEN_TYPE_KEY = 'token_base_type';
  private readonly BASE_TOKEN_EXPIRES_KEY = 'token_base_expires';
  private readonly BASE_TOKEN_JTI_KEY = 'token_base_jti';


  saveCurrentTokenAsBase() {
    const t = this.getToken();
    if (!t) return;
    localStorage.setItem(this.BASE_TOKEN_KEY, t);
    localStorage.setItem(this.BASE_TOKEN_TYPE_KEY, this.getTokenType() || 'Bearer');
    localStorage.setItem(this.BASE_TOKEN_EXPIRES_KEY, localStorage.getItem('tokenExpiresAt') || '');
    localStorage.setItem(this.BASE_TOKEN_JTI_KEY, localStorage.getItem('jti') || '');
  }

  /** استرجاع توكن الأساس وتطبيقه مكان توكن التمثيل */
  restoreBaseToken(): boolean {
    const base = localStorage.getItem(this.BASE_TOKEN_KEY);
    if (!base) return false;

    const baseType = localStorage.getItem(this.BASE_TOKEN_TYPE_KEY) || 'Bearer';
    const baseExp  = localStorage.getItem(this.BASE_TOKEN_EXPIRES_KEY) || '';
    const baseJti  = localStorage.getItem(this.BASE_TOKEN_JTI_KEY) || '';

    this.applyToken({
      accessToken: base,
      tokenType: baseType,
      expiresAt: baseExp,
      jti: baseJti
    });


    localStorage.removeItem(this.BASE_TOKEN_KEY);
    localStorage.removeItem(this.BASE_TOKEN_TYPE_KEY);
    localStorage.removeItem(this.BASE_TOKEN_EXPIRES_KEY);
    localStorage.removeItem(this.BASE_TOKEN_JTI_KEY);
    return true;
  }

getCurrentInternalUniteId(): number | null {
  const p = this.profileSig();
  if (!p || p.profileType !== 'INTERNAL' || !p.internalDetails?.unite) {
    return null;
  }
  return p.internalDetails.unite.id;
}

getCurrentInternalSubUniteId(): number | null {
  const p = this.profileSig();
  if (!p || p.profileType !== 'INTERNAL') {
    return null;
  }


  if (p.internalDetails?.subUnite?.id) {
    return p.internalDetails.subUnite.id;
  }

  if ((p.internalDetails as any).subUniteId) {
    return (p.internalDetails as any).subUniteId;
  }

  return null;
}





}

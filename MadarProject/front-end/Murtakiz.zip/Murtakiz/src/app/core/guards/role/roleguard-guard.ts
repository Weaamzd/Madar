import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from '../../auth/authService';

export const roleguardGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);


  if (!auth.isAuthenticated()) {
    return router.createUrlTree(
      ['/api/v1/murtakiz/auth/login'],                      
      { queryParams: { returnUrl: state.url } }  
    );
  }


  const required: string[] = route.data?.['roles'] ?? [];
  if (required.length === 0) return true;


  if (auth.hasAnyRole(...required)) return true;


  return router.createUrlTree(['/forbidden']);
};

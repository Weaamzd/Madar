package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Table(name = "external_employees", schema = "SYS")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ExternalEmployee {

    @Id
    @Column(name = "ext_emp_id", length = 50)
    private String id;

    @Column(name = "full_name_ar", nullable = false, length = 200)
    private String fullNameAr;

    @Column(name = "full_name_en", length = 200)
    private String fullNameEn;

    @Column(name = "email", length = 200)
    private String email;

    @Column(name = "phone", length = 50)
    private String phone;

    @Column(name = "organization_name", nullable = false, length = 200)
    private String organizationName;

    @Column(name = "job_title", length = 200)
    private String jobTitle;

    @Column(name = "collaboration_type", nullable = false, length = 50)
    private String collaborationType;

    @Column(name = "start_date", nullable = false)
    private LocalDate startDate;

    @Column(name = "end_date")
    private LocalDate endDate;

    @Column(name = "status", nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "notes", length = 500)
    private String notes;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "updated_by", length = 100)
    private String updatedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_manager_no", referencedColumnName = "emp_no",
            foreignKey = @ForeignKey(name = "fk_ext_emp__manager"))
    private Employee empManagerNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sub_unite_id", referencedColumnName = "sub_unite_id",
            foreignKey = @ForeignKey(name = "fk_ext_emp__sub_unite"))
    private SubUnite subUniteId;
}

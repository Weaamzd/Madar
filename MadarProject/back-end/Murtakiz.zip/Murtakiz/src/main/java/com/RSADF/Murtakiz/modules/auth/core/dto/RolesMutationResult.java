package com.RSADF.Murtakiz.modules.auth.core.dto;


import java.time.LocalDateTime;
import java.util.List;

public class RolesMutationResult {
    private Long userId;
    private String empNo;               // يُملأ في إضافة الأدوار فقط
    private List<String> added;         // ما أُضيف فعليًا
    private List<String> skipped;       // كان موجود مسبقًا
    private int deletedCount;           // في الحذف فقط
    private List<String> notFoundRoles; // أسماء أدوار غير موجودة بالسيستم
    private LocalDateTime at;

    public RolesMutationResult() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getEmpNo() { return empNo; }
    public void setEmpNo(String empNo) { this.empNo = empNo; }
    public List<String> getAdded() { return added; }
    public void setAdded(List<String> added) { this.added = added; }
    public List<String> getSkipped() { return skipped; }
    public void setSkipped(List<String> skipped) { this.skipped = skipped; }
    public int getDeletedCount() { return deletedCount; }
    public void setDeletedCount(int deletedCount) { this.deletedCount = deletedCount; }
    public List<String> getNotFoundRoles() { return notFoundRoles; }
    public void setNotFoundRoles(List<String> notFoundRoles) { this.notFoundRoles = notFoundRoles; }
    public LocalDateTime getAt() { return at; }
    public void setAt(LocalDateTime at) { this.at = at; }
}
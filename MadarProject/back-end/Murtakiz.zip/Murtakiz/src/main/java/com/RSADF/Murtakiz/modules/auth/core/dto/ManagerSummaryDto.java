package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ManagerSummaryDto {
    private String empNo;
    private String fullNameAr;
    private Long subUniteId;
    private String subUniteName;
}
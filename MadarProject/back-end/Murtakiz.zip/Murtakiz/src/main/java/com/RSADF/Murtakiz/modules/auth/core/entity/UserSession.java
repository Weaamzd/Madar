package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "USER_SESSIONS", schema = "SYS",
        indexes = {
                @Index(name = "IX_USER_SESSIONS_HASH", columnList = "ACCESS_TOKEN_HASH"),
                @Index(name = "IX_USER_SESSIONS_JTI",  columnList = "ACCESS_TOKEN_JTI")
        })
@Getter
@Setter
@NoArgsConstructor
public class UserSession {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SESSION_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "USER_ID", nullable = false)
    private User user;

    @Column(name = "ACCESS_TOKEN_HASH", nullable = false, length = 64)
    private String accessTokenHash;

    @Column(name = "ACCESS_TOKEN_JTI", length = 64)
    private String accessTokenJti;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "EXPIRES_AT")
    private LocalDateTime expiresAt;

    @Column(name = "REVOKED_AT")
    private LocalDateTime revokedAt;

    @Column(name = "USER_AGENT", length = 200)
    private String userAgent;

    @Column(name = "IP_ADDRESS", length = 50)
    private String ipAddress;
}


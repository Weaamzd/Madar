package com.RSADF.Murtakiz.modules.auth.infra.service;

import com.RSADF.Murtakiz.modules.auth.core.dto.AuthResponse;
import com.RSADF.Murtakiz.modules.auth.core.dto.LoginRequest;
import com.RSADF.Murtakiz.modules.auth.core.dto.UserSummary;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleRepository;
import com.RSADF.Murtakiz.modules.auth.jwt.ClaimsMapper;
import com.RSADF.Murtakiz.modules.auth.jwt.JwtProperties;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;


import com.RSADF.Murtakiz.modules.auth.core.dto.AuthResponse;
import com.RSADF.Murtakiz.modules.auth.core.dto.UserSummary;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;

import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;


import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.*;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final ClaimsMapper claimsMapper;
    private final JwtService jwtService;
    private final UserRoleRepository userRoleRepository;
    private final JwtProperties jwtProperties;
    private final LoginAttemptService attemptService;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       ClaimsMapper claimsMapper,
                       JwtService jwtService,
                       UserRoleRepository userRoleRepository,
                       JwtProperties jwtProperties,
                       LoginAttemptService attemptService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.claimsMapper = claimsMapper;
        this.jwtService = jwtService;
        this.userRoleRepository = userRoleRepository;
        this.jwtProperties = jwtProperties;
        this.attemptService = attemptService;
    }

    private static String norm(String s) { return s == null ? null : s.trim(); }


    @Transactional
    public AuthResponse login(LoginRequest req, HttpServletRequest request) {
        String username = norm(req.getUsername());
        String password = req.getPassword();

        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "username/password required");
        }

        if (attemptService.blocked(username)) {
            throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS, "Too many attempts");
        }

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> {
                    attemptService.onFailure(username);
                    return new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Bad credentials");
                });

        if (user.getStatus() != null && !"Active".equalsIgnoreCase(user.getStatus())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "User is not active");
        }

        if (user.getPasswordHash() == null || !passwordEncoder.matches(password, user.getPasswordHash())) {
            attemptService.onFailure(username);
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Bad credentials");
        }

        attemptService.onSuccess(username);


        Map<String, Object> claims = new HashMap<>(claimsMapper.toClaims(user));
        if (user.getId() != null) {
            claims.put("roles", userRoleRepository.findRoleNamesByUserId(user.getId()));
        }

        JwtService.AuthTokenDto token = jwtService.generateAccessTokenAndPersistSession(user, claims, request);

        user.setLastLoginAt(LocalDateTime.now());


        Instant expInstant = token.expiresAt().atZone(ZoneId.systemDefault()).toInstant();
        return new AuthResponse("Bearer", token.accessToken(), expInstant, token.jti());
    }


    @Transactional
    public AuthResponse loginWithoutRequest(LoginRequest req, String userAgent, String ipAddress) {
        User user = userRepository.findByUsername(req.getUsername())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (user.getPasswordHash() == null || !passwordEncoder.matches(req.getPassword(), user.getPasswordHash())) {
            throw new RuntimeException("Invalid credentials");
        }

        Map<String, Object> claims = claimsMapper.toClaims(user);
        if (user.getId() != null) {
            claims.put("roles", userRoleRepository.findRoleNamesByUserId(user.getId()));
        }

        JwtService.AuthTokenDto token = jwtService.generateAccessTokenAndPersistSession(user, claims, userAgent, ipAddress);

        Instant expInstant = token.expiresAt()
                .atZone(ZoneId.systemDefault())
                .toInstant();

        return new AuthResponse("Bearer", token.accessToken(), expInstant, token.jti());
    }


/*    public AuthResponse login1(LoginRequest req) {
        String username = req.getUsername();
        String rawPassword = req.getPassword();

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (user.getPasswordHash() == null || !passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
            throw new RuntimeException("Invalid credentials");
        }


        Map<String, Object> claims = claimsMapper.toClaims(user);

        // subject = username
        String token = jwtService.generateAccessToken(user.getUsername(), claims);


        //UserSummary summary = toSummary(user);

        Instant expiresAt = Instant.now().plusSeconds(jwtProperties.getAccessTokenMinutes() * 60);

        return new AuthResponse("Bearer", token, expiresAt);
    }*/

    private UserSummary toSummary(User u) {

        String empNo = null, fullName = null, email = null, jobTitle = null, regionCode = null, regionDbKey = null;

        if (u.getEmployee() != null) {

            try {
                empNo = String.valueOf(u.getEmployee().getEmpNo());
                fullName = u.getEmployee().getFullNameAr();
                email = u.getEmployee().getEmail();
                jobTitle = u.getEmployee().getJobTitle();
            } catch (Exception ignored) {}
        }

        if (u.getCurrentRegion() != null) {
            try {
                regionCode = u.getCurrentRegion().getRegionCode();
                regionDbKey = u.getCurrentRegion().getRegionDbKey();
            } catch (Exception ignored) {}
        }

        List<String> roles = Optional.ofNullable(userRoleRepository.findRoleNamesByUserId(u.getId()))
                .orElseGet(List::of);

        return new UserSummary(
                u.getId(),
                u.getUsername(),
                empNo,
                fullName,
                email,
                jobTitle,
                regionCode,
                regionDbKey,
                roles
        );
    }
}

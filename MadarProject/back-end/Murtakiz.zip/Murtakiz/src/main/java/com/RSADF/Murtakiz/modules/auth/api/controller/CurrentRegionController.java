package com.RSADF.Murtakiz.modules.auth.api.controller;


import com.RSADF.Murtakiz.modules.auth.core.dto.CurrentRegionDto;
import com.RSADF.Murtakiz.modules.auth.infra.service.CurrentRegionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/api/v1/murtakiz/org")
public class CurrentRegionController {

    private final CurrentRegionService svc;

    public CurrentRegionController(CurrentRegionService svc) {
        this.svc = svc;
    }



    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")
    @GetMapping("/unites/{uniteId}/current-region")
    public ResponseEntity<CurrentRegionDto> getCurrentRegion(@PathVariable Long uniteId) {
        return ResponseEntity.ok(svc.getCurrentRegionByUnite(uniteId));
    }
}

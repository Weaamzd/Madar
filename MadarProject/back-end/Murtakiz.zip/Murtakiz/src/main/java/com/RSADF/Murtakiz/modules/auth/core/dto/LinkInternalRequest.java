package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkInternalRequest {
    @NotBlank private String username;
    @NotBlank
    private String empNo;
    private String note;          // اختياري: سبب/ملاحظة
}
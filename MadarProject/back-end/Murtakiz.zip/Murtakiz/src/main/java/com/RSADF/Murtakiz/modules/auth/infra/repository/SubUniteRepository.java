package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubUniteRepository extends JpaRepository<SubUnite, Long> {


    @Query("""
    select e
    from Employee e
    left join fetch e.subUnite su
    where e.empNo = :empNo
""")
    Optional<Employee> findByIdWithSubUnite(@Param("empNo") String empNo);


    List<SubUnite> findByIdIn(Collection<Long> ids);


    List<SubUnite> findByUnite_IdAndParentIsNull(Long uniteId);


    List<SubUnite> findByParent_Id(Long parentSubUniteId);


    boolean existsByParent_Id(Long parentSubUniteId);


    List<SubUnite> findByParent_IdIn(Collection<Long> parentIds);


    @Query("""
           select s
           from SubUnite s
           left join fetch s.parent p
           left join fetch s.uniteType t
           left join fetch s.unite u
           where u.id = :uniteId
           """)
    List<SubUnite> findAllByUniteIdWithJoins(@Param("uniteId") Long uniteId);


    // List<SubUnite> findByUnite_Id(Long uniteId);





}
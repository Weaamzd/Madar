package com.RSADF.Murtakiz.modules.auth.core.dto;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;

import java.time.LocalDateTime;


public record DelegationFullDetailsDto(
        Long delegationId,
        DelegationStatus status,
        DelegationScopeType scopeType,

        Boolean requireAcceptance,
        Boolean allowSubdelegate,
        Boolean noExpiry,

        LocalDateTime startAt,
        LocalDateTime endAt,
        LocalDateTime createdAt,

        // حالة الوقت
        Boolean activeNow,     // فعّال الآن (status ACTIVE && ضمن نافذة الزمن)
        Boolean withinWindow,  // فقط ضمن نافذة الزمن

        // الأشخاص
        String delegatorEmpNo,
        String delegatorUsername,
        String delegatorFullNameAr,

        String delegateeEmpNo,
        String delegateeUsername,
        String delegateeFullNameAr,

        String createdByEmpNo,
        String createdByUsername,
        String createdByFullNameAr,

        // معلومات القبول (لو تستخدمها)
        LocalDateTime acceptedAt,
        String acceptedByEmpNo,
        String acceptedByUsername,
        String acceptedByFullNameAr,

        // ملخص صلاحيات التفويض
        Long actionsMaskAggregated,           // OR لجميع السكوبات
        java.util.List<String> actionsAll,    // أسماء الأفعال المجمعة بدون تكرار

        // إحصائيات جلسات التمثيل
        Long activeSessionsCount,
        Long totalSessionsCount,

        // السكوبات التفصيلية
        java.util.List<DelegationScopeDtoFull> scopes
) {}

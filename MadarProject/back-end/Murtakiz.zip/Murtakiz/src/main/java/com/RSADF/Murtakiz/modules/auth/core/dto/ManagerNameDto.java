package com.RSADF.Murtakiz.modules.auth.core.dto;


import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class ManagerNameDto {
    private String empNo;        // رقم الموظف (المدير)
    private String fullNameAr;   // الاسم العربي
}

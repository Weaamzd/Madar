package com.RSADF.Murtakiz.modules.kpi.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
        name = "KPI_INITIATIVE",
        schema = "SYS"   // غيّريها لو الجدول في سكيمة ثانية
)
@Getter
@Setter
@NoArgsConstructor
public class KpiInitiative {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "INITIATIVE_ID")
    private Long id;

    @Column(name = "INITIATIVE_CODE", nullable = false, length = 50, unique = true)
    private String initiativeCode;

    @Column(name = "INITIATIVE_NAME_AR", nullable = false, length = 300)
    private String nameAr;

    @Column(name = "INITIATIVE_DESC_AR", length = 1000)
    private String descAr;


    @Column(name = "INITIATIVE_TYPE", nullable = false, length = 20)
    private String initiativeType;

    @Column(name = "GOAL_CODE", length = 50)
    private String goalCode;

    @Column(name = "OWNER_EMP_NO", length = 50)
    private String ownerEmpNo;

    @Column(name = "OWNER_UNITE_ID")
    private Long ownerUniteId;

    @Column(name = "OWNER_SUB_UNITE_ID")
    private Long ownerSubUniteId;


    @Column(name = "START_DATE")
    private LocalDate startDate;

    @Column(name = "TARGET_END_DATE")
    private LocalDate targetEndDate;

    @Column(name = "ACTUAL_END_DATE")
    private LocalDate actualEndDate;

    // PLANNED / ONGOING / COMPLETED / ON_HOLD / CANCELLED
    @Column(name = "STATUS_CODE", length = 20)
    private String statusCode;

    @Column(name = "PROGRESS_PCT", precision = 5, scale = 2)
    private BigDecimal progressPct;


    @Column(name = "BUDGET_AMOUNT", precision = 18, scale = 4)
    private BigDecimal budgetAmount;

    @Column(name = "ACTUAL_COST", precision = 18, scale = 4)
    private BigDecimal actualCost;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "CREATED_BY_EMP_NO", length = 50)
    private String createdByEmpNo;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "UPDATED_BY_EMP_NO", length = 50)
    private String updatedByEmpNo;

}

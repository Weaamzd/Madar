package com.RSADF.Murtakiz.modules.auth.api.controller;
import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.entity.UserRegistrationRequest;
import com.RSADF.Murtakiz.modules.auth.infra.service.UserAdminService;
import com.RSADF.Murtakiz.modules.auth.infra.service.UserDirectoryFacade;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/v1/murtakiz/admin/users")
//@PreAuthorize("hasRole('" + SYSTEM_ADMIN + "')")
public class UserAdminController {

    private final UserAdminService userAdminService;
    private final UserDirectoryFacade userDirectoryFacade;

    public UserAdminController(UserAdminService userAdminService,
                               UserDirectoryFacade userDirectoryFacade) {
        this.userAdminService = userAdminService;
        this.userDirectoryFacade = userDirectoryFacade;
    }

    //@PreAuthorize("hasRole('SYSTEM_ADMIN')")
    @PreAuthorize("isAuthenticated()")
    @PostMapping
    public ResponseEntity<UserSummaryDto> create(@Valid @RequestBody CreateUserRequest req) {
        UserSummaryDto result = userAdminService.createUser(req);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/create-users")
    public ResponseEntity<UserSummaryDto> createUser(@Valid @RequestBody CreateUserRequest dto) {


        String adminEmpNo = null;
        UserSummaryDto summary = userAdminService.createUserWithRegistration(dto, adminEmpNo);
        return ResponseEntity.ok(summary);
    }


    //@PreAuthorize("hasRole('SYSTEM_ADMIN')")
    @PreAuthorize("isAuthenticated()")
    @PatchMapping("/toggle-status")
    public ResponseEntity<UserStatusResult> toggleByEmpNo(
            @RequestParam String empNo,
            @RequestParam(defaultValue = "true") boolean revokeAllSessions
    ) {
        return ResponseEntity.ok(userAdminService.toggleStatusByEmpNo(empNo, revokeAllSessions));
    }

    @PatchMapping("/toggle-status/by-username")
    @PreAuthorize("isAuthenticated()")

    public ResponseEntity<UserStatusResult> toggleByUsername(
            @RequestParam String username,
            @RequestParam(defaultValue = "true") boolean revokeAllSessions) {

        return ResponseEntity.ok(
                userAdminService.toggleStatusByUsername(username, revokeAllSessions)
        );
    }




    @PutMapping("/update")
    public ResponseEntity<UserSummaryDto> update(@Valid @RequestBody CreateUserRequest req) {
        return ResponseEntity.ok(userAdminService.updateUser(req));
    }

    @GetMapping("/precheck")
    public ResponseEntity<UserEmployeePrecheckDto> precheck(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String empNo
    ) {
        var dto = userDirectoryFacade.precheck(username, empNo);
        return ResponseEntity.ok(dto);
    }


    @PatchMapping("/link/internal/by-empno")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> linkInternalByEmpNo(
            @Valid @RequestBody LinkInternalByEmpNoUsernameRequest req,
            Authentication auth) {
        String actorEmpNo = null;
        userAdminService.linkInternalByEmpNoUsername(req, actorEmpNo);
        return ResponseEntity.ok().build();
    }

    @PatchMapping("/link/external/by-extid")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> linkExternalByExtId(
            @Valid @RequestBody LinkExternalByExtIdUsernameRequest req,
            Authentication auth) {
        String actorEmpNo = null;
        userAdminService.linkExternalByExtIdUsername(req, actorEmpNo);
        return ResponseEntity.ok().build();
    }




    @PatchMapping("/unlink/by-username")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> unlinkByUsername(
            @Valid @RequestBody UnlinkByUsernameRequest req,
            Authentication auth) {

        String actorEmpNo = null;
        userAdminService.unlinkAllByUsername(req, actorEmpNo);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/precheck/empno")
    public ResponseEntity<?> precheckCandidateByEmpNo(@RequestParam String empNo) {
        var candidate = userAdminService.precheckCandidateByEmpNo(empNo);
        return candidate.<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.noContent().build());
    }
    @PostMapping("/create-for-existing-employee")
    public ResponseEntity<UserSummaryDto> createForExistingEmployee(
            @Valid @RequestBody CreateUserForExistingEmployeeRequest req) {
        var result = userAdminService.createUserForEmployeeIfNoUser(req);
        return ResponseEntity.ok(result);
    }


    @PostMapping("/create-for-existing-emp")
    public ResponseEntity<UserSummaryDto> createForExistingEmp(
            @Valid @RequestBody CreateUserForExistingEmployeeRequest req) {


        String adminEmpNo = null;
        var result = userAdminService.createUserForEmployee(req, adminEmpNo);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/registration/{requestId}/approve-admin")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> approveAdminRegistration(
            @PathVariable Long requestId,
            @RequestParam boolean approved,
            @RequestParam(required = false) String notes,
            Authentication auth) {

        String adminEmpNo = null;

        userAdminService.approveAdminRegistration(requestId, approved, notes, adminEmpNo);
        return ResponseEntity.ok().build();
    }


    /*@PostMapping("/registration/user-terms/approve")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Void> approveUserTerms(Authentication auth) {


        Long userId = null;

        userAdminService.approveUserTerms(userId);
        return ResponseEntity.ok().build();
    }*/

    @PostMapping("/registration/user-terms/approve")
    public ResponseEntity<Void> approveUserTerms(@RequestParam String username) {
        userAdminService.approveUserTermsByUsername(username);
        return ResponseEntity.ok().build();
    }


    @GetMapping("/registration-requests/search")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Page<UserRegistrationRequestSummaryDto>> searchRegistrationRequests(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String stageStatus,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        Page<UserRegistrationRequestSummaryDto> result = userAdminService.searchRegistrationRequests(
                username,
                stageStatus,
                null,
                null,
                page,
                size
        );
        return ResponseEntity.ok(result);
    }

    @GetMapping("/registration-requests/search-scope")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<Page<UserRegistrationRequestSummaryDto>> searchRegistrationRequestsByOrgScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String stageStatus,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        Page<UserRegistrationRequestSummaryDto> result = userAdminService.listRegistrationRequestsByOrgScope(
                uniteId,
                subUniteId,
                username,
                stageStatus,
                page,
                size
        );
        return ResponseEntity.ok(result);
    }


    @GetMapping("/registration-requests/my-by-username")
    public ResponseEntity<List<UserRegistrationRequestSummaryDto>> listMyRegistrationRequestsByUsername(
            @RequestParam String username
    ) {
        List<UserRegistrationRequestSummaryDto> result =
                userAdminService.listMyRegistrationRequestsByUsername(username);

        return ResponseEntity.ok(result);
    }




    @GetMapping("/registration-requests/my")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<UserRegistrationRequestSummaryDto>> listMyRegistrationRequests(Authentication auth) {


        String username = auth.getName();

        List<UserRegistrationRequestSummaryDto> result =
                userAdminService.listMyRegistrationRequestsByUsername(username);

        return ResponseEntity.ok(result);
    }











}

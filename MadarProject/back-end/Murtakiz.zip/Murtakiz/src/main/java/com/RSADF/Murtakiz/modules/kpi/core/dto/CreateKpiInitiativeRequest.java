package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreateKpiInitiativeRequest {


    private String initiativeCode;
    private String nameAr;
    private String descAr;
    private String initiativeType;    // PLANNED / CORRECTIVE


    private String goalCode;


    private String ownerEmpNo;
    private Long ownerUniteId;
    private Long ownerSubUniteId;


    private LocalDate startDate;
    private LocalDate targetEndDate;
    private Double budgetAmount;

    private String kpiCode;
    private String linkType;          // PRIMARY / CORRECTIVE / SUPPORT
}

package com.RSADF.Murtakiz.modules.kpi.api.controller;

import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiInitiativeRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiInitiativeDto;
import com.RSADF.Murtakiz.modules.kpi.infra.service.KpiInitiativeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/murtakiz/kpi/initiatives")
@RequiredArgsConstructor
public class KpiInitiativeController {

    private final KpiInitiativeService initiativeService;

    @GetMapping("/kpi/{kpiCode}")
    public ResponseEntity<List<KpiInitiativeDto>> listByKpi(
            @PathVariable String kpiCode
    ) {
        List<KpiInitiativeDto> result =
                initiativeService.getInitiativesByKpiCode(kpiCode);

        return ResponseEntity.ok(result);
    }


    @PostMapping("/create-and-link")
    public ResponseEntity<KpiInitiativeDto> createInitiativeAndLink(
            @RequestBody CreateKpiInitiativeRequest request
    ) {
        String actorEmpNo = SecurityUtils.actorEmpNo();
        String ctxEmpNo   = SecurityUtils.ctxEmpNo();

        if (actorEmpNo == null) {
            throw new AccessDeniedException("لا يمكن تحديد رقم الموظف من التوكن (actorEmpNo = null)");
        }

        KpiInitiativeDto dto =
                initiativeService.createInitiativeAndLinkToKpi(request, actorEmpNo, ctxEmpNo);

        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }
}

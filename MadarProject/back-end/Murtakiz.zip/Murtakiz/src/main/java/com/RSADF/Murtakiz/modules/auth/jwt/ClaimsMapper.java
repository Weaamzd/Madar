package com.RSADF.Murtakiz.modules.auth.jwt;


import com.RSADF.Murtakiz.modules.auth.core.entity.Role;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.RoleRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleRepository;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class ClaimsMapper {

    private final UserRoleRepository userRoleRepository;

    public ClaimsMapper(UserRoleRepository userRoleRepository) {
        this.userRoleRepository = userRoleRepository;
    }

    public Map<String, Object> toClaims(User user) {
        List<String> roleNames = Optional
                .ofNullable(userRoleRepository.findRoleNamesByUserId(user.getId()))
                .orElseGet(List::of)
                .stream().distinct().toList();

        Map<String, Object> claims = new HashMap<>();
        claims.put("roles", roleNames);


        boolean enabled = user.getStatus() != null && user.getStatus().equalsIgnoreCase("Active");
        claims.put("enabled", enabled);


        if (user.getCurrentRegion() != null) {
            claims.put("regionId", user.getCurrentRegion().getId());
        }

        // ====== داخلي أم خارجي؟ ======
        boolean isExternal = user.getExternalEmployee() != null;
        claims.put("is_external", isExternal);

        if (isExternal) {
            var ext = user.getExternalEmployee();
            claims.put("ext_emp_id", ext.getId());
            claims.put("display_name", safe(ext.getFullNameAr(), ext.getFullNameEn(), user.getUsername()));
            if (ext.getEmail() != null) claims.put("email", ext.getEmail());

        } else {

            if (user.getEmployee() != null) {
                claims.put("empNo", user.getEmployee().getEmpNo());
                claims.put("display_name", safe(user.getEmployee().getFullNameAr(), user.getUsername()));
                if (user.getEmployee().getEmail() != null) claims.put("email", user.getEmployee().getEmail());
            } else {

                claims.put("display_name", user.getUsername());
            }
        }

        return claims;
    }

    private static String safe(String... candidates) {
        for (String c : candidates) {
            if (c != null && !c.isBlank()) return c;
        }
        return "";
    }
}

package com.RSADF.Murtakiz.modules.auth.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.Enums.BooleanToNumberConverter;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Set;
@Entity
@Table(
        name = "SECURITY_DELEGATION",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_DELEG__A_EMP",   columnList = "DELEGATOR_EMP_NO"),
                @Index(name = "IX_DELEG__B_EMP",   columnList = "DELEGATEE_EMP_NO"),
                @Index(name = "IX_DELEG__STATUS",  columnList = "STATUS"),
                @Index(name = "IX_DELEG__DATES",   columnList = "START_AT, END_AT")
        }
)
@Getter @Setter @NoArgsConstructor
public class SecurityDelegation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DELEGATION_ID")
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATOR_EMP_NO", referencedColumnName = "EMP_NO", nullable = false)
    private User delegatorUser;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATEE_EMP_NO", referencedColumnName = "EMP_NO", nullable = false)
    private User delegateeUser;

    @Enumerated(EnumType.STRING)
    @Column(name = "SCOPE_TYPE", nullable = false, length = 20)  // ALL | LIMITED
    private DelegationScopeType scopeType;

    @Column(name = "REQUIRE_ACCEPTANCE", nullable = false)
    private Boolean requireAcceptance = false;

    @Column(name = "ALLOW_SUBDELEGATE", nullable = false)
    private Boolean allowSubdelegate = false;

    @Column(name = "START_AT", nullable = false)
    private LocalDateTime startAt;

    @Column(name = "END_AT")
    private LocalDateTime endAt;

    @Column(name = "NO_EXPIRY", nullable = false)
    private Boolean noExpiry = false;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)  // PENDING | ACTIVE | REJECTED | REVOKED | EXPIRED
    private DelegationStatus status;

    @Column(name = "ACCEPTED_AT")
    private LocalDateTime acceptedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACCEPTED_BY_EMP_NO", referencedColumnName = "EMP_NO")
    private User acceptedByUser;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CREATED_BY_EMP_NO", referencedColumnName = "EMP_NO", nullable = false)
    private User createdByUser;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}



/*
package com.RSADF.Murtakiz.modules.auth.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.HashSet;

@Entity
@Table(
        name = "SECURITY_DELEGATION",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_DELEGATION__A",      columnList = "DELEGATOR_USER_ID"),
                @Index(name = "IX_DELEGATION__B",      columnList = "DELEGATEE_USER_ID"),
                @Index(name = "IX_DELEGATION__STATUS", columnList = "STATUS"),
                @Index(name = "IX_DELEGATION__ENDAT",  columnList = "END_AT")
        }
)
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class SecurityDelegation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DELEGATION_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATOR_USER_ID", nullable = false)
    private User delegator;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATEE_USER_ID", nullable = false)
    private User delegatee;

    @Enumerated(EnumType.STRING)
    @Column(name = "SCOPE_TYPE", nullable = false, length = 20)
    private DelegationScopeType scopeType;


    @Column(name = "REQUIRE_ACCEPTANCE", nullable = false)
    private Boolean requireAcceptance = Boolean.FALSE;

    @Column(name = "ALLOW_SUBDELEGATE", nullable = false)
    private Boolean allowSubdelegate = Boolean.FALSE;

    @Column(name = "START_AT", nullable = false)
    private LocalDateTime startAt;

    @Column(name = "END_AT", nullable = false)
    private LocalDateTime endAt;

    @Enumerated(EnumType.STRING)
    @Column(name = "STATUS", nullable = false, length = 20)
    private DelegationStatus status;

    @Column(name = "ACCEPTED_AT")
    private LocalDateTime acceptedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ACCEPTED_BY")
    private User acceptedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CREATED_BY")
    private User createdBy;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    */
/*@OneToMany(mappedBy = "delegation", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<SecurityDelegationScope> scopes = new HashSet<>();*//*

}*/

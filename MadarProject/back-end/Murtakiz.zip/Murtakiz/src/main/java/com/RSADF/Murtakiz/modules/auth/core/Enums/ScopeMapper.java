package com.RSADF.Murtakiz.modules.auth.core.Enums;


public final class ScopeMapper {
    public static DelegationScopeType map(BusinessScopeType b) {
        return switch (b) {
            case DEPT_FULL    -> DelegationScopeType.ALL;
            case UNIT_LIMITED -> DelegationScopeType.LIMITED;
        };
    }
}

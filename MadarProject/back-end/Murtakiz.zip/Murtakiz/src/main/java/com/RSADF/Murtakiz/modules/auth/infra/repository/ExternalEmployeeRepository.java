package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.ExternalEmployee;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface ExternalEmployeeRepository extends JpaRepository<ExternalEmployee, String> {
    Optional<ExternalEmployee> findByEmail(String email);


    @Query("""
    select ee
    from ExternalEmployee ee
    left join fetch ee.subUniteId su
    left join fetch su.unite u
    where ( (:uniteId is not null and su.unite.id = :uniteId)
         or (:subUniteId is not null and su.id    = :subUniteId) )
      and (:extEmpId     is null or ee.id like concat(:extEmpId, '%'))
      and (:fullNameAr   is null or lower(ee.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
      and (:uniteName    is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
      and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
      and (:managerNo    is null or ee.empManagerNo.empNo = :managerNo)
    order by ee.id
    """)
    List<ExternalEmployee> findByOrgScopeWithTextFiltersAndManager(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("extEmpId") String extEmpId,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName,
            @Param("managerNo") String managerNo
    );


    @Query("""
    select ee
    from ExternalEmployee ee
    left join fetch ee.subUniteId su
    left join fetch su.unite u
    where ee.id = :extEmpId
""")
    Optional<ExternalEmployee> findOneWithOrgById(@Param("extEmpId") String extEmpId);


    @Query("""
    select u
    from User u
    left join fetch u.employee e
    left join fetch u.externalEmployee xe
    left join fetch u.currentRegion cr
    where (:username   is null or lower(u.username) like lower(concat('%', :username, '%')))
      and (:status     is null or lower(u.status) = lower(:status))
      and (
            (:linkedState is null or upper(:linkedState) = 'ALL')
         or (upper(:linkedState) = 'UNLINKED' and u.empNo is null and u.externalEmpId is null)
         or (upper(:linkedState) = 'LINKED'   and (u.empNo is not null or u.externalEmpId is not null))
      )
    order by u.id
""")
    List<User> findAllByFiltersWithRegion(
            @Param("username") String username,
            @Param("status")   String status,
            @Param("linkedState") String linkedState
    );

    List<ExternalEmployee> findByIdIn(Collection<String> ids);

    @Query("""
        select ee
        from ExternalEmployee ee
        left join fetch ee.subUniteId su
        left join fetch su.unite u
        where not exists (
            select 1 from User x where x.externalEmpId = ee.id
        )
        and (:extEmpId     is null or ee.id like concat(:extEmpId, '%'))
        and (:fullNameAr   is null or lower(ee.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
        and (:uniteName    is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
        and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
        order by ee.id
    """)
    List<ExternalEmployee> findExternalWithoutUserWithOrgFiltered(
            @Param("extEmpId") String extEmpId,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );

    @Query("""
        select ee
        from ExternalEmployee ee
        left join fetch ee.subUniteId su
        left join fetch su.unite u
    """)
    List<ExternalEmployee> findAllWithOrg();

    @Query("""
        select ee
        from ExternalEmployee ee
        left join fetch ee.subUniteId su
        left join fetch su.unite u
        where ( (:uniteId    is not null and u.id = :uniteId)
             or (:subUniteId is not null and su.id = :subUniteId) )
          and (:extEmpId    is null or ee.id like concat(:extEmpId, '%'))
          and (:fullNameAr  is null or lower(ee.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
          and (:uniteName   is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
          and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
        order by ee.id
    """)
    List<ExternalEmployee> findByOrgScopeWithTextFilters(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("extEmpId") String extEmpId,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );

    @Query("""
        select ee
        from ExternalEmployee ee
        left join fetch ee.subUniteId su
        left join fetch su.unite u
        where (:extEmpId    is null or ee.id like concat(:extEmpId, '%'))
          and (:fullNameAr  is null or lower(ee.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
          and (:uniteName   is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
          and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
        order by ee.id
    """)
    List<ExternalEmployee> findAllWithOrgFiltered(
            @Param("extEmpId") String extEmpId,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );


    @Query("""
    select u
    from User u
    left join fetch u.currentRegion cr
    where u.externalEmpId in :extIds
""")
    List<User> findAllByExternalEmpIdInWithRegion(@Param("extIds") Collection<String> extIds);


    @Query("""
        select ee
        from ExternalEmployee ee
        left join fetch ee.subUniteId su
        left join fetch su.unite u
        where not exists (
            select 1 from User usr where usr.externalEmpId = ee.id
        )
        and (
              (:subUniteId is not null and su.id = :subUniteId)
           or (:uniteId    is not null and u.id  = :uniteId)
        )
        and (:q is null or lower(ee.id) like lower(concat('%', :q, '%')) or lower(ee.fullNameAr) like lower(concat('%', :q, '%')))
        and (:fullNameAr is null or lower(ee.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
        order by ee.id
    """)
    List<ExternalEmployee> findExternalWithoutUserInScope(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("q") String q,
            @Param("fullNameAr") String fullNameAr
    );

}


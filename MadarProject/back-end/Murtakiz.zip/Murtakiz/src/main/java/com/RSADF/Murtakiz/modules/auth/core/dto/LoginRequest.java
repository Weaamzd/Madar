package com.RSADF.Murtakiz.modules.auth.core.dto;


import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter
public class LoginRequest {
/*    private String username;
    private String password;*/

    @NotBlank String username;
    @NotBlank String password;
}

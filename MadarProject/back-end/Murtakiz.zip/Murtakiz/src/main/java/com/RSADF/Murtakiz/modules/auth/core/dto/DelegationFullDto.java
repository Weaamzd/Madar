package com.RSADF.Murtakiz.modules.auth.core.dto;


import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;

import java.time.LocalDateTime;
import java.util.List;

public record DelegationFullDto(
        Long delegationId,
        DelegationStatus status,
        LocalDateTime startAt,
        LocalDateTime endAt,
        Boolean noExpiry,
        Boolean requireAcceptance,
        Boolean allowSubdelegate,
        DelegationScopeType scopeType,

        Long actionsMaskAggregated,            // OR لكل السكوبات (ALL_MASK إن صفر)
        List<DelegationScopeDto> scopes,       // تفاصيل السكوبات

        String delegatorEmpNo,
        String delegatorUsername,
        String delegateeEmpNo,
        String delegateeUsername,

        LocalDateTime createdAt,
        String createdByEmpNo,

        Boolean activeNow,                     // now ضمن نافذة التفويض
        Long activeSessionsCount               // جلسات تمثيل نشطة على هذا التفويض
) {}

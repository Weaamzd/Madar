package com.RSADF.Murtakiz.modules.auth.api.controller;


import com.RSADF.Murtakiz.OnBehalfAuthentication;
import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.auth.core.dto.UserFullProfileDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.UserSummary;
import com.RSADF.Murtakiz.modules.auth.infra.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/murtakiz/auth")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

/*
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/me")
    public ResponseEntity<UserSummary> me(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String empNo = null;


        if (authentication instanceof OnBehalfAuthentication) {
            empNo = Optional.ofNullable(SecurityUtils.ctxEmpNo())
                    .orElse(SecurityUtils.actorEmpNo());
        }


        if (empNo == null) {
            @SuppressWarnings("unchecked")
            Map<String, Object> details = (Map<String, Object>) authentication.getDetails();
            if (details != null && details.get("empNo") != null) {
                empNo = String.valueOf(details.get("empNo"));
            }
        }

        if (empNo == null || empNo.isBlank()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return userService.getProfileByEmpNo(empNo)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    */


    @PreAuthorize("isAuthenticated()")
    @GetMapping("/me")
    public ResponseEntity<UserFullProfileDto> me(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String username = authentication.getName();

        return userService.getFullProfileByUsername(username)
                .map(ResponseEntity::ok)

                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());

        // .orElseGet(() -> ResponseEntity.ok(minimal(username, authentication)));
    }

/*    @GetMapping("/me")
    public ResponseEntity<UserSummary> me(Authentication authentication) {
        if (authentication == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> details = (Map<String, Object>) authentication.getDetails();

        if (details == null || details.get("empNo") == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        String empNo = details.get("empNo").toString();

        Optional<UserSummary> summaryOpt = userService.getProfileByEmpNo(empNo);
        return summaryOpt
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }*/
}

package com.RSADF.Murtakiz.modules.auth.api.controller;

import com.RSADF.Murtakiz.modules.auth.core.dto.CreateExternalUserRequest;
import com.RSADF.Murtakiz.modules.auth.core.dto.ExternalUserSummaryDto;
import com.RSADF.Murtakiz.modules.auth.infra.service.UserAdminService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/murtakiz/admin/external-users")
@PreAuthorize("isAuthenticated()")
public class ExternalUserAdminController {

    private final UserAdminService userAdminService;

    public ExternalUserAdminController(UserAdminService userAdminService) {
        this.userAdminService = userAdminService;
    }

    @PostMapping
    public ResponseEntity<ExternalUserSummaryDto> createExternal(@Valid @RequestBody CreateExternalUserRequest req) {
        ExternalUserSummaryDto result = userAdminService.createExternalUser(req);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }


    @PostMapping("/with-registration")
    public ResponseEntity<ExternalUserSummaryDto> createExternalWithRegistration(
            @Valid @RequestBody CreateExternalUserRequest req) {


        String adminEmpNo = null;

        ExternalUserSummaryDto result =
                userAdminService.createExternalUserWithRegistration(req, adminEmpNo);

        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }
}

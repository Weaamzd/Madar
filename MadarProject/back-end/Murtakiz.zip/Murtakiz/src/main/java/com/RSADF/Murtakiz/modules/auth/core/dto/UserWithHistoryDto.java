package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;


@Builder @Getter @Setter
public class UserWithHistoryDto {
    private Long userId;
    private String username;
    private String status;
    private LocalDateTime lastLoginAt;

    // ربط حالي:
    private String empNo;          // للداخلي (إن وُجد)
    private String empFullNameAr;  // من Employee
    private String externalEmpId;  // للخارجي (إن وُجد)
    private String externalFullNameAr; // من ExternalEmployee (إن احتجتها)
    private String email;
    private String jobTitle;

    // المنطقة الحالية:
    private Long currentRegionId;
    private String regionCode;
    private String regionDbKey;

    // أدوار + جلسات:
    private List<String> roles;
    private boolean loggedIn;

    // الهستوري الكامل:
    private List<UserLinkEventDto> linkHistory;
}


package com.RSADF.Murtakiz.modules.auth.core.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "JWT_BLACKLIST", schema = "SYS",
        indexes = @Index(name = "IX_JWT_BLACKLIST_JTI", columnList = "JTI"))
@Getter
@Setter
@NoArgsConstructor
public class JwtBlacklist {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "TOKEN_HASH", nullable = false, unique = true, length = 64)
    private String tokenHash;

    @Column(name = "JTI", length = 64)
    private String jti;

    @Column(name = "SUBJECT", length = 200)
    private String subject;

    @Column(name = "EXPIRES_AT")
    private LocalDateTime expiresAt;

    @Column(name = "REVOKED_AT", nullable = false)
    private LocalDateTime revokedAt;

    @Column(name = "REASON", length = 100)
    private String reason;

    @Column(name = "USER_AGENT", length = 200)
    private String userAgent;

    @Column(name = "IP_ADDRESS", length = 50)
    private String ipAddress;
}

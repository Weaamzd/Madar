package com.RSADF.Murtakiz.modules.auth.core.dto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CreateExternalUserRequest {

    @NotBlank
    private String username;

    @NotBlank
    private String password;

    private String status;

    private Long currentRegionId;

    @NotBlank
    private String extEmpId;

    @NotBlank
    private String fullNameAr;

    private String fullNameEn;

    @Email
    private String email;

    private String phone;

    @NotBlank
    private String organizationName;

    private String jobTitle;

    @NotBlank
    private String collaborationType;

    @NotNull
    private LocalDate startDate;

    private LocalDate endDate;

    private String notes;

    private String managerEmpNo;

    @NotNull
    private Long subUniteId;

    @NotEmpty
    private List<String> rolesNames;

    // عدد الأيام المسموحة قبل التعطيل (اختياري)
    private Integer allowedDays;

    // وقت إنشاء الطلب/المستخدم (اختياري من الواجهة – وغالبًا ستتجاهلينه في السيرفس وتستخدمين now())
    private LocalDateTime createdAt;
}

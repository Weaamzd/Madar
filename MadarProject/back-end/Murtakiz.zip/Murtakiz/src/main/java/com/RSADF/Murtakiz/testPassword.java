package com.RSADF.Murtakiz;


import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class testPassword {

    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private UserRepository userRepository;
    @Autowired private org.springframework.jdbc.core.JdbcTemplate jdbcTemplate;

    public void encryptPasswordIfPlainText() {

        Integer cnt = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM all_tables WHERE owner = 'SYS' AND table_name = 'USERS'", Integer.class);
        if (cnt == null || cnt == 0) {
            System.out.println("⚠️ Table USERS غير موجود في الـ schema الحالي. تمّ تخطي عملية التشفير.");
            return;
        }

        String username = "abdulaziz.ghamdi";
        userRepository.findByUsername(username).ifPresent(user -> {
            String rawPassword = user.getPasswordHash();
            if (rawPassword == null) return;
            if (!rawPassword.startsWith("$2")) {
                String encoded = passwordEncoder.encode(rawPassword);
                user.setPasswordHash(encoded);
                userRepository.save(user);
                System.out.println("✅ تم تشفير كلمة المرور للمستخدم: " + username);
            } else {
                System.out.println("ℹ️ كلمة المرور مشفّرة مسبقًا للمستخدم: " + username);
            }
        });
    }
}







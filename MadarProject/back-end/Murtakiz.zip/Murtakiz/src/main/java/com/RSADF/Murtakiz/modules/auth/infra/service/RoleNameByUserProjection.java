package com.RSADF.Murtakiz.modules.auth.infra.service;

public interface RoleNameByUserProjection {
    Long getUserId();
    String getRoleName();
}
package com.RSADF.Murtakiz.modules.auth.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.Enums.BooleanToNumberConverter;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "SECURITY_DELEGATION_SESSION",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_SDS__DELEG",   columnList = "DELEGATION_ID"),
                @Index(name = "IX_SDS__JTI",     columnList = "TOKEN_JTI"),
                @Index(name = "IX_SDS__ACTIVE",  columnList = "IS_ACTIVE, ACT_START_AT"),
                @Index(name = "IX_SDS__ACTOR",   columnList = "ACTOR_EMP_NO"),
                @Index(name = "IX_SDS__OBEHALF", columnList = "ON_BEHALF_EMP_NO")
        }
)
@Getter @Setter @NoArgsConstructor
public class SecurityDelegationSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SESSION_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATION_ID", nullable = false)
    private SecurityDelegation delegation;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ACTOR_EMP_NO", referencedColumnName = "EMP_NO", nullable = false)
    private User actor;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ON_BEHALF_EMP_NO", referencedColumnName = "EMP_NO", nullable = false)
    private User onBehalf;

    @Column(name = "ACT_START_AT", nullable = false)
    private LocalDateTime actStartAt;

    @Column(name = "ACT_END_AT")
    private LocalDateTime actEndAt;

    @Column(name = "TOKEN_JTI", length = 64)
    private String tokenJti;

    @Column(name = "USER_AGENT", length = 200)
    private String userAgent;

    @Column(name = "IP_ADDRESS", length = 50)
    private String ipAddress;

    @Convert(converter = BooleanToNumberConverter.class)
    @Column(name = "IS_ACTIVE", nullable = false)
    private Boolean active = Boolean.TRUE;
}


/*
package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "SECURITY_DELEGATION_SESSION",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_DELEG_SESS__DELEG", columnList = "DELEGATION_ID"),
                @Index(name = "IX_DELEG_SESS__JTI",   columnList = "TOKEN_JTI")
        }
)
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class SecurityDelegationSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SESSION_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATION_ID", nullable = false)
    private SecurityDelegation delegation;

    @Column(name = "ACT_START_AT", nullable = false)
    private LocalDateTime actStartAt;

    @Column(name = "ACT_END_AT")
    private LocalDateTime actEndAt;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "STARTED_BY_USER", nullable = false)
    private User startedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ENDED_BY_USER")
    private User endedBy;

    @Column(name = "TOKEN_JTI", length = 64)
    private String tokenJti;

    @Column(name = "USER_AGENT", length = 200)
    private String userAgent;

    @Column(name = "IP_ADDRESS", length = 50)
    private String ipAddress;

    @Column(name = "IS_ACTIVE", nullable = false)
    private Boolean active = Boolean.TRUE;
}*/

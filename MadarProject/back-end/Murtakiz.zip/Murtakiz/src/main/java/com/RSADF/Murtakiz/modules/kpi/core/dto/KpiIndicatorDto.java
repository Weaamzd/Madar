package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class KpiIndicatorDto {

    private Long id;
    private String code;
    private String nameAr;
    private String descAr;

    private String goalCode;
    private String perspectiveCode;

    private String ownerEmpNo;
    private Long ownerUniteId;
    private Long ownerSubUniteId;

    private String targetSource;
    private String meansToAchieveTarget;

    private BigDecimal targetValue;
    private BigDecimal baselineValue;
    private String measurementUnit;

    private String polarityCode;
    private String measurementMethod;
    private String formulaText;

    private String frequencyCode;

    private String currentStatus;
    private LocalDate lastUpdateDate;

    private String isMain;
    private String parentKpiCode;

    private String isActive;

    private LocalDateTime createdAt;
    private String createdByEmpNo;
    private LocalDateTime updatedAt;
    private String updatedByEmpNo;
}


package com.RSADF.Murtakiz.modules.kpi.infra.service;

import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiIndicatorReadingRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorReadingDto;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicator;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorReading;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiStrategicGoal;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorReadingRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiStrategicGoalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class KpiIndicatorReadingService {

    private final KpiIndicatorRepository indicatorRepository;
    private final KpiIndicatorReadingRepository readingRepository;
    private final KpiStrategicGoalRepository goalRepository;

    @Transactional
    public KpiIndicatorReadingDto createReading(
            CreateKpiIndicatorReadingRequest request,
            String actorEmpNo,
            String ctxEmpNo
    ) {
        // 1) تأكد أن المؤشر موجود
        KpiIndicator kpi = indicatorRepository.findByCode(request.getKpiCode())
                .orElseThrow(() -> new IllegalArgumentException(
                        "KPI not found with code: " + request.getKpiCode()
                ));

        // 2) إنشاء القراءة
        KpiIndicatorReading reading = new KpiIndicatorReading();
        reading.setKpiCode(kpi.getCode());
        reading.setPeriodStartDate(request.getPeriodStartDate());
        reading.setPeriodEndDate(request.getPeriodEndDate());
        reading.setPeriodLabel(request.getPeriodLabel());

        reading.setActualValue(request.getActualValue());
        reading.setStatusCode(request.getStatusCode());

        reading.setDataSourceName(request.getDataSourceName());
        reading.setNotes(request.getNotes());

        reading.setEnteredAt(LocalDateTime.now());

        String enteredEmpNo = (ctxEmpNo != null && !ctxEmpNo.isBlank())
                ? ctxEmpNo
                : actorEmpNo;
        reading.setEnteredByEmpNo(enteredEmpNo);

        reading.setIsLocked("N");

        KpiIndicatorReading saved = readingRepository.save(reading);



        // 3) تحديث بيانات المؤشر نفسه (حالة + آخر تحديث)
        kpi.setCurrentStatus(reading.getStatusCode());
        LocalDate lastDate = reading.getPeriodEndDate() != null
                ? reading.getPeriodEndDate()
                : reading.getPeriodStartDate();
        kpi.setLastUpdateDate(lastDate);
        kpi.setUpdatedAt(LocalDateTime.now());
        kpi.setUpdatedByEmpNo(actorEmpNo);
        indicatorRepository.save(kpi);

        // 4) إعادة حساب تقدم الهدف + الأهداف الأعلى
        recomputeGoalHierarchyProgress(kpi, actorEmpNo);

        // 5) رجّعي DTO
        return mapToDto(saved);
    }

    private void recomputeGoalHierarchyProgress(KpiIndicator kpi, String actorEmpNo) {
        if (kpi.getGoalCode() == null || kpi.getGoalCode().isBlank()) {
            return;
        }

        KpiStrategicGoal goal = goalRepository.findByCode(kpi.getGoalCode())
                .orElse(null);
        if (goal == null) return;

        recomputeSingleGoalProgress(goal, actorEmpNo);

        propagateGoalProgressUp(goal, actorEmpNo);
    }

    private void recomputeSingleGoalProgress(KpiStrategicGoal goal, String actorEmpNo) {
        List<KpiIndicator> indicators =
                indicatorRepository.findByGoalCodeAndIsActive(goal.getCode(), "Y");

        List<Double> progresses = new ArrayList<>();
        for (KpiIndicator ind : indicators) {
            Double p = computeKpiProgress(ind);
            if (p != null) {
                progresses.add(p);
            }
        }

        if (progresses.isEmpty()) {
            goal.setProgressPct(null);
            goal.setStatusCode(null);
        } else {
            double avg = progresses.stream()
                    .mapToDouble(Double::doubleValue)
                    .average()
                    .orElse(0.0);

            goal.setProgressPct(avg);

            if (avg >= 90.0) {
                goal.setStatusCode("ON_TRACK");
            } else if (avg >= 70.0) {
                goal.setStatusCode("AT_RISK");
            } else {
                goal.setStatusCode("OFF_TRACK");
            }
        }

        goal.setUpdatedAt(LocalDateTime.now());
        goal.setUpdatedByEmpNo(actorEmpNo);
        goalRepository.save(goal);
    }

    private void propagateGoalProgressUp(KpiStrategicGoal goal, String actorEmpNo) {
        String parentCode = goal.getParentGoalCode();

        while (parentCode != null && !parentCode.isBlank()) {
            KpiStrategicGoal parent = goalRepository.findByCode(parentCode)
                    .orElse(null);
            if (parent == null) break;

            List<KpiStrategicGoal> children =
                    goalRepository.findByParentGoalCode(parentCode);

            List<Double> childProgresses = children.stream()
                    .map(KpiStrategicGoal::getProgressPct)
                    .filter(Objects::nonNull)
                    .toList();

            if (childProgresses.isEmpty()) {
                parent.setProgressPct(null);
                parent.setStatusCode(null);
            } else {
                double avg = childProgresses.stream()
                        .mapToDouble(Double::doubleValue)
                        .average()
                        .orElse(0.0);

                parent.setProgressPct(avg);

                if (avg >= 90.0) {
                    parent.setStatusCode("ON_TRACK");
                } else if (avg >= 70.0) {
                    parent.setStatusCode("AT_RISK");
                } else {
                    parent.setStatusCode("OFF_TRACK");
                }
            }

            parent.setUpdatedAt(LocalDateTime.now());
            parent.setUpdatedByEmpNo(actorEmpNo);
            goalRepository.save(parent);

            parentCode = parent.getParentGoalCode();
        }
    }

    private Double computeKpiProgress(KpiIndicator kpi) {

        if ("Y".equalsIgnoreCase(kpi.getIsMain())) {

            List<KpiIndicator> children =
                    indicatorRepository.findByParentKpiCodeAndIsActive(kpi.getCode(), "Y");

            if (children != null && !children.isEmpty()) {
                List<Double> childProgresses = new ArrayList<>();
                for (KpiIndicator child : children) {
                    Double cp = computeKpiProgressLeaf(child);
                    if (cp != null) childProgresses.add(cp);
                }
                if (childProgresses.isEmpty()) return null;
                return childProgresses.stream()
                        .mapToDouble(Double::doubleValue)
                        .average()
                        .orElse(0.0);
            }
        }

        return computeKpiProgressLeaf(kpi);
    }


    private Double computeKpiProgressLeaf(KpiIndicator kpi) {
        Optional<KpiIndicatorReading> latestOpt =
                readingRepository.findTopByKpiCodeOrderByPeriodStartDateDesc(kpi.getCode());

        if (latestOpt.isEmpty()) return null;
        KpiIndicatorReading latest = latestOpt.get();


        if (kpi.getTargetValue() == null) {
            return null;
        }

        BigDecimal targetBD = kpi.getTargetValue();
        if (targetBD.compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }

        if (latest.getActualValue() == null) {
            return null;
        }

        double target = targetBD.doubleValue();
        double actual = latest.getActualValue();
        String polarity = kpi.getPolarityCode();

        if (polarity == null || polarity.isBlank() || "HIGHER_BETTER".equalsIgnoreCase(polarity)) {
            return Math.min(100.0, (actual / target) * 100.0);
        } else if ("LOWER_BETTER".equalsIgnoreCase(polarity)) {
            if (actual == 0.0) return 100.0;
            double v = (target / actual) * 100.0;
            return Math.min(100.0, v);
        } else if ("RANGE_BEST".equalsIgnoreCase(polarity)) {
            double diffPct = Math.abs(actual - target) / target;
            double score = Math.max(0.0, 100.0 * (1.0 - diffPct));
            return score;
        } else {
            return Math.min(100.0, (actual / target) * 100.0);
        }
    }


    private KpiIndicatorReadingDto mapToDto(KpiIndicatorReading entity) {
        KpiIndicatorReadingDto dto = new KpiIndicatorReadingDto();
        dto.setId(entity.getId());
        dto.setKpiCode(entity.getKpiCode());
        dto.setPeriodStartDate(entity.getPeriodStartDate());
        dto.setPeriodEndDate(entity.getPeriodEndDate());
        dto.setPeriodLabel(entity.getPeriodLabel());
        dto.setActualValue(entity.getActualValue());
        dto.setStatusCode(entity.getStatusCode());
        dto.setDataSourceName(entity.getDataSourceName());
        dto.setNotes(entity.getNotes());
        dto.setEnteredAt(entity.getEnteredAt());
        dto.setEnteredByEmpNo(entity.getEnteredByEmpNo());
        dto.setIsLocked(entity.getIsLocked());
        return dto;
    }

    private Double calcProgressForKpi(KpiIndicator kpi, KpiIndicatorReading reading) {
        if (kpi.getTargetValue() == null || reading.getActualValue() == null) {
            return null;
        }

        BigDecimal targetBD = kpi.getTargetValue();
        if (targetBD.compareTo(BigDecimal.ZERO) <= 0) {
            return null;
        }

        double target = targetBD.doubleValue();
        double actual = reading.getActualValue();

        double progress;
        String polarity = kpi.getPolarityCode();

        if ("LOWER_BETTER".equalsIgnoreCase(polarity)) {
            if (actual <= 0.0) return 100.0;
            progress = (target / actual) * 100.0;
        } else {

            progress = (actual / target) * 100.0;
        }

        if (progress < 0) progress = 0;
        if (progress > 200) progress = 200;
        return progress;
    }


    private String mapProgressToStatus(Double progress) {
        if (progress == null) return null;
        if (progress >= 90) return "ON_TRACK";
        if (progress >= 70) return "AT_RISK";
        return "OFF_TRACK";
    }


    @Transactional(readOnly = true)
    public List<KpiIndicatorReadingDto> getReadingsByKpiCode(String kpiCode) {

        indicatorRepository.findByCode(kpiCode)
                .orElseThrow(() -> new IllegalArgumentException(
                        "KPI not found with code: " + kpiCode
                ));

        List<KpiIndicatorReading> readings =
                readingRepository.findByKpiCodeOrderByPeriodStartDateDesc(kpiCode);

        return readings.stream()
                .map(this::mapToDto)
                .toList();
    }



}


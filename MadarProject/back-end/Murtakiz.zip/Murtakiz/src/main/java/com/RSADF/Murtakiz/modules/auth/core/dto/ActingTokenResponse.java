package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@AllArgsConstructor
public class ActingTokenResponse {
    private String accessToken;
    private LocalDateTime expiresAt;
    private String jti;
    private Long sessionId;
    private Long delegationId;
}
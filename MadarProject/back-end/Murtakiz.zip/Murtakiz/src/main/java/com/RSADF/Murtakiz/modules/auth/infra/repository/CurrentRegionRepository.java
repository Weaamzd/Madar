package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.CurrentRegion;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CurrentRegionRepository extends JpaRepository<CurrentRegion, Long> {


    Optional<CurrentRegion> findFirstByUnite_IdOrderByIdDesc(Long uniteId);


    List<CurrentRegion> findByUnite_Id(Long uniteId);

    @Query("""
   select u
   from User u
   left join fetch u.currentRegion cr
   where u.username = :username
""")
    Optional<User> findByUsernameWithRegion(@Param("username") String username);

}



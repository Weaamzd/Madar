package com.RSADF.Murtakiz;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StartupRunner implements CommandLineRunner {

    @Autowired
    private testPassword passwordTestUtil;

    @Override
    public void run(String... args) throws Exception {
        passwordTestUtil.encryptPasswordIfPlainText();
    }
}
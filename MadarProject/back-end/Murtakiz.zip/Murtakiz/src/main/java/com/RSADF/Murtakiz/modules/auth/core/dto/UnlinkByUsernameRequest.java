package com.RSADF.Murtakiz.modules.auth.core.dto;

// src/main/java/.../dto/UnlinkByUsernameRequest.java
import jakarta.validation.constraints.NotBlank;
import lombok.Getter; import lombok.Setter;

@Getter @Setter
public class UnlinkByUsernameRequest {
    @NotBlank
    private String username;
    // اختياري: ملاحظة تُحفظ في الهيستوري
    private String note;
    // اختياري: فصل الجلسات النشطة (افتراضي false أو true بحسب سياستك)
    private Boolean revokeSessions = Boolean.TRUE; // أو FALSE حسب رغبتك
}


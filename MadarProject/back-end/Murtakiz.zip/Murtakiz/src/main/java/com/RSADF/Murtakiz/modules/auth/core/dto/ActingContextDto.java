package com.RSADF.Murtakiz.modules.auth.core.dto;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@AllArgsConstructor
public class ActingContextDto {
    private Long delegationId;
    private String onBehalfEmpNo;     // A
    private String onBehalfUsername;  // اختياري
    private DelegationScopeType scopeType;
    private long actionsMask;         // مجمّع OR على السكوبات
    private List<Long> uniteIds;
    private List<Long> subUniteIds;
    private LocalDateTime startAt;
    private LocalDateTime endAt;
}

package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import com.RSADF.Murtakiz.modules.auth.core.entity.SecurityDelegation;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface SecurityDelegationRepository extends JpaRepository<SecurityDelegation, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select d from SecurityDelegation d where d.id = :id")
    Optional<SecurityDelegation> findByIdForUpdate(@Param("id") Long id);


    @Query("""
  select d from SecurityDelegation d
  where d.delegatorUser.employee.empNo = :delegatorEmpNo
    and d.delegateeUser.employee.empNo = :delegateeEmpNo
    and d.status = :status
    and :now between d.startAt and coalesce(d.endAt, :maxTime)
""")
    List<SecurityDelegation> findActiveByEmpNos(
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("now") LocalDateTime now,
            @Param("maxTime") LocalDateTime maxTime,
            @Param("status") DelegationStatus status
    );

    @Query("""
select (count(d) > 0) from SecurityDelegation d
where d.delegatorUser.empNo = :delegatorEmpNo
  and d.delegateeUser.empNo = :delegateeEmpNo
  and d.status in :statuses
  and d.startAt <= :newEnd
  and coalesce(d.endAt, :maxTime) >= :newStart
""")
    boolean existsOverlappingOpen(
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("newStart") LocalDateTime newStart,
            @Param("newEnd")   LocalDateTime newEnd,
            @Param("maxTime")  LocalDateTime maxTime,
            @Param("statuses") Collection<DelegationStatus> statuses
    );




    @Query("""
      select d from SecurityDelegation d
      where d.delegateeUser.empNo = :actorEmpNo
        and d.status = :status
        and :now between d.startAt and coalesce(d.endAt, :maxTime)
      order by d.startAt desc
    """)
    List<SecurityDelegation> findEligibleForActor(
            @Param("actorEmpNo") String actorEmpNo,
            @Param("now") LocalDateTime now,
            @Param("maxTime") LocalDateTime maxTime,
            @Param("status") DelegationStatus status
    );


    @Query("""
   select d
   from SecurityDelegation d
   join fetch d.delegatorUser du
   join fetch d.delegateeUser de
   where d.createdByUser.empNo = :creatorEmpNo
   order by d.createdAt desc
""")
    List<SecurityDelegation> findAllCreatedByEmpNo(@Param("creatorEmpNo") String creatorEmpNo);



    @Query("""
   select d
   from SecurityDelegation d
   join fetch d.delegatorUser du
   join fetch d.delegateeUser de
   where du.empNo = :delegatorEmpNo
   order by d.createdAt desc
""")
    List<SecurityDelegation> findAllByDelegatorEmpNo(@Param("delegatorEmpNo") String delegatorEmpNo);


    @Query("""
      select d
      from SecurityDelegation d
      join fetch d.delegatorUser du
      left join fetch du.employee due
      join fetch d.delegateeUser de
      left join fetch de.employee dee
      join fetch d.createdByUser cu
      left join fetch cu.employee cue
      left join fetch d.acceptedByUser abu
      left join fetch abu.employee abue
      order by d.createdAt desc
    """)
    List<SecurityDelegation> findAllWithPeople();

    @Query("""
      select d
      from SecurityDelegation d
      join fetch d.delegatorUser du
      left join fetch du.employee due
      join fetch d.delegateeUser de
      left join fetch de.employee dee
      join fetch d.createdByUser cu
      left join fetch cu.employee cue
      left join fetch d.acceptedByUser abu
      left join fetch abu.employee abue
      where (:creatorEmpNo is null or cu.empNo = :creatorEmpNo)
        and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
        and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
        and (:status is null or d.status = :status)
      order by d.createdAt desc
    """)
    List<SecurityDelegation> findAllWithPeopleFiltered(
            @Param("creatorEmpNo") String creatorEmpNo,
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("status") DelegationStatus status
    );


    @Query(
            value = """
        select distinct d
        from SecurityDelegation d
          join d.delegatorUser du
          left join du.employee due
          join d.delegateeUser de
          left join de.employee dee
          join d.createdByUser cu
          left join cu.employee cue
          left join d.acceptedByUser abu
          left join abu.employee abue
          join SecurityDelegationScope s on s.delegation = d
        where
          (
            (:uniteId     is not null and s.unite.id    = :uniteId)
            or
            (:subUniteId  is not null and s.subUnite.id = :subUniteId)
          )
          and (:creatorEmpNo   is null or cu.empNo = :creatorEmpNo)
          and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
          and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
          and (:status         is null or d.status = :status)
        """,
            countQuery = """
        select count(distinct d.id)
        from SecurityDelegation d
          join SecurityDelegationScope s on s.delegation = d
          join d.delegatorUser du
          join d.delegateeUser de
          join d.createdByUser cu
        where
          (
            (:uniteId     is not null and s.unite.id    = :uniteId)
            or
            (:subUniteId  is not null and s.subUnite.id = :subUniteId)
          )
          and (:creatorEmpNo   is null or cu.empNo = :creatorEmpNo)
          and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
          and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
          and (:status         is null or d.status = :status)
        """
    )
    Page<SecurityDelegation> findAllByScopeFilteredPaged(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("creatorEmpNo") String creatorEmpNo,
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("status") DelegationStatus status,
            Pageable pageable
    );


    @Query("""
        select distinct d
        from SecurityDelegation d
          join d.delegatorUser du
          left join du.employee due
          join d.delegateeUser de
          left join de.employee dee
          join d.createdByUser cu
          left join cu.employee cue
          left join d.acceptedByUser abu
          left join abu.employee abue
          join SecurityDelegationScope s on s.delegation = d
        where
          (
            (:uniteId     is not null and s.unite.id    = :uniteId)
            or
            (:subUniteId  is not null and s.subUnite.id = :subUniteId)
          )
          and (:creatorEmpNo   is null or cu.empNo = :creatorEmpNo)
          and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
          and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
          and (:status         is null or d.status = :status)
        order by d.createdAt desc
        """)
    List<SecurityDelegation> findAllByScopeFiltered(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("creatorEmpNo") String creatorEmpNo,
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("status") DelegationStatus status
    );


    @Query("""
   select distinct d
   from SecurityDelegation d
     join d.delegatorUser du
     left join du.employee due
     join d.delegateeUser de
     left join de.employee dee
     join d.createdByUser cu
     left join cu.employee cue
     left join d.acceptedByUser abu
     left join abu.employee abue
     join SecurityDelegationScope s on s.delegation = d
   where ( (:uniteId    is not null and s.unite.id    = :uniteId)
        or (:subUniteId is not null and s.subUnite.id = :subUniteId) )
     and (:creatorEmpNo   is null or cu.empNo = :creatorEmpNo)
     and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
     and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
     and (:status        is null or d.status = :status)
   order by d.createdAt desc
""")
    Page<SecurityDelegation> findByScopeWithPeoplePaged(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("creatorEmpNo") String creatorEmpNo,
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("status") DelegationStatus status,
            Pageable pageable
    );

    @Query("""
   select distinct d
   from SecurityDelegation d
     join d.delegatorUser du
     left join du.employee due
     join d.delegateeUser de
     left join de.employee dee
     join d.createdByUser cu
     left join cu.employee cue
     left join d.acceptedByUser abu
     left join abu.employee abue
     join SecurityDelegationScope s on s.delegation = d
   where ( (:uniteId    is not null and s.unite.id    = :uniteId)
        or (:subUniteId is not null and s.subUnite.id = :subUniteId) )
     and (:creatorEmpNo   is null or cu.empNo = :creatorEmpNo)
     and (:delegatorEmpNo is null or du.empNo = :delegatorEmpNo)
     and (:delegateeEmpNo is null or de.empNo = :delegateeEmpNo)
     and (:status        is null or d.status = :status)
   order by d.createdAt desc
""")
    List<SecurityDelegation> findByScopeWithPeopleUnpaged(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("creatorEmpNo") String creatorEmpNo,
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("status") DelegationStatus status
    );



}



    /*@Query("""
    select d from SecurityDelegation d
    where d.delegatorUser.empNo = :delegatorEmpNo
      and d.delegateeUser.empNo = :delegateeEmpNo
      and d.status = 'ACTIVE'
      and :now between d.startAt and coalesce(d.endAt, TIMESTAMP '9999-12-31 23:59:59')
  """)
    List<SecurityDelegation> findActiveByEmpNos(@Param("delegatorEmpNo") String delegatorEmpNo,
                                                @Param("delegateeEmpNo") String delegateeEmpNo,
                                                @Param("now") LocalDateTime now);*/

/*
    @Query("""
  select d from SecurityDelegation d
  where d.delegatorUser.empNo = :delegatorEmpNo
    and d.delegateeUser.empNo = :delegateeEmpNo
    and d.status = com.RSADF.Murtakiz.modules.auth.core.entity.DelegationStatus.ACTIVE
    and d.startAt <= :now
    and (d.endAt is null or d.endAt >= :now)
""")
    List<SecurityDelegation> findActiveByEmpNos(
            @Param("delegatorEmpNo") String delegatorEmpNo,
            @Param("delegateeEmpNo") String delegateeEmpNo,
            @Param("now") LocalDateTime now);
*/
package com.RSADF.Murtakiz.modules.kpi.core.dto;


import lombok.Data;

@Data
public class CreateKpiStrategicGoalRequest {

    private String code;              // GOAL_CODE
    private String nameAr;            // GOAL_NAME_AR
    private String perspectiveCode;   // PERSPECTIVE_CODE

    private String goalType;          // GOAL_TYPE

    private String ownerEmpNo;        // OWNER_EMP_NO (اختياري)
    private Long ownerUniteId;        // OWNER_UNITE_ID (اختياري)
    private Long ownerSubUniteId;     // OWNER_SUB_UNITE_ID (اختياري)

    private String regionCode;        // REGION_CODE (اختياري)

    private Integer horizonFromYear;  // HORIZON_FROM_YEAR
    private Integer horizonToYear;    // HORIZON_TO_YEAR

    private String parentGoalCode;    // PARENT_GOAL_CODE
}



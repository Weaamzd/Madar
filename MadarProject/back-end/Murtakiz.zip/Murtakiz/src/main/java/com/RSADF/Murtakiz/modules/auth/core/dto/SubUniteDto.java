package com.RSADF.Murtakiz.modules.auth.core.dto;


public class SubUniteDto {
    private Long id;
    private String code;
    private String name;

    private Long uniteId;          // قد تكون null لو هذه تحت SubUnite أخرى
    private Long uniteTypeId;
    private String uniteTypeName;

    private Long parentSubUniteId; // null لو مستوى أول تحت Unite
    private boolean hasChildren;   // هل يوجد مستويات أعمق؟

    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Long getUniteId() { return uniteId; }
    public void setUniteId(Long uniteId) { this.uniteId = uniteId; }
    public Long getUniteTypeId() { return uniteTypeId; }
    public void setUniteTypeId(Long uniteTypeId) { this.uniteTypeId = uniteTypeId; }
    public String getUniteTypeName() { return uniteTypeName; }
    public void setUniteTypeName(String uniteTypeName) { this.uniteTypeName = uniteTypeName; }
    public Long getParentSubUniteId() { return parentSubUniteId; }
    public void setParentSubUniteId(Long parentSubUniteId) { this.parentSubUniteId = parentSubUniteId; }
    public boolean isHasChildren() { return hasChildren; }
    public void setHasChildren(boolean hasChildren) { this.hasChildren = hasChildren; }
}


package com.RSADF.Murtakiz.modules.kpi.core.entity;


import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(
        name = "KPI_INDICATOR_READING",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_KPI_READ__KPI_CODE", columnList = "KPI_CODE"),
                @Index(name = "IX_KPI_READ__STATUS", columnList = "STATUS_CODE"),
                @Index(name = "IX_KPI_READ__PERIOD", columnList = "PERIOD_START_DATE, PERIOD_END_DATE")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class KpiIndicatorReading {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "READING_ID")
    private Long id;



    @Column(name = "KPI_CODE", length = 50, nullable = false)
    private String kpiCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "KPI_CODE",
            referencedColumnName = "KPI_CODE",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_READ__KPI_ID")
    )
    @ToString.Exclude
    private KpiIndicator kpi;




    @Column(name = "PERIOD_START_DATE", nullable = false)
    private LocalDate periodStartDate;

    @Column(name = "PERIOD_END_DATE")
    private LocalDate periodEndDate;

    @Column(name = "PERIOD_LABEL", length = 50)
    private String periodLabel;



    @Column(name = "ACTUAL_VALUE", nullable = false)
    private Double actualValue;

    @Column(name = "STATUS_CODE", length = 20)
    private String statusCode;




    @Column(name = "DATA_SOURCE_NAME", length = 200)
    private String dataSourceName;

    @Column(name = "NOTES", length = 500)
    private String notes;




    @Column(name = "ENTERED_AT", nullable = false)
    private LocalDateTime enteredAt;

    @Column(name = "ENTERED_BY_EMP_NO", length = 50)
    private String enteredByEmpNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "ENTERED_BY_EMP_NO",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_READ__ENTER_EMP")
    )
    @ToString.Exclude
    private Employee enteredBy;




    @Column(name = "IS_LOCKED", length = 1, nullable = false)
    private String isLocked;  // Y / N
}


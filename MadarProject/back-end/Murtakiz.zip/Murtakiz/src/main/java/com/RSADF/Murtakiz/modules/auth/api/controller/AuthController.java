package com.RSADF.Murtakiz.modules.auth.api.controller;




import com.RSADF.Murtakiz.modules.auth.infra.service.AuthService;
import com.RSADF.Murtakiz.modules.auth.core.dto.AuthResponse;
import com.RSADF.Murtakiz.modules.auth.core.dto.LoginRequest;
import com.RSADF.Murtakiz.modules.auth.infra.service.HttpTokenResolver;
import com.RSADF.Murtakiz.modules.auth.infra.service.LogoutService;
import com.RSADF.Murtakiz.modules.auth.jwt.ClaimsMapper;
import jakarta.annotation.security.PermitAll;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/murtakiz/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final LogoutService logoutService;
    private final ClaimsMapper claimsMapper;

    @PermitAll
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest req,
                                              HttpServletRequest request) {
        try {

            AuthResponse res = authService.login(req, request);
            return ResponseEntity.ok(res);
        } catch (IllegalArgumentException ex) {

            return ResponseEntity.badRequest().build();
        } catch (RuntimeException ex) {

            return ResponseEntity.status(401).build();
        }
    }



    @PreAuthorize("isAuthenticated()")
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpServletRequest request, HttpServletResponse response) {
        logoutService.logoutCurrent(request, "USER_LOGOUT");
        clearAuthCookies(response);

        return ResponseEntity.ok(
                Map.of(
                        "message", "تم تسجيل الخروج بنجاح",
                        "reason", "USER_LOGOUT",
                        "timestamp", Instant.now().toString()
                )
        );
    }


    @PreAuthorize("isAuthenticated()")
    @PostMapping("/logout-all")
    public ResponseEntity<Map<String, Object>> logoutAll(HttpServletRequest request, HttpServletResponse response) {
        long revoked = logoutService.logoutAllDevices(request, "USER_LOGOUT_ALL");
        clearAuthCookies(response);

        return ResponseEntity.ok(
                Map.of(
                        "message", "تم تسجيل الخروج من جميع الأجهزة",
                        "revokedSessions", revoked,
                        "reason", "USER_LOGOUT_ALL",
                        "timestamp", Instant.now().toString()
                )
        );
    }

    private static void clearAuthCookies(HttpServletResponse resp) {
        Cookie access = new Cookie(HttpTokenResolver.ACCESS_COOKIE, "");
        access.setPath("/");
        access.setHttpOnly(true);
        access.setSecure(true);
        access.setMaxAge(0);
        resp.addCookie(access);

        Cookie refresh = new Cookie(HttpTokenResolver.REFRESH_COOKIE, "");
        refresh.setPath("/");
        refresh.setHttpOnly(true);
        refresh.setSecure(true);
        refresh.setMaxAge(0);
        resp.addCookie(refresh);
    }
}

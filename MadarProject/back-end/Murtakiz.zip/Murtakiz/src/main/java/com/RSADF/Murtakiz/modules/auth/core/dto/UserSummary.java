package com.RSADF.Murtakiz.modules.auth.core.dto;



import lombok.*;
import java.util.List;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class UserSummary {
    private Long userId;
    private String username;
    private String empNo;
    private String fullName;
    private String email;
    private String jobTitle;
    private String regionCode;
    private String regionDbKey;
    private List<String> roles;
}


package com.RSADF.Murtakiz.modules.auth.core.dto;

public class DelegationScopeDetailsDto {
}


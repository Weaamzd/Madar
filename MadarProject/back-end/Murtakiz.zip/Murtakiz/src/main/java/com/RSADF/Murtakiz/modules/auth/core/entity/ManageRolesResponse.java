package com.RSADF.Murtakiz.modules.auth.core.entity;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ManageRolesResponse {
    private Long userId;
    private List<Long> addedRoleIds;
    private List<Long> removedRoleIds;
    private List<Long> alreadyLinked;
    private List<Long> notFoundRoleIds;
    private int totalRequested;
}
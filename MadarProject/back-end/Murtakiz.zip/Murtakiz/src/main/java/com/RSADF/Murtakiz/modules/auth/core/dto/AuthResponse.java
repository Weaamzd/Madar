package com.RSADF.Murtakiz.modules.auth.core.dto;


import lombok.*;
import java.time.Instant;
import java.time.LocalDateTime;

@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class AuthResponse {
    private String tokenType;   // "Bearer"
    private String accessToken; // JWT
    private Instant expiresAt;
    String jti;

}


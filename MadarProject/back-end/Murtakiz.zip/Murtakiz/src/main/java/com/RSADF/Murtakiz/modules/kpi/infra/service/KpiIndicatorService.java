package com.RSADF.Murtakiz.modules.kpi.infra.service;

import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import com.RSADF.Murtakiz.modules.auth.infra.repository.SubUniteRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UniteRepository;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiIndicatorRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorDto;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorDto2;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicator;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiStrategicGoal;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiStrategicGoalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class KpiIndicatorService {

    private final KpiIndicatorRepository indicatorRepository;

    /**
     * ترجع كل المؤشرات من الجدول على شكل قائمة DTO
     */
    public List<KpiIndicatorDto> getAllIndicators2() {
        List<KpiIndicator> entities = indicatorRepository.findAll();

        return entities.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    /**
     * تحويل Entity -> DTO
     */
    private KpiIndicatorDto mapToDto3(KpiIndicator e) {
        KpiIndicatorDto dto = new KpiIndicatorDto();

        dto.setId(e.getId());
        dto.setCode(e.getCode());
        dto.setNameAr(e.getNameAr());
        dto.setDescAr(e.getDescAr());

        dto.setGoalCode(e.getGoalCode());
        dto.setPerspectiveCode(e.getPerspectiveCode());

        dto.setOwnerEmpNo(e.getOwnerEmpNo());
        dto.setOwnerUniteId(e.getOwnerUniteId());
        dto.setOwnerSubUniteId(e.getOwnerSubUniteId());

        dto.setTargetValue(e.getTargetValue());
        dto.setTargetSource(e.getTargetSource());
        dto.setMeansToAchieveTarget(e.getMeansToAchieveTarget());

        dto.setBaselineValue(e.getBaselineValue());
        dto.setMeasurementUnit(e.getMeasurementUnit());

        dto.setPolarityCode(e.getPolarityCode());
        dto.setMeasurementMethod(e.getMeasurementMethod());
        dto.setFormulaText(e.getFormulaText());

        dto.setFrequencyCode(e.getFrequencyCode());

        dto.setCurrentStatus(e.getCurrentStatus());
        dto.setLastUpdateDate(e.getLastUpdateDate());

        dto.setIsMain(e.getIsMain());
        dto.setParentKpiCode(e.getParentKpiCode());

        dto.setIsActive(e.getIsActive());

        dto.setCreatedAt(e.getCreatedAt());
        dto.setCreatedByEmpNo(e.getCreatedByEmpNo());
        dto.setUpdatedAt(e.getUpdatedAt());
        dto.setUpdatedByEmpNo(e.getUpdatedByEmpNo());

        return dto;
    }


    private final KpiStrategicGoalRepository goalRepository;
    private final UniteRepository uniteRepository;
    private final SubUniteRepository subUniteRepository;

    @Transactional
    public KpiIndicatorDto createIndicator(
            CreateKpiIndicatorRequest request,
            String actorEmpNo,
            String ctxEmpNo
    ) {

        if (indicatorRepository.existsByCode(request.getCode())) {
            throw new IllegalArgumentException("KPI code already exists: " + request.getCode());
        }

        KpiStrategicGoal goal = goalRepository.findByCode(request.getGoalCode())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Strategic goal not found with code: " + request.getGoalCode()
                ));

        KpiIndicator kpi = new KpiIndicator();
        kpi.setCode(request.getCode());
        kpi.setNameAr(request.getNameAr());
        kpi.setDescAr(request.getDescAr());

        kpi.setGoalCode(request.getGoalCode());

        String perspective = request.getPerspectiveCode();
        if (perspective == null || perspective.isBlank()) {
            perspective = goal.getPerspectiveCode();
        }
        kpi.setPerspectiveCode(perspective);

        String ownerEmpNo = request.getOwnerEmpNo();
        if (ownerEmpNo == null || ownerEmpNo.isBlank()) {

            ownerEmpNo = (ctxEmpNo != null && !ctxEmpNo.isBlank())
                    ? ctxEmpNo
                    : actorEmpNo;
        }
        kpi.setOwnerEmpNo(ownerEmpNo);

        if (request.getOwnerUniteId() != null) {
            uniteRepository.findById(request.getOwnerUniteId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Unite not found: " + request.getOwnerUniteId()
                    ));
            kpi.setOwnerUniteId(request.getOwnerUniteId());
        }

        if (request.getOwnerSubUniteId() != null) {
            subUniteRepository.findById(request.getOwnerSubUniteId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "SubUnite not found: " + request.getOwnerSubUniteId()
                    ));
            kpi.setOwnerSubUniteId(request.getOwnerSubUniteId());
        }


        kpi.setTargetValue(request.getTargetValue());
        kpi.setTargetSource(request.getTargetSource());
        kpi.setMeansToAchieveTarget(request.getMeansToAchieveTarget());

        kpi.setBaselineValue(request.getBaselineValue());
        kpi.setMeasurementUnit(request.getMeasurementUnit());

        kpi.setPolarityCode(request.getPolarityCode());
        kpi.setMeasurementMethod(request.getMeasurementMethod());
        kpi.setFormulaText(request.getFormulaText());

        kpi.setFrequencyCode(request.getFrequencyCode());

        String status = request.getCurrentStatus();
        if (status == null || status.isBlank()) {
            status = "ON_TRACK";
        }
        kpi.setCurrentStatus(status);
        kpi.setLastUpdateDate(LocalDate.now());


        String isMain = request.getIsMain();
        if (isMain == null || isMain.isBlank()) {
            isMain = "Y";
        }
        kpi.setIsMain(isMain);

        kpi.setParentKpiCode(request.getParentKpiCode());


        String isActive = request.getIsActive();
        if (isActive == null || isActive.isBlank()) {
            isActive = "Y";
        }
        kpi.setIsActive(isActive);


        kpi.setCreatedAt(LocalDateTime.now());
        kpi.setCreatedByEmpNo(actorEmpNo);

        KpiIndicator saved = indicatorRepository.save(kpi);


        long kpiCount = indicatorRepository.countByGoalCode(goal.getCode());
        goal.setKpiCount((int) kpiCount);


        goal.setUpdatedAt(LocalDateTime.now());
        goal.setUpdatedByEmpNo(actorEmpNo);

        goalRepository.save(goal);


        return mapToDto(saved);
    }



    @Transactional(readOnly = true)
    public Page<KpiIndicatorDto> searchIndicators(
            String goalCode,
            Long ownerUniteId,
            Long ownerSubUniteId,
            String isMain,
            String isActive,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {

        String goalCodeNorm = emptyToNull(goalCode);
        String isMainNorm   = emptyToNull(isMain);
        String isActiveNorm = emptyToNull(isActive);

        Pageable pageable = buildPageable(page, size, unpaged);

        if (Boolean.TRUE.equals(unpaged)
                && ownerUniteId != null
                && ownerSubUniteId == null) {

            List<KpiIndicator> list = indicatorRepository.findByUniteTreeNative(
                    goalCodeNorm,
                    ownerUniteId,
                    isMainNorm,
                    isActiveNorm
            );

            List<KpiIndicatorDto> dtos = list.stream()
                    .map(this::mapToDto)
                    .toList();

            return new PageImpl<>(dtos, Pageable.unpaged(), dtos.size());
        }


        if (Boolean.TRUE.equals(unpaged)
                && ownerSubUniteId != null) {

            List<KpiIndicator> list = indicatorRepository.findBySubUniteTreeNative(
                    goalCodeNorm,
                    ownerSubUniteId,
                    isMainNorm,
                    isActiveNorm
            );

            List<KpiIndicatorDto> dtos = list.stream()
                    .map(this::mapToDto)
                    .toList();

            return new PageImpl<>(dtos, Pageable.unpaged(), dtos.size());
        }

        Page<KpiIndicator> resultPage = indicatorRepository.searchIndicators(
                goalCodeNorm,
                ownerUniteId,
                ownerSubUniteId,
                isMainNorm,
                isActiveNorm,
                pageable
        );

        return resultPage.map(this::mapToDto);
    }




    @Transactional(readOnly = true)
    public Page<KpiIndicatorDto> getMainIndicatorsByUnite(
            Long ownerUniteId,
            String goalCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiIndicator> resultPage = indicatorRepository.searchIndicators(
                emptyToNull(goalCode),
                ownerUniteId,
                null,
                "Y",
                "Y",
                pageable
        );

        return resultPage.map(this::mapToDto);
    }


    @Transactional(readOnly = true)
    public Page<KpiIndicatorDto> getMainIndicatorsBySubUnite(
            Long ownerSubUniteId,
            String goalCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiIndicator> resultPage = indicatorRepository.searchIndicators(
                emptyToNull(goalCode),
                null,
                ownerSubUniteId,
                "Y",
                "Y",
                pageable
        );

        return resultPage.map(this::mapToDto);
    }


    @Transactional(readOnly = true)
    public List<KpiIndicatorDto> getChildrenIndicators(String parentKpiCode) {
        List<KpiIndicator> children = indicatorRepository.findByParentKpiCode(parentKpiCode);
        return children.stream()
                .map(this::mapToDto)
                .toList();
    }



    private Pageable buildPageable(Integer page, Integer size, Boolean unpaged) {
        if (Boolean.TRUE.equals(unpaged)) {
            return Pageable.unpaged();
        }

        int p = (page == null || page < 0) ? 0 : page;
        int s = (size == null || size <= 0) ? 20 : size;

        return PageRequest.of(p, s);
    }

    private String emptyToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    private KpiIndicatorDto mapToDto(KpiIndicator entity) {
        KpiIndicatorDto dto = new KpiIndicatorDto();

        dto.setId(entity.getId());
        dto.setCode(entity.getCode());
        dto.setNameAr(entity.getNameAr());
        dto.setDescAr(entity.getDescAr());

        dto.setGoalCode(entity.getGoalCode());
        dto.setPerspectiveCode(entity.getPerspectiveCode());

        dto.setOwnerEmpNo(entity.getOwnerEmpNo());
        if (entity.getOwnerUnite() != null) {
            dto.setOwnerUniteId(entity.getOwnerUnite().getId());
        }
        if (entity.getOwnerSubUnite() != null) {
            dto.setOwnerSubUniteId(entity.getOwnerSubUnite().getId());
        }

        dto.setTargetValue(entity.getTargetValue());
        dto.setTargetSource(entity.getTargetSource());
        dto.setMeansToAchieveTarget(entity.getMeansToAchieveTarget());

        dto.setBaselineValue(entity.getBaselineValue());
        dto.setMeasurementUnit(entity.getMeasurementUnit());

        dto.setPolarityCode(entity.getPolarityCode());
        dto.setMeasurementMethod(entity.getMeasurementMethod());
        dto.setFormulaText(entity.getFormulaText());

        dto.setFrequencyCode(entity.getFrequencyCode());

        dto.setCurrentStatus(entity.getCurrentStatus());
        dto.setLastUpdateDate(entity.getLastUpdateDate());

        dto.setIsMain(entity.getIsMain());
        dto.setParentKpiCode(entity.getParentKpiCode());

        dto.setIsActive(entity.getIsActive());

        dto.setCreatedAt(entity.getCreatedAt());
        dto.setCreatedByEmpNo(entity.getCreatedByEmpNo());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setUpdatedByEmpNo(entity.getUpdatedByEmpNo());

        return dto;
    }


    public List<Object[]> debugIds() {
        return indicatorRepository.debugIds();
    }




    public List<KpiIndicatorDto2> getAllIndicators() {
        List<KpiIndicator> entities = indicatorRepository.findAll();

        return entities.stream()
                .map(this::mapToDto2)
                .collect(Collectors.toList());
    }



    private KpiIndicatorDto2 mapToDto2(KpiIndicator e) {
        KpiIndicatorDto2 dto = new KpiIndicatorDto2();

        dto.setId(e.getId());
        dto.setCode(e.getCode());
        dto.setNameAr(e.getNameAr());
        dto.setDescAr(e.getDescAr());

        dto.setGoalCode(e.getGoalCode());
        dto.setPerspectiveCode(e.getPerspectiveCode());

        dto.setOwnerEmpNo(e.getOwnerEmpNo());
        dto.setOwnerUniteId(e.getOwnerUniteId());
        dto.setOwnerSubUniteId(e.getOwnerSubUniteId());

        dto.setTargetValue(e.getTargetValue());
        dto.setTargetSource(e.getTargetSource());
        dto.setMeansToAchieveTarget(e.getMeansToAchieveTarget());

        dto.setBaselineValue(e.getBaselineValue());
        dto.setMeasurementUnit(e.getMeasurementUnit());
        dto.setPolarityCode(e.getPolarityCode());
        dto.setMeasurementMethod(e.getMeasurementMethod());
        dto.setFormulaText(e.getFormulaText());

        dto.setFrequencyCode(e.getFrequencyCode());
        dto.setCurrentStatus(e.getCurrentStatus());
        dto.setLastUpdateDate(e.getLastUpdateDate());

        dto.setIsMain(e.getIsMain());
        dto.setParentKpiCode(e.getParentKpiCode());

        dto.setIsActive(e.getIsActive());

        dto.setCreatedAt(e.getCreatedAt());
        dto.setCreatedByEmpNo(e.getCreatedByEmpNo());
        dto.setUpdatedAt(e.getUpdatedAt());
        dto.setUpdatedByEmpNo(e.getUpdatedByEmpNo());

        return dto;
    }




}

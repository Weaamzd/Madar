package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.UserEmployeePrecheckDto;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.EmployeeRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserDirectoryFacade {

    private final UserRepository userRepo;
    private final EmployeeRepository empRepo;
    private final UserRoleRepository userRoleRepo;

    public UserDirectoryFacade(UserRepository userRepo,
                               EmployeeRepository empRepo,
                               UserRoleRepository userRoleRepo) {
        this.userRepo = userRepo;
        this.empRepo = empRepo;
        this.userRoleRepo = userRoleRepo;
    }

    @Transactional(readOnly = true)
    public UserEmployeePrecheckDto precheck(String username, String empNo) {
        if ((username == null || username.isBlank()) && (empNo == null || empNo.isBlank())) {
            throw new IllegalArgumentException("أرسل username أو empNo على الأقل");
        }

        var out = new UserEmployeePrecheckDto();


        User u = null;
        if (username != null && !username.isBlank()) {
            u = userRepo.findByUsername(username).orElse(null);
        }
        if (u == null && empNo != null && !empNo.isBlank()) {
            u = userRepo.findByEmpNo(empNo).orElse(null);
        }

        if (u != null) {
            out.setUserExists(true);
            out.setUserId(u.getId());
            out.setUsername(u.getUsername());
            out.setEmpNo(u.getEmpNo());
            out.setStatus(u.getStatus());
            out.setLastLoginAt(u.getLastLoginAt());
            if (u.getCurrentRegion() != null) {
                out.setCurrentRegionId(u.getCurrentRegion().getId());
                out.setRegionCode(u.getCurrentRegion().getRegionCode());
                out.setRegionDbKey(u.getCurrentRegion().getRegionDbKey());
            }
            var roles = userRoleRepo.findRoleNamesByUserId(u.getId());
            out.setRoles(roles);
        }


        String empNoKey = (empNo != null && !empNo.isBlank())
                ? empNo
                : (u != null ? u.getEmpNo() : null);

        if (empNoKey != null) {
            var emp = empRepo.findById(empNoKey).orElse(null);
            if (emp != null) {
                out.setEmployeeExists(true);
                out.setEmpNo(emp.getEmpNo());
                out.setFullNameAr(emp.getFullNameAr());
                out.setEmail(emp.getEmail());
                out.setJobTitle(emp.getJobTitle());
                out.setHireDate(emp.getHireDate());
                out.setStartDate(emp.getStartDate());
                out.setManagerNo(emp.getManagerNo());

                var su = emp.getSubUnite();
                if (su != null) {
                    out.setSubUniteId(su.getId());
                    out.setSubUniteCode(su.getCode());
                    out.setSubUniteName(su.getName());
                    var uo = su.getUnite();
                    if (uo != null) {
                        out.setUniteId(uo.getId());
                        out.setUniteCode(uo.getCode());
                        out.setUniteName(uo.getName());
                    }
                }
            }
        }

        if (!out.isUserExists() && !out.isEmployeeExists()) {
            out.setEmpNo(empNo);
            out.setUsername(username);
        }

        return out;
    }
}

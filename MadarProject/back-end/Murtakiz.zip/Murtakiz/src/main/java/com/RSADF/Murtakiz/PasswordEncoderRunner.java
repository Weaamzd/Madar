package com.RSADF.Murtakiz;



import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class PasswordEncoderRunner implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {
        String rawPassword = "pass2hash";
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encodedPassword = encoder.encode(rawPassword);
        System.out.println("====== BCrypt Encrypted Password ======");
        System.out.println(encodedPassword);
        System.out.println("=======================================");
    }
}

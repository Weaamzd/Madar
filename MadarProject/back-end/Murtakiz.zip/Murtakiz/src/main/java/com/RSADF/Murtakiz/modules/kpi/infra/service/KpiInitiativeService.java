package com.RSADF.Murtakiz.modules.kpi.infra.service;

import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import com.RSADF.Murtakiz.modules.auth.infra.repository.SubUniteRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UniteRepository;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiInitiativeRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiInitiativeDto;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicator;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorInitiative;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorInitiativeId;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiInitiative;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorInitiativeRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiInitiativeRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiStrategicGoalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;



import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiInitiativeRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiInitiativeDto;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorInitiative;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiInitiative;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorInitiativeRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiIndicatorRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiInitiativeRepository;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiStrategicGoalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class KpiInitiativeService {

    private final KpiInitiativeRepository initiativeRepository;
    private final KpiIndicatorRepository indicatorRepository;
    private final KpiIndicatorInitiativeRepository indicatorInitiativeRepository;
    private final KpiStrategicGoalRepository goalRepository;


    @Transactional(readOnly = true)
    public List<KpiInitiativeDto> getInitiativesByKpiCode(String kpiCode) {


        List<KpiInitiative> entities =
                indicatorInitiativeRepository.findInitiativesByKpiCode(kpiCode);

        return entities.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }


    @Transactional
    public KpiInitiativeDto createInitiativeAndLinkToKpi(
            CreateKpiInitiativeRequest request,
            String actorEmpNo,
            String ctxEmpNo
    ) {

        if (initiativeRepository.existsByInitiativeCode(request.getInitiativeCode())) {
            throw new IllegalArgumentException(
                    "Initiative code already exists: " + request.getInitiativeCode()
            );
        }


        if (!indicatorRepository.existsByCode(request.getKpiCode())) {
            throw new IllegalArgumentException(
                    "KPI not found with code: " + request.getKpiCode()
            );
        }


        if (request.getGoalCode() != null && !request.getGoalCode().isBlank()) {
            if (!goalRepository.existsByCode(request.getGoalCode())) {
                throw new IllegalArgumentException(
                        "Goal not found with code: " + request.getGoalCode()
                );
            }
        }


        String ownerEmpNo = request.getOwnerEmpNo();
        if (ownerEmpNo == null || ownerEmpNo.isBlank()) {
            ownerEmpNo = (ctxEmpNo != null && !ctxEmpNo.isBlank())
                    ? ctxEmpNo
                    : actorEmpNo;
        }


        KpiInitiative init = new KpiInitiative();
        init.setInitiativeCode(request.getInitiativeCode());
        init.setNameAr(request.getNameAr());
        init.setDescAr(request.getDescAr());


        String initiativeType = request.getInitiativeType();
        if (initiativeType == null || initiativeType.isBlank()) {
            initiativeType = "PLANNED";
        }
        init.setInitiativeType(initiativeType);

        init.setGoalCode(request.getGoalCode());
        init.setOwnerEmpNo(ownerEmpNo);

        init.setOwnerUniteId(request.getOwnerUniteId());
        init.setOwnerSubUniteId(request.getOwnerSubUniteId());


        init.setStartDate(request.getStartDate());
        init.setTargetEndDate(request.getTargetEndDate());
        init.setStatusCode("PLANNED");
        init.setProgressPct(BigDecimal.ZERO);


        if (request.getBudgetAmount() != null) {
            init.setBudgetAmount(BigDecimal.valueOf(request.getBudgetAmount()));
        } else {
            init.setBudgetAmount(null);
        }
        init.setActualCost(BigDecimal.ZERO);


        init.setCreatedAt(LocalDateTime.now());
        init.setCreatedByEmpNo(actorEmpNo);

        KpiInitiative savedInit = initiativeRepository.save(init);


        String linkType = request.getLinkType();
        if (linkType == null || linkType.isBlank()) {
            linkType = "PRIMARY";
        }

        KpiIndicatorInitiative link = new KpiIndicatorInitiative();
        link.setKpiCode(request.getKpiCode());
        link.setInitiativeCode(savedInit.getInitiativeCode());
        link.setLinkType(linkType);

        indicatorInitiativeRepository.save(link);


        return mapToDto(savedInit);
    }

    /**
     * تحويل Entity → DTO
     */
    private KpiInitiativeDto mapToDto(KpiInitiative entity) {
        KpiInitiativeDto dto = new KpiInitiativeDto();

        dto.setId(entity.getId());
        dto.setCode(entity.getInitiativeCode());
        dto.setNameAr(entity.getNameAr());
        dto.setDescAr(entity.getDescAr());
        dto.setInitiativeType(entity.getInitiativeType());

        dto.setGoalCode(entity.getGoalCode());
        dto.setOwnerEmpNo(entity.getOwnerEmpNo());
        dto.setOwnerUniteId(entity.getOwnerUniteId());
        dto.setOwnerSubUniteId(entity.getOwnerSubUniteId());

        dto.setStartDate(entity.getStartDate());
        dto.setTargetEndDate(entity.getTargetEndDate());
        dto.setActualEndDate(entity.getActualEndDate());
        dto.setStatusCode(entity.getStatusCode());

        if (entity.getProgressPct() != null) {
            dto.setProgressPct(entity.getProgressPct().doubleValue());
        }
        if (entity.getBudgetAmount() != null) {
            dto.setBudgetAmount(entity.getBudgetAmount().doubleValue());
        }
        if (entity.getActualCost() != null) {
            dto.setActualCost(entity.getActualCost().doubleValue());
        }

        dto.setCreatedAt(entity.getCreatedAt());
        dto.setCreatedByEmpNo(entity.getCreatedByEmpNo());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setUpdatedByEmpNo(entity.getUpdatedByEmpNo());

        return dto;
    }
}


package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnlinkRequest {
    @NotBlank
    private String username;
    // INTERNAL أو EXTERNAL أو null لفصل أي ربط موجود
    private String type;
    private boolean revokeSessions = true;
    private String note;
}
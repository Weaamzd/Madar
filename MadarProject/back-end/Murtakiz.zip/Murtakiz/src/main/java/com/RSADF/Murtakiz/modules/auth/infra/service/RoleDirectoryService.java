package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.entity.Role;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.RoleRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleDao;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleRepository;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class RoleDirectoryService {

    private final UserRepository userRepo;
    private final RoleRepository roleRepo;
    private final UserRoleRepository userRoleRepo;
    private final UserRoleDao userRoleDao;

    public RoleDirectoryService(UserRepository userRepo,
                                 RoleRepository roleRepo,
                                 UserRoleRepository userRoleRepo,
                                 UserRoleDao userRoleDao) {
        this.userRepo = userRepo;
        this.roleRepo = roleRepo;
        this.userRoleRepo = userRoleRepo;
        this.userRoleDao = userRoleDao;
    }

   /* public RoleDirectoryService(RoleRepository roleRepo) {
        this.roleRepo = roleRepo;
    }*/


    public RolesMutationResult addRolesByEmpNo(String empNo, AssignRolesRequest body) {
        if (body == null || body.getRoles() == null || body.getRoles().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roles list required");
        }

        User user = userRepo.findByEmployeeEmpNo(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found by empNo: " + empNo));

        List<String> requestedNames = body.getRoles().stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .toList();

        if (requestedNames.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roles list empty");
        }

        List<Role> roles = roleRepo.findByNameIn(requestedNames);
        Map<String, Long> nameToId = roles.stream().collect(Collectors.toMap(Role::getName, Role::getId));
        List<String> notFound = requestedNames.stream()
                .filter(n -> !nameToId.containsKey(n))
                .toList();


        List<Long> roleIds = roles.stream().map(Role::getId).toList();


        Set<Long> existing = roleIds.isEmpty()
                ? Set.of()
                : userRoleRepo.findExistingRoleIdsForUser(user.getId(), roleIds);

        List<String> addedNames = new ArrayList<>();
        for (Role r : roles) {
            if (!existing.contains(r.getId())) {
                userRoleDao.linkUserToRole(user.getId(), r.getId());
                addedNames.add(r.getName());
            }
        }

        List<String> skipped = roles.stream()
                .map(Role::getName)
                .filter(n -> !addedNames.contains(n))
                .toList();

        RolesMutationResult res = new RolesMutationResult();
        res.setUserId(user.getId());
        res.setEmpNo(empNo);
        res.setAdded(addedNames);
        res.setSkipped(skipped);
        res.setNotFoundRoles(notFound);
        res.setDeletedCount(0);
        res.setAt(LocalDateTime.now());
        return res;
    }

    public RolesMutationResult removeRolesByEmpNo(String empNo, RemoveRolesRequest body) {
        if (empNo == null || empNo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "empNo required");
        }
        if (body == null || body.getRoles() == null || body.getRoles().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roles list required");
        }

        User user = userRepo.findByEmployeeEmpNo(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found by empNo: " + empNo));


        List<String> requestedNames = body.getRoles().stream()
                .filter(Objects::nonNull)
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .distinct()
                .toList();
        if (requestedNames.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "roles list empty");
        }


        List<Role> roles = roleRepo.findByNameIn(requestedNames);
        Map<String, Long> nameToId = roles.stream().collect(Collectors.toMap(Role::getName, Role::getId));
        List<String> notFound = requestedNames.stream()
                .filter(n -> !nameToId.containsKey(n))
                .toList();
        List<Long> roleIds = roles.stream().map(Role::getId).toList();

        int deleted = 0;
        if (!roleIds.isEmpty()) {

            deleted = userRoleRepo.deleteByEmpNoAndRoleIds(empNo, roleIds);
        }

        RolesMutationResult res = new RolesMutationResult();
        res.setUserId(user.getId());
        res.setEmpNo(empNo);
        res.setAdded(List.of());
        res.setSkipped(List.of());
        res.setNotFoundRoles(notFound);
        res.setDeletedCount(deleted);
        res.setAt(LocalDateTime.now());
        return res;
    }
    /** يرجّع جميع الأدوار مرتبة بالاسم تصاعديًا */
    public List<RoleItemDto> listAllRoles() {
        List<Role> roles = roleRepo.findAll(Sort.by(Sort.Direction.ASC, "name"));
        return roles.stream()
                .map(r -> new RoleItemDto(r.getId(), r.getName()))
                .toList();
    }

    @Transactional(readOnly = true)
    public RoleOptionsDto getRoleOptionsByEmpNo(String empNo) {
        User user = userRepo.findByEmployeeEmpNo(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + empNo));


        List<Role> all = roleRepo.findAll(Sort.by(Sort.Direction.ASC, "name"));

        Set<Long> assignedIds = new HashSet<>(userRoleRepo.findRoleIdsByUserId(user.getId()));

        List<RoleItemDto> assigned = all.stream()
                .filter(r -> assignedIds.contains(r.getId()))
                .map(r -> new RoleItemDto(r.getId(), r.getName()))
                .toList();

        List<RoleItemDto> available = all.stream()
                .filter(r -> !assignedIds.contains(r.getId()))
                .map(r -> new RoleItemDto(r.getId(), r.getName()))
                .toList();

        return new RoleOptionsDto(assigned, available);
    }

}

package com.RSADF.Murtakiz.modules.auth.core.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * طلب إنشاء مستخدم جديد + سجل موظف + ربط أدوار.
 */
public class CreateUserRequest {

    // ---------- بيانات المستخدم ----------
    @NotBlank(message = "username مطلوب")
    @Size(max = 100)
    private String username;

    @NotBlank(message = "password مطلوب")
    @Size(min = 6, message = "الحد الأدنى 6 حروف")
    private String password;

    private String status = "Active";

    private Long currentRegionId;

    /**
     * عدد الأيام المسموحة للحساب قبل تعطيله تلقائيًا
     * (مثلاً 3 أيام للموافقة من الأدمن)
     * يمكن تركها null ويُحدَّد الافتراضي في السيرفس.
     */
    private Integer allowedDays;

    /**
     * وقت إنشاء الطلب / الحساب (يمكن تعبئته من الباك إند)
     * لو أرسل من الواجهة يمكن تجاهله واستخدام الآن في السيرفس.
     */
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;

    // ---------- بيانات الموظف ----------
    @NotNull(message = "Employee.empNo مطلوب")
    @Size(max = 50)
    private String empNo;

    @NotBlank
    @Size(max = 200)
    private String fullNameAr;

    @NotBlank
    @Email
    @Size(max = 200)
    private String email;

    @NotBlank
    @Size(max = 200)
    private String jobTitle;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate hireDate;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    private String managerNo;

    @NotNull
    private Long subUniteId;

    // ---------- الأدوار ----------
    /**
     * أسماء الأدوار المطلوب ربطها بالمستخدم (مثلاً: ["ADMIN","USER"])
     */
    @NotEmpty(message = "rolesNames لا يجب أن تكون فارغة")
    private List<@NotBlank String> rolesNames;


    // === START GETTERS/SETTERS ===
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getCurrentRegionId() {
        return currentRegionId;
    }

    public void setCurrentRegionId(Long currentRegionId) {
        this.currentRegionId = currentRegionId;
    }

    public Integer getAllowedDays() {
        return allowedDays;
    }

    public void setAllowedDays(Integer allowedDays) {
        this.allowedDays = allowedDays;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getFullNameAr() {
        return fullNameAr;
    }

    public void setFullNameAr(String fullNameAr) {
        this.fullNameAr = fullNameAr;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public String getManagerNo() {
        return managerNo;
    }

    public void setManagerNo(String managerNo) {
        this.managerNo = managerNo;
    }

    public Long getSubUniteId() {
        return subUniteId;
    }

    public void setSubUniteId(Long subUniteId) {
        this.subUniteId = subUniteId;
    }

    public List<String> getRolesNames() {
        return rolesNames;
    }

    public void setRolesNames(List<String> rolesNames) {
        this.rolesNames = rolesNames;
    }
    // === END GETTERS/SETTERS ===
}

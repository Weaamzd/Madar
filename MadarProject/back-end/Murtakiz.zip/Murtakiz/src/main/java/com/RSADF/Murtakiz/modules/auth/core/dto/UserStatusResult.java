package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;
import java.time.LocalDateTime;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class UserStatusResult {
    private Long userId;
    private String username;
    private String oldStatus;
    private String newStatus;
    private long revokedSessions;
    private LocalDateTime changedAt;
}
package com.RSADF.Murtakiz.modules.auth.core.dto;


import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;


@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class EmployeeUserDetailsDto {
    // Employee
    private String empNo;
    private String fullNameAr;
    private String email;
    private String jobTitle;
    private LocalDate hireDate;
    private LocalDate startDate;
    private String managerNo;

    // Org
    private SubUniteMiniDto subUnite;
    private UniteMiniDto unite;

    // User
    private UserMiniDto user;

    // Roles
    private List<String> roles;

    private boolean loggedIn;
}
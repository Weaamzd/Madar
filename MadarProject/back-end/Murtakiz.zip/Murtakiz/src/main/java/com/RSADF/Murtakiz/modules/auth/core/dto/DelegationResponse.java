package com.RSADF.Murtakiz.modules.auth.core.dto;


import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import lombok.AllArgsConstructor; import lombok.Getter;

import java.time.LocalDateTime;

@Getter @AllArgsConstructor
public class DelegationResponse {
    private Long delegationId;
    private String status;
    private LocalDateTime startAt;
    private LocalDateTime endAt; // قد تكون null
    private Boolean noExpiry;
    private String delegatorEmpNo;
    private String delegateeEmpNo;
    private DelegationScopeType scopeType;
    private long scopesCount;
}

/*@Getter @AllArgsConstructor
public class DelegationResponse {
    private Long delegationId;
    private String status;
    private LocalDateTime startAt;
    private LocalDateTime endAt; // قد تكون null
    private boolean noExpiry;
    private Long delegatorUserId;
    private Long delegateeUserId;
    private DelegationScopeType scopeType;
    private long scopesCount;
}*/


/*
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DelegationResponse {
    private Long delegationId;
    private String status;            // PENDING/ACTIVE...
    private LocalDateTime startAt;
    private LocalDateTime endAt;
    private Long delegatorUserId;
    private Long delegateeUserId;
    private DelegationScopeType scopeType;
    private Long scopesCount;
}*/

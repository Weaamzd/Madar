package com.RSADF.Murtakiz.modules.kpi.api.controller;

import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiIndicatorReadingRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorReadingDto;
import com.RSADF.Murtakiz.modules.kpi.infra.service.KpiIndicatorReadingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/murtakiz/kpi/readings")
@RequiredArgsConstructor
public class KpiIndicatorReadingController {

    private final KpiIndicatorReadingService readingService;

    @PostMapping
    public ResponseEntity<KpiIndicatorReadingDto> createReading(
            @RequestBody CreateKpiIndicatorReadingRequest request
    ) {
        String actorEmpNo = SecurityUtils.actorEmpNo();
        String ctxEmpNo = SecurityUtils.ctxEmpNo();

        if (actorEmpNo == null) {
            throw new AccessDeniedException("لا يمكن تحديد رقم الموظف من التوكن (actorEmpNo = null)");
        }

        KpiIndicatorReadingDto dto = readingService.createReading(request, actorEmpNo, ctxEmpNo);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }

    @GetMapping("/by-kpi/{kpiCode}")
    public ResponseEntity<List<KpiIndicatorReadingDto>> getReadingsByKpi(
            @PathVariable String kpiCode
    ) {

        String actorEmpNo = SecurityUtils.actorEmpNo();
        if (actorEmpNo == null) {
            throw new AccessDeniedException("لا يمكن تحديد رقم الموظف من التوكن (actorEmpNo = null)");
        }

        List<KpiIndicatorReadingDto> list = readingService.getReadingsByKpiCode(kpiCode);
        return ResponseEntity.ok(list);
    }
}

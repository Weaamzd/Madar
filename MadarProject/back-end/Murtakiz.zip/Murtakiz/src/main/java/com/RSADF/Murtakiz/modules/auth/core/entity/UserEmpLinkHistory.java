package com.RSADF.Murtakiz.modules.auth.core.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "USER_EMP_LINK_HISTORY", schema = "SYS")
@Getter
@Setter
@NoArgsConstructor
public class UserEmpLinkHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LINK_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "USER_ID", nullable = false)
    private User user;

    @Column(name = "USERNAME", nullable = false, length = 100)
    private String username;

    @Column(name = "LINK_TYPE", nullable = false, length = 10) // INTERNAL | EXTERNAL
    private String linkType;

    @Column(name = "EMP_NO", length = 50)
    private String empNo;

    @Column(name = "EXT_EMP_ID", length = 50)
    private String extEmpId;

    @Column(name = "LINKED_AT", nullable = false)
    private LocalDateTime linkedAt;

    @Column(name = "UNLINKED_AT")
    private LocalDateTime unlinkedAt;

    @Column(name = "ACTION_NOTE", length = 400)
    private String actionNote;

    @Column(name = "ACTOR_EMP_NO", length = 50)
    private String actorEmpNo;
}

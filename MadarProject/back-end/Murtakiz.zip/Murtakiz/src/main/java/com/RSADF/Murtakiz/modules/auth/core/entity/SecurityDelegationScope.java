package com.RSADF.Murtakiz.modules.auth.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "SECURITY_DELEGATION_SCOPE",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_SDS__DELEG", columnList = "DELEGATION_ID"),
                @Index(name = "IX_SDS__UNITE", columnList = "UNITE_ID"),
                @Index(name = "IX_SDS__SUB",   columnList = "SUB_UNITE_ID")
        }
)
@Getter @Setter @NoArgsConstructor
public class SecurityDelegationScope {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SCOPE_ID")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATION_ID", nullable = false)
    private SecurityDelegation delegation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UNITE_ID")
    private Unite unite;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_UNITE_ID")
    private SubUnite subUnite;

    @Column(name = "REGION_CODE", length = 50)
    private String regionCode;

    @Column(name = "MODULE_KEY", length = 50)
    private String moduleKey;

    @Column(name = "PERMISSION_KEY", length = 100)
    private String permissionKey;

    // (1=READ, 2=CREATE, 4=UPDATE, 8=DELETE, 16=APPROVE, 31=ALL)
    @Column(name = "ACTIONS_MASK")
    private Long actionsMask;
}


/*
package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "SECURITY_DELEGATION_SCOPE",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_SDS__DELEG", columnList = "DELEGATION_ID"),
                @Index(name = "IX_SDS__UNITE", columnList = "UNITE_ID"),
                @Index(name = "IX_SDS__SUB",   columnList = "SUB_UNITE_ID")
        }
)
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class SecurityDelegationScope {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SCOPE_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DELEGATION_ID", nullable = false)
    private SecurityDelegation delegation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "UNITE_ID")
    private Unite unite;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_UNITE_ID")
    private SubUnite subUnite;

    @Column(name = "REGION_CODE", length = 50)
    private String regionCode;

    @Column(name = "MODULE_KEY", length = 50)
    private String moduleKey;

    @Column(name = "PERMISSION_KEY", length = 100)
    private String permissionKey; // اختياري (EMPLOYEE_READ…)

    @Column(name = "ACTIONS_MASK")
    private Long actionsMask;
}
*/

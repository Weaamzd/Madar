package com.RSADF.Murtakiz.modules.kpi.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(
        name = "KPI_STRATEGIC_GOAL",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_KPI_GOAL__OWNER_EMP", columnList = "OWNER_EMP_NO"),
                @Index(name = "IX_KPI_GOAL__OWNER_UNITE", columnList = "OWNER_UNITE_ID"),
                @Index(name = "IX_KPI_GOAL__OWNER_SUB", columnList = "OWNER_SUB_UNITE_ID")
        }
)
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class KpiStrategicGoal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "GOAL_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @Column(name = "GOAL_CODE", nullable = false, length = 50, unique = true)
    @ToString.Include
    private String code;

    @Column(name = "GOAL_NAME_AR", nullable = false, length = 300)
    @ToString.Include
    private String nameAr;

    @Column(name = "PERSPECTIVE_CODE", nullable = false, length = 50)
    private String perspectiveCode;



    @Column(name = "GOAL_TYPE", nullable = false, length = 20)
    private String goalType;


    @Column(name = "OWNER_EMP_NO", length = 50)
    private String ownerEmpNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_EMP_NO",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_STRATEGIC_GOAL__OWNER_EMP")
    )
    private Employee owner;



    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_UNITE_ID",
            foreignKey = @ForeignKey(name = "FK_KPI_STRATEGIC_GOAL__OWNER_UNITE")
    )
    private Unite ownerUnite;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_SUB_UNITE_ID",
            foreignKey = @ForeignKey(name = "FK_KPI_GOAL__OWNER_SUB")
    )
    private SubUnite ownerSubUnite;


    @Column(name = "REGION_CODE", length = 50)
    private String regionCode;


    @Column(name = "HORIZON_FROM_YEAR")
    private Integer horizonFromYear;

    @Column(name = "HORIZON_TO_YEAR")
    private Integer horizonToYear;


    @Column(name = "STATUS_CODE", length = 20)
    private String statusCode;

    @Column(name = "PROGRESS_PCT")
    private Double progressPct;

    @Column(name = "KPI_COUNT")
    private Integer kpiCount;


    @Column(name = "PARENT_GOAL_CODE", length = 50)
    private String parentGoalCode;



    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "CREATED_BY_EMP_NO", length = 50)
    private String createdByEmpNo;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "UPDATED_BY_EMP_NO", length = 50)
    private String updatedByEmpNo;
}


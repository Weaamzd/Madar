package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkExternalRequest {
    @NotBlank
    private String username;
    @NotBlank private String externalEmpId;
    private Long currentRegionId;
    private String note;
}
package com.RSADF.Murtakiz.modules.auth.core.dto;

public record EmployeeOrgInfo(
        String empNo,
        Long uniteId,
        String uniteName,
        Long subUniteId,
        String subUniteName
) {}

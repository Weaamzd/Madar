package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class EmployeeForUserCreationDto {
    // هوية الموظف
    private String empNo;
    private String fullNameAr;
    private String email;
    private String jobTitle;
    private LocalDate hireDate;
    private LocalDate startDate;
    private String managerNo;

    // SubUnite
    private Long subUniteId;
    private String subUniteCode;
    private String subUniteName;

    // Unite
    private Long uniteId;
    private String uniteCode;
    private String uniteName;

    // (اختياري) مسار هرمي مبسّط إن كان موجودًا في بياناتك
    // private Long parentSubUniteId;
    // private String parentSubUniteName;
}

package com.RSADF.Murtakiz.modules.auth.api.controller;


import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.infra.service.DelegationService;
import com.RSADF.Murtakiz.modules.auth.jwt.TokenHash;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;




import com.RSADF.Murtakiz.modules.auth.core.dto.ActingContextDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.ActingTokenResponse;
import com.RSADF.Murtakiz.modules.auth.core.dto.CreateDelegationRequest;
import com.RSADF.Murtakiz.modules.auth.core.dto.DelegationResponse;

@RestController
@RequestMapping("/api/v1/murtakiz/delegations")
@RequiredArgsConstructor
public class DelegationController {

    private final DelegationService delegationService;

    @GetMapping("/all-full")
    public ResponseEntity<java.util.List<DelegationFullDetailsDto>> allFull() {
        return ResponseEntity.ok(delegationService.listAllDelegationsFull());
    }


    @GetMapping("/all-full/search")
    public ResponseEntity<java.util.List<DelegationFullDetailsDto>> allFullFiltered(
            @RequestParam(required = false) String creatorEmpNo,
            @RequestParam(required = false) String delegatorEmpNo,
            @RequestParam(required = false) String delegateeEmpNo,
            @RequestParam(required = false) DelegationStatus status
    ) {
        return ResponseEntity.ok(
                delegationService.listDelegationsFullFiltered(creatorEmpNo, delegatorEmpNo, delegateeEmpNo, status)
        );
    }

    @GetMapping("/all-full/by-scope")
    public ResponseEntity<List<DelegationFullDetailsDto>> allFullFilteredByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String creatorEmpNo,
            @RequestParam(required = false) String delegatorEmpNo,
            @RequestParam(required = false) String delegateeEmpNo,
            @RequestParam(required = false) DelegationStatus status
    ) {
        var resp = delegationService.listDelegationsFullFilteredByScope(
                uniteId, subUniteId, creatorEmpNo, delegatorEmpNo, delegateeEmpNo, status
        );
        return ResponseEntity.ok(resp);
    }



    @SuppressWarnings("unchecked")
    private Map<String, Object> claimsFromDetails() {
        var auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getDetails() instanceof Map<?, ?> m) {
            return (Map<String, Object>) m;
        }
        return Map.of();
    }

    private String fallbackActorEmpNoFromDetails() {
        var c = claimsFromDetails();
        Object v = c.getOrDefault("actor_emp_no", c.getOrDefault("emp_no", c.get("empNo")));
        return v == null ? null : v.toString();
    }

    private Long fallbackActingSessionIdFromDetails() {
        var c = claimsFromDetails();
        Object del = c.get("delegation");
        if (del instanceof Map<?, ?> m) {
            Object sid = m.get("session_id");
            if (sid != null) {
                try {
                    return Long.valueOf(sid.toString());
                } catch (Exception ignore) {
                }
            }
        }
        return null;
    }

    private String bearer(HttpServletRequest req) {
        String h = req.getHeader(HttpHeaders.AUTHORIZATION);
        return (h != null && h.startsWith("Bearer ")) ? h.substring(7) : null;
    }


    private String getDelegatorEmpNoFromToken() {
        //  SecurityUtils (OnBehalfAuthentication)
        String empNo = SecurityUtils.actorEmpNo();
        if (empNo != null && !empNo.isBlank()) return empNo;


        empNo = fallbackActorEmpNoFromDetails();
        return (empNo == null || empNo.isBlank()) ? null : empNo;
    }

    @PostMapping
    public ResponseEntity<DelegationResponse> create(@RequestBody CreateDelegationRequest req) {
        String empNoFromToken = getDelegatorEmpNoFromToken();
        if (empNoFromToken == null || empNoFromToken.isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing actor_emp_no");
        }
        DelegationResponse resp = delegationService.create(req, empNoFromToken);
        return ResponseEntity.status(HttpStatus.CREATED).body(resp);
    }

    @PostMapping("/{id}/revoke")
    public ResponseEntity<DelegationResponse> revoke(@PathVariable Long id) {
        String actorEmpNo = getDelegatorEmpNoFromToken();
        if (actorEmpNo == null || actorEmpNo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing actor_emp_no");
        }
        DelegationResponse resp = delegationService.revoke(id, actorEmpNo);
        return ResponseEntity.ok(resp);
    }


    @GetMapping("/act/contexts")
    public ResponseEntity<List<ActingContextDto>> contexts() {
        String actorEmpNo = SecurityUtils.actorEmpNo();
        if (actorEmpNo == null || actorEmpNo.isBlank()) {
            actorEmpNo = fallbackActorEmpNoFromDetails();
        }
        if (actorEmpNo == null || actorEmpNo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing actor_emp_no");
        }
        List<ActingContextDto> list =
                Optional.ofNullable(delegationService.listActingContexts(actorEmpNo))
                        .orElseGet(Collections::emptyList);
        return ResponseEntity.ok(list);
    }


    @PostMapping("/{delegationId}/act/start")
    public ResponseEntity<ActingTokenResponse> startActing(@PathVariable Long delegationId,
                                                           HttpServletRequest request) {
        String empNo = SecurityUtils.actorEmpNo();
        if (empNo == null) empNo = fallbackActorEmpNoFromDetails();
        if (empNo == null || empNo.isBlank()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
        String ua = request.getHeader("User-Agent");
        String ip = request.getRemoteAddr();
        var token = delegationService.startActing(delegationId, empNo, ua, ip);
        return ResponseEntity.ok(token);
    }


    @PostMapping("/act/stop")
    public ResponseEntity<Void> stopActing(HttpServletRequest request) {
        Long sessionId = (SecurityUtils.ctx() == null) ? null : SecurityUtils.ctx().actingSessionId();
        if (sessionId == null) sessionId = fallbackActingSessionIdFromDetails();
        if (sessionId == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        String raw = bearer(request);
        String hash = (raw == null) ? null : TokenHash.sha256(raw);
        delegationService.stopActing(sessionId, hash);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/created-by/{empNo}")
    public ResponseEntity<List<DelegationFullDto>> listCreatedBy(@PathVariable String empNo) {
        var result = delegationService.listDelegationsCreatedBy(empNo);
        return ResponseEntity.ok(result);
    }


    @GetMapping("/by-scope/full")
    public ResponseEntity<PageResponse<DelegationFullDetailsDto>> listByScopeFull(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String creatorEmpNo,
            @RequestParam(required = false) String delegatorEmpNo,
            @RequestParam(required = false) String delegateeEmpNo,
            @RequestParam(required = false) DelegationStatus status,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = delegationService.listDelegationsByUnitOrSubFull(
                uniteId, subUniteId,
                creatorEmpNo, delegatorEmpNo, delegateeEmpNo, status,
                page, size, unpaged
        );
        return ResponseEntity.ok(resp);
    }


}
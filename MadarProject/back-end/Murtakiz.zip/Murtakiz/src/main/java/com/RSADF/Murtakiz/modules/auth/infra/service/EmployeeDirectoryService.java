package com.RSADF.Murtakiz.modules.auth.infra.service;



import com.RSADF.Murtakiz.modules.auth.core.Enums.PersonSourceType;
import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.entity.*;
import com.RSADF.Murtakiz.modules.auth.infra.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class EmployeeDirectoryService {

    private final EmployeeRepository employeeRepo;
    private final UserRepository userRepo;
    private final UserRoleRepository userRoleRepo;
    private final UserSessionRepository userSessionRepo;
    private final UserEmpLinkHistoryRepository userEmpLinkHistoryRepo;
    private final SubUniteRepository subUniteRepo;


    private final ExternalEmployeeRepository externalEmployeeRepo;


    public EmployeeDirectoryService(EmployeeRepository employeeRepo,
                                    UserRepository userRepo,
                                    UserRoleRepository userRoleRepo,
                                    UserSessionRepository userSessionRepo,
                                    ExternalEmployeeRepository externalEmployeeRepo,
                                    UserEmpLinkHistoryRepository userEmpLinkHistoryRepo,
                                    SubUniteRepository subUniteRepo) {
        this.employeeRepo = employeeRepo;
        this.userRepo = userRepo;
        this.userRoleRepo = userRoleRepo;
        this.userSessionRepo = userSessionRepo;
        this.externalEmployeeRepo = externalEmployeeRepo;
        this.userEmpLinkHistoryRepo = userEmpLinkHistoryRepo;
        this.subUniteRepo = subUniteRepo;
    }

    @Transactional(readOnly = true)
    public PageResponse<EmployeeUserDetailsDto> listEmployeeProfilesByScope(
            Long uniteId, Long subUniteId,

            String empNo,
            String fullNameAr,
            String username,
            String userStatus,                    // Active / Inactive / Suspended
            Boolean loggedIn,                     // true/false
            String uniteName,
            String subUniteName,

            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }


        List<Employee> emps = employeeRepo.findByOrgScopeWithTextFilters(
                uniteId, subUniteId,
                (empNo == null || empNo.isBlank()) ? null : empNo.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );
        if (emps.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }


        List<String> empNos = emps.stream().map(Employee::getEmpNo).toList();

        List<User> users = userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = users.stream()
                .collect(java.util.stream.Collectors.toMap(
                        u -> u.getEmployee().getEmpNo(),
                        java.util.function.Function.identity(),
                        (a, b) -> a
                ));

        List<Long> userIds = users.stream().map(User::getId).toList();
        Map<Long, List<String>> rolesByUserId;
        if (!userIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(userIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        } else {
            rolesByUserId = java.util.Collections.emptyMap();
        }

        Set<Long> activeUserIds = userIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(userIds);


        List<EmployeeUserDetailsDto> allDtos = new java.util.ArrayList<>(emps.size());
        for (Employee e : emps) {
            // org
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = null;
            if (su != null && su.getUnite() != null) {
                Unite u = su.getUnite();
                uniteDto = new UniteMiniDto(u.getId(), u.getCode(), u.getName());
            }

            // user + roles + session
            User u = userByEmpNo.get(e.getEmpNo());
            UserMiniDto userDto = null;
            List<String> roleNames = List.of();
            boolean isLoggedIn = false;

            if (u != null) {
                userDto = new UserMiniDto(
                        u.getId(),
                        u.getUsername(),
                        u.getStatus(),
                        u.getLastLoginAt(),
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
                );
                roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
                isLoggedIn = activeUserIds.contains(u.getId());
            }

            EmployeeUserDetailsDto dto = new EmployeeUserDetailsDto();
            dto.setEmpNo(e.getEmpNo());
            dto.setFullNameAr(e.getFullNameAr());
            dto.setEmail(e.getEmail());
            dto.setJobTitle(e.getJobTitle());
            dto.setHireDate(e.getHireDate());
            dto.setStartDate(e.getStartDate());
            dto.setManagerNo(e.getManagerNo());
            dto.setSubUnite(subDto);
            dto.setUnite(uniteDto);
            dto.setUser(userDto);
            dto.setRoles(roleNames);
            dto.setLoggedIn(isLoggedIn);

            allDtos.add(dto);
        }


        java.util.function.Predicate<EmployeeUserDetailsDto> pf = d -> true;

        if (username != null && !username.isBlank()) {
            String x = username.trim().toLowerCase();
            pf = pf.and(d -> d.getUser() != null && d.getUser().getUsername() != null
                    && d.getUser().getUsername().toLowerCase().contains(x));
        }
        if (userStatus != null && !userStatus.isBlank()) {
            String st = userStatus.trim();
            pf = pf.and(d -> d.getUser() != null && st.equalsIgnoreCase(d.getUser().getStatus()));
        }
        if (loggedIn != null) {
            pf = pf.and(d -> loggedIn.equals(d.isLoggedIn()));
        }


        List<EmployeeUserDetailsDto> filtered = allDtos.stream().filter(pf).toList();

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(filtered, filtered.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, filtered.size());
            int to   = Math.min(from + s, filtered.size());
            List<EmployeeUserDetailsDto> slice = filtered.subList(from, to);
            int totalPages = (int) Math.ceil(filtered.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, filtered.size(), totalPages, p, s, last);
        }
    }




    @Transactional(readOnly = true)
    public PageResponse<EmployeeUserDetailsDto> listAllEmployeeProfiles(

            String empNo,
            String fullNameAr,
            String username,
            String userStatus,     // Active / Inactive / Suspended
            Boolean loggedIn,      // true/false
            String uniteName,
            String subUniteName,

            Integer page,          // 0-based
            Integer size,
            Boolean unpaged
    ) {

        List<Employee> emps = employeeRepo.findAllWithOrgFiltered(
                (empNo == null || empNo.isBlank()) ? null : empNo.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );
        if (emps.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }


        List<String> empNos = emps.stream().map(Employee::getEmpNo).toList();
        List<User> users = userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = users.stream()
                .collect(java.util.stream.Collectors.toMap(
                        u -> u.getEmployee().getEmpNo(),
                        java.util.function.Function.identity(),
                        (a, b) -> a
                ));


        List<Long> userIds = users.stream().map(User::getId).toList();

        Map<Long, List<String>> rolesByUserId = java.util.Collections.emptyMap();
        if (!userIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(userIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        }

        Set<Long> activeUserIds = userIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(userIds);


        List<EmployeeUserDetailsDto> full = new java.util.ArrayList<>(emps.size());
        for (Employee e : emps) {

            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = null;
            if (su != null && su.getUnite() != null) {
                Unite u = su.getUnite();
                uniteDto = new UniteMiniDto(u.getId(), u.getCode(), u.getName());
            }

            // user + roles + session
            User u = userByEmpNo.get(e.getEmpNo());
            UserMiniDto userDto = null;
            List<String> roleNames = List.of();
            boolean isLoggedIn = false;

            if (u != null) {
                userDto = new UserMiniDto(
                        u.getId(),
                        u.getUsername(),
                        u.getStatus(),
                        u.getLastLoginAt(),
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
                );
                roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
                isLoggedIn = activeUserIds.contains(u.getId());
            }

            EmployeeUserDetailsDto dto = new EmployeeUserDetailsDto();
            dto.setEmpNo(e.getEmpNo());
            dto.setFullNameAr(e.getFullNameAr());
            dto.setEmail(e.getEmail());
            dto.setJobTitle(e.getJobTitle());
            dto.setHireDate(e.getHireDate());
            dto.setStartDate(e.getStartDate());
            dto.setManagerNo(e.getManagerNo());
            dto.setSubUnite(subDto);
            dto.setUnite(uniteDto);
            dto.setUser(userDto);
            dto.setRoles(roleNames);
            dto.setLoggedIn(isLoggedIn);

            full.add(dto);
        }

        java.util.function.Predicate<EmployeeUserDetailsDto> pf = d -> true;

        if (username != null && !username.isBlank()) {
            String x = username.trim().toLowerCase();
            pf = pf.and(d -> d.getUser() != null && d.getUser().getUsername() != null
                    && d.getUser().getUsername().toLowerCase().contains(x));
        }
        if (userStatus != null && !userStatus.isBlank()) {
            String st = userStatus.trim();
            pf = pf.and(d -> d.getUser() != null && st.equalsIgnoreCase(d.getUser().getStatus()));
        }
        if (loggedIn != null) {
            pf = pf.and(d -> loggedIn.equals(d.isLoggedIn()));
        }

        List<EmployeeUserDetailsDto> filtered = full.stream().filter(pf).toList();

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(filtered, filtered.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, filtered.size());
            int to   = Math.min(from + s, filtered.size());
            List<EmployeeUserDetailsDto> slice = filtered.subList(from, to);
            int totalPages = (int) Math.ceil(filtered.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, filtered.size(), totalPages, p, s, last);
        }
    }

    public List<EmployeeUserDetailsDto> listAllEmployeeProfiles() {

        List<Employee> emps = employeeRepo.findAllWithOrg();
        if (emps.isEmpty()) return List.of();


        List<String> empNos = emps.stream().map(Employee::getEmpNo).toList();


        List<User> users = userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = users.stream()
                .collect(java.util.stream.Collectors.toMap(
                        u -> u.getEmployee().getEmpNo(),
                        java.util.function.Function.identity(),
                        (a, b) -> a
                ));


        List<Long> userIds = users.stream().map(User::getId).toList();

        Map<Long, List<String>> rolesByUserId = java.util.Collections.emptyMap();
        if (!userIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(userIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        }

        Set<Long> activeUserIds = userIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(userIds);


        List<EmployeeUserDetailsDto> result = new java.util.ArrayList<>(emps.size());
        for (Employee e : emps) {
            // org
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = null;
            if (su != null && su.getUnite() != null) {
                Unite u = su.getUnite();
                uniteDto = new UniteMiniDto(u.getId(), u.getCode(), u.getName());
            }

            // user + roles + session
            User u = userByEmpNo.get(e.getEmpNo());
            UserMiniDto userDto = null;
            List<String> roleNames = List.of();
            boolean loggedIn = false;

            if (u != null) {
                userDto = new UserMiniDto(
                        u.getId(),
                        u.getUsername(),
                        u.getStatus(),
                        u.getLastLoginAt(),
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                        u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
                );
                roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
                loggedIn = activeUserIds.contains(u.getId());
            }

            // dto
            EmployeeUserDetailsDto dto = new EmployeeUserDetailsDto();
            dto.setEmpNo(e.getEmpNo());
            dto.setFullNameAr(e.getFullNameAr());
            dto.setEmail(e.getEmail());
            dto.setJobTitle(e.getJobTitle());
            dto.setHireDate(e.getHireDate());
            dto.setStartDate(e.getStartDate());
            dto.setManagerNo(e.getManagerNo());
            dto.setSubUnite(subDto);
            dto.setUnite(uniteDto);
            dto.setUser(userDto);
            dto.setRoles(roleNames);
            dto.setLoggedIn(loggedIn);

            result.add(dto);
        }

        return result;
    }

    public EmployeeUserDetailsDto getEmployeeProfile(String empNo) {
        Employee e = employeeRepo.findById(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee غير موجود: " + empNo));

        SubUnite su = e.getSubUnite();
        SubUniteMiniDto subDto = null;
        UniteMiniDto uniteDto = null;
        if (su != null) {
            subDto = new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            Unite u = su.getUnite();
            if (u != null) {
                uniteDto = new UniteMiniDto(u.getId(), u.getCode(), u.getName());
            }
        }

        UserMiniDto userDto = null;
        List<String> roleNames = List.of();
        boolean loggedIn = false;

        var userOpt = userRepo.findByEmployeeEmpNoWithRegion(empNo);
        if (userOpt.isPresent()) {
            User u = userOpt.get();
            userDto = new UserMiniDto(
                    u.getId(),
                    u.getUsername(),
                    u.getStatus(),
                    u.getLastLoginAt(),
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
            );

            roleNames = userRoleRepo.findRoleNamesByUserId(u.getId());


            loggedIn = userSessionRepo.hasActiveSession(u.getId(), LocalDateTime.now());
        }

        EmployeeUserDetailsDto dto = new EmployeeUserDetailsDto();
        dto.setEmpNo(e.getEmpNo());
        dto.setFullNameAr(e.getFullNameAr());
        dto.setEmail(e.getEmail());
        dto.setJobTitle(e.getJobTitle());
        dto.setHireDate(e.getHireDate());
        dto.setStartDate(e.getStartDate());
        dto.setManagerNo(e.getManagerNo());
        dto.setSubUnite(subDto);
        dto.setUnite(uniteDto);
        dto.setUser(userDto);
        dto.setRoles(roleNames);
        dto.setLoggedIn(loggedIn);

        return dto;
    }


    public ExternalEmployeeUserProfileDto getExternalEmployeeProfile(String extEmpId) {

        ExternalEmployee ee = externalEmployeeRepo.findOneWithOrgById(extEmpId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "ExternalEmployee غير موجود: " + extEmpId));


        SubUniteMiniDto subDto = null;
        UniteMiniDto uniteDto = null;

        SubUnite su = ee.getSubUniteId();
        if (su != null) {
            subDto = new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());

            Unite u = su.getUnite();
            if (u != null) {
                uniteDto = new UniteMiniDto(u.getId(), u.getCode(), u.getName());
            }
        }

        ExternalEmployeeDetailsDto details = ExternalEmployeeDetailsDto.builder()
                .id(ee.getId())
                .fullNameAr(ee.getFullNameAr())
                .fullNameEn(ee.getFullNameEn())
                .email(ee.getEmail())
                .phone(ee.getPhone())
                .organizationName(ee.getOrganizationName())
                .jobTitle(ee.getJobTitle())
                .collaborationType(ee.getCollaborationType())
                .startDate(ee.getStartDate())
                .endDate(ee.getEndDate())
                .status(ee.getStatus())
                .notes(ee.getNotes())
                .managerEmpNo(ee.getEmpManagerNo() != null ? ee.getEmpManagerNo().getEmpNo() : null)
                .subUnite(subDto)
                .unite(uniteDto)
                .build();

        UserMiniDto userDto = null;
        List<String> roleNames = List.of();
        boolean loggedIn = false;

        var userOpt = userRepo.findByExternalEmpIdWithRegion(extEmpId);
        if (userOpt.isPresent()) {
            User u = userOpt.get();

            userDto = new UserMiniDto(
                    u.getId(),
                    u.getUsername(),
                    u.getStatus(),
                    u.getLastLoginAt(),
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                    u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
            );

            roleNames = userRoleRepo.findRoleNamesByUserId(u.getId());
            loggedIn  = userSessionRepo.hasActiveSession(u.getId(), LocalDateTime.now());
        }


        return ExternalEmployeeUserProfileDto.builder()
                .details(details)
                .user(userDto)
                .roles(roleNames)
                .loggedIn(loggedIn)
                .build();
    }

    public List<ManagerNameDto> listAllManagers() {
        List<ManagerNameProjection> rows = employeeRepo.findAllManagers();
        return rows.stream()
                .map(p -> new ManagerNameDto(p.getEmpNo(), p.getEmpFullNameAr()))
                .toList();
    }

    public EmployeeOrgInfo getOrgByEmpNo(String empNo) {
        var emp = employeeRepo.findById(empNo)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee not found: " + empNo));

        var sub = emp.getSubUnite();
        var unite = (sub != null) ? sub.getUnite() : null;

        return new EmployeeOrgInfo(
                empNo,
                unite != null ? unite.getId() : null,
                unite != null ? unite.getName() : null,
                sub != null ? sub.getId() : null,
                sub != null ? sub.getName() : null
        );
    }

    @Transactional(readOnly = true)
    public PageResponse<UnifiedPersonDetailsDto> listPeopleProfilesByScope(
            Long uniteId, Long subUniteId,

            String empNoOrExtId,
            String fullNameAr,
            String username,
            String userStatus,                   // Active / Inactive / Suspended
            Boolean loggedIn,                    // true/false
            String uniteName,
            String subUniteName,
            String managerNo,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }


        List<Employee> internal = employeeRepo.findByOrgScopeWithTextFilters(
                uniteId, subUniteId,
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(), // كـ empNo
                (fullNameAr   == null || fullNameAr.isBlank())   ? null : fullNameAr.trim(),
                (uniteName    == null || uniteName.isBlank())    ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        List<ExternalEmployee> external = externalEmployeeRepo.findByOrgScopeWithTextFilters(
                uniteId, subUniteId,
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(), // كـ extEmpId
                (fullNameAr   == null || fullNameAr.isBlank())   ? null : fullNameAr.trim(),
                (uniteName    == null || uniteName.isBlank())    ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        if (managerNo != null && !managerNo.isBlank()) {
            String mNo = managerNo.trim();

            internal = internal.stream()
                    .filter(e -> mNo.equals(e.getManagerNo()))
                    .toList();
            external = external.stream()
                    .filter(ee -> ee.getEmpManagerNo() != null && mNo.equals(ee.getEmpManagerNo().getEmpNo()))
                    .toList();
        }

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<String> empNos = internal.stream().map(Employee::getEmpNo).toList();
        List<User> usersByEmp = empNos.isEmpty()
                ? List.of()
                : userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = usersByEmp.stream()
                .collect(java.util.stream.Collectors.toMap(
                        User::getEmpNo,
                        java.util.function.Function.identity(),
                        (a, b) -> a
                ));

        List<String> extIds = external.stream().map(ExternalEmployee::getId).toList();
        List<User> usersByExt = extIds.isEmpty()
                ? List.of()
                : userRepo.findAllByExternalEmpIdInWithRegion(extIds);
        Map<String, User> userByExtId = usersByExt.stream()
                .collect(java.util.stream.Collectors.toMap(
                        User::getExternalEmpId,
                        java.util.function.Function.identity(),
                        (a, b) -> a
                ));


        List<Long> allUserIds = java.util.stream.Stream.concat(usersByEmp.stream(), usersByExt.stream())
                .map(User::getId).distinct().toList();

        Map<Long, List<String>> rolesByUserId;
        if (!allUserIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(allUserIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        } else {
            rolesByUserId = java.util.Collections.emptyMap();
        }

        Set<Long> activeUserIds = allUserIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(allUserIds);

        List<UnifiedPersonDetailsDto> unified = new java.util.ArrayList<>(internal.size() + external.size());

        for (Employee e : internal) {
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            User u = userByEmpNo.get(e.getEmpNo());
            UserMiniDto userDto = null;
            List<String> roleNames = List.of();
            boolean isLoggedIn = false;
            String regionCode = null, regionDbKey = null;

            if (u != null) {
                userDto = new UserMiniDto(
                        u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)
                );
                roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
                isLoggedIn = activeUserIds.contains(u.getId());
                if (u.getCurrentRegion() != null) {
                    regionCode = u.getCurrentRegion().getRegionCode();
                    regionDbKey = u.getCurrentRegion().getRegionDbKey();
                }
            }

            UnifiedPersonDetailsDto dto = UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.INTERNAL)
                    .empNo(e.getEmpNo())
                    .extEmpId(null)
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(userDto)
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .hasUser(userDto != null)
                    .build();

            unified.add(dto);
        }

        for (ExternalEmployee ee : external) {
            SubUnite su = ee.getSubUniteId();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            User u = userByExtId.get(ee.getId());
            UserMiniDto userDto = null;
            List<String> roleNames = List.of();
            boolean isLoggedIn = false;
            String regionCode = null, regionDbKey = null;

            if (u != null) {
                userDto = new UserMiniDto(
                        u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null),
                        (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)
                );
                roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
                isLoggedIn = activeUserIds.contains(u.getId());
                if (u.getCurrentRegion() != null) {
                    regionCode = u.getCurrentRegion().getRegionCode();
                    regionDbKey = u.getCurrentRegion().getRegionDbKey();
                }
            }

            UnifiedPersonDetailsDto dto = UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.EXTERNAL)
                    .empNo(null)
                    .extEmpId(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .jobTitle(ee.getJobTitle())
                    .organizationName(ee.getOrganizationName())
                    .collaborationType(ee.getCollaborationType())
                    .externalStartDate(ee.getStartDate())
                    .externalEndDate(ee.getEndDate())
                    .externalStatus(ee.getStatus())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(userDto)
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .hasUser(userDto != null)
                    .build();

            unified.add(dto);
        }

        java.util.function.Predicate<UnifiedPersonDetailsDto> pf = d -> true;

        if (username != null && !username.isBlank()) {
            String x = username.trim().toLowerCase();
            pf = pf.and(d -> d.getUser() != null && d.getUser().getUsername() != null
                    && d.getUser().getUsername().toLowerCase().contains(x));
        }
        if (userStatus != null && !userStatus.isBlank()) {
            String st = userStatus.trim();
            pf = pf.and(d -> d.getUser() != null && st.equalsIgnoreCase(d.getUser().getStatus()));
        }
        if (loggedIn != null) {
            pf = pf.and(d -> loggedIn.equals(d.isLoggedIn()));
        }

        List<UnifiedPersonDetailsDto> filtered = unified.stream().filter(pf).toList();

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(filtered, filtered.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, filtered.size());
            int to   = Math.min(from + s, filtered.size());
            List<UnifiedPersonDetailsDto> slice = filtered.subList(from, to);
            int totalPages = (int) Math.ceil(filtered.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, filtered.size(), totalPages, p, s, last);
        }
    }


    @Transactional(readOnly = true)
    public PageResponse<UnifiedPersonDetailsDto> listAllPeopleProfiles(
            String empNo,
            String fullNameAr,
            String username,
            String userStatus,
            Boolean loggedIn,
            String uniteName,
            String subUniteName,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {

        List<Employee> internal = employeeRepo.findAllWithOrgFiltered(
                (empNo == null || empNo.isBlank()) ? null : empNo.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        List<ExternalEmployee> external = externalEmployeeRepo.findAllWithOrgFiltered(
                (empNo == null || empNo.isBlank()) ? null : empNo.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }


        List<String> empNos = internal.stream().map(Employee::getEmpNo).toList();
        List<User> usersByEmp = empNos.isEmpty()
                ? List.of()
                : userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = usersByEmp.stream().collect(
                java.util.stream.Collectors.toMap(
                        User::getEmpNo, java.util.function.Function.identity(), (a, b) -> a));

        List<String> extIds = external.stream().map(ExternalEmployee::getId).toList();
        List<User> usersByExt = extIds.isEmpty()
                ? List.of()
                : userRepo.findAllByExternalEmpIdInWithRegion(extIds);
        Map<String, User> userByExtId = usersByExt.stream().collect(
                java.util.stream.Collectors.toMap(
                        User::getExternalEmpId, java.util.function.Function.identity(), (a, b) -> a));


        internal = internal.stream()
                .filter(e -> userByEmpNo.containsKey(e.getEmpNo()))
                .toList();

        external = external.stream()
                .filter(ee -> userByExtId.containsKey(ee.getId()))
                .toList();


        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }


        List<Long> allUserIds = java.util.stream.Stream.concat(usersByEmp.stream(), usersByExt.stream())
                .map(User::getId).distinct().toList();

        Map<Long, List<String>> rolesByUserId;
        if (!allUserIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(allUserIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        } else {
            rolesByUserId = java.util.Collections.emptyMap();
        }

        Set<Long> activeUserIds = allUserIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(allUserIds);

        List<UnifiedPersonDetailsDto> unified = new java.util.ArrayList<>(internal.size() + external.size());

        for (Employee e : internal) {
            User u = userByEmpNo.get(e.getEmpNo());
            if (u == null) continue;

            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            UserMiniDto userDto = new UserMiniDto(
                    u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)
            );
            List<String> roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
            boolean isLoggedIn = activeUserIds.contains(u.getId());
            String regionCode = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null);
            String regionDbKey = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null);

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.INTERNAL)
                    .empNo(e.getEmpNo())
                    .extEmpId(null)
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(userDto)
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .build());
        }

        // خارجي
        for (ExternalEmployee ee : external) {
            User u = userByExtId.get(ee.getId());
            if (u == null) continue;

            SubUnite su = ee.getSubUniteId();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            UserMiniDto userDto = new UserMiniDto(
                    u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null),
                    (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)
            );
            List<String> roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
            boolean isLoggedIn = activeUserIds.contains(u.getId());
            String regionCode = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null);
            String regionDbKey = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null);

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.EXTERNAL)
                    .empNo(null)
                    .extEmpId(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .jobTitle(ee.getJobTitle())
                    .organizationName(ee.getOrganizationName())
                    .collaborationType(ee.getCollaborationType())
                    .externalStartDate(ee.getStartDate())
                    .externalEndDate(ee.getEndDate())
                    .externalStatus(ee.getStatus())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(userDto)
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .build());
        }

        java.util.function.Predicate<UnifiedPersonDetailsDto> pf = d -> true;

        if (username != null && !username.isBlank()) {
            String x = username.trim().toLowerCase();
            pf = pf.and(d -> d.getUser() != null && d.getUser().getUsername() != null
                    && d.getUser().getUsername().toLowerCase().contains(x));
        }
        if (userStatus != null && !userStatus.isBlank()) {
            String st = userStatus.trim();
            pf = pf.and(d -> d.getUser() != null && st.equalsIgnoreCase(d.getUser().getStatus()));
        }
        if (loggedIn != null) {
            pf = pf.and(d -> loggedIn.equals(d.isLoggedIn()));
        }

        List<UnifiedPersonDetailsDto> filtered = unified.stream().filter(pf).toList();

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(filtered, filtered.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, filtered.size());
            int to   = Math.min(from + s, filtered.size());
            List<UnifiedPersonDetailsDto> slice = filtered.subList(from, to);
            int totalPages = (int) Math.ceil(filtered.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, filtered.size(), totalPages, p, s, last);
        }
    }


    @Transactional(readOnly = true)
    public PageResponse<UnifiedPersonDetailsDto> listAllPeopleProfilesByScope(
            Long uniteId, Long subUniteId,
            String empNoOrExtId,
            String fullNameAr,
            String username,
            String userStatus,
            Boolean loggedIn,
            String uniteName,
            String subUniteName,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }

        List<Employee> internal = employeeRepo.findByOrgScopeWithTextFilters(
                uniteId, subUniteId,
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(),
                (fullNameAr   == null || fullNameAr.isBlank())   ? null : fullNameAr.trim(),
                (uniteName    == null || uniteName.isBlank())    ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );


        List<ExternalEmployee> external = externalEmployeeRepo.findByOrgScopeWithTextFilters(
                uniteId, subUniteId,
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(),
                (fullNameAr   == null || fullNameAr.isBlank())   ? null : fullNameAr.trim(),
                (uniteName    == null || uniteName.isBlank())    ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<String> empNos = internal.stream().map(Employee::getEmpNo).toList();
        List<User> usersByEmp = empNos.isEmpty() ? List.of() : userRepo.findAllByEmployeeEmpNoInWithRegion(empNos);
        Map<String, User> userByEmpNo = usersByEmp.stream().collect(
                java.util.stream.Collectors.toMap(User::getEmpNo, java.util.function.Function.identity(), (a,b)->a));

        List<String> extIds = external.stream().map(ExternalEmployee::getId).toList();
        List<User> usersByExt = extIds.isEmpty() ? List.of() : userRepo.findAllByExternalEmpIdInWithRegion(extIds);
        Map<String, User> userByExtId = usersByExt.stream().collect(
                java.util.stream.Collectors.toMap(User::getExternalEmpId, java.util.function.Function.identity(), (a,b)->a));

        internal = internal.stream().filter(e -> userByEmpNo.containsKey(e.getEmpNo())).toList();
        external = external.stream().filter(ee -> userByExtId.containsKey(ee.getId())).toList();

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<Long> allUserIds = java.util.stream.Stream.concat(usersByEmp.stream(), usersByExt.stream())
                .map(User::getId).distinct().toList();

        Map<Long, List<String>> rolesByUserId;
        if (!allUserIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(allUserIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        } else {
            rolesByUserId = java.util.Collections.emptyMap();
        }

        Set<Long> activeUserIds = allUserIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(allUserIds);

        List<UnifiedPersonDetailsDto> unified = new java.util.ArrayList<>(internal.size() + external.size());

        for (Employee e : internal) {
            User u = userByEmpNo.get(e.getEmpNo());
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            List<String> roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
            boolean isLoggedIn = activeUserIds.contains(u.getId());
            String regionCode = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null);
            String regionDbKey = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null);

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.INTERNAL)
                    .empNo(e.getEmpNo())
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(new UserMiniDto(
                            u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                            (u.getCurrentRegion()!=null?u.getCurrentRegion().getId():null),
                            regionCode, regionDbKey))
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .build());
        }

        for (ExternalEmployee ee : external) {
            User u = userByExtId.get(ee.getId());
            SubUnite su = ee.getSubUniteId();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            List<String> roleNames = rolesByUserId.getOrDefault(u.getId(), List.of());
            boolean isLoggedIn = activeUserIds.contains(u.getId());
            String regionCode = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null);
            String regionDbKey = (u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null);

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.EXTERNAL)
                    .extEmpId(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .jobTitle(ee.getJobTitle())
                    .organizationName(ee.getOrganizationName())
                    .collaborationType(ee.getCollaborationType())
                    .externalStartDate(ee.getStartDate())
                    .externalEndDate(ee.getEndDate())
                    .externalStatus(ee.getStatus())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(new UserMiniDto(
                            u.getId(), u.getUsername(), u.getStatus(), u.getLastLoginAt(),
                            (u.getCurrentRegion()!=null?u.getCurrentRegion().getId():null),
                            regionCode, regionDbKey))
                    .roles(roleNames)
                    .loggedIn(isLoggedIn)
                    .regionCode(regionCode)
                    .regionDbKey(regionDbKey)
                    .build());
        }

        java.util.function.Predicate<UnifiedPersonDetailsDto> pf = d -> true;
        if (username != null && !username.isBlank()) {
            String x = username.trim().toLowerCase();
            pf = pf.and(d -> d.getUser() != null && d.getUser().getUsername() != null
                    && d.getUser().getUsername().toLowerCase().contains(x));
        }
        if (userStatus != null && !userStatus.isBlank()) {
            String st = userStatus.trim();
            pf = pf.and(d -> d.getUser() != null && st.equalsIgnoreCase(d.getUser().getStatus()));
        }
        if (loggedIn != null) {
            pf = pf.and(d -> loggedIn.equals(d.isLoggedIn()));
        }
        List<UnifiedPersonDetailsDto> filtered = unified.stream().filter(pf).toList();

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(filtered, filtered.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, filtered.size());
            int to   = Math.min(from + s, filtered.size());
            List<UnifiedPersonDetailsDto> slice = filtered.subList(from, to);
            int totalPages = (int) Math.ceil(filtered.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, filtered.size(), totalPages, p, s, last);
        }
    }

    public List<ManagerNameDto> listManagersByScope(Long uniteId, Long subUniteId) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }
        var rows = employeeRepo.findManagersByOrgScope(uniteId, subUniteId);
        return rows.stream()
                .map(p -> new ManagerNameDto(p.getEmpNo(), p.getEmpFullNameAr()))
                .toList();
    }


    @Transactional(readOnly = true)
    public PageResponse<UserWithHistoryDto> listUnlinkedUsersWithHistory(
            String username,
            String userStatus,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {

        List<User> users = userRepo.findAllUnlinkedUsersWithRegion(
                (username == null || username.isBlank()) ? null : username.trim(),
                (userStatus == null || userStatus.isBlank()) ? null : userStatus.trim().toLowerCase()
        );

        if (users.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<UserWithHistoryDto> dtos = new java.util.ArrayList<>(users.size());
        for (User u : users) {
            List<UserEmpLinkHistory> hist = userEmpLinkHistoryRepo
                    .findAllByUserIdOrderByLinkedAtAsc(u.getId());

            List<UserLinkEventDto> events = hist.stream().map(h -> UserLinkEventDto.builder()
                            .linkType(h.getLinkType())
                            .empNo(h.getEmpNo())
                            .extEmpId(h.getExtEmpId())
                            .linkedAt(h.getLinkedAt())
                            .unlinkedAt(h.getUnlinkedAt())
                            .actionNote(h.getActionNote())
                            .actorEmpNo(h.getActorEmpNo())
                            .build())
                    .toList();

            dtos.add(UserWithHistoryDto.builder()
                    .userId(u.getId())
                    .username(u.getUsername())
                    .status(u.getStatus())
                    .lastLoginAt(u.getLastLoginAt())
                    .currentRegionId(u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null)
                    .regionCode(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null)
                    .regionDbKey(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)
                    .linkHistory(events)
                    .build());
        }

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(dtos, dtos.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, dtos.size());
            int to   = Math.min(from + s, dtos.size());
            List<UserWithHistoryDto> slice = dtos.subList(from, to);
            int totalPages = (int) Math.ceil(dtos.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, dtos.size(), totalPages, p, s, last);
        }
    }


    @Transactional(readOnly = true)
    public PageResponse<UnifiedPersonDetailsDto> listAllPeopleWithoutUser(
            String empNoOrExtId,
            String fullNameAr,
            String uniteName,
            String subUniteName,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {

        List<Employee> internal = employeeRepo.findInternalWithoutUserWithOrgFiltered(
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        List<ExternalEmployee> external = externalEmployeeRepo.findExternalWithoutUserWithOrgFiltered(
                (empNoOrExtId == null || empNoOrExtId.isBlank()) ? null : empNoOrExtId.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim(),
                (uniteName == null || uniteName.isBlank()) ? null : uniteName.trim(),
                (subUniteName == null || subUniteName.isBlank()) ? null : subUniteName.trim()
        );

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }


        List<UnifiedPersonDetailsDto> unified = new java.util.ArrayList<>(internal.size() + external.size());

        for (Employee e : internal) {
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.INTERNAL)
                    .empNo(e.getEmpNo())
                    .extEmpId(null)
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(null)
                    .roles(List.of())
                    .loggedIn(false)
                    .regionCode(null)
                    .regionDbKey(null)
                    .build());
        }

        for (ExternalEmployee ee : external) {
            SubUnite su = ee.getSubUniteId();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.EXTERNAL)
                    .empNo(null)
                    .extEmpId(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .jobTitle(ee.getJobTitle())
                    .organizationName(ee.getOrganizationName())
                    .collaborationType(ee.getCollaborationType())
                    .externalStartDate(ee.getStartDate())
                    .externalEndDate(ee.getEndDate())
                    .externalStatus(ee.getStatus())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(null)
                    .roles(List.of())
                    .loggedIn(false)
                    .regionCode(null)
                    .regionDbKey(null)
                    .build());
        }

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(unified, unified.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, unified.size());
            int to   = Math.min(from + s, unified.size());
            List<UnifiedPersonDetailsDto> slice = unified.subList(from, to);
            int totalPages = (int) Math.ceil(unified.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, unified.size(), totalPages, p, s, last);
        }
    }


    @Transactional(readOnly = true)
    public PageResponse<UnifiedPersonDetailsDto> listAllPeopleWithoutUserByScope(
            Long uniteId,
            Long subUniteId,
            String empNoOrExtIdOrName,
            String fullNameAr,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }

        List<Employee> internal = employeeRepo.findInternalWithoutUserInScope(
                uniteId,
                subUniteId,
                (empNoOrExtIdOrName == null || empNoOrExtIdOrName.isBlank()) ? null : empNoOrExtIdOrName.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim()
        );


        List<ExternalEmployee> external = externalEmployeeRepo.findExternalWithoutUserInScope(
                uniteId,
                subUniteId,
                (empNoOrExtIdOrName == null || empNoOrExtIdOrName.isBlank()) ? null : empNoOrExtIdOrName.trim(),
                (fullNameAr == null || fullNameAr.isBlank()) ? null : fullNameAr.trim()
        );

        if (internal.isEmpty() && external.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<UnifiedPersonDetailsDto> unified = new java.util.ArrayList<>(internal.size() + external.size());

        for (Employee e : internal) {
            SubUnite su = e.getSubUnite();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.INTERNAL)
                    .empNo(e.getEmpNo())
                    .extEmpId(null)
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(null)
                    .roles(List.of())
                    .loggedIn(false)
                    .regionCode(null)
                    .regionDbKey(null)
                    .build());
        }

        for (ExternalEmployee ee : external) {
            SubUnite su = ee.getSubUniteId();
            SubUniteMiniDto subDto = (su == null) ? null : new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
            UniteMiniDto uniteDto = (su != null && su.getUnite() != null)
                    ? new UniteMiniDto(su.getUnite().getId(), su.getUnite().getCode(), su.getUnite().getName())
                    : null;

            unified.add(UnifiedPersonDetailsDto.builder()
                    .sourceType(PersonSourceType.EXTERNAL)
                    .empNo(null)
                    .extEmpId(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .jobTitle(ee.getJobTitle())
                    .organizationName(ee.getOrganizationName())
                    .collaborationType(ee.getCollaborationType())
                    .externalStartDate(ee.getStartDate())
                    .externalEndDate(ee.getEndDate())
                    .externalStatus(ee.getStatus())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .user(null)
                    .roles(List.of())
                    .loggedIn(false)
                    .regionCode(null)
                    .regionDbKey(null)
                    .build());
        }

        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(unified, unified.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, unified.size());
            int to   = Math.min(from + s, unified.size());
            List<UnifiedPersonDetailsDto> slice = unified.subList(from, to);
            int totalPages = (int) Math.ceil(unified.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, unified.size(), totalPages, p, s, last);
        }
    }



    @Transactional(readOnly = true)
    public PageResponse<UserWithHistoryDto> listUsersWithHistory(
            String username,       // contains
            String userStatus,     // Active/Inactive/Suspended
            String linkedState,    // UNLINKED / LINKED / ALL(null)
            Integer page,
            Integer size,
            Boolean unpaged
    ) {

        List<User> users = userRepo.findAllByFiltersWithRegion(
                (username == null || username.isBlank()) ? null : username.trim(),
                (userStatus == null || userStatus.isBlank()) ? null : userStatus.trim().toLowerCase(),
                (linkedState == null || linkedState.isBlank()) ? null : linkedState.trim().toUpperCase()
        );

        if (users.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<Long> userIds = users.stream().map(User::getId).toList();

        Map<Long, List<String>> rolesByUserId = java.util.Collections.emptyMap();
        if (!userIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(userIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        }

        Set<Long> activeUserIds = userIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(userIds);

        Map<String, ExternalEmployee> extById = java.util.Collections.emptyMap();
        List<String> extIds = users.stream()
                .map(User::getExternalEmpId)
                .filter(java.util.Objects::nonNull)
                .distinct()
                .toList();
        if (!extIds.isEmpty()) {
            List<ExternalEmployee> exts = externalEmployeeRepo.findByIdIn(extIds);
            extById = exts.stream().collect(java.util.stream.Collectors.toMap(
                    ExternalEmployee::getId, java.util.function.Function.identity()));
        }

        List<UserWithHistoryDto> dtos = new java.util.ArrayList<>(users.size());
        for (User u : users) {

            List<UserEmpLinkHistory> hist = userEmpLinkHistoryRepo
                    .findAllByUserIdOrderByLinkedAtAsc(u.getId());

            List<UserLinkEventDto> events = hist.stream().map(h -> UserLinkEventDto.builder()
                            .linkType(h.getLinkType())
                            .empNo(h.getEmpNo())
                            .extEmpId(h.getExtEmpId())
                            .linkedAt(h.getLinkedAt())
                            .unlinkedAt(h.getUnlinkedAt())
                            .actionNote(h.getActionNote())
                            .actorEmpNo(h.getActorEmpNo())
                            .build())
                    .toList();


            String empNo = u.getEmpNo();
            String empName = (u.getEmployee() != null) ? u.getEmployee().getFullNameAr() : null;

            String extId = u.getExternalEmpId();
            String extName = null;
            if (u.getExternalEmployee() != null) {
                extName = u.getExternalEmployee().getFullNameAr();
            } else if (extId != null && extById.containsKey(extId)) {
                extName = extById.get(extId).getFullNameAr();
            }

            String email = null;
            String jobTitle = null;
            if (u.getEmployee() != null) {
                email = u.getEmployee().getEmail();
                jobTitle = u.getEmployee().getJobTitle();
            } else if (u.getExternalEmployee() != null) {
                email = u.getExternalEmployee().getEmail();
                jobTitle = u.getExternalEmployee().getJobTitle();
            }


            dtos.add(UserWithHistoryDto.builder()
                    .userId(u.getId())
                    .username(u.getUsername())
                    .status(u.getStatus())
                    .lastLoginAt(u.getLastLoginAt())

                    .empNo(empNo)
                    .empFullNameAr(empName)
                    .externalEmpId(extId)
                    .externalFullNameAr(extName)

                    .email(email)
                    .jobTitle(jobTitle)

                    .currentRegionId(u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null)
                    .regionCode(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null)
                    .regionDbKey(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)

                    .roles(rolesByUserId.getOrDefault(u.getId(), List.of()))
                    .loggedIn(activeUserIds.contains(u.getId()))

                    .linkHistory(events)
                    .build());
        }


        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(dtos, dtos.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, dtos.size());
            int to   = Math.min(from + s, dtos.size());
            List<UserWithHistoryDto> slice = dtos.subList(from, to);
            int totalPages = (int) Math.ceil(dtos.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, dtos.size(), totalPages, p, s, last);
        }
    }

    @Transactional(readOnly = true)
    public UserWithHistoryDto getUserWithHistory(String username) {
        if (username == null || username.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "username مطلوب");
        }
        String uName = username.trim();


        User u = userRepo.findOneWithEverythingByUsername(uName)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User غير موجود: " + uName));


        List<String> roles = userRoleRepo.findRoleNamesByUserId(u.getId());


        boolean loggedIn = userSessionRepo.hasActiveSession(u.getId(), LocalDateTime.now());


        List<UserEmpLinkHistory> hist = userEmpLinkHistoryRepo
                .findAllByUserIdOrderByLinkedAtAsc(u.getId());

        List<UserLinkEventDto> events = hist.stream().map(h -> UserLinkEventDto.builder()
                        .linkType(h.getLinkType())
                        .empNo(h.getEmpNo())
                        .extEmpId(h.getExtEmpId())
                        .linkedAt(h.getLinkedAt())
                        .unlinkedAt(h.getUnlinkedAt())
                        .actionNote(h.getActionNote())
                        .actorEmpNo(h.getActorEmpNo())
                        .build())
                .toList();

        String empNo     = u.getEmpNo();
        String empName   = (u.getEmployee() != null) ? u.getEmployee().getFullNameAr() : null;

        String extId     = u.getExternalEmpId();
        String extName   = (u.getExternalEmployee() != null) ? u.getExternalEmployee().getFullNameAr() : null;

        String email     = null;
        String jobTitle  = null;
        if (u.getEmployee() != null) {
            email    = u.getEmployee().getEmail();
            jobTitle = u.getEmployee().getJobTitle();
        } else if (u.getExternalEmployee() != null) {
            email    = u.getExternalEmployee().getEmail();
            jobTitle = u.getExternalEmployee().getJobTitle();
        }

        return UserWithHistoryDto.builder()
                .userId(u.getId())
                .username(u.getUsername())
                .status(u.getStatus())
                .lastLoginAt(u.getLastLoginAt())

                .empNo(empNo)
                .empFullNameAr(empName)
                .externalEmpId(extId)
                .externalFullNameAr(extName)

                .email(email)
                .jobTitle(jobTitle)

                .currentRegionId(u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null)
                .regionCode(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null)
                .regionDbKey(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)

                .roles(roles)
                .loggedIn(loggedIn)
                .linkHistory(events)
                .build();
    }


    @Transactional(readOnly = true)
    public PageResponse<UserWithHistoryDto> listUsersWithHistoryByScope(
            Long uniteId,
            Long subUniteId,
            String username,
            String userStatus,
            String linkedState,   // UNLINKED / LINKED / ALL
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }


        List<User> users = userRepo.findAllByFiltersWithRegionAndOrgScope(
                uniteId,
                subUniteId,
                (username == null || username.isBlank()) ? null : username.trim(),
                (userStatus == null || userStatus.isBlank()) ? null : userStatus.trim().toLowerCase(),
                (linkedState == null || linkedState.isBlank()) ? null : linkedState.trim().toUpperCase()
        );

        if (users.isEmpty()) {
            boolean last = true;
            if (Boolean.TRUE.equals(unpaged) || page == null || size == null) {
                return new PageResponse<>(List.of(), 0, 1, null, null, last);
            } else {
                return new PageResponse<>(List.of(), 0, 0, page, size, last);
            }
        }

        List<Long> userIds = users.stream().map(User::getId).toList();

        Map<Long, List<String>> rolesByUserId = java.util.Collections.emptyMap();
        if (!userIds.isEmpty()) {
            var rows = userRoleRepo.findRoleNamesByUserIdIn(userIds);
            rolesByUserId = rows.stream().collect(
                    java.util.stream.Collectors.groupingBy(
                            RoleNameByUserProjection::getUserId,
                            java.util.stream.Collectors.mapping(RoleNameByUserProjection::getRoleName, java.util.stream.Collectors.toList())
                    )
            );
        }

        Set<Long> activeUserIds = userIds.isEmpty()
                ? java.util.Collections.emptySet()
                : userSessionRepo.findActiveUserIds(userIds);


        Map<String, ExternalEmployee> extById = java.util.Collections.emptyMap();
        List<String> extIds = users.stream()
                .map(User::getExternalEmpId)
                .filter(java.util.Objects::nonNull)
                .distinct()
                .toList();
        if (!extIds.isEmpty()) {
            List<ExternalEmployee> exts = externalEmployeeRepo.findByIdIn(extIds);
            extById = exts.stream().collect(java.util.stream.Collectors.toMap(
                    ExternalEmployee::getId, java.util.function.Function.identity()));
        }


        List<UserWithHistoryDto> dtos = new java.util.ArrayList<>(users.size());
        for (User u : users) {
            var hist = userEmpLinkHistoryRepo.findAllByUserIdOrderByLinkedAtAsc(u.getId());
            var events = hist.stream().map(h -> UserLinkEventDto.builder()
                            .linkType(h.getLinkType())
                            .empNo(h.getEmpNo())
                            .extEmpId(h.getExtEmpId())
                            .linkedAt(h.getLinkedAt())
                            .unlinkedAt(h.getUnlinkedAt())
                            .actionNote(h.getActionNote())
                            .actorEmpNo(h.getActorEmpNo())
                            .build())
                    .toList();

            String empNo = u.getEmpNo();
            String empName = (u.getEmployee() != null) ? u.getEmployee().getFullNameAr() : null;

            String extId = u.getExternalEmpId();
            String extName = null;
            if (u.getExternalEmployee() != null) {
                extName = u.getExternalEmployee().getFullNameAr();
            } else if (extId != null && extById.containsKey(extId)) {
                extName = extById.get(extId).getFullNameAr();
            }

            String email = null;
            String jobTitle = null;
            if (u.getEmployee() != null) {
                email = u.getEmployee().getEmail();
                jobTitle = u.getEmployee().getJobTitle();
            } else if (u.getExternalEmployee() != null) {
                email = u.getExternalEmployee().getEmail();
                jobTitle = u.getExternalEmployee().getJobTitle();
            }

            dtos.add(UserWithHistoryDto.builder()
                    .userId(u.getId())
                    .username(u.getUsername())
                    .status(u.getStatus())
                    .lastLoginAt(u.getLastLoginAt())

                    .empNo(empNo)
                    .empFullNameAr(empName)
                    .externalEmpId(extId)
                    .externalFullNameAr(extName)

                    .email(email)
                    .jobTitle(jobTitle)

                    .currentRegionId(u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null)
                    .regionCode(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null)
                    .regionDbKey(u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null)

                    .roles(rolesByUserId.getOrDefault(u.getId(), List.of()))
                    .loggedIn(activeUserIds.contains(u.getId()))

                    .linkHistory(events)
                    .build());
        }


        boolean doUnpaged = Boolean.TRUE.equals(unpaged) || page == null || size == null || page < 0 || size <= 0;
        if (doUnpaged) {
            return new PageResponse<>(dtos, dtos.size(), 1, null, null, true);
        } else {
            int p = page;
            int s = size;
            int from = Math.min(p * s, dtos.size());
            int to   = Math.min(from + s, dtos.size());
            List<UserWithHistoryDto> slice = dtos.subList(from, to);
            int totalPages = (int) Math.ceil(dtos.size() / (double) s);
            boolean last = (p + 1) >= totalPages;
            return new PageResponse<>(slice, dtos.size(), totalPages, p, s, last);
        }
    }

    @Transactional(readOnly = true)
    public EmployeeOrgWithManagersDto getOrgWithManagersByEmpNo(String empNo) {
        if (empNo == null || empNo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "empNo مطلوب");
        }


        Employee emp = employeeRepo.findByIdWithSubUnite(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee غير موجود: " + empNo));

        SubUnite mySub = emp.getSubUnite();
        Unite myUnite = (mySub != null) ? mySub.getUnite() : null;

        long directCount = employeeRepo.countDirectReports(empNo);


        boolean hasNoManagerAbove = (emp.getManagerNo() == null);


        boolean isManager = (directCount > 0) || hasNoManagerAbove;

        EmployeeOrgWithManagersDto out = EmployeeOrgWithManagersDto.builder()
                .empNo(emp.getEmpNo())
                .fullNameAr(emp.getFullNameAr())
                .uniteId(myUnite != null ? myUnite.getId() : null)
                .uniteName(myUnite != null ? myUnite.getName() : null)
                .subUniteId(mySub != null ? mySub.getId() : null)
                .subUniteName(mySub != null ? mySub.getName() : null)
                .isManager(isManager)
                .directReportsCount((int) directCount)
                .subordinateManagers(List.of())
                .build();


        if (!isManager) {
            out.setManagerLevel("NONE");
            return out;
        }


        boolean isSubUnitTopLevel = (mySub != null && mySub.getParent() == null);

        if (isSubUnitTopLevel) {

            out.setManagerLevel("MAIN_UNIT_MANAGER");


            List<SubUnite> allDescendants = new ArrayList<>();
            List<Long> frontier = List.of(mySub.getId());

            while (!frontier.isEmpty()) {
                List<SubUnite> children = subUniteRepo.findByParent_IdIn(frontier);
                if (children.isEmpty()) {
                    break;
                }

                allDescendants.addAll(children);
                frontier = children.stream()
                        .map(SubUnite::getId)
                        .collect(Collectors.toList());
            }


            List<ManagerSummaryDto> mlist = new ArrayList<>();
            for (SubUnite s : allDescendants) {
                List<Employee> managersInChild = employeeRepo.findManagersBySubUniteId(s.getId());
                for (Employee m : managersInChild) {
                    mlist.add(ManagerSummaryDto.builder()
                            .empNo(m.getEmpNo())
                            .fullNameAr(m.getFullNameAr())
                            .subUniteId(s.getId())
                            .subUniteName(s.getName())
                            .build());
                }
            }

            out.setSubordinateManagers(mlist);
            return out;

        } else {

            out.setManagerLevel("SUB_UNIT_MANAGER");

            Long mySubId = mySub != null ? mySub.getId() : null;
            if (mySubId == null) {

                out.setSubordinateManagers(List.of());
                return out;
            }

            boolean hasChildren = subUniteRepo.existsByParent_Id(mySubId);
            if (!hasChildren) {

                out.setSubordinateManagers(List.of());
                return out;
            }


            List<SubUnite> childSubs = subUniteRepo.findByParent_Id(mySubId);
            List<ManagerSummaryDto> mlist = new ArrayList<>();
            for (SubUnite child : childSubs) {
                List<Employee> managersInChild = employeeRepo.findManagersBySubUniteId(child.getId());
                for (Employee m : managersInChild) {
                    mlist.add(ManagerSummaryDto.builder()
                            .empNo(m.getEmpNo())
                            .fullNameAr(m.getFullNameAr())
                            .subUniteId(child.getId())
                            .subUniteName(child.getName())
                            .build());
                }
            }

            out.setSubordinateManagers(mlist);
            return out;
        }
    }


/*

    @Transactional(readOnly = true)
    public EmployeeOrgWithManagersDto getOrgWithManagersByEmpNo(String empNo) {
        if (empNo == null || empNo.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "empNo مطلوب");
        }

        Employee emp = employeeRepo.findByIdWithSubUnite(empNo)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Employee غير موجود: " + empNo));

        SubUnite mySub = emp.getSubUnite();
        Unite myUnite = (mySub != null) ? mySub.getUnite() : null;


        long directCount = employeeRepo.countDirectReports(empNo);

        boolean hasNoManagerAbove = (emp.getManagerNo() == null);

        boolean isManager = (directCount > 0) || hasNoManagerAbove;
        //boolean isManager = directCount > 0;

        EmployeeOrgWithManagersDto out = EmployeeOrgWithManagersDto.builder()
                .empNo(emp.getEmpNo())
                .fullNameAr(emp.getFullNameAr())
                .uniteId(myUnite != null ? myUnite.getId() : null)
                .uniteName(myUnite != null ? myUnite.getName() : null)
                .subUniteId(mySub != null ? mySub.getId() : null)
                .subUniteName(mySub != null ? mySub.getName() : null)
                .isManager(isManager)
                .directReportsCount((int) directCount)
                .subordinateManagers(List.of())
                .build();

        if (!isManager) {
            out.setManagerLevel("NONE");
            return out;
        }


        boolean isSubUnitTopLevel = (mySub != null && mySub.getParent() == null);
        if (isSubUnitTopLevel) {
            out.setManagerLevel("MAIN_UNIT_MANAGER");


            List<SubUnite> childSubs = subUniteRepo.findByParent_Id(mySub.getId());
            List<ManagerSummaryDto> mlist = new ArrayList<>();

            for (SubUnite child : childSubs) {

                List<Employee> managersInChild = employeeRepo.findManagersBySubUniteId(child.getId());
                for (Employee m : managersInChild) {
                    mlist.add(ManagerSummaryDto.builder()
                            .empNo(m.getEmpNo())
                            .fullNameAr(m.getFullNameAr())
                            .subUniteId(child.getId())
                            .subUniteName(child.getName())
                            .build());
                }
            }
            out.setSubordinateManagers(mlist);
            return out;
        } else {

            out.setManagerLevel("SUB_UNIT_MANAGER");


            Long mySubId = mySub != null ? mySub.getId() : null;
            if (mySubId == null) {

                out.setSubordinateManagers(List.of());
                return out;
            }

            boolean hasChildren = subUniteRepo.existsByParent_Id(mySubId);
            if (!hasChildren) {

                out.setSubordinateManagers(List.of());
                return out;
            }


            List<SubUnite> childSubs = subUniteRepo.findByParent_Id(mySubId);
            List<ManagerSummaryDto> mlist = new ArrayList<>();
            for (SubUnite child : childSubs) {
                List<Employee> managersInChild = employeeRepo.findManagersBySubUniteId(child.getId());
                for (Employee m : managersInChild) {
                    mlist.add(ManagerSummaryDto.builder()
                            .empNo(m.getEmpNo())
                            .fullNameAr(m.getFullNameAr())
                            .subUniteId(child.getId())
                            .subUniteName(child.getName())
                            .build());
                }
            }
            out.setSubordinateManagers(mlist);
            return out;
        }
    }
*/


}

package com.RSADF.Murtakiz.modules.auth.core.entity;



import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(
        name = "CURRENT_REGION",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_CURRENT_REGION__UNITE", columnList = "UNITE_ID")
        }
)
@Getter @Setter @NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class CurrentRegion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CURRENT_REGION_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @Column(name = "REGION_CODE", nullable = false, length = 50)
    @ToString.Include
    private String regionCode;

    @Column(name = "REGION_DB_KEY", nullable = false, length = 50)
    @ToString.Include
    private String regionDbKey;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(
            name = "UNITE_ID",
            nullable = false,
            foreignKey = @ForeignKey(name = "FK_CURRENT_REGION__UNITE")
    )
    @ToString.Exclude
    private Unite unite;
}




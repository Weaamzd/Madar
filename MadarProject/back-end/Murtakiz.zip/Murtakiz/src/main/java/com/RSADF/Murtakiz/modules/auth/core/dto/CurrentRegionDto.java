package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.Data;

@Data
public class CurrentRegionDto {
    private Long id;
    private String regionCode;
    private String regionDbKey;

    // معلومات مساعدة عن الوحدة
    private Long uniteId;
    private String uniteCode;
    private String uniteName;
}

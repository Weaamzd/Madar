package com.RSADF.Murtakiz.modules.auth.infra.service;



import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.core.entity.UserSession;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserSessionRepository;

import com.RSADF.Murtakiz.modules.auth.jwt.JwtProperties;
import com.RSADF.Murtakiz.modules.auth.jwt.TokenHash;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.SecretKey;
import io.jsonwebtoken.security.Keys;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class JwtService {

    private final SecretKey key;
    private final String issuer;
    private final long accessMinutes;

    private final UserSessionRepository sessionRepo;

    public JwtService(
            JwtProperties props,
            UserSessionRepository sessionRepo
    ) {
        byte[] raw = io.jsonwebtoken.io.Decoders.BASE64.decode(props.getSecretBase64());
        this.key = Keys.hmacShaKeyFor(raw);
        this.issuer = props.getIssuer();
        this.accessMinutes = props.getAccessTokenMinutes();
        this.sessionRepo = sessionRepo;
    }

    /** للاستخدام العام – يبني توكن بمدة محددة ويُضمّن JTI */
    public String generateToken(String subject, Map<String, Object> claims, long minutes) {
        Instant now = Instant.now();
        Instant exp = now.plus(minutes, ChronoUnit.MINUTES);
        String jti = UUID.randomUUID().toString();

        return Jwts.builder()
                .setIssuer(issuer)
                .setSubject(subject)
                .setId(jti)
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(exp))
                .addClaims(claims)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }


    public String generateAccessToken(String subject, Map<String, Object> claims) {
        return generateToken(subject, claims, accessMinutes);
    }


    public Claims parseAndValidate(String token) {
        return Jwts.parserBuilder()
                .requireIssuer(issuer)
                .setAllowedClockSkewSeconds(60)
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public boolean isExpired(Claims c) {
        return c.getExpiration() != null && c.getExpiration().before(new Date());
    }




    public record AuthTokenDto(String accessToken, LocalDateTime expiresAt, String jti) {}


    @Transactional
    public AuthTokenDto generateAccessTokenAndPersistSession(
            User user,
            Map<String, Object> extraClaims,
            HttpServletRequest request
    ) {

        Instant now = Instant.now();
        Instant exp = now.plus(accessMinutes, ChronoUnit.MINUTES);
        String jti = UUID.randomUUID().toString();

        Map<String, Object> claims = new HashMap<>();
        if (extraClaims != null) claims.putAll(extraClaims);
        claims.putIfAbsent("username", user.getUsername());

        String token = Jwts.builder()
                .setIssuer(issuer)
                .setSubject(String.valueOf(user.getId()))
                .setId(jti)
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(exp))
                .addClaims(claims)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();


        String tokenHash = TokenHash.sha256(token);

        UserSession session = new UserSession();
        session.setUser(user);
        session.setAccessTokenHash(tokenHash);
        session.setAccessTokenJti(jti);
        session.setCreatedAt(LocalDateTime.ofInstant(now, ZoneId.systemDefault()));
        session.setExpiresAt(LocalDateTime.ofInstant(exp, ZoneId.systemDefault()));
        session.setUserAgent(request.getHeader("User-Agent"));
        session.setIpAddress(resolveClientIp(request));

        sessionRepo.save(session);

        return new AuthTokenDto(
                token,
                LocalDateTime.ofInstant(exp, ZoneId.systemDefault()),
                jti
        );
    }


    @Transactional
    public AuthTokenDto generateAccessTokenAndPersistSession(
            User user,
            Map<String, Object> extraClaims,
            String userAgent,
            String ipAddress
    ) {
        Instant now = Instant.now();
        Instant exp = now.plus(accessMinutes, ChronoUnit.MINUTES);
        String jti = UUID.randomUUID().toString();

        Map<String, Object> claims = new HashMap<>();
        if (extraClaims != null) claims.putAll(extraClaims);
        claims.putIfAbsent("username", user.getUsername());

        String token = Jwts.builder()
                .setIssuer(issuer)
                .setSubject(String.valueOf(user.getId()))
                .setId(jti)
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(exp))
                .addClaims(claims)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();

        String tokenHash = TokenHash.sha256(token);

        UserSession session = new UserSession();
        session.setUser(user);
        session.setAccessTokenHash(tokenHash);
        session.setAccessTokenJti(jti);
        session.setCreatedAt(LocalDateTime.ofInstant(now, ZoneId.systemDefault()));
        session.setExpiresAt(LocalDateTime.ofInstant(exp, ZoneId.systemDefault()));
        session.setUserAgent(userAgent);
        session.setIpAddress(ipAddress);

        sessionRepo.save(session);

        return new AuthTokenDto(
                token,
                LocalDateTime.ofInstant(exp, ZoneId.systemDefault()),
                jti
        );
    }


    private static String resolveClientIp(HttpServletRequest request) {
        String xff = request.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isBlank()) {

            return xff.split(",")[0].trim();
        }
        String realIp = request.getHeader("X-Real-IP");
        if (realIp != null && !realIp.isBlank()) return realIp.trim();
        return request.getRemoteAddr();
    }
}


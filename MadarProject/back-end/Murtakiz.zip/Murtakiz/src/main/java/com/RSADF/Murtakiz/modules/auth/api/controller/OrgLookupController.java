package com.RSADF.Murtakiz.modules.auth.api.controller;



import com.RSADF.Murtakiz.modules.auth.core.dto.SubUniteDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.SubUniteTreeDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.UniteDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.UniteMiniDto;
import com.RSADF.Murtakiz.modules.auth.infra.service.OrgLookupService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

import static com.RSADF.Murtakiz.Roles.EMPLOYEE;
import static com.RSADF.Murtakiz.Roles.SYSTEM_ADMIN;

@RestController
@RequestMapping("/api/v1/murtakiz/org")
public class OrgLookupController {

    private final OrgLookupService svc;

    public OrgLookupController(OrgLookupService svc) {
        this.svc = svc;
    }


    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")
    @GetMapping("/sub-units/{id}")
    public ResponseEntity<SubUniteDto> getSubUnite(@PathVariable Long id) {
        return ResponseEntity.ok(svc.getSubUnite(id));
    }


    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")

    @GetMapping("/unites/{id}")
    public ResponseEntity<UniteDto> getUnite(@PathVariable Long id) {
        return ResponseEntity.ok(svc.getUnite(id));
    }



    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")

    @GetMapping("/unites/{uniteId}/sub-units")
    public ResponseEntity<List<SubUniteDto>> listDirectUnderUnite(@PathVariable Long uniteId) {
        @SuppressWarnings("unchecked")
        List<SubUniteDto> result = (List<SubUniteDto>)(List<?>)
                svc.listSubUnitesUnderUnite(uniteId, 1);
        return ResponseEntity.ok(result);
    }


    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")

    @GetMapping("/unites/{uniteId}/sub-units/tree")
    public ResponseEntity<List<SubUniteTreeDto>> getUniteSubtree(
            @PathVariable Long uniteId,
            @RequestParam(name = "depth", required = false, defaultValue = "4") Integer depth) {

        int d = Math.max(2, Math.min(depth, 10));
        @SuppressWarnings("unchecked")
        List<SubUniteTreeDto> tree = (List<SubUniteTreeDto>)(List<?>)
                svc.listSubUnitesUnderUnite(uniteId, d);
        return ResponseEntity.ok(tree);
    }



    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")

    @GetMapping("/sub-units/{subUniteId}/children")
    public ResponseEntity<List<SubUniteDto>> listDirectChildren(@PathVariable Long subUniteId) {
        SubUniteTreeDto rootWithKids = svc.getSubUniteSubtree(subUniteId, 2);

        List<SubUniteDto> children = rootWithKids.getChildren().stream().map(child -> {
            SubUniteDto dto = new SubUniteDto();
            dto.setId(child.getId());
            dto.setCode(child.getCode());
            dto.setName(child.getName());
            dto.setUniteId(child.getUniteId());
            dto.setUniteTypeId(child.getUniteTypeId());
            dto.setUniteTypeName(child.getUniteTypeName());
            dto.setParentSubUniteId(child.getParentSubUniteId());
            dto.setHasChildren(child.isHasChildren());
            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(children);
    }



    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + EMPLOYEE + "')")

    @GetMapping("/sub-units/{subUniteId}/subtree")
    public ResponseEntity<SubUniteTreeDto> getSubUniteSubtree(
            @PathVariable Long subUniteId,
            @RequestParam(name = "depth", required = false, defaultValue = "4") Integer depth) {

        int d = Math.max(1, Math.min(depth, 10));
        return ResponseEntity.ok(svc.getSubUniteSubtree(subUniteId, d));
    }

    /** أدمن أو موظف */

    @GetMapping("/unites")
    public ResponseEntity<List<UniteDto>> listAllUnites() {
        return ResponseEntity.ok(svc.listAllUnites());
    }

    /** أدمن أو موظف */

    @GetMapping("/unites/mini")
    public ResponseEntity<List<UniteMiniDto>> listAllUnitesMini() {
        return ResponseEntity.ok(svc.listAllUnitesMini());
    }


}

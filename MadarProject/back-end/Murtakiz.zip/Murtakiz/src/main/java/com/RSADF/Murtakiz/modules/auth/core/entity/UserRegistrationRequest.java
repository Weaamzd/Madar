package com.RSADF.Murtakiz.modules.auth.core.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "USER_REGISTRATION_REQUESTS", schema = "SYS")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserRegistrationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "REQUEST_ID")
    private Long id;

    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "PARENT_REQUEST_ID")
    private UserRegistrationRequest parent;

    /*@Column(name = "PARENT_REQUEST_ID")
    private Long parentRequestId;*/

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    private List<UserRegistrationRequest> children = new ArrayList<>();

    @Column(name = "CURRENT_STAGE", length = 30)
    private String currentStage;

    @Column(name = "STAGE_STATUS", length = 20)
    private String stageStatus;

    @Column(name = "WAITING_FOR_EMP_NO", length = 50)
    private String waitingForEmpNo;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "NOTES", length = 500)
    private String notes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID", insertable = false, updatable = false)
    private User user;
}

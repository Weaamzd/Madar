package com.RSADF.Murtakiz.modules.kpi.core.entity;

import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(
        name = "KPI_INDICATOR",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_KPI_INDICATOR__GOAL", columnList = "GOAL_CODE"),
                @Index(name = "IX_KPI_INDICATOR__OWNER_EMP", columnList = "OWNER_EMP_NO"),
                @Index(name = "IX_KPI_INDICATOR__UNITE", columnList = "OWNER_UNITE_ID"),
                @Index(name = "IX_KPI_INDICATOR__SUB_UNITE", columnList = "OWNER_SUB_UNITE_ID"),
                @Index(name = "IX_KPI_INDICATOR__PARENT", columnList = "PARENT_KPI_CODE")
        }
)
@Getter
@Setter
@NoArgsConstructor
public class KpiIndicator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "KPI_ID")
    private Long id;

    @Column(name = "KPI_CODE", nullable = false, length = 50, unique = true)
    private String code;

    @Column(name = "KPI_NAME_AR", nullable = false, length = 300)
    private String nameAr;

    @Column(name = "KPI_DESC_AR", length = 500)
    private String descAr;

    // يرتبط بـ KPI_STRATEGIC_GOAL(GOAL_CODE)
    @Column(name = "GOAL_CODE", length = 50)
    private String goalCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "GOAL_CODE",
            referencedColumnName = "GOAL_CODE",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_INDICATOR__GOAL")
    )
    private KpiStrategicGoal goal;

    @Column(name = "PERSPECTIVE_CODE", nullable = false, length = 50)
    private String perspectiveCode;

    // OWNER_EMP_NO → EMPLOYEES(EMP_NO)
    @Column(name = "OWNER_EMP_NO", length = 50)
    private String ownerEmpNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_EMP_NO",
            referencedColumnName = "EMP_NO",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_INDICATOR__OWNER_EMP")
    )
    private Employee owner;

    // OWNER_UNITE_ID → UNITE(UNITE_ID)
    @Column(name = "OWNER_UNITE_ID")
    private Long ownerUniteId;


    // العلاقة (نخليها read-only من ناحية العمود عشان ما يحدث تعارض)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_UNITE_ID",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_INDICATOR__OWNER_UNITE")
    )
    private Unite ownerUnite;



    // OWNER_SUB_UNITE_ID → SUB_UNITE(SUB_UNITE_ID)
    @Column(name = "OWNER_SUB_UNITE_ID")
    private Long ownerSubUniteId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "OWNER_SUB_UNITE_ID",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_INDICATOR__OWNER_SUB")
    )
    private SubUnite ownerSubUnite;

    // TARGET_VALUE NUMBER(18,4)
    @Column(name = "TARGET_VALUE", precision = 18, scale = 4)
    private BigDecimal targetValue;

    @Column(name = "TARGET_SOURCE", length = 200)
    private String targetSource;

    @Column(name = "MEANS_TO_ACHIEVE_TARGET", length = 500)
    private String meansToAchieveTarget;

    // BASELINE_VALUE NUMBER(18,4)
    @Column(name = "BASELINE_VALUE", precision = 18, scale = 4)
    private BigDecimal baselineValue;

    @Column(name = "MEASUREMENT_UNIT", length = 50)
    private String measurementUnit;

    // POLARITY_CODE: HIGHER_BETTER / LOWER_BETTER / RANGE_BEST
    @Column(name = "POLARITY_CODE", length = 30)
    private String polarityCode;

    @Column(name = "MEASUREMENT_METHOD", length = 500)
    private String measurementMethod;

    @Column(name = "FORMULA_TEXT", length = 1000)
    private String formulaText;

    // FREQUENCY_CODE: MONTHLY / QUARTERLY / ...
    @Column(name = "FREQUENCY_CODE", length = 30)
    private String frequencyCode;

    // CURRENT_STATUS: ON_TRACK / AT_RISK / OFF_TRACK
    @Column(name = "CURRENT_STATUS", length = 20)
    private String currentStatus;

    // LAST_UPDATE_DATE DATE
    @Column(name = "LAST_UPDATE_DATE")
    private LocalDate lastUpdateDate;

    // IS_MAIN CHAR(1) 'Y' / 'N'
    @Column(name = "IS_MAIN", nullable = false, length = 1)
    private String isMain;   // يفضل تخليها 'Y' أو 'N'

    // PARENT_KPI_CODE → KPI_INDICATOR(KPI_CODE)
    @Column(name = "PARENT_KPI_CODE", length = 50)
    private String parentKpiCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "PARENT_KPI_CODE",
            referencedColumnName = "KPI_CODE",
            insertable = false,
            updatable = false,
            foreignKey = @ForeignKey(name = "FK_KPI_INDICATOR__PARENT")
    )
    private KpiIndicator parent;

    // IS_ACTIVE CHAR(1) 'Y' / 'N'
    @Column(name = "IS_ACTIVE", nullable = false, length = 1)
    private String isActive;

    @Column(name = "CREATED_AT", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "CREATED_BY_EMP_NO", length = 50)
    private String createdByEmpNo;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "UPDATED_BY_EMP_NO", length = 50)
    private String updatedByEmpNo;
}

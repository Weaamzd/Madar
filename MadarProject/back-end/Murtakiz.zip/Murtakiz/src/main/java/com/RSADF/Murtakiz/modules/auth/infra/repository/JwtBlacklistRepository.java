package com.RSADF.Murtakiz.modules.auth.infra.repository;


import com.RSADF.Murtakiz.modules.auth.core.entity.JwtBlacklist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JwtBlacklistRepository extends JpaRepository<JwtBlacklist, Long> {
    boolean existsByTokenHash(String tokenHash);
    boolean existsByJti(String jti);
}

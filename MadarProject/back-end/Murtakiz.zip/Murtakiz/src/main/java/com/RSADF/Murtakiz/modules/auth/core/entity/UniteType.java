package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(
        name = "UNITE_TYPE",
        schema = "SYS",
        uniqueConstraints = @UniqueConstraint(name = "UQ_UNITE_TYPE__NAME", columnNames = "UNITE_TYPE_NAME")
)
@Getter @Setter @NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class UniteType {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UNITE_TYPE_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @Column(name = "UNITE_TYPE_NAME", nullable = false, length = 100)
    @ToString.Include
    private String name;


/*    @OneToMany(mappedBy = "uniteType", fetch = FetchType.LAZY)
    @ToString.Exclude
    private Set<Unite> unites = new HashSet<>();

    @OneToMany(mappedBy = "uniteType", fetch = FetchType.LAZY)
    @ToString.Exclude
    private Set<SubUnite> subUnites = new HashSet<>();*/
}

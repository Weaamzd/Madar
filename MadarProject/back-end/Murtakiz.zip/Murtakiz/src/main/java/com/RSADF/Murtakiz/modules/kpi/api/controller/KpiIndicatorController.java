package com.RSADF.Murtakiz.modules.kpi.api.controller;

import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiIndicatorRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorDto;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiIndicatorDto2;
import com.RSADF.Murtakiz.modules.kpi.infra.service.KpiIndicatorService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/murtakiz/kpi/indicators")
@RequiredArgsConstructor
public class KpiIndicatorController {

    private final KpiIndicatorService indicatorService;


  /*  @GetMapping
    public List<KpiIndicatorDto> getAllIndicators() {
        return indicatorService.getAllIndicators2();
    }*/




    @GetMapping("/debug-ids")
    public List<Object[]> debugIds() {
        return indicatorService.debugIds();
    }


    @PostMapping
    public ResponseEntity<KpiIndicatorDto> createIndicator(
            @RequestBody CreateKpiIndicatorRequest request
    ) {
        String actorEmpNo = SecurityUtils.actorEmpNo();
        String ctxEmpNo = SecurityUtils.ctxEmpNo();

        if (actorEmpNo == null) {
            throw new AccessDeniedException("لا يمكن تحديد رقم الموظف من التوكن (actorEmpNo = null)");
        }

        KpiIndicatorDto dto = indicatorService.createIndicator(request, actorEmpNo, ctxEmpNo);

        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }


    @GetMapping("/by-unite2")
    public List<KpiIndicatorDto2> getAllIndicators() {
        return indicatorService.getAllIndicators();
    }

    @GetMapping
    public ResponseEntity<Page<KpiIndicatorDto>> searchIndicators(
            @RequestParam(required = false) String goalCode,
            @RequestParam(required = false) Long ownerUniteId,
            @RequestParam(required = false) Long ownerSubUniteId,
            @RequestParam(required = false) String isMain,
            @RequestParam(required = false) String isActive,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        Page<KpiIndicatorDto> result = indicatorService.searchIndicators(
                goalCode,
                ownerUniteId,
                ownerSubUniteId,
                isMain,
                isActive,
                page,
                size,
                unpaged
        );
        return ResponseEntity.ok(result);
    }


    @GetMapping("/main/by-unite")
    public ResponseEntity<Page<KpiIndicatorDto>> getMainByUnite(
            @RequestParam Long ownerUniteId,
            @RequestParam(required = false) String goalCode,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        Page<KpiIndicatorDto> result = indicatorService.getMainIndicatorsByUnite(
                ownerUniteId,
                goalCode,
                page,
                size,
                unpaged
        );
        return ResponseEntity.ok(result);
    }


    @GetMapping("/main/by-sub-unite")
    public ResponseEntity<Page<KpiIndicatorDto>> getMainBySubUnite(
            @RequestParam Long ownerSubUniteId,
            @RequestParam(required = false) String goalCode,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        Page<KpiIndicatorDto> result = indicatorService.getMainIndicatorsBySubUnite(
                ownerSubUniteId,
                goalCode,
                page,
                size,
                unpaged
        );
        return ResponseEntity.ok(result);
    }


    @GetMapping("/{parentCode}/children")
    public ResponseEntity<List<KpiIndicatorDto>> getChildren(
            @PathVariable("parentCode") String parentCode
    ) {
        List<KpiIndicatorDto> children = indicatorService.getChildrenIndicators(parentCode);
        return ResponseEntity.ok(children);
    }
}


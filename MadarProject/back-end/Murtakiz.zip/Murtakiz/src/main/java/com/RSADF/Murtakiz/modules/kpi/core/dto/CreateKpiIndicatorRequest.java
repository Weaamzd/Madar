package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CreateKpiIndicatorRequest {

    private String code;          // KPI_CODE
    private String nameAr;        // KPI_NAME_AR
    private String descAr;        // KPI_DESC_AR

    private String goalCode;

    private String perspectiveCode;   // PERSPECTIVE_CODE

    private String ownerEmpNo;    // OWNER_EMP_NO (اختياري)
    private Long ownerUniteId;    // OWNER_UNITE_ID (اختياري)
    private Long ownerSubUniteId; // OWNER_SUB_UNITE_ID (اختياري)

    private BigDecimal targetValue;           // TARGET_VALUE
    private String targetSource;          // TARGET_SOURCE
    private String meansToAchieveTarget;  // MEANS_TO_ACHIEVE_TARGET

    private BigDecimal baselineValue;         // BASELINE_VALUE
    private String measurementUnit;       // MEASUREMENT_UNIT

    private String polarityCode;          // POLARITY_CODE
    private String measurementMethod;     // MEASUREMENT_METHOD
    private String formulaText;           // FORMULA_TEXT

    private String frequencyCode;         // FREQUENCY_CODE

    private String currentStatus;         // CURRENT_STATUS (ON_TRACK / AT_RISK / OFF_TRACK...)

    private String isMain;                // IS_MAIN ('Y' or 'N')
    private String parentKpiCode;         // PARENT_KPI_CODE (لو مؤشر فرعي)

    private String isActive;              // IS_ACTIVE ('Y' or 'N')
}

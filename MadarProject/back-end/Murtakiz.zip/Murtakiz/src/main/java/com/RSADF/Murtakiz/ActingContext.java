package com.RSADF.Murtakiz;



import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

public record ActingContext(
        String actorUsername,     // b.user
        String actorEmpNo,        // E2105
        String ctxEmpNo,          // E2102  ← سياق البيانات
        boolean acting,           // true/false
        Long delegationId,        // 2
        Long actingSessionId,     // 9
        DelegationScopeType scopeType,  // LIMITED/ALL
        long actionsMask,         // 1/2/4/8/16/31
        List<Long> uniteIds,      // [10]   (قد تكون null/فارغة)
        List<Long> subUniteIds,   // [201..] (قد تكون null/فارغة)
        Set<String> roles         // الأدوار الفعّالة
) implements Serializable {

    public boolean has(Action a) {
        long bit = a.bit;
        return (actionsMask & bit) == bit;

    }

    public boolean inUnite(Long uniteId) {
        return uniteIds == null || uniteIds.isEmpty() || uniteIds.contains(uniteId);
    }

    public boolean inSubUnite(Long subId) {
        return subUniteIds == null || subUniteIds.isEmpty() || subUniteIds.contains(subId);
    }
}

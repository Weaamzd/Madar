package com.RSADF.Murtakiz.modules.auth.core.dto;



import java.time.LocalDateTime;
import java.util.List;

/** ملخص لإرجاعه بعد الإنشاء */
public class UserSummaryDto {
    private Long userId;
    private String username;
    private String empNo;
    private String fullName;
    private String email;
    private String jobTitle;
    private String status;
    private String regionCode;
    private String regionDbKey;
    private LocalDateTime lastLoginAt;
    private List<String> roles;

    private Long subUniteId;
    private String subUniteCode;
    private String subUniteName;

    // Getters/Setters
    // ... (اختصارًا)
    public Long getUserId() {return userId;}
    public void setUserId(Long userId) {this.userId = userId;}
    public String getUsername() {return username;}
    public void setUsername(String username) {this.username = username;}
    public String getEmpNo() {return empNo;}
    public void setEmpNo(String empNo) {this.empNo = empNo;}
    public String getFullName() {return fullName;}
    public void setFullName(String fullName) {this.fullName = fullName;}
    public String getEmail() {return email;}
    public void setEmail(String email) {this.email = email;}
    public String getJobTitle() {return jobTitle;}
    public void setJobTitle(String jobTitle) {this.jobTitle = jobTitle;}
    public String getStatus() {return status;}
    public void setStatus(String status) {this.status = status;}
    public String getRegionCode() {return regionCode;}
    public void setRegionCode(String regionCode) {this.regionCode = regionCode;}
    public String getRegionDbKey() {return regionDbKey;}
    public void setRegionDbKey(String regionDbKey) {this.regionDbKey = regionDbKey;}
    public LocalDateTime getLastLoginAt() {return lastLoginAt;}
    public void setLastLoginAt(LocalDateTime lastLoginAt) {this.lastLoginAt = lastLoginAt;}
    public List<String> getRoles() {return roles;}
    public void setRoles(List<String> roles) {this.roles = roles;}

    public Long getSubUniteId() { return subUniteId; }
    public void setSubUniteId(Long subUniteId) { this.subUniteId = subUniteId; }
    public String getSubUniteCode() { return subUniteCode; }
    public void setSubUniteCode(String subUniteCode) { this.subUniteCode = subUniteCode; }
    public String getSubUniteName() { return subUniteName; }
    public void setSubUniteName(String subUniteName) { this.subUniteName = subUniteName; }
}

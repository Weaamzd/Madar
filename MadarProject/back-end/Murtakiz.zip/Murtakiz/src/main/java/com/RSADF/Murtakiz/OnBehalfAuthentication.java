package com.RSADF.Murtakiz;


import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;

public class OnBehalfAuthentication extends AbstractAuthenticationToken {

    private final String principal;         // username
    private final ActingContext ctx;
    private final Map<String, Object> claimsSafeCopy;

    public OnBehalfAuthentication(
            String principal,
            Collection<? extends GrantedAuthority> authorities,
            ActingContext ctx,
            Map<String, Object> claimsSafeCopy
    ) {
        super(authorities);
        this.principal = principal;
        this.ctx = ctx;
        this.claimsSafeCopy = claimsSafeCopy == null ? Map.of() : Map.copyOf(claimsSafeCopy);
        super.setAuthenticated(true);
    }

    @Override public Object getCredentials() { return null; }
    @Override public Object getPrincipal() { return principal; }

    public ActingContext getActingContext() { return ctx; }
    public Map<String,Object> getClaims() { return claimsSafeCopy; }
}

package com.RSADF.Murtakiz.modules.auth.infra.repository;


import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.Collection;


@Repository
public class UserRoleDao {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void linkUserToRole(Long userId, Long roleId) {

        em.createNativeQuery("INSERT INTO SYS.USER_ROLES (USER_ID, ROLE_ID) VALUES (:uid, :rid)")
                .setParameter("uid", userId)
                .setParameter("rid", roleId)
                .executeUpdate();
    }

    @Transactional
    public int deleteLinks(Long userId, Collection<Long> roleIds) {
        return em.createNativeQuery("""
            DELETE FROM SYS.USER_ROLES
            WHERE USER_ID = :uid
              AND ROLE_ID IN (:rids)
        """)
                .setParameter("uid", userId)
                .setParameter("rids", roleIds)
                .executeUpdate();
    }
}

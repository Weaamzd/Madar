package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class ExternalUserSummaryDto {
    private Long userId;
    private String username;

    private String extEmpId;



    private String fullNameAr;
    private String fullNameEn;
    private String email;
    private String phone;
    private String organizationName;
    private String jobTitle;
    private String collaborationType;
    private LocalDate startDate;
    private LocalDate endDate;
    private String status;

    private Long subUniteId;
    private String subUniteName;

    private String regionCode;
    private String regionDbKey;

    private List<String> roles;
}


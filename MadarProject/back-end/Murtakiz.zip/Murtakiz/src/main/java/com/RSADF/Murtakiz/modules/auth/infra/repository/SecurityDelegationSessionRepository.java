package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.SecurityDelegationSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SecurityDelegationSessionRepository extends JpaRepository<SecurityDelegationSession, Long> {

    @Query("""
        select s
        from SecurityDelegationSession s
        where s.delegation.id = :delegationId
          and s.active = true
    """)
    List<SecurityDelegationSession> findActiveByDelegationId(@Param("delegationId") Long delegationId);






    @Query("""
        select s from SecurityDelegationSession s
        where s.id = :sessionId and s.active = true
    """)
    Optional<SecurityDelegationSession> findActiveById(@Param("sessionId") Long sessionId);





    @Modifying
    @Query("""
        update SecurityDelegationSession s
        set s.active = false, s.actEndAt = :now
        where s.id = :sessionId and s.active = true
    """)
    int deactivateById(@Param("sessionId") Long sessionId,
                       @Param("now") LocalDateTime now);


    @Modifying
    @Query("""
        update SecurityDelegationSession s
        set s.active = false, s.actEndAt = :now
        where s.delegation.id = :delegationId and s.active = true
    """)
    int deactivateAllByDelegationId(@Param("delegationId") Long delegationId,
                                    @Param("now") LocalDateTime now);


/*    @Query("""
   select count(s)
   from SecurityDelegationSession s
   where s.delegation.id = :delegationId
     and s.active = true
""")
    long countActiveByDelegationId(@Param("delegationId") Long delegationId);*/

    @Query("""
       select count(s) from SecurityDelegationSession s
       where s.delegation.id = :delegationId
    """)
    long countByDelegationId(@Param("delegationId") Long delegationId);

    @Query("""
       select count(s) from SecurityDelegationSession s
       where s.delegation.id = :delegationId and s.active = true
    """)
    long countActiveByDelegationId(@Param("delegationId") Long delegationId);




}

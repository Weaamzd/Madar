package com.RSADF.Murtakiz.modules.auth.infra.repository;


public interface ManagerNameProjection {
    String getEmpNo();
    String getEmpFullNameAr();
}

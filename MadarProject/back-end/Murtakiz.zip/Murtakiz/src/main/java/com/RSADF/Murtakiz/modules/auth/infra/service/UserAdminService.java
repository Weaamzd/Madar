package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.entity.*;
import com.RSADF.Murtakiz.modules.auth.infra.repository.*;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class UserAdminService {

    private final UserRepository userRepo;
    private final EmployeeRepository empRepo;
    private final RoleRepository roleRepo;
    private final CurrentRegionRepository regionRepo;
    private final UserRoleDao userRoleDao;
    private final PasswordEncoder passwordEncoder;
    private final SubUniteRepository subUniteRepo;
    private final UserSessionRepository userSessionRepo;
    private final ExternalEmployeeRepository externalEmpRepo;
    private final UserRoleRepository userRoleRepo;
    private final UserRegistrationRequestRepository registrationRequestRepository;


    private final UserEmpLinkHistoryRepository userEmpLinkHistoryRepo;

    public UserAdminService(UserRepository userRepo,
                            EmployeeRepository empRepo,
                            RoleRepository roleRepo,
                            CurrentRegionRepository regionRepo,
                            UserRoleDao userRoleDao,
                            PasswordEncoder passwordEncoder,
                            SubUniteRepository subUniteRepo,
                            UserSessionRepository userSessionRepo,
                            ExternalEmployeeRepository externalEmpRepo,
                            UserRoleRepository userRoleRepo,

                            UserEmpLinkHistoryRepository userEmpLinkHistoryRepo,
                            UserRegistrationRequestRepository registrationRequestRepository) {
        this.userRepo = userRepo;
        this.empRepo = empRepo;
        this.roleRepo = roleRepo;
        this.regionRepo = regionRepo;
        this.userRoleDao = userRoleDao;
        this.passwordEncoder = passwordEncoder;
        this.subUniteRepo = subUniteRepo;
        this.userSessionRepo = userSessionRepo;
        this.externalEmpRepo = externalEmpRepo;
        this.userRoleRepo = userRoleRepo;

        this.userEmpLinkHistoryRepo = userEmpLinkHistoryRepo;
        this.registrationRequestRepository = registrationRequestRepository;
    }



    @Transactional
    public UserSummaryDto createUser(CreateUserRequest req) {

        if (userRepo.existsByUsername(req.getUsername())) {
            throw new IllegalArgumentException("اسم المستخدم موجود بالفعل: " + req.getUsername());
        }


        SubUnite sub = subUniteRepo.findById(req.getSubUniteId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "SubUnite غير موجود: id=" + req.getSubUniteId()
                ));


        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new IllegalArgumentException("Region غير موجود ID=" + req.getCurrentRegionId()));
        }


        Employee emp = empRepo.findById(req.getEmpNo()).orElseGet(Employee::new);
        emp.setEmpNo(req.getEmpNo());
        emp.setFullNameAr(req.getFullNameAr());
        emp.setEmail(req.getEmail());
        emp.setJobTitle(req.getJobTitle());
        emp.setHireDate(req.getHireDate());
        emp.setStartDate(req.getStartDate());
        emp.setManagerNo(req.getManagerNo());
        emp.setSubUnite(sub);
        //emp.setSubUniteId(req.getSubUniteId());
        empRepo.save(emp);



        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword())); // BCrypt
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);
        user.setEmployee(emp);
        user.setCurrentRegion(region);

        user.setEmpNo(emp.getEmpNo());

        user = userRepo.save(user);

        if (req.getRolesNames() == null || req.getRolesNames().isEmpty()) {
            throw new IllegalArgumentException("لم يتم تمرير أدوار rolesNames");
        }
        List<Role> roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {

            Set<String> found = new HashSet<>();
            roles.forEach(r -> found.add(r.getName()));
            List<String> missing = new ArrayList<>();
            for (String n : req.getRolesNames()) if (!found.contains(n)) missing.add(n);
            throw new IllegalArgumentException("الأدوار التالية غير موجودة: " + missing);
        }
        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }

        UserSummaryDto out = new UserSummaryDto();
        out.setUserId(user.getId());
        out.setUsername(user.getUsername());
        out.setEmpNo(emp.getEmpNo());
        out.setFullName(emp.getFullNameAr());
        out.setEmail(emp.getEmail());
        out.setJobTitle(emp.getJobTitle());
        out.setStatus(user.getStatus());
        if (region != null) {
            out.setRegionCode(region.getRegionCode());
            out.setRegionDbKey(region.getRegionDbKey());
        }
        out.setLastLoginAt(user.getLastLoginAt());

        out.setSubUniteId(sub.getId());
        out.setSubUniteCode(sub.getCode());
        out.setSubUniteName(sub.getName());

        out.setRoles(req.getRolesNames());
        return out;
    }

    @Transactional
    public UserSummaryDto createUserWithRegistration(CreateUserRequest dto,
                                                     String adminEmpNo) {

        if (userRepo.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("USERNAME_ALREADY_EXISTS");
        }


        Employee employee = empRepo.findById(dto.getEmpNo())
                .orElseGet(Employee::new);

        employee.setEmpNo(dto.getEmpNo());
        employee.setFullNameAr(dto.getFullNameAr());
        employee.setEmail(dto.getEmail());
        employee.setJobTitle(dto.getJobTitle());
        employee.setHireDate(dto.getHireDate());
        employee.setStartDate(dto.getStartDate());
        employee.setManagerNo(dto.getManagerNo());


        SubUnite subUnite = subUniteRepo.findById(dto.getSubUniteId())
                .orElseThrow(() -> new IllegalArgumentException("SUB_UNITE_NOT_FOUND"));
        employee.setSubUnite(subUnite);

        empRepo.save(employee);

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));


        user.setStatus(dto.getStatus() != null ? dto.getStatus() : "Active");


        user.setEmpNo(employee.getEmpNo());

        // createdAt + allowedDays
        user.setCreatedAt(LocalDateTime.now());
        Integer allowedDays = dto.getAllowedDays() != null ? dto.getAllowedDays() : 3;
        user.setAllowedDays(allowedDays);


        if (dto.getCurrentRegionId() != null) {
            CurrentRegion region = regionRepo.findById(dto.getCurrentRegionId())
                    .orElseThrow(() -> new IllegalArgumentException("REGION_NOT_FOUND"));
            user.setCurrentRegion(region);
        }


        user = userRepo.save(user);


        if (dto.getRolesNames() == null || dto.getRolesNames().isEmpty()) {
            throw new IllegalArgumentException("لم يتم تمرير أدوار rolesNames");
        }

        List<Role> roles = roleRepo.findByNameIn(dto.getRolesNames());
        if (roles.size() != dto.getRolesNames().size()) {
            Set<String> found = new HashSet<>();
            for (Role r : roles) {
                found.add(r.getName());
            }

            List<String> missing = new ArrayList<>();
            for (String name : dto.getRolesNames()) {
                if (!found.contains(name)) {
                    missing.add(name);
                }
            }

            throw new IllegalArgumentException("الأدوار التالية غير موجودة: " + missing);
        }


        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }


        UserRegistrationRequest req = new UserRegistrationRequest();
        req.setUserId(user.getId());
        req.setCurrentStage("ADMIN_REVIEW");
        req.setStageStatus("PENDING");
        req.setWaitingForEmpNo(adminEmpNo);
        req.setCreatedAt(LocalDateTime.now());
        req.setNotes("طلب إنشاء حساب جديد للمستخدم " + user.getUsername());

        registrationRequestRepository.save(req);


        UserSummaryDto summary = new UserSummaryDto();
        summary.setUserId(user.getId());
        summary.setUsername(user.getUsername());
        summary.setEmpNo(user.getEmpNo());
        summary.setFullName(employee.getFullNameAr());
        summary.setEmail(employee.getEmail());
        summary.setJobTitle(employee.getJobTitle());
        summary.setStatus(user.getStatus());
        summary.setLastLoginAt(user.getLastLoginAt());

        if (user.getCurrentRegion() != null) {
            summary.setRegionCode(user.getCurrentRegion().getRegionCode());
            summary.setRegionDbKey(user.getCurrentRegion().getRegionDbKey());
        }

        if (employee.getSubUnite() != null) {
            summary.setSubUniteId(employee.getSubUnite().getId());
            summary.setSubUniteName(employee.getSubUnite().getName());

            // summary.setSubUniteCode(employee.getSubUnite().getCode());
        }


        summary.setRoles(userRoleRepo.findRoleNamesByUserId(user.getId()));

        return summary;
    }


    @Transactional
    public ExternalUserSummaryDto createExternalUser(CreateExternalUserRequest req) {
        if (userRepo.existsByUsername(req.getUsername())) {
            throw new IllegalArgumentException("اسم المستخدم موجود بالفعل: " + req.getUsername());
        }

        SubUnite sub = subUniteRepo.findById(req.getSubUniteId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "SubUnite غير موجود: id=" + req.getSubUniteId()));

        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new IllegalArgumentException("Region غير موجود ID=" + req.getCurrentRegionId()));
        }

        ExternalEmployee ext = ExternalEmployee.builder()
                .id(req.getExtEmpId())
                .fullNameAr(req.getFullNameAr())
                .fullNameEn(req.getFullNameEn())
                .email(req.getEmail())
                .phone(req.getPhone())
                .organizationName(req.getOrganizationName())
                .jobTitle(req.getJobTitle())
                .collaborationType(req.getCollaborationType())
                .startDate(req.getStartDate())
                .endDate(req.getEndDate())
                .status("ACTIVE")
                .notes(req.getNotes())
                .createdAt(LocalDateTime.now())
                .createdBy("system")
                .subUniteId(sub)
                .build();

        if (req.getManagerEmpNo() != null && !req.getManagerEmpNo().isBlank()) {
            Employee manager = empRepo.findById(req.getManagerEmpNo())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Employee (manager) غير موجود: " + req.getManagerEmpNo()));
            ext.setEmpManagerNo(manager);
        }

        ext = externalEmpRepo.save(ext);


        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);


        user.setExternalEmpId(ext.getId());


        user.setEmpNo(null);
        user.setCurrentRegion(region);
        user.setExternalEmpId(ext.getId());
        user = userRepo.save(user);



        if (req.getRolesNames() == null || req.getRolesNames().isEmpty()) {
            throw new IllegalArgumentException("لم يتم تمرير أدوار rolesNames");
        }
        List<Role> roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {
            var found = roles.stream().map(Role::getName).collect(java.util.stream.Collectors.toSet());
            var missing = req.getRolesNames().stream().filter(n -> !found.contains(n)).toList();
            throw new IllegalArgumentException("الأدوار التالية غير موجودة: " + missing);
        }
        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }


        return ExternalUserSummaryDto.builder()
                .userId(user.getId())
                .username(user.getUsername())
                .extEmpId(ext.getId())
                .fullNameAr(ext.getFullNameAr())
                .fullNameEn(ext.getFullNameEn())
                .email(ext.getEmail())
                .phone(ext.getPhone())
                .organizationName(ext.getOrganizationName())
                .jobTitle(ext.getJobTitle())
                .collaborationType(ext.getCollaborationType())
                .startDate(ext.getStartDate())
                .endDate(ext.getEndDate())
                .status(ext.getStatus())
                .subUniteId(sub.getId())
                .subUniteName(sub.getName())
                .regionCode(region != null ? region.getRegionCode() : null)
                .regionDbKey(region != null ? region.getRegionDbKey() : null)
                .roles(req.getRolesNames())
                .build();

    }

    @Transactional
    public ExternalUserSummaryDto createExternalUserWithRegistration(CreateExternalUserRequest req,
                                                                     String adminEmpNo) {

        if (userRepo.existsByUsername(req.getUsername())) {
            throw new IllegalArgumentException("اسم المستخدم موجود بالفعل: " + req.getUsername());
        }


        SubUnite sub = subUniteRepo.findById(req.getSubUniteId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "SubUnite غير موجود: id=" + req.getSubUniteId()));


        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Region غير موجود ID=" + req.getCurrentRegionId()));
        }

        ExternalEmployee ext = ExternalEmployee.builder()
                .id(req.getExtEmpId())
                .fullNameAr(req.getFullNameAr())
                .fullNameEn(req.getFullNameEn())
                .email(req.getEmail())
                .phone(req.getPhone())
                .organizationName(req.getOrganizationName())
                .jobTitle(req.getJobTitle())
                .collaborationType(req.getCollaborationType())
                .startDate(req.getStartDate())
                .endDate(req.getEndDate())
                .status("ACTIVE")
                .notes(req.getNotes())
                .createdAt(LocalDateTime.now())
                .createdBy("system")
                .subUniteId(sub)
                .build();


        if (req.getManagerEmpNo() != null && !req.getManagerEmpNo().isBlank()) {
            Employee manager = empRepo.findById(req.getManagerEmpNo())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Employee (manager) غير موجود: " + req.getManagerEmpNo()));
            ext.setEmpManagerNo(manager);
        }

        ext = externalEmpRepo.save(ext);


        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);


        user.setEmpNo(null);
        user.setExternalEmpId(ext.getId());
        user.setCurrentRegion(region);


        user.setCreatedAt(LocalDateTime.now());
        Integer allowedDays = req.getAllowedDays() != null ? req.getAllowedDays() : 3;
        user.setAllowedDays(allowedDays);

        user = userRepo.save(user);


        if (req.getRolesNames() == null || req.getRolesNames().isEmpty()) {
            throw new IllegalArgumentException("لم يتم تمرير أدوار rolesNames");
        }
        List<Role> roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {
            var found = roles.stream().map(Role::getName).collect(java.util.stream.Collectors.toSet());
            var missing = req.getRolesNames().stream().filter(n -> !found.contains(n)).toList();
            throw new IllegalArgumentException("الأدوار التالية غير موجودة: " + missing);
        }
        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }


        UserRegistrationRequest reg = new UserRegistrationRequest();
        reg.setUserId(user.getId());
        reg.setCurrentStage("ADMIN_REVIEW");
        reg.setStageStatus("PENDING");
        reg.setWaitingForEmpNo(adminEmpNo);
        reg.setCreatedAt(LocalDateTime.now());
        reg.setNotes("طلب إنشاء حساب مستخدم خارجي للهوية: " + ext.getId());

        registrationRequestRepository.save(reg);


        return ExternalUserSummaryDto.builder()
                .userId(user.getId())
                .username(user.getUsername())
                .extEmpId(ext.getId())
                .fullNameAr(ext.getFullNameAr())
                .fullNameEn(ext.getFullNameEn())
                .email(ext.getEmail())
                .phone(ext.getPhone())
                .organizationName(ext.getOrganizationName())
                .jobTitle(ext.getJobTitle())
                .collaborationType(ext.getCollaborationType())
                .startDate(ext.getStartDate())
                .endDate(ext.getEndDate())
                .status(ext.getStatus())
                .subUniteId(sub.getId())
                .subUniteName(sub.getName())
                .regionCode(region != null ? region.getRegionCode() : null)
                .regionDbKey(region != null ? region.getRegionDbKey() : null)
                .roles(req.getRolesNames())
                .build();
    }

    @Transactional
    public UserStatusResult toggleStatusByEmpNo(String empNo, boolean revokeAllSessions) {
        var userOpt = userRepo.findByEmployeeEmpNo(empNo);
        User u = userOpt.orElseThrow(() ->
                new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found for empNo: " + empNo)
        );

        String oldStatus = (u.getStatus() == null ? "Active" : u.getStatus().trim());
        String newStatus = oldStatus.equalsIgnoreCase("Active") ? "Inactive" : "Active";
        u.setStatus(newStatus);


        long revoked = 0L;
        if (revokeAllSessions) {
            revoked = userSessionRepo.deleteByUser_Id(u.getId());
        }

        return UserStatusResult.builder()
                .userId(u.getId())
                .username(u.getUsername())

                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .revokedSessions(revoked)
                .changedAt(LocalDateTime.now())
                .build();
    }

    @Transactional
    public UserStatusResult toggleStatusByUsername(String username, boolean revokeAllSessions) {
        User u = userRepo.findByUsername(username)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found for username: " + username));

        String oldStatus = (u.getStatus() == null ? "Active" : u.getStatus().trim());
        String newStatus = oldStatus.equalsIgnoreCase("Active") ? "Inactive" : "Active";
        u.setStatus(newStatus);

        long revoked = 0L;
        if (revokeAllSessions) {

            revoked = userSessionRepo.deleteByUser_Id(u.getId());
        }


        return UserStatusResult.builder()
                .userId(u.getId())
                .username(u.getUsername())
                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .revokedSessions(revoked)
                .changedAt(LocalDateTime.now())
                .build();
    }


    private User resolveUser(Long userId, String username) {
        if (userId != null) {
            return userRepo.findById(userId)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + userId));
        }
        if (username != null && !username.isBlank()) {
            return userRepo.findByUsername(username)
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + username));
        }
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Provide userId or username");
    }


    @Transactional
    public UserSummaryDto updateUser(@Valid CreateUserRequest req) {

        User user = userRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found for username: " + req.getUsername()
                ));

        SubUnite sub = subUniteRepo.findById(req.getSubUniteId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "SubUnite غير موجود: id=" + req.getSubUniteId()
                ));

        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Region غير موجود ID=" + req.getCurrentRegionId()
                    ));
        }

        Employee emp = empRepo.findById(req.getEmpNo()).orElseGet(Employee::new);
        emp.setEmpNo(req.getEmpNo());
        emp.setFullNameAr(req.getFullNameAr());
        emp.setEmail(req.getEmail());
        emp.setJobTitle(req.getJobTitle());
        emp.setHireDate(req.getHireDate());
        emp.setStartDate(req.getStartDate());
        emp.setManagerNo(req.getManagerNo());
        emp.setSubUnite(sub);
        empRepo.save(emp);

        Optional<User> otherWithEmpNo = userRepo.findByEmpNo(req.getEmpNo());
        if (otherWithEmpNo.isPresent() && !otherWithEmpNo.get().getId().equals(user.getId())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "EMP_NO مرتبط بمستخدم آخر: " + req.getEmpNo()
            );
        }

        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);
        user.setEmpNo(emp.getEmpNo());
        user.setCurrentRegion(region);
        user = userRepo.save(user);

        if (req.getRolesNames() == null || req.getRolesNames().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "rolesNames لا يجب أن تكون فارغة");
        }
        List<Role> roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {
            Set<String> found = roles.stream().map(Role::getName).collect(java.util.stream.Collectors.toSet());
            List<String> missing = req.getRolesNames().stream().filter(n -> !found.contains(n)).toList();
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "الأدوار التالية غير موجودة: " + missing);
        }

        List<Long> currentRoleIds = userRoleRepo.findRoleIdsByUserId(user.getId());
        Set<Long> currentSet  = new HashSet<>(currentRoleIds);
        List<Long> desiredIds = roles.stream().map(Role::getId).toList();
        Set<Long> desiredSet  = new HashSet<>(desiredIds);

        Set<Long> toRemove = new HashSet<>(currentSet);  toRemove.removeAll(desiredSet);
        Set<Long> toAdd    = new HashSet<>(desiredSet);  toAdd.removeAll(currentSet);

        if (!toRemove.isEmpty()) {
            userRoleRepo.deleteByUserIdAndRoleIds(user.getId(), toRemove);
        }
        for (Long roleId : toAdd) {
            userRoleDao.linkUserToRole(user.getId(), roleId);
        }

        UserSummaryDto out = new UserSummaryDto();
        out.setUserId(user.getId());
        out.setUsername(user.getUsername());
        out.setEmpNo(emp.getEmpNo());
        out.setFullName(emp.getFullNameAr());
        out.setEmail(emp.getEmail());
        out.setJobTitle(emp.getJobTitle());
        out.setStatus(user.getStatus());
        if (region != null) {
            out.setRegionCode(region.getRegionCode());
            out.setRegionDbKey(region.getRegionDbKey());
        }
        out.setLastLoginAt(user.getLastLoginAt());
        out.setSubUniteId(sub.getId());
        out.setSubUniteCode(sub.getCode());
        out.setSubUniteName(sub.getName());
        out.setRoles(req.getRolesNames());

        return out;
    }

    private void ensureUserNotLinked(User u) {
        if (u.getEmpNo() != null || (u.getExternalEmpId() != null && !u.getExternalEmpId().isBlank())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "المستخدم مرتبط أصلًا بموظف داخلي/خارجي. افصل أولًا.");
        }
    }

    private void ensureEmpNoNotLinkedElsewhere(String empNo, Long currentUserId) {
        userRepo.findByEmpNo(empNo).ifPresent(other -> {
            if (!other.getId().equals(currentUserId)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "EMP_NO مرتبط بمستخدم آخر: " + empNo);
            }
        });
    }

    private void ensureExtIdNotLinkedElsewhere(String extEmpId, Long currentUserId) {
        userRepo.findByExternalEmpId(extEmpId).ifPresent(other -> {
            if (!other.getId().equals(currentUserId)) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "EXT_EMP_ID مرتبط بمستخدم آخر: " + extEmpId);
            }
        });
    }

    private void stopAllSessions(User u) {

        userSessionRepo.deactivateAllByUserId(u.getId(), LocalDateTime.now());
    }

    private void openHistory(User u, String type, String empNo, String extId, String note, String actorEmpNo) {
        UserEmpLinkHistory h = new UserEmpLinkHistory();
        h.setUser(u);
        h.setUsername(u.getUsername());
        h.setLinkType(type); // INTERNAL/EXTERNAL
        h.setEmpNo(empNo);
        h.setExtEmpId(extId);
        h.setLinkedAt(LocalDateTime.now());
        h.setActionNote(note);
        h.setActorEmpNo(actorEmpNo);
        userEmpLinkHistoryRepo.save(h);
    }





    private void closeHistoryIfOpen(User u, String type, String note, String actorEmpNo) {
        userEmpLinkHistoryRepo.closeOpenByUserAndType(u.getId(), type, LocalDateTime.now(), note, actorEmpNo);
    }



    @Transactional
    public void linkInternalByEmpNoUsername(
            @Valid LinkInternalByEmpNoUsernameRequest req, String actorEmpNo) {


        User u = userRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found: " + req.getUsername()));


        ensureUserNotLinked(u);


        Employee e = empRepo.findById(req.getEmpNo())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "Employee not found: " + req.getEmpNo()));


        ensureEmpNoNotLinkedElsewhere(req.getEmpNo(), u.getId());


        u.setEmpNo(e.getEmpNo());
        u.setExternalEmpId(null);
        userRepo.save(u);




        closeHistoryIfOpen(u, "INTERNAL", null, actorEmpNo);
        openHistory(u, "INTERNAL", e.getEmpNo(), null, req.getNote(), actorEmpNo);
        stopAllSessions(u);


    }

    @Transactional
    public void linkExternalByExtIdUsername(
            @Valid LinkExternalByExtIdUsernameRequest req, String actorEmpNo) {

        User u = userRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found: " + req.getUsername()));


        ensureUserNotLinked(u);


        ExternalEmployee ext = externalEmpRepo.findById(req.getExtEmpId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.BAD_REQUEST, "ExternalEmployee not found: " + req.getExtEmpId()));


        ensureExtIdNotLinkedElsewhere(req.getExtEmpId(), u.getId());

        u.setEmpNo(null);
        u.setExternalEmpId(ext.getId());
        userRepo.save(u);

        closeHistoryIfOpen(u, "EXTERNAL", null, actorEmpNo);
        openHistory(u, "EXTERNAL", null, ext.getId(), req.getNote(), actorEmpNo);
        stopAllSessions(u);



    }


    @Transactional
    public void unlink(UnlinkRequest req, String actorEmpNo) {
        User u = userRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "User not found: " + req.getUsername()));

        boolean didAnything = false;

        if (req.getType() == null || "INTERNAL".equalsIgnoreCase(req.getType())) {
            if (u.getEmpNo() != null) {
                closeHistoryIfOpen(u, "INTERNAL", req.getNote(), actorEmpNo);
                u.setEmpNo(null);
                didAnything = true;
            }
        }

        if (req.getType() == null || "EXTERNAL".equalsIgnoreCase(req.getType())) {
            if (u.getExternalEmpId() != null && !u.getExternalEmpId().isBlank()) {
                closeHistoryIfOpen(u, "EXTERNAL", req.getNote(), actorEmpNo);
                u.setExternalEmpId(null);
                didAnything = true;
            }
        }

        if (!didAnything) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "لا يوجد ربط حالي لنوع: " + req.getType());
        }

        userRepo.save(u);

        if (req.isRevokeSessions()) {
            stopAllSessions(u);
        }
    }






    @Transactional
    public void linkInternalByEmpNo(@Valid LinkInternalByEmpNoRequest req, String actorEmpNo) {
        User u = userRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + req.getUserId()));

        ensureUserNotLinked(u);

        Employee e = empRepo.findById(req.getEmpNo())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Employee not found: " + req.getEmpNo()));

        ensureEmpNoNotLinkedElsewhere(req.getEmpNo(), u.getId());

        u.setEmpNo(e.getEmpNo());
        u.setExternalEmpId(null);

        if (req.getCurrentRegionId() != null && req.getCurrentRegionId() != 0) {
            CurrentRegion region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Region not found: " + req.getCurrentRegionId()));
            u.setCurrentRegion(region);
        }

        userRepo.save(u);

        closeHistoryIfOpen(u, "INTERNAL", null, actorEmpNo);
        openHistory(u, "INTERNAL", e.getEmpNo(), null, req.getNote(), actorEmpNo);
        stopAllSessions(u);


    }

    @Transactional
    public void linkExternalByExtId(@Valid LinkExternalByExtIdRequest req, String actorEmpNo) {
        User u = userRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found: " + req.getUserId()));

        ensureUserNotLinked(u);

        ExternalEmployee ext = externalEmpRepo.findById(req.getExtEmpId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "ExternalEmployee not found: " + req.getExtEmpId()));

        ensureExtIdNotLinkedElsewhere(req.getExtEmpId(), u.getId());

        u.setEmpNo(null);
        u.setExternalEmpId(ext.getId());

        if (req.getCurrentRegionId() != null && req.getCurrentRegionId() != 0) {
            CurrentRegion region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Region not found: " + req.getCurrentRegionId()));
            u.setCurrentRegion(region);
        }

        userRepo.save(u);

        closeHistoryIfOpen(u, "EXTERNAL", null, actorEmpNo);
        openHistory(u, "EXTERNAL", null, ext.getId(), req.getNote(), actorEmpNo);
        stopAllSessions(u);


    }



    @Transactional
    public void unlinkAllByUsername(UnlinkByUsernameRequest req, String actorEmpNo) {
        User u = userRepo.findByUsername(req.getUsername())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "User not found: " + req.getUsername()));

        boolean unlinkedAny = false;

        if (u.getEmpNo() != null) {

            closeHistoryIfOpen(u, "INTERNAL", req.getNote(), actorEmpNo);
            u.setEmpNo(null);
            unlinkedAny = true;
        }


        if (u.getExternalEmpId() != null && !u.getExternalEmpId().isBlank()) {
            closeHistoryIfOpen(u, "EXTERNAL", req.getNote(), actorEmpNo);
            u.setExternalEmpId(null);
            unlinkedAny = true;
        }

        userRepo.save(u);


        if (Boolean.TRUE.equals(req.getRevokeSessions()) && unlinkedAny) {
            stopAllSessions(u);
        }

    }



    @Transactional(readOnly = true)
    public Optional<EmployeeForUserCreationDto> precheckCandidateByEmpNo(String empNo) {

        var empOpt = empRepo.findById(empNo);
        if (empOpt.isEmpty()) {

            return Optional.empty();
        }


        var userOpt = userRepo.findByEmployeeEmpNo(empNo);
        if (userOpt.isPresent()) {

            return Optional.empty();
        }


        Employee e = empOpt.get();
        EmployeeForUserCreationDto dto = new EmployeeForUserCreationDto();
        dto.setEmpNo(e.getEmpNo());
        dto.setFullNameAr(e.getFullNameAr());
        dto.setEmail(e.getEmail());
        dto.setJobTitle(e.getJobTitle());
        dto.setHireDate(e.getHireDate());
        dto.setStartDate(e.getStartDate());
        dto.setManagerNo(e.getManagerNo());

        SubUnite su = e.getSubUnite();
        if (su != null) {
            dto.setSubUniteId(su.getId());
            dto.setSubUniteCode(su.getCode());
            dto.setSubUniteName(su.getName());
            Unite u = su.getUnite();
            if (u != null) {
                dto.setUniteId(u.getId());
                dto.setUniteCode(u.getCode());
                dto.setUniteName(u.getName());
            }
        }

        return Optional.of(dto);
    }

    @Transactional
    public UserSummaryDto createUserForEmployeeIfNoUser(@Valid CreateUserForExistingEmployeeRequest req) {

        Employee emp = empRepo.findById(req.getEmpNo())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee غير موجود برقم: " + req.getEmpNo()
                ));

        if (userRepo.findByEmployeeEmpNo(req.getEmpNo()).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "لا يمكن الإنشاء: هذا الموظف لديه مستخدم مرتبط مسبقًا"
            );
        }

        if (userRepo.existsByUsername(req.getUsername())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "اسم المستخدم موجود بالفعل: " + req.getUsername()
            );
        }

        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Region غير موجود ID=" + req.getCurrentRegionId()
                    ));
        }

        var roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {
            var found = roles.stream().map(Role::getName).collect(java.util.stream.Collectors.toSet());
            var missing = req.getRolesNames().stream().filter(n -> !found.contains(n)).toList();
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "الأدوار التالية غير موجودة: " + missing);
        }

        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);
        user.setEmpNo(emp.getEmpNo());
        user.setEmployee(emp);
        user.setCurrentRegion(region);
        user = userRepo.save(user);

        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }

        SubUnite su = emp.getSubUnite();
        UserSummaryDto out = new UserSummaryDto();
        out.setUserId(user.getId());
        out.setUsername(user.getUsername());
        out.setEmpNo(emp.getEmpNo());
        out.setFullName(emp.getFullNameAr());
        out.setEmail(emp.getEmail());
        out.setJobTitle(emp.getJobTitle());
        out.setStatus(user.getStatus());
        if (region != null) {
            out.setRegionCode(region.getRegionCode());
            out.setRegionDbKey(region.getRegionDbKey());
        }
        out.setLastLoginAt(user.getLastLoginAt());
        if (su != null) {
            out.setSubUniteId(su.getId());
            out.setSubUniteCode(su.getCode());
            out.setSubUniteName(su.getName());
        }
        out.setRoles(req.getRolesNames());
        return out;
    }

    @Transactional
    public UserSummaryDto createUserForEmployee(
            @Valid CreateUserForExistingEmployeeRequest req,
            String adminEmpNo
    ) {

        Employee emp = empRepo.findById(req.getEmpNo())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee غير موجود برقم: " + req.getEmpNo()
                ));

        if (userRepo.findByEmployeeEmpNo(req.getEmpNo()).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "لا يمكن الإنشاء: هذا الموظف لديه مستخدم مرتبط مسبقًا"
            );
        }

        if (userRepo.existsByUsername(req.getUsername())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "اسم المستخدم موجود بالفعل: " + req.getUsername()
            );
        }

        CurrentRegion region = null;
        if (req.getCurrentRegionId() != null) {
            region = regionRepo.findById(req.getCurrentRegionId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.BAD_REQUEST, "Region غير موجود ID=" + req.getCurrentRegionId()
                    ));
        }

        var roles = roleRepo.findByNameIn(req.getRolesNames());
        if (roles.size() != req.getRolesNames().size()) {
            var found = roles.stream().map(Role::getName).collect(java.util.stream.Collectors.toSet());
            var missing = req.getRolesNames().stream().filter(n -> !found.contains(n)).toList();
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "الأدوار التالية غير موجودة: " + missing);
        }

        User user = new User();
        user.setUsername(req.getUsername());
        user.setPasswordHash(passwordEncoder.encode(req.getPassword()));
        user.setStatus(Optional.ofNullable(req.getStatus()).orElse("Active"));
        user.setLastLoginAt((LocalDateTime) null);
        user.setEmpNo(emp.getEmpNo());
        user.setEmployee(emp);
        user.setCurrentRegion(region);

        user.setCreatedAt(LocalDateTime.now());

        Integer allowedDays = req.getAllowedDays() != null ? req.getAllowedDays() : 3;
        user.setAllowedDays(allowedDays);

        user = userRepo.save(user);

        for (Role r : roles) {
            userRoleDao.linkUserToRole(user.getId(), r.getId());
        }

        UserRegistrationRequest reg = new UserRegistrationRequest();
        reg.setUserId(user.getId());
        reg.setCurrentStage("ADMIN_REVIEW");
        reg.setStageStatus("PENDING");
        reg.setWaitingForEmpNo(adminEmpNo);
        reg.setCreatedAt(LocalDateTime.now());
        reg.setNotes("طلب إنشاء حساب جديد للمستخدم " + user.getUsername());

        registrationRequestRepository.save(reg);

        SubUnite su = emp.getSubUnite();
        UserSummaryDto out = new UserSummaryDto();
        out.setUserId(user.getId());
        out.setUsername(user.getUsername());
        out.setEmpNo(emp.getEmpNo());
        out.setFullName(emp.getFullNameAr());
        out.setEmail(emp.getEmail());
        out.setJobTitle(emp.getJobTitle());
        out.setStatus(user.getStatus());
        if (region != null) {
            out.setRegionCode(region.getRegionCode());
            out.setRegionDbKey(region.getRegionDbKey());
        }
        out.setLastLoginAt(user.getLastLoginAt());
        if (su != null) {
            out.setSubUniteId(su.getId());
            out.setSubUniteCode(su.getCode());
            out.setSubUniteName(su.getName());
        }
        out.setRoles(req.getRolesNames());
        return out;
    }

    @Transactional
    public void approveAdminRegistration(
            Long requestId,
            boolean approved,
            String adminNote,
            String adminEmpNo
    ) {

        UserRegistrationRequest req = registrationRequestRepository.findById(requestId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Request not found: " + requestId
                ));

        if (!"ADMIN_REVIEW".equalsIgnoreCase(req.getCurrentStage())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "الطلب ليس في مرحلة ADMIN_REVIEW"
            );
        }
        if (!"PENDING".equalsIgnoreCase(req.getStageStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "لا يمكن اتخاذ قرار: حالة الطلب ليست PENDING"
            );
        }

        User user = userRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "User not found for id: " + req.getUserId()
                ));

        StringBuilder notesBuilder = new StringBuilder();
        if (req.getNotes() != null && !req.getNotes().isBlank()) {
            notesBuilder.append(req.getNotes()).append(" | ");
        }
        notesBuilder.append("قرار الأدمن (")
                .append(adminEmpNo != null ? adminEmpNo : "SYSTEM")
                .append("): ")
                .append(approved ? "موافقة" : "رفض");

        if (adminNote != null && !adminNote.isBlank()) {
            notesBuilder.append(" - ملاحظات: ").append(adminNote);
        }

        req.setNotes(notesBuilder.toString());
        req.setUpdatedAt(LocalDateTime.now());

        if (!approved) {
            req.setStageStatus("REJECTED");
            registrationRequestRepository.save(req);

            user.setStatus("Inactive");
            userRepo.save(user);

            return;
        }

        req.setStageStatus("APPROVED");
        req.setUpdatedAt(LocalDateTime.now());
        registrationRequestRepository.save(req);

        if ("Inactive".equalsIgnoreCase(user.getStatus())) {
            user.setStatus("Active");
            userRepo.save(user);
        }

        UserRegistrationRequest termsReq = new UserRegistrationRequest();
        termsReq.setUserId(user.getId());
        termsReq.setCurrentStage("USER_TERMS");
        termsReq.setStageStatus("PENDING");
        termsReq.setWaitingForEmpNo(null);
        termsReq.setCreatedAt(LocalDateTime.now());
        termsReq.setNotes("بانتظار موافقة المستخدم على الشروط والأحكام");

        //termsReq.setParentRequestId(req.getId());
        termsReq.setParent(req);

        registrationRequestRepository.save(termsReq);
    }



    @Transactional
    public void approveUserTerms(Long userId) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "User not found: " + userId
                ));


        UserRegistrationRequest termsReq = registrationRequestRepository
                .findTopByUserIdAndCurrentStageAndStageStatusOrderByCreatedAtDesc(
                        userId,
                        "USER_TERMS",
                        "PENDING"
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "لا يوجد طلب USER_TERMS بحالة PENDING لهذا المستخدم"
                ));

        termsReq.setStageStatus("APPROVED");
        termsReq.setUpdatedAt(LocalDateTime.now());
        registrationRequestRepository.save(termsReq);


        user.setStatus("Active");


        user.setAllowedDays(null);



        userRepo.save(user);
    }

    @Transactional
    public void approveUserTermsByUsername(String username) {

        User user = userRepo.findByUsername(username)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "User not found: " + username
                ));

        UserRegistrationRequest req = registrationRequestRepository
                .findTopByUserIdAndCurrentStageAndStageStatusOrderByCreatedAtDesc(
                        user.getId(),
                        "USER_TERMS",
                        "PENDING"
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "No pending USER_TERMS registration request for user: " + username
                ));

        if (!"USER_TERMS".equals(req.getCurrentStage()) || !"PENDING".equals(req.getStageStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Cannot approve terms: request is not in USER_TERMS/PENDING state"
            );
        }


        req.setStageStatus("APPROVED");
        req.setUpdatedAt(LocalDateTime.now());
        registrationRequestRepository.save(req);


        user.setAllowedDays(null);
        user.setStatus("Active");
        userRepo.save(user);
    }


    @Transactional(readOnly = true)
    public Page<UserRegistrationRequestSummaryDto> listRegistrationRequestsByOrgScope(
            Long uniteId,
            Long subUniteId,
            String username,
            String stageStatus,
            int page,
            int size
    ) {

        return searchRegistrationRequests(
                username,
                stageStatus,
                uniteId,
                subUniteId,
                page,
                size
        );
    }

    @Transactional(readOnly = true)
    public List<UserRegistrationRequestSummaryDto> listMyRegistrationRequestsByUsername(String username) {
        List<UserRegistrationRequest> list =
                registrationRequestRepository.findAllByUsernameWithUserFullDetails(username);

        return list.stream()
                .map(this::toSummary)
                .toList();
    }



    @Transactional(readOnly = true)
    public Page<UserRegistrationRequestSummaryDto> searchRegistrationRequests(
            String username,
            String stageStatus,
            Long uniteId,
            Long subUniteId,
            int page,
            int size
    ) {
        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by(Sort.Direction.DESC, "createdAt")
        );

        Page<UserRegistrationRequest> entitiesPage = registrationRequestRepository.searchFull(
                (username == null || username.isBlank())      ? null : username,
                (stageStatus == null || stageStatus.isBlank()) ? null : stageStatus,
                uniteId,
                subUniteId,
                pageable
        );

        return entitiesPage.map(this::toSummary);
    }




    private UserRegistrationRequestSummaryDto toSummary(UserRegistrationRequest r) {



        UserRegistrationRequestSummaryDto.UserRegistrationRequestSummaryDtoBuilder b =
                UserRegistrationRequestSummaryDto.builder()
                        .id(r.getId())
                        .parentRequestId(
                                r.getParent() != null ? r.getParent().getId() : null
                        )


                        .currentStage(r.getCurrentStage())
                        .stageStatus(r.getStageStatus())
                        .waitingForEmpNo(r.getWaitingForEmpNo())
                        .createdAt(r.getCreatedAt());


        User u = r.getUser();
        if (u != null) {
            b.userId(u.getId())
                    .username(u.getUsername())
                    .userStatus(u.getStatus());


            CurrentRegion cr = u.getCurrentRegion();
            if (cr != null) {
                b.regionId(cr.getId());

                b.regionName(cr.getRegionCode());
            }


            if (u.getEmployee() != null) {
                Employee e = u.getEmployee();
                b.employeeType("INTERNAL")
                        .empNo(e.getEmpNo())
                        .fullNameAr(e.getFullNameAr());

                if (e.getSubUnite() != null) {
                    SubUnite su = e.getSubUnite();
                    b.subUniteId(su.getId())
                            .subUniteName(su.getName());

                    if (su.getUnite() != null) {
                        Unite un = su.getUnite();
                        b.uniteId(un.getId())
                                .uniteName(un.getName());
                    }
                }

            } else if (u.getExternalEmployee() != null) {
                ExternalEmployee xe = u.getExternalEmployee();
                b.employeeType("EXTERNAL")

                        .empNo(xe.getId())
                        .fullNameAr(xe.getFullNameAr());

                if (xe.getSubUniteId() != null) {
                    SubUnite xsu = xe.getSubUniteId();
                    b.subUniteId(xsu.getId())
                            .subUniteName(xsu.getName());

                    if (xsu.getUnite() != null) {
                        Unite xu = xsu.getUnite();
                        b.uniteId(xu.getId())
                                .uniteName(xu.getName());
                    }
                }
            } else {
                b.employeeType("UNKNOWN");
            }
        }

        return b.build();
    }




}

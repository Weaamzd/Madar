package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserFullProfileDto {
    private String profileType; // INTERNAL | EXTERNAL | UNLINKED

    // معلومات المستخدم
    private UserMiniDto user;
    private List<String> roles;
    private boolean loggedIn;

    // تفاصيل الموظف (أحدهما فقط يُملأ)
    private InternalEmployeeDetailsDto internalDetails; // nullable
    private ExternalEmployeeDetailsDto2 externalDetails; // nullable
}

package com.RSADF.Murtakiz.modules.kpi.core.entity;

import jakarta.persistence.*;
import lombok.*;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "KPI_INDICATOR_INITIATIVE",
        schema = "SYS"
)
@IdClass(KpiIndicatorInitiativeId.class)
@Getter
@Setter
@NoArgsConstructor
public class KpiIndicatorInitiative {

    @Id
    @Column(name = "KPI_CODE", length = 50)
    private String kpiCode;

    @Id
    @Column(name = "INITIATIVE_CODE", length = 50)
    private String initiativeCode;

    @Column(name = "LINK_TYPE", length = 20)
    private String linkType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "KPI_CODE",
            referencedColumnName = "KPI_CODE",
            insertable = false,
            updatable = false
    )
    private KpiIndicator kpi;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "INITIATIVE_CODE",
            referencedColumnName = "INITIATIVE_CODE",
            insertable = false,
            updatable = false
    )
    private KpiInitiative initiative;
}


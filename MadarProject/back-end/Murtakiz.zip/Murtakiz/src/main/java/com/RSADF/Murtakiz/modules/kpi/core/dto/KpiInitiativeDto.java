package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class KpiInitiativeDto {

    private Long id;
    private String code;
    private String nameAr;
    private String descAr;
    private String initiativeType;

    private String goalCode;

    private String ownerEmpNo;
    private Long ownerUniteId;
    private Long ownerSubUniteId;

    private LocalDate startDate;
    private LocalDate targetEndDate;
    private LocalDate actualEndDate;
    private String statusCode;
    private Double progressPct;

    private Double budgetAmount;
    private Double actualCost;

    private LocalDateTime createdAt;
    private String createdByEmpNo;
    private LocalDateTime updatedAt;
    private String updatedByEmpNo;
}

package com.RSADF.Murtakiz.modules.auth.core.dto;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @NoArgsConstructor
public class CreateDelegationRequest {
    // من الحساب الحالي أو تصرّح هنا (ننصح بالتصريح هنا EMP_NO)
    private String delegatorEmpNo;           // اختياري: إن لم يُمرَّر نأخذ من التوكن

    private String delegateeEmpNo;           // مطلوب

    private DelegationScopeType scopeType;   // ALL أو LIMITED (لحالاتك أدناه سنستخدم LIMITED مع UNITE/SUB_UNITE)

    // نافذة الزمن
    private LocalDateTime startAt;           // مطلوب
    private LocalDateTime endAt;             // اختياري لو noExpiry=true
    private Boolean noExpiry = false;

    // خيارات
    private Boolean requireAcceptance = false;
    private Boolean allowSubdelegate  = false;

    // عند LIMITED:
    private Long uniteId;                    // “قسم كامل” (كل الشعب ضمنًا)
    private List<Long> subUnitIds;           // أو شعب محددة
    private List<String> actions;            // ["READ","UPDATE"] / null = كل الصلاحيات
}

/*@Getter @Setter
public class CreateDelegationRequest {

    // من ينيب؟ (إن تركتها null سنأخذها من المستخدم في الـ Token)
    private Long delegatorUserId;

    @NotNull
    private Long delegateeUserId;

    // وقت البداية/النهاية
    @NotNull
    private LocalDateTime startAt;

    // لو noExpiry=true خله null
    private LocalDateTime endAt;

    // مدة غير محدودة؟
    private Boolean noExpiry = Boolean.FALSE;

    // هل يلزم قبول المندوب؟
    private Boolean requireAcceptance = Boolean.FALSE;

    // السماح بإعادة التفويض؟
    private Boolean allowSubdelegate = Boolean.FALSE;

    // نوع النطاق: ALL | LIMITED
    @NotNull
    private DelegationScopeType scopeType;

    // عند LIMITED:
    // A) تفويض على “قسم كامل + كل شعبه” → ضع uniteId فقط
    private Long uniteId;
    // B) تفويض على “شُعب محددة” تحت هذا القسم (أرسل IDs للشعب)
    private List<Long> subUnitIds;

    // الصلاحيات: إن تركتها null/فارغة → نعطيه كامل الصلاحيات (ALL)
    // القيم المسموحة: READ, CREATE, UPDATE, DELETE, APPROVE
    private List<String> actions;
}*/


/*
package com.RSADF.Murtakiz.modules.auth.core.dto;

import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CreateDelegationRequest {
    private Long delegatorUserId;
    private Long delegateeUserId;           // مطلوب

    private DelegationScopeType scopeType;

    // نافذة الزمن
    private LocalDateTime startAt;
    private LocalDateTime endAt;

    // خيارات
    private Boolean requireAcceptance = false;
    private Boolean allowSubdelegate  = false;

    // عند LIMITED:
    private Long uniteId;                   // اختيار “وحدة كاملة” (يشمل كل شعبها ضمناً)
    private List<Long> subUnitIds;          // أو شعب معيّنة تحت الوحدة/الوحدات
    private List<String> actions;           // ["READ","UPDATE"] .. فارغة/null = كل الصلاحيات
}*/

package com.RSADF.Murtakiz.modules.auth.core.dto;


public class UniteDto {
    private Long id;
    private String code;
    private String name;
    private Long uniteTypeId;
    private String uniteTypeName;

    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Long getUniteTypeId() { return uniteTypeId; }
    public void setUniteTypeId(Long uniteTypeId) { this.uniteTypeId = uniteTypeId; }
    public String getUniteTypeName() { return uniteTypeName; }
    public void setUniteTypeName(String uniteTypeName) { this.uniteTypeName = uniteTypeName; }
}


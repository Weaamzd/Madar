package com.RSADF.Murtakiz.modules.auth.infra.service;

import java.time.LocalDateTime;

public interface JwtInspector {
    String extractJti(String token);
    String extractSubject(String token);
    LocalDateTime extractExpiry(String token);
}
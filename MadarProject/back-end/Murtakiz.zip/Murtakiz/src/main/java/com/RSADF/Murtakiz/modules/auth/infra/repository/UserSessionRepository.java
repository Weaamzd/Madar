package com.RSADF.Murtakiz.modules.auth.infra.repository;


import com.RSADF.Murtakiz.modules.auth.core.entity.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface UserSessionRepository extends JpaRepository<UserSession, Long> {

    @Query("""
        select (count(us) > 0)
        from UserSession us
        where us.user.id = :userId
          and us.revokedAt is null
          and (us.expiresAt is null or us.expiresAt > :now)
    """)
    boolean hasActiveSessions(@Param("userId") Long userId,
                             @Param("now") LocalDateTime now);

    List<UserSession> findByUser_IdAndRevokedAtIsNull(Long userId);
    Optional<UserSession> findByAccessTokenHashAndRevokedAtIsNull(String tokenHash);

    void deleteByAccessTokenHash(String tokenHash);
    void deleteByAccessTokenJti(String jti);
    long deleteByUser_Id(Long userId);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
  update UserSession s
  set s.revokedAt = :now
  where s.user.id = :userId
    and s.revokedAt is null
""")
    int deactivateAllByUserId(@Param("userId") Long userId,
                              @Param("now") LocalDateTime now);


    @Query("""
        select distinct us.user.id
        from UserSession us
        where us.user.id in :userIds
          and us.revokedAt is null
          and (us.expiresAt is null or us.expiresAt > CURRENT_TIMESTAMP)
    """)
    Set<Long> findActiveUserIds(@Param("userIds") Collection<Long> userIds);


/*    @Query("""
        select (count(us) > 0)
        from UserSession us
        where us.user.id = :userId
          and us.revokedAt is null
          and (us.expiresAt is null or us.expiresAt > CURRENT_TIMESTAMP)
    """)
    boolean hasActiveSession(@Param("userId") Long userId);*/

    @Query("""
        select (count(us) > 0)
        from UserSession us
        where us.user.id = :userId
          and us.revokedAt is null
          and (us.expiresAt is null or us.expiresAt > :now)
    """)
    boolean hasActiveSession(@Param("userId") Long userId, @Param("now") LocalDateTime now);
}


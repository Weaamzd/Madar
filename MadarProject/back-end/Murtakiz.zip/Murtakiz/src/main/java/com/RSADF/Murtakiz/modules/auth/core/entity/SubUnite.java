package com.RSADF.Murtakiz.modules.auth.core.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(
        name = "SUB_UNITE",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_SUB_UNITE__UNITE", columnList = "UNITE_ID"),
                @Index(name = "IX_SUB_UNITE__TYPE",  columnList = "UNITE_TYPE_ID"),
                @Index(name = "IX_SUB_UNITE__PARENT",columnList = "PARENT_SUB_UNITE_ID")
        }
)
@Getter @Setter @NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class SubUnite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SUB_UNITE_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;


    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "UNITE_ID", foreignKey = @ForeignKey(name = "FK_SUB_UNITE__UNITE"))
    @ToString.Exclude
    private Unite unite;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UNITE_TYPE_ID", nullable = false, foreignKey = @ForeignKey(name = "FK_SUB_UNITE__TYPE"))
    @ToString.Exclude
    private UniteType uniteType;

    @Column(name = "SUB_UNITE_CODE", nullable = false, length = 50)
    @ToString.Include
    private String code;

    @Column(name = "SUB_UNITE_NAME", nullable = false, length = 200)
    @ToString.Include
    private String name;


    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "PARENT_SUB_UNITE_ID", foreignKey = @ForeignKey(name = "FK_SUB_UNITE__PARENT"))
    @ToString.Exclude
    private SubUnite parent;

    @OneToMany(mappedBy = "parent", fetch = FetchType.LAZY)
    @ToString.Exclude
    private Set<SubUnite> children = new HashSet<>();
}


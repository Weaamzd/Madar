package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
public class CreateUserForExistingEmployeeRequest {
    @NotBlank
    @Size(max = 100)
    private String username;

    @NotBlank @Size(min = 6)
    private String password;

    private String status = "Active";

    @NotNull
    private String empNo;               // الموظف الموجود مسبقًا

    private Long currentRegionId;       // اختياري

    @NotEmpty
    private List<@NotBlank String> rolesNames;

    // 👇 جديد: عدد الأيام المسموح بها قبل تعطيل الحساب
    private Integer allowedDays;        // لو null نخليها 3 في السيرفر
}

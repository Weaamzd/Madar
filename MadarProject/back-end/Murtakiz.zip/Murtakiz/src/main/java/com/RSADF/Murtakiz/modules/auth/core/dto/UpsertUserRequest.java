/*
package com.RSADF.Murtakiz.modules.auth.core.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.LocalDate;
import java.util.List;

@Getter @Setter @NoArgsConstructor
public class UpsertUserRequest {
    // ---------- المستخدم ----------
    @NotBlank @Size(max = 100)
    private String username;

    @NotBlank @Size(min = 6)
    private String password;

    private String status = "Active";

    private Long currentRegionId;

    // ---------- الموظف ----------
    @NotNull @Size(max = 50)
    private String empNo;

    @NotBlank @Size(max = 200)
    private String fullNameAr;

    @NotBlank @Email @Size(max = 200)
    private String email;

    @NotBlank @Size(max = 200)
    private String jobTitle;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate hireDate;

    @NotNull
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    private String managerNo;

    @NotNull
    private Long subUniteId;

    // ---------- الأدوار ----------
    @NotEmpty
    private List<@NotBlank String> rolesNames;
}
*/

package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkExternalByExtIdRequest {
    @NotNull
    Long userId;        // حساب المستخدم الهدف
    @NotBlank
    String extEmpId;   // الموظف الخارجي المراد ربطه
    Long currentRegionId;        // اختياري
    String note;
}

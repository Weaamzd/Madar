package com.RSADF.Murtakiz.modules.auth.infra.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;

@Service
@RequiredArgsConstructor
public class JwtInspectorImpl implements JwtInspector {

    private final JwtService jwtService;

    @Override
    public String extractJti(String token) {
        var claims = jwtService.parseAndValidate(token);
        return claims.getId();
    }

    @Override
    public String extractSubject(String token) {
        var claims = jwtService.parseAndValidate(token);
        return claims.getSubject();
    }

    @Override
    public LocalDateTime extractExpiry(String token) {
        var claims = jwtService.parseAndValidate(token);
        var exp = claims.getExpiration();
        return exp == null ? null : LocalDateTime.ofInstant(exp.toInstant(), ZoneId.systemDefault());
    }
}
package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Table(name = "USER_ROLES", schema = "SYS")
@Getter
@Setter
public class UserRole implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ROLE_ID")
    private Long id;



    public UserRole() {
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


     @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name = "ROLE_ID", insertable = false, updatable = false)
     private Role role;

     @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name = "USER_ID", insertable = false, updatable = false)
     private User user;
}




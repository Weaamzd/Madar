package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class UserMiniDto {
    private Long userId;
    private String username;
    private String status;
    private LocalDateTime lastLoginAt;

    // (اختياري) لو تبغى تعرض معلومات المنطقة الحالية
    private Long currentRegionId;
    private String regionCode;
    private String regionDbKey;
}
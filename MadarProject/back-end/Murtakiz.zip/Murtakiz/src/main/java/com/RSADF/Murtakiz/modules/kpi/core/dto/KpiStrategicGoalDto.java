package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class KpiStrategicGoalDto {

    private Long id;
    private String code;
    private String nameAr;
    private String perspectiveCode;

    private String goalType;          // GOAL_TYPE

    private String ownerEmpNo;
    private Long ownerUniteId;
    private Long ownerSubUniteId;
    private String regionCode;

    private Integer horizonFromYear;
    private Integer horizonToYear;

    private String parentGoalCode;    // PARENT_GOAL_CODE

    private String statusCode;
    private Double progressPct;
    private Integer kpiCount;

    private LocalDateTime createdAt;
    private String createdByEmpNo;
    private LocalDateTime updatedAt;
    private String updatedByEmpNo;
}

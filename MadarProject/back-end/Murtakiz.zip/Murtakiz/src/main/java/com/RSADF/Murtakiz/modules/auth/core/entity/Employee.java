package com.RSADF.Murtakiz.modules.auth.core.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity @Table(name = "EMPLOYEES", schema = "SYS")
@Getter @Setter @NoArgsConstructor
public class Employee {
    @Id
    @Column(name = "EMP_NO", length = 50)
    private String empNo;

    @Column(name = "EMP_FULL_NAME_AR", nullable = false, length = 200)
    private String fullNameAr;

    @Column(name = "EMP_EMAIL", nullable = false, length = 200)
    private String email;

    @Column(name = "EMP_JOB_TITLE", nullable = false, length = 200)
    private String jobTitle;

    @Column(name = "EMP_HIRE_DATE", nullable = false)
    private LocalDate hireDate;

    @Column(name = "EMP_START_DATE", nullable = false)
    private LocalDate startDate;

    @Column(name = "EMP_MANAGER_NO")
    private String managerNo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SUB_UNITE_ID", nullable = false)
    private SubUnite subUnite;

}

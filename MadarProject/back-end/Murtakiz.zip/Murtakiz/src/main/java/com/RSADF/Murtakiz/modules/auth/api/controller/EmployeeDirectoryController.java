package com.RSADF.Murtakiz.modules.auth.api.controller;


import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.infra.service.EmployeeDirectoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@RequestMapping("/api/v1/murtakiz/org/employees")
public class EmployeeDirectoryController {

    private final EmployeeDirectoryService svc;

    public EmployeeDirectoryController(EmployeeDirectoryService svc) {
        this.svc = svc;
    }

    @GetMapping("/profiles/by-scope")
    public ResponseEntity<PageResponse<EmployeeUserDetailsDto>> listProfilesByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,

            @RequestParam(required = false) String empNo,
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,     // Active/Inactive/Suspended
            @RequestParam(required = false) Boolean loggedIn,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,

            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listEmployeeProfilesByScope(
                uniteId, subUniteId,
                empNo, fullNameAr, username, userStatus, loggedIn, uniteName, subUniteName,
                page, size, unpaged
        );
        return ResponseEntity.ok(resp);
    }

    @GetMapping("/{empNo}/org")
    public ResponseEntity<EmployeeOrgInfo> getOrgByEmpNo(@PathVariable String empNo) {
        var dto = svc.getOrgByEmpNo(empNo);
        return ResponseEntity.ok(dto);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{empNo}/org-with-managers")
    public ResponseEntity<EmployeeOrgWithManagersDto> getOrgWithManagers(@PathVariable String empNo) {
        var dto = svc.getOrgWithManagersByEmpNo(empNo);
        return ResponseEntity.ok(dto);
    }


    /** أدمن أو موظف */
    /*@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + DEPARTMENT_MANAGER + "')")*/
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/{empNo}/profile")
    public ResponseEntity<EmployeeUserDetailsDto> getProfile(@PathVariable String empNo) {
        return ResponseEntity.ok(svc.getEmployeeProfile(empNo));
    }

    @GetMapping("/{extEmpId}/exprofile")
    public ResponseEntity<ExternalEmployeeUserProfileDto> getExternalProfile(@PathVariable String extEmpId) {
        var dto = svc.getExternalEmployeeProfile(extEmpId);
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/profiles")
    public ResponseEntity<PageResponse<EmployeeUserDetailsDto>> listProfiles(
            @RequestParam(required = false) String empNo,
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,
            @RequestParam(required = false) Boolean loggedIn,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listAllEmployeeProfiles(
                empNo, fullNameAr, username, userStatus, loggedIn, uniteName, subUniteName,
                page, size, unpaged
        );
        return ResponseEntity.ok(resp);
    }


    //@PreAuthorize("hasAnyRole('" + SYSTEM_ADMIN + "','" + DEPARTMENT_MANAGER + "')")
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/managers")
    public ResponseEntity<List<ManagerNameDto>> listManagers() {
        return ResponseEntity.ok(svc.listAllManagers());
    }

    @GetMapping("/people")
    public PageResponse<UnifiedPersonDetailsDto> listPeople(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String q,            // empNo أو extEmpId
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,
            @RequestParam(required = false) Boolean loggedIn,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) String managerNo,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return svc.listPeopleProfilesByScope(
                uniteId, subUniteId,
                q, fullNameAr, username, userStatus, loggedIn,
                uniteName, subUniteName,
                managerNo,
                page, size, unpaged
        );
    }


    @GetMapping("/people/all")
    public PageResponse<UnifiedPersonDetailsDto> listAllPeople(
            @RequestParam(required = false) String empNo,
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,
            @RequestParam(required = false) Boolean loggedIn,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return svc.listAllPeopleProfiles(
                empNo, fullNameAr, username, userStatus, loggedIn,
                uniteName, subUniteName, page, size, unpaged
        );
    }

    @GetMapping("/people/by-scope/all")
    public PageResponse<UnifiedPersonDetailsDto> listAllPeopleByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,
            @RequestParam(required = false) Boolean loggedIn,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return svc.listAllPeopleProfilesByScope(
                uniteId, subUniteId,
                q, fullNameAr, username, userStatus, loggedIn,
                uniteName, subUniteName,
                page, size, unpaged
        );
    }


    @GetMapping("/managers/by-scope")
    public ResponseEntity<List<ManagerNameDto>> listManagersByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId
    ) {
        return ResponseEntity.ok(svc.listManagersByScope(uniteId, subUniteId));
    }


    /** 1) المستخدمون غير المرتبطين + الهستوري الكامل */
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/users/unlinked")
    public ResponseEntity<PageResponse<UserWithHistoryDto>> listUnlinkedUsersWithHistory(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus, // Active / Inactive / Suspended
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listUnlinkedUsersWithHistory(username, userStatus, page, size, unpaged);
        return ResponseEntity.ok(resp);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/users")
    public ResponseEntity<PageResponse<UserWithHistoryDto>> listUsersWithHistory(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,   // Active / Inactive / Suspended
            @RequestParam(required = false) String linkedState,  // UNLINKED / LINKED / ALL
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listUsersWithHistory(username, userStatus, linkedState, page, size, unpaged);
        return ResponseEntity.ok(resp);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/users/by-scope")
    public ResponseEntity<PageResponse<UserWithHistoryDto>> listUsersWithHistoryByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String userStatus,   // Active / Inactive / Suspended
            @RequestParam(required = false) String linkedState,  // UNLINKED / LINKED / ALL
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listUsersWithHistoryByScope(
                uniteId, subUniteId,
                username, userStatus, linkedState,
                page, size, unpaged
        );
        return ResponseEntity.ok(resp);
    }


    @PreAuthorize("isAuthenticated()")
    @GetMapping("/users/with-history")
    public ResponseEntity<UserWithHistoryDto> getUserWithHistoryByUsernameParam(@RequestParam String username) {
        var dto = svc.getUserWithHistory(username);
        return ResponseEntity.ok(dto);
    }




    @PreAuthorize("isAuthenticated()")
    @GetMapping("/people/unlinked")
    public ResponseEntity<PageResponse<UnifiedPersonDetailsDto>> listAllPeopleWithoutUser(
            @RequestParam(required = false) String q,            // empNo أو extEmpId
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listAllPeopleWithoutUser(q, fullNameAr, uniteName, subUniteName, page, size, unpaged);
        return ResponseEntity.ok(resp);
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/people/unlinked/by-scope")
    public ResponseEntity<PageResponse<UnifiedPersonDetailsDto>> listAllPeopleWithoutUserByScope(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String fullNameAr,
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false, defaultValue = "false") Boolean unpaged
    ) {
        var resp = svc.listAllPeopleWithoutUserByScope(
                uniteId, subUniteId, q, fullNameAr, page, size, unpaged
        );
        return ResponseEntity.ok(resp);
    }




}


package com.RSADF.Murtakiz.modules.auth.api.controller;


import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.infra.service.RoleDirectoryService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.RSADF.Murtakiz.Roles.SYSTEM_ADMIN;

@RestController
@RequestMapping("/api/v1/murtakiz/org/roles")
public class RolesController {

    private final RoleDirectoryService svc;


    public RolesController(RoleDirectoryService svc) {
        this.svc = svc;
    }


    /** أدمن فقط */
    //@PreAuthorize("hasRole('" + SYSTEM_ADMIN + "')")
    @PreAuthorize("isAuthenticated()")
    @PostMapping("/{empNo}/roles")
    public ResponseEntity<RolesMutationResult> addRoles(
            @PathVariable String empNo,
            @Valid @RequestBody AssignRolesRequest body
    ) {
        return ResponseEntity.ok(svc.addRolesByEmpNo(empNo, body));
    }


    /** أدمن فقط */
    //@PreAuthorize("hasRole('" + SYSTEM_ADMIN + "')")
    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("del/{empNo}/roles")

    public ResponseEntity<RolesMutationResult> removeRoles(
            @PathVariable String empNo,
            @Valid @RequestBody RemoveRolesRequest body
    ) {
        return ResponseEntity.ok(svc.removeRolesByEmpNo(empNo, body));
    }


    /** أدمن فقط */
    //@PreAuthorize("hasRole('" + SYSTEM_ADMIN + "')")
    @PreAuthorize("isAuthenticated()")
    @GetMapping
    public ResponseEntity<List<RoleItemDto>> listAll() {
        return ResponseEntity.ok(svc.listAllRoles());
    }

    @GetMapping("/options/{empNo}")
    public RoleOptionsDto getOptions(@PathVariable String empNo) {
        return svc.getRoleOptionsByEmpNo(empNo);
    }

    @PostMapping("/assign/{empNo}")
    public RolesMutationResult assign(@PathVariable String empNo,
                                      @RequestBody AssignRolesRequest body) {
        return svc.addRolesByEmpNo(empNo, body);
    }

    @PostMapping("/remove/{empNo}")
    public RolesMutationResult remove(@PathVariable String empNo,
                                      @RequestBody RemoveRolesRequest body) {
        return svc.removeRolesByEmpNo(empNo, body);
    }
}

package com.RSADF.Murtakiz.modules.kpi.core.repository;


import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiStrategicGoal;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KpiStrategicGoalRepository extends JpaRepository<KpiStrategicGoal, Long> {

    boolean existsByCode(String code);

    Optional<KpiStrategicGoal> findByCode(String code);


    List<KpiStrategicGoal> findByParentGoalCode(String parentGoalCode);

    @Query("""
        select g
        from KpiStrategicGoal g
        left join g.ownerUnite u
        left join g.ownerSubUnite su
        where (:uniteId is null or u.id = :uniteId)
          and (:subUniteId is null or su.id = :subUniteId)
          and (:uniteName is null or upper(u.name) like upper(concat('%', :uniteName, '%')))
          and (:subUniteName is null or upper(su.name) like upper(concat('%', :subUniteName, '%')))
          and (:code is null or upper(g.code) like upper(concat('%', :code, '%')))
          and (:nameAr is null or upper(g.nameAr) like upper(concat('%', :nameAr, '%')))
          and (:goalType is null or g.goalType = :goalType)
          and (:perspectiveCode is null or g.perspectiveCode = :perspectiveCode)
          and (:regionCode is null or g.regionCode = :regionCode)
          and (:statusCode is null or g.statusCode = :statusCode)
    """)
    Page<KpiStrategicGoal> searchGoals(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName,
            @Param("code") String code,
            @Param("nameAr") String nameAr,
            @Param("goalType") String goalType,
            @Param("perspectiveCode") String perspectiveCode,
            @Param("regionCode") String regionCode,
            @Param("statusCode") String statusCode,
            Pageable pageable
    );
}

package com.RSADF.Murtakiz.modules.auth.core.dto;

// package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserRegistrationRequestSummaryDto {
    private Long id;
    private String currentStage;
    private String stageStatus;
    private String waitingForEmpNo;
    private LocalDateTime createdAt;
    private Long parentRequestId;


    private Long userId;
    private String username;
    private String userStatus;

    private String employeeType;
    private String empNo;
    private String fullNameAr;

    private Long regionId;
    private String regionName;

    private Long uniteId;
    private String uniteName;

    private Long subUniteId;
    private String subUniteName;
}


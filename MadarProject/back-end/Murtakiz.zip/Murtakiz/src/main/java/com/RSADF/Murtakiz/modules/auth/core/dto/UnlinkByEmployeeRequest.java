package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnlinkByEmployeeRequest {
    // نمرّر أحدهما فقط: empNo أو extEmpId
    String empNo;
    String extEmpId;
    boolean revokeSessions;      // إيقاف الجلسات بعد الفصل
    String note;                 // للتوثيق في الهيستوري
}

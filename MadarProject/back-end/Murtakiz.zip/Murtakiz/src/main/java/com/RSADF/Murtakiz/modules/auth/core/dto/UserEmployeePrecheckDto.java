package com.RSADF.Murtakiz.modules.auth.core.dto;


import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @NoArgsConstructor
public class UserEmployeePrecheckDto {

    private boolean userExists;
    private boolean employeeExists;


    private String empNo;
    private String username;


    private String fullNameAr;
    private String email;
    private String jobTitle;
    private LocalDate hireDate;
    private LocalDate startDate;
    private String managerNo;
    private Long subUniteId;
    private String subUniteCode;
    private String subUniteName;
    private Long uniteId;
    private String uniteCode;
    private String uniteName;


    private Long userId;
    private String status;
    private LocalDateTime lastLoginAt;
    private Long currentRegionId;
    private String regionCode;
    private String regionDbKey;
    private List<String> roles;
}

package com.RSADF.Murtakiz.modules.auth.infra.service;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class InMemoryLoginAttemptService implements LoginAttemptService {

    private final int maxAttempts;
    private final Duration lockDuration;
    private final Duration window;

    public InMemoryLoginAttemptService(
            @Value("${security.login-attempts.max:5}") int maxAttempts,
            @Value("${security.login-attempts.lock-minutes:15}") long lockMinutes,
            @Value("${security.login-attempts.window-minutes:10}") long windowMinutes
    ) {
        this.maxAttempts = maxAttempts;
        this.lockDuration = Duration.ofMinutes(lockMinutes);
        this.window = Duration.ofMinutes(windowMinutes);
    }

    private static final class Attempt {
        int failures = 0;
        Instant firstFailureAt = null;
        Instant blockedUntil = null;
    }

    private final Map<String, Attempt> store = new ConcurrentHashMap<>();

    @Override
    public boolean blocked(String username) {
        Attempt a = store.get(username);
        if (a == null) return false;
        if (a.blockedUntil == null) return false;
        if (Instant.now().isBefore(a.blockedUntil)) return true;

        a.blockedUntil = null;
        a.failures = 0;
        a.firstFailureAt = null;
        return false;
    }

    @Override
    public void onSuccess(String username) {
        store.remove(username);
    }

    @Override
    public void onFailure(String username) {
        Attempt a = store.computeIfAbsent(username, k -> new Attempt());
        Instant now = Instant.now();


        if (a.firstFailureAt == null || Duration.between(a.firstFailureAt, now).compareTo(window) > 0) {
            a.firstFailureAt = now;
            a.failures = 0;
        }

        a.failures += 1;

        if (a.failures >= maxAttempts) {
            a.blockedUntil = now.plus(lockDuration);
        }
    }
}

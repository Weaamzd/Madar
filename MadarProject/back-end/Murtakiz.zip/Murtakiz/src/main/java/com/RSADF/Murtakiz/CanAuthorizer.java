package com.RSADF.Murtakiz;


import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import org.springframework.stereotype.Component;

@Component("can")
public class CanAuthorizer {

    private final PermissionService ps;

    public CanAuthorizer(PermissionService ps) { this.ps = ps; }

    public boolean updateUnit(Long uniteId)    { return ps.canUpdateUnit(uniteId); }
    public boolean createInSub(Long subId)     { return ps.canCreateInSubUnit(subId); }


    public boolean has(String actionName) {
        Action a = Action.valueOf(actionName.toUpperCase());
        return ps.has(a);
    }

    public boolean inUnite(Long uniteId) { return ps.inUnite(uniteId); }
    public boolean inSub(Long subId)     { return ps.inSubUnite(subId); }
}

package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class PageResponse<T> {
    private List<T> content;
    private long totalElements;
    private int totalPages;
    private Integer page;   // nullable
    private Integer size;   // nullable
    private boolean last;
}

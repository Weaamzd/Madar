package com.RSADF.Murtakiz.modules.auth.jwt;
import com.RSADF.Murtakiz.ActingContext;
import com.RSADF.Murtakiz.OnBehalfAuthentication;
import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.infra.repository.JwtBlacklistRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.SecurityDelegationSessionRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserSessionRepository;
import com.RSADF.Murtakiz.modules.auth.infra.service.JwtService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;



public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwt;
    private final JwtBlacklistRepository blacklistRepo;
    private final UserSessionRepository sessionRepo;
    private final SecurityDelegationSessionRepository actingSessionRepo;

    public JwtAuthenticationFilter(
            JwtService jwt,
            JwtBlacklistRepository blacklistRepo,
            UserSessionRepository sessionRepo,
            SecurityDelegationSessionRepository actingSessionRepo
    ) {
        this.jwt = jwt;
        this.blacklistRepo = blacklistRepo;
        this.sessionRepo = sessionRepo;
        this.actingSessionRepo = actingSessionRepo;
    }

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (!StringUtils.hasText(authHeader) || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);

        try {

            Claims claims = jwt.parseAndValidate(token);

            String hash = TokenHash.sha256(token);
            if (blacklistRepo.existsByTokenHash(hash)) { reject(response, "blacklisted"); return; }

            var sessionOpt = sessionRepo.findByAccessTokenHashAndRevokedAtIsNull(hash);
            if (sessionOpt.isEmpty()) { reject(response, "no-session"); return; }

            if (jwt.isExpired(claims)) { reject(response, "expired"); return; }


            String username = getString(claims, "username");
            if (!StringUtils.hasText(username)) username = claims.getSubject();
            if (!StringUtils.hasText(username)) { filterChain.doFilter(request, response); return; }

            Boolean enabled = getBoolean(claims, "enabled");
            if (enabled != null && !enabled) { SecurityContextHolder.clearContext(); reject(response); return; }

            List<String> rolesEff = getStringList(claims, "roles_effective");
            if (rolesEff == null) rolesEff = getStringList(claims, "roles");
            if (rolesEff == null) rolesEff = getStringList(claims, "roles_actor");

            var authorities = new ArrayList<SimpleGrantedAuthority>();
            if (rolesEff != null) {
                authorities.addAll(
                        rolesEff.stream()
                                .filter(Objects::nonNull)
                                .map(String::trim)
                                .filter(s -> !s.isEmpty())
                                .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                                .map(SimpleGrantedAuthority::new)
                                .toList()
                );
            }


           /* Boolean actFlag = getBoolean(claims, "act");
            boolean acting = actFlag != null && actFlag;



            String actorEmpNo = firstNonNull(getString(claims, "emp_no"), getString(claims, "empNo"));
            String ctxEmpNo   = firstNonNull(getString(claims, "ctx_emp_no"), actorEmpNo);*/


            Boolean actFlag = getBoolean(claims, "act");
            boolean acting = actFlag != null && actFlag;


            String actorEmpNo = firstNonNull(
                    getString(claims, "emp_no"),
                    getString(claims, "empNo")
            );

            String ctxEmpNo = firstNonNull(
                    getString(claims, "ctx_emp_no"),
                    actorEmpNo
            );


            Map<?, ?> delMap = null;
            Object delObj = claims.get("delegation");
            if (delObj instanceof Map<?, ?> m) delMap = m;

            Long delegationId   = delMap == null ? null : toLong(delMap.get("id"));
            Long sessionId      = delMap == null ? null : toLong(delMap.get("session_id"));
            String scopeTypeStr = delMap == null ? null : String.valueOf(delMap.get("scope_type"));
            Long maskLong       = delMap == null ? null : toLong(delMap.get("actions_mask"));
            long actionsMask    = (maskLong == null ? Action.ALL_MASK : maskLong);
            var uniteIds        = delMap == null ? List.<Long>of() : toLongList(delMap.get("unite_ids"));
            var subUniteIds     = delMap == null ? List.<Long>of() : toLongList(delMap.get("sub_unite_ids"));

            if (acting) {

                if (sessionId == null || actingSessionRepo.findActiveById(sessionId).isEmpty()) {
                    reject(response); return;
                }
            }

            Set<String> roles = new HashSet<>();
            if (rolesEff != null) roles.addAll(rolesEff);

            var ctx = new ActingContext(
                    username,
                    actorEmpNo,
                    ctxEmpNo,
                    acting,
                    delegationId,
                    sessionId,
                    scopeTypeStr == null ? null : DelegationScopeType.valueOf(scopeTypeStr),
                    actionsMask,
                    uniteIds,
                    subUniteIds,
                    roles
            );


            Boolean isExternal = getBoolean(claims, "is_external");

            Long extEmpId = null;
            Object extIdObj = claims.get("ext_emp_id");
            if (extIdObj != null) {
                try { extEmpId = Long.valueOf(extIdObj.toString()); } catch (Exception ignore) {}
            }

            String displayName = getString(claims, "display_name");

            String email = getString(claims, "email");


            Map<String, Object> safeClaims = new HashMap<>(claims);
            if (displayName != null) safeClaims.put("display_name", displayName);
            if (isExternal != null)  safeClaims.put("is_external", isExternal);
            if (extEmpId != null)    safeClaims.put("ext_emp_id", extEmpId);
            if (email != null)       safeClaims.put("email", email);

            var auth = new OnBehalfAuthentication(username, authorities, ctx, safeClaims);
            auth.setDetails(safeClaims);
            SecurityContextHolder.getContext().setAuthentication(auth);


        } catch (Exception ex) {
            SecurityContextHolder.clearContext();
            reject(response);
            return;
        }

        filterChain.doFilter(request, response);
    }


    private static void reject(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
    }

    private static List<String> getStringList(Claims c, String k) {
        Object v = c.get(k);
        if (v instanceof List<?> l) return l.stream().map(Objects::toString).toList();
        return null;
    }

    private static String getString(Claims c, String k) {
        Object v = c.get(k);
        return v == null ? null : v.toString();
    }

    private static Boolean getBoolean(Claims c, String k) {
        Object v = c.get(k);
        if (v instanceof Boolean b) return b;
        if (v instanceof String s) return "true".equalsIgnoreCase(s);
        return null;
    }

    private static String firstNonNull(String a, String b) {
        return a != null ? a : b;
    }

    private static Long toLong(Object o) {
        if (o == null) return null;
        if (o instanceof Number n) return n.longValue();
        try { return Long.parseLong(o.toString()); } catch (Exception e) { return null; }
    }

    @SuppressWarnings("unchecked")
    private static List<Long> toLongList(Object o) {
        if (o == null) return List.of();
        if (o instanceof List<?> l) {
            List<Long> out = new ArrayList<>();
            for (Object e : l) {
                Long v = toLong(e);
                if (v != null) out.add(v);
            }
            return out;
        }
        return List.of();
    }

    private static void reject(HttpServletResponse response, String reason) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.getWriter().write("{\"error\":\"unauthorized\",\"reason\":\"" + reason + "\"}");
    }

}


/*
import com.RSADF.Murtakiz.modules.auth.infra.repository.SecurityDelegationSessionRepository;
import com.RSADF.Murtakiz.modules.auth.infra.service.JwtService;
import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;


import com.RSADF.Murtakiz.modules.auth.infra.repository.JwtBlacklistRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserSessionRepository;
import com.RSADF.Murtakiz.modules.auth.infra.service.JwtService;

import io.jsonwebtoken.Claims;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;


public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwt;
    private final JwtBlacklistRepository blacklistRepo;
    private final UserSessionRepository sessionRepo;
    private final SecurityDelegationSessionRepository actingSessionRepo;

    public JwtAuthenticationFilter(JwtService jwt,
                                   JwtBlacklistRepository blacklistRepo,
                                   UserSessionRepository sessionRepo,
                                   SecurityDelegationSessionRepository actingSessionRepo) {
        this.jwt = jwt;
        this.blacklistRepo = blacklistRepo;
        this.sessionRepo = sessionRepo;
        this.actingSessionRepo = actingSessionRepo;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (!StringUtils.hasText(authHeader) || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);
        try {
            Claims claims = jwt.parseAndValidate(token);

            String hash = TokenHash.sha256(token);
            if (blacklistRepo.existsByTokenHash(hash)) { reject(response); return; }

            var sessionOpt = sessionRepo.findByAccessTokenHashAndRevokedAtIsNull(hash);
            if (sessionOpt.isEmpty() || jwt.isExpired(claims)) { reject(response); return; }


            boolean acting = getBoolean(claims, "act") != null && getBoolean(claims, "act");
            if (acting) {
                Object del = claims.get("delegation");
                if (!(del instanceof Map<?,?> delMap)) { reject(response); return; }
                Object sid = delMap.get("session_id");
                if (sid == null) { reject(response); return; }
                Long sessionId = Long.valueOf(sid.toString());


                if (actingSessionRepo.findActiveById(sessionId).isEmpty()) {
                    reject(response); return;
                }
            }


            String username = getString(claims, "username");
            if (!StringUtils.hasText(username)) username = claims.getSubject();
            if (!StringUtils.hasText(username)) { filterChain.doFilter(request, response); return; }

            Boolean enabled = getBoolean(claims, "enabled");
            if (enabled != null && !enabled) { SecurityContextHolder.clearContext(); reject(response); return; }


            List<String> rolesEff = getStringList(claims, "roles_effective");
            if (rolesEff == null) rolesEff = getStringList(claims, "roles");
            if (rolesEff == null) rolesEff = getStringList(claims, "roles_actor");

            var authorities = new ArrayList<SimpleGrantedAuthority>();
            if (rolesEff != null) {
                authorities.addAll(
                        rolesEff.stream()
                                .filter(Objects::nonNull)
                                .map(String::trim)
                                .filter(s -> !s.isEmpty())
                                .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                                .map(SimpleGrantedAuthority::new)
                                .toList()
                );
            }

            var auth = new UsernamePasswordAuthenticationToken(username, null, authorities);


            Map<String, Object> safe = new HashMap<>(claims);

            String actorEmpNo = firstNonNull(getString(claims, "emp_no"), getString(claims, "empNo"));
            String ctxEmpNo   = firstNonNull(getString(claims, "ctx_emp_no"), actorEmpNo);
            safe.put("actor_emp_no", actorEmpNo);
            safe.put("ctx_emp_no", ctxEmpNo);

            auth.setDetails(Collections.unmodifiableMap(safe));
            SecurityContextHolder.getContext().setAuthentication(auth);

        } catch (Exception ex) {
            SecurityContextHolder.clearContext();
            reject(response);
            return;
        }

        filterChain.doFilter(request, response);
    }

    private static void reject(HttpServletResponse response) throws IOException { response.setStatus(401); }
    @SuppressWarnings("unchecked") private List<String> getStringList(Claims c, String k){ Object v=c.get(k); if(v instanceof List<?> l) return l.stream().map(Objects::toString).toList(); return null; }
    private static String getString(Claims c,String k){ Object v=c.get(k); return v==null?null:v.toString(); }
    private static Boolean getBoolean(Claims c,String k){ Object v=c.get(k); if(v instanceof Boolean b) return b; if(v instanceof String s) return "true".equalsIgnoreCase(s); return null; }
    private static String firstNonNull(String a, String b){ return a!=null?a:b; }
}*/


/*
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwt;
    private final JwtBlacklistRepository blacklistRepo;
    private final UserSessionRepository sessionRepo;

    public JwtAuthenticationFilter(JwtService jwt,
                                   JwtBlacklistRepository blacklistRepo,
                                   UserSessionRepository sessionRepo) {
        this.jwt = jwt;
        this.blacklistRepo = blacklistRepo;
        this.sessionRepo = sessionRepo;
    }

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain
    ) throws ServletException, IOException {

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (!StringUtils.hasText(authHeader) || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);
        try {

            Claims claims = jwt.parseAndValidate(token);


            String hash = TokenHash.sha256(token);


            if (blacklistRepo.existsByTokenHash(hash)) {
                reject(response);
                return;
            }


            var sessionOpt = sessionRepo.findByAccessTokenHashAndRevokedAtIsNull(hash);
            if (sessionOpt.isEmpty()) {
                reject(response);
                return;
            }

            var sess = sessionOpt.get();
            LocalDateTime now = LocalDateTime.now();
            if (sess.getExpiresAt() != null && now.isAfter(sess.getExpiresAt())) {
                reject(response);
                return;
            }


            String username = getString(claims, "username");
            if (!StringUtils.hasText(username)) {
                username = claims.getSubject();
            }
            if (!StringUtils.hasText(username)) {
                filterChain.doFilter(request, response);
                return;
            }

             claim enabled=false
            Boolean enabled = getBoolean(claims, "enabled");
            if (enabled != null && !enabled) {
                SecurityContextHolder.clearContext();
                reject(response);
                return;
            }

            List<String> roles = getStringList(claims, "roles");
            var authorities = new ArrayList<SimpleGrantedAuthority>();
            if (roles != null) {
                authorities.addAll(
                        roles.stream()
                                .filter(Objects::nonNull)
                                .map(String::trim)
                                .filter(s -> !s.isEmpty())
                                .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                                .map(SimpleGrantedAuthority::new)
                                .toList()
                );
            }

            AbstractAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(username, null, authorities);

            Map<String, Object> safeDetails = new HashMap<>(claims);
            authentication.setDetails(Collections.unmodifiableMap(safeDetails));

            SecurityContextHolder.getContext().setAuthentication(authentication);

        } catch (Exception ex) {

            SecurityContextHolder.clearContext();
            reject(response);
            return;
        }

        filterChain.doFilter(request, response);
    }

    private static void reject(HttpServletResponse response) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

        // response.getWriter().write("{\"error\":\"unauthorized\"}");
    }

    @SuppressWarnings("unchecked")
    private List<String> getStringList(Claims claims, String key) {
        Object v = claims.get(key);
        if (v instanceof List<?> list) {
            return list.stream().map(Objects::toString).collect(Collectors.toList());
        }
        return null;
    }

    private static String getString(Claims claims, String key) {
        Object v = claims.get(key);
        return v == null ? null : v.toString();
    }

    private Boolean getBoolean(Claims claims, String key) {
        Object v = claims.get(key);
        if (v instanceof Boolean b) return b;
        if (v instanceof String s) {
            if ("true".equalsIgnoreCase(s)) return Boolean.TRUE;
            if ("false".equalsIgnoreCase(s)) return Boolean.FALSE;
        }
        return null;
    }
}
*/


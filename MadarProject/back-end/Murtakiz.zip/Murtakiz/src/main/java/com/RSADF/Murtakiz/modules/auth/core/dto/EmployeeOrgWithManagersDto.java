package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeOrgWithManagersDto {
    private String empNo;
    private String fullNameAr;
    private Long uniteId;
    private String uniteName;
    private Long subUniteId;
    private String subUniteName;

    private boolean isManager;
    // "NONE" | "MAIN_UNIT_MANAGER" | "SUB_UNIT_MANAGER"
    private String managerLevel;

    // عدد المرؤوسين المباشرين
    private int directReportsCount;

    // لو المدير على وحدة رئيسية => قائمة مدراء الوحدات الفرعية التابعة
    // لو المدير على وحدة فرعية ولها وحدات فرعية داخلها => قائمة مدراء تلك الوحدات
    private List<ManagerSummaryDto> subordinateManagers;
}
package com.RSADF.Murtakiz.modules.kpi.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import com.RSADF.Murtakiz.modules.auth.infra.repository.SubUniteRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UniteRepository;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiStrategicGoalRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiStrategicGoalDto;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiStrategicGoal;
import com.RSADF.Murtakiz.modules.kpi.core.repository.KpiStrategicGoalRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class KpiStrategicGoalService {

    private final KpiStrategicGoalRepository goalRepository;
    private final UniteRepository uniteRepository;
    private final SubUniteRepository subUniteRepository;

    /**
     * إنشاء هدف استراتيجي جديد
     *
     * @param request    بيانات الهدف (من الـ DTO)
     * @param actorEmpNo رقم الموظف الحقيقي الذي نفّذ العملية (من SecurityUtils.actorEmpNo)
     * @param ctxEmpNo   رقم الموظف في سياق التمثيل (من SecurityUtils.ctxEmpNo)، قد يكون نفس actorEmpNo
     */



    @Transactional
    public KpiStrategicGoalDto createGoal(
            CreateKpiStrategicGoalRequest request,
            String actorEmpNo,
            String ctxEmpNo
    ) {

        if (goalRepository.existsByCode(request.getCode())) {
            throw new IllegalArgumentException("Goal code already exists: " + request.getCode());
        }

        KpiStrategicGoal goal = new KpiStrategicGoal();
        goal.setCode(request.getCode());
        goal.setNameAr(request.getNameAr());
        goal.setPerspectiveCode(request.getPerspectiveCode());

        String goalType = request.getGoalType();
        if (goalType == null || goalType.isBlank()) {

            goalType = "STRATEGIC";
        }
        goal.setGoalType(goalType);


        String ownerEmpNo = request.getOwnerEmpNo();
        if (ownerEmpNo == null || ownerEmpNo.isBlank()) {
            ownerEmpNo = (ctxEmpNo != null && !ctxEmpNo.isBlank())
                    ? ctxEmpNo
                    : actorEmpNo;
        }
        goal.setOwnerEmpNo(ownerEmpNo);

        goal.setRegionCode(request.getRegionCode());
        goal.setHorizonFromYear(request.getHorizonFromYear());
        goal.setHorizonToYear(request.getHorizonToYear());

        if (request.getParentGoalCode() != null && !request.getParentGoalCode().isBlank()) {
            if (!goalRepository.existsByCode(request.getParentGoalCode())) {
                throw new IllegalArgumentException("Parent goal not found: " + request.getParentGoalCode());
            }
            goal.setParentGoalCode(request.getParentGoalCode());
        }


        goal.setStatusCode("ON_TRACK");
        goal.setProgressPct(0.0);
        goal.setKpiCount(0);


        if (request.getOwnerUniteId() != null) {
            Unite unite = uniteRepository.findById(request.getOwnerUniteId())
                    .orElseThrow(() -> new IllegalArgumentException("Unite not found: " + request.getOwnerUniteId()));
            goal.setOwnerUnite(unite);
        }

        if (request.getOwnerSubUniteId() != null) {
            SubUnite subUnite = subUniteRepository.findById(request.getOwnerSubUniteId())
                    .orElseThrow(() -> new IllegalArgumentException("SubUnite not found: " + request.getOwnerSubUniteId()));
            goal.setOwnerSubUnite(subUnite);
        }

        goal.setCreatedAt(LocalDateTime.now());
        goal.setCreatedByEmpNo(actorEmpNo);

        KpiStrategicGoal saved = goalRepository.save(goal);

        return mapToDto(saved);
    }

    private KpiStrategicGoalDto mapToDto(KpiStrategicGoal entity) {
        KpiStrategicGoalDto dto = new KpiStrategicGoalDto();

        dto.setId(entity.getId());
        dto.setCode(entity.getCode());
        dto.setNameAr(entity.getNameAr());
        dto.setPerspectiveCode(entity.getPerspectiveCode());
        dto.setGoalType(entity.getGoalType());


        dto.setOwnerEmpNo(entity.getOwnerEmpNo());
        dto.setRegionCode(entity.getRegionCode());
        dto.setHorizonFromYear(entity.getHorizonFromYear());
        dto.setHorizonToYear(entity.getHorizonToYear());

        dto.setParentGoalCode(entity.getParentGoalCode());


        dto.setStatusCode(entity.getStatusCode());
        dto.setProgressPct(entity.getProgressPct());
        dto.setKpiCount(entity.getKpiCount());

        dto.setCreatedAt(entity.getCreatedAt());
        dto.setCreatedByEmpNo(entity.getCreatedByEmpNo());
        dto.setUpdatedAt(entity.getUpdatedAt());
        dto.setUpdatedByEmpNo(entity.getUpdatedByEmpNo());

        if (entity.getOwnerUnite() != null) {
            dto.setOwnerUniteId(entity.getOwnerUnite().getId());
        }
        if (entity.getOwnerSubUnite() != null) {
            dto.setOwnerSubUniteId(entity.getOwnerSubUnite().getId());
        }

        return dto;
    }

    /**
     * إرجاع الأهداف الاستراتيجية بناءً على وحدة رئيسية فقط
     */
    @Transactional(readOnly = true)
    public Page<KpiStrategicGoalDto> getGoalsByUnite(
            Long uniteId,
            String uniteName,
            String subUniteName,
            String code,
            String nameAr,
            String goalType,
            String perspectiveCode,
            String regionCode,
            String statusCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiStrategicGoal> result = goalRepository.searchGoals(
                uniteId,
                null,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                pageable
        );

        return result.map(this::mapToDto);
    }

    /**
     * إرجاع الأهداف الاستراتيجية بناءً على وحدة فرعية فقط
     */
    @Transactional(readOnly = true)
    public Page<KpiStrategicGoalDto> getGoalsBySubUnite(
            Long subUniteId,
            String uniteName,
            String subUniteName,
            String code,
            String nameAr,
            String goalType,
            String perspectiveCode,
            String regionCode,
            String statusCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiStrategicGoal> result = goalRepository.searchGoals(
                null,
                subUniteId,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                pageable
        );

        return result.map(this::mapToDto);
    }

    /**
     * إرجاع جميع الأهداف (مع فلاتر اختيارية) – بدون تقييد بوحدة معيّنة
     */
    @Transactional(readOnly = true)
    public Page<KpiStrategicGoalDto> getAllGoals(
            String uniteName,
            String subUniteName,
            String code,
            String nameAr,
            String goalType,
            String perspectiveCode,
            String regionCode,
            String statusCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiStrategicGoal> result = goalRepository.searchGoals(
                null,
                null,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                pageable
        );

        return result.map(this::mapToDto);
    }

    /**
     * بحث مرن: حسب وحدة رئيسية أو وحدة فرعية أو الاثنين معاً
     */
    @Transactional(readOnly = true)
    public Page<KpiStrategicGoalDto> searchGoalsByUniteOrSubUnite(
            Long uniteId,
            Long subUniteId,
            String uniteName,
            String subUniteName,
            String code,
            String nameAr,
            String goalType,
            String perspectiveCode,
            String regionCode,
            String statusCode,
            Integer page,
            Integer size,
            Boolean unpaged
    ) {
        Pageable pageable = buildPageable(page, size, unpaged);

        Page<KpiStrategicGoal> result = goalRepository.searchGoals(
                uniteId,
                subUniteId,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                pageable
        );

        return result.map(this::mapToDto);
    }





    private Pageable buildPageable(Integer page, Integer size, Boolean unpaged) {
        if (Boolean.TRUE.equals(unpaged)) {
            return Pageable.unpaged();
        }
        int p = (page == null || page < 0) ? 0 : page;
        int s = (size == null || size <= 0) ? 20 : size;
        return PageRequest.of(p, s, Sort.by(Sort.Direction.ASC, "code"));
    }
}





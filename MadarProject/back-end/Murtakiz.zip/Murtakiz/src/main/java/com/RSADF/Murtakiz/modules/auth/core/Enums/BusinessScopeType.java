package com.RSADF.Murtakiz.modules.auth.core.Enums;

public enum BusinessScopeType { DEPT_FULL, UNIT_LIMITED; }
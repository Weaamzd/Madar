package com.RSADF.Murtakiz;

import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public final class SecurityUtils {
    private SecurityUtils() {}

    public static ActingContext ctx() {
        Authentication a = SecurityContextHolder.getContext().getAuthentication();
        if (a instanceof OnBehalfAuthentication oba) return oba.getActingContext();
        return null;
    }

    public static String actorEmpNo() {
        var c = ctx(); return c == null ? null : c.actorEmpNo();
    }

    public static String ctxEmpNo() {
        var c = ctx(); return c == null ? null : c.ctxEmpNo();
    }

    public static boolean isActing() {
        var c = ctx(); return c != null && c.acting();
    }

    public static boolean hasAction(Action a) {
        var c = ctx(); return c != null && c.has(a);
    }

    public static boolean inUnite(Long uniteId) {
        var c = ctx(); return c != null && c.inUnite(uniteId);
    }

    public static boolean inSubUnite(Long subId) {
        var c = ctx(); return c != null && c.inSubUnite(subId);
    }
}

package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;


@Entity
@Table(name = "USERS", schema = "SYS")
@Getter @Setter @NoArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID")
    private Long id;

    @Column(name = "USERNAME", nullable = false, unique = true, length = 100)
    private String username;

    @Column(name = "PASSWORD_HASH", nullable = false, length = 200)
    private String passwordHash;

    @Column(name = "STATUS", length = 20)
    private String status; // Active / Inactive / Suspended

    @Column(name = "LAST_LOGIN_AT")
    private LocalDateTime lastLoginAt;




    @Column(name = "EMP_NO", length = 50, unique = true)
    private String empNo;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMP_NO", insertable = false, updatable = false)
    private Employee employee;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CURRENT_REGION_ID")
    private CurrentRegion currentRegion;


    @Column(name = "EXTERNAL_EMP_ID", length = 50)
    private String externalEmpId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EXTERNAL_EMP_ID", insertable = false, updatable = false)
    private ExternalEmployee externalEmployee;



    @Column(name = "ALLOWED_DAYS")
    private Integer allowedDays;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;


/*    @Column(name = "EXT_EMP_ID")
    private Long extEmpId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EXT_EMP_ID", insertable = false, updatable = false,
            foreignKey = @ForeignKey(name = "FK_USERS__EXT_EMP"))
    private ExternalEmployee externalEmployee;*/


    /*@ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "USER_ROLES",
            joinColumns = @JoinColumn(name = "USER_ID"),
            inverseJoinColumns = @JoinColumn(name = "ROLE_ID"))
    private Set<Role> roles = new HashSet<>();*/
}


package com.RSADF.Murtakiz;


import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import org.springframework.stereotype.Service;

@Service
public class PermissionService {


    public boolean has(Action action) {
        var c = SecurityUtils.ctx();
        return c != null && c.has(action);
    }


    public boolean inUnite(Long uniteId) {
        return SecurityUtils.inUnite(uniteId);
    }


    public boolean inSubUnite(Long subId) {
        return SecurityUtils.inSubUnite(subId);
    }


    public boolean canUpdateUnit(Long uniteId) {
        return has(Action.UPDATE) && inUnite(uniteId);
    }

    public boolean canCreateInSubUnit(Long subId) {
        return has(Action.CREATE) && inSubUnite(subId);
    }
}


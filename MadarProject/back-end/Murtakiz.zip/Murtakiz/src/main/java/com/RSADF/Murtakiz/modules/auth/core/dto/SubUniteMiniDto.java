package com.RSADF.Murtakiz.modules.auth.core.dto;


import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class SubUniteMiniDto {
    private Long id;
    private String code;
    private String name;
}
package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @ToString
public class RoleItemDto {
    private Long id;
    private String name;
}
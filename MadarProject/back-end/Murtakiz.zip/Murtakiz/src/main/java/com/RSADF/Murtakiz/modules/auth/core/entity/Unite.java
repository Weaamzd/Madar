package com.RSADF.Murtakiz.modules.auth.core.entity;


import jakarta.persistence.*;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(
        name = "UNITE",
        schema = "SYS",
        indexes = {
                @Index(name = "IX_UNITE__TYPE", columnList = "UNITE_TYPE_ID")
        }
)
@Getter @Setter @NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class Unite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "UNITE_ID")
    @EqualsAndHashCode.Include
    @ToString.Include
    private Long id;

    @Column(name = "UNITE_CODE", nullable = false, length = 50)
    @ToString.Include
    private String code;

    @Column(name = "UNITE_NAME", nullable = false, length = 200)
    @ToString.Include
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UNITE_TYPE_ID", nullable = false, foreignKey = @ForeignKey(name = "FK_UNITE__TYPE"))
    @ToString.Exclude
    private UniteType uniteType;

}


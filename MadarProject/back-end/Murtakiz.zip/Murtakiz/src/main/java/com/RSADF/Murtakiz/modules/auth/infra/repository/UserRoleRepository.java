package com.RSADF.Murtakiz.modules.auth.infra.repository;



import com.RSADF.Murtakiz.modules.auth.core.entity.UserRole;
import com.RSADF.Murtakiz.modules.auth.infra.service.RoleNameByUserProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {


    @Query(value = """
      SELECT r.ROLE_NAME
      FROM SYS.USER_ROLES ur
      JOIN SYS.ROLES r ON r.ROLE_ID = ur.ROLE_ID
      WHERE ur.USER_ID = :userId
      """, nativeQuery = true)
    List<String> findRoleNamesByUserId(@Param("userId") Long userId);

    @Query("""
           select ur
           from UserRole ur
           join fetch ur.role r
           where ur.user.id = :userId
           """)
    List<UserRole> findByUserIdWithRole(@Param("userId") Long userId);

    @Query(value = """
      SELECT ur.USER_ID as userId, r.ROLE_NAME as roleName
      FROM SYS.USER_ROLES ur
      JOIN SYS.ROLES r ON r.ROLE_ID = ur.ROLE_ID
      WHERE ur.USER_ID IN (:userIds)
    """, nativeQuery = true)
    List<RoleNameByUserProjection> findRoleNamesByUserIdIn(@Param("userIds") Collection<Long> userIds);

    @Query(value = """
      SELECT ur.ROLE_ID
      FROM SYS.USER_ROLES ur
      WHERE ur.USER_ID = :userId
    """, nativeQuery = true)
    List<Long> findRoleIdsByUserId(@Param("userId") Long userId);

    @Modifying
    @Query(value = """
      DELETE FROM SYS.USER_ROLES
      WHERE USER_ID = :userId
        AND ROLE_ID IN (:roleIds)
    """, nativeQuery = true)
    int deleteLinks(@Param("userId") Long userId, @Param("roleIds") Collection<Long> roleIds);




    @Query("""
        select ur.role.id
        from UserRole ur
        where ur.user.id = :userId
          and ur.role.id in :roleIds
    """)
    Set<Long> findExistingRoleIdsForUser(@Param("userId") Long userId, @Param("roleIds") Collection<Long> roleIds);


    @Modifying
    @Query("""
        delete from UserRole ur
        where ur.user.id = :userId
          and ur.role.id in :roleIds
    """)
    int deleteByUserIdAndRoleIds(@Param("userId") Long userId, @Param("roleIds") Collection<Long> roleIds);

    @Modifying
    @Query("""
        delete from UserRole ur
        where ur.user.id = (
            select u.id from User u
            join u.employee e
            where e.empNo = :empNo
        )
        and ur.role.id in :roleIds
    """)
    int deleteByEmpNoAndRoleIds(@Param("empNo") String empNo, @Param("roleIds") Collection<Long> roleIds);

    @Modifying
    @Query(value = """
  DELETE FROM SYS.USER_ROLES ur
  WHERE ur.USER_ID = (SELECT u.USER_ID FROM SYS.USERS u WHERE u.EMP_NO = :empNo)
    AND ur.ROLE_ID IN (:roleIds)
""", nativeQuery = true)
    int deleteByEmpNoAndRoleIdsNative(@Param("empNo") String empNo, @Param("roleIds") Collection<Long> roleIds);


    // List<String> findRoleNamesByUserId(Long userId);

/*    @Query("""
           select r.name
           from UserRole ur
           join ur.role r
           where ur.user.id = :userId
           """)
    List<String> findRoleNamesByUserId(@Param("userId") Long userId);*/
}

package com.RSADF.Murtakiz.modules.auth.core.Enums;



import java.util.*;

public enum Action {
    READ   (1L << 0),
    CREATE (1L << 1),
    UPDATE (1L << 2),
    DELETE (1L << 3),
    APPROVE(1L << 4);

    public final long bit;
    Action(long bit) { this.bit = bit; }


    public static final long ALL_MASK = Arrays.stream(values()).mapToLong(a -> a.bit).reduce(0L, (x,y)->x|y);

    public static long toMask(Collection<Action> actions) {
        if (actions == null || actions.isEmpty()) return 0L;
        long m = 0L; for (Action a : actions) m |= a.bit; return m;
    }
    public static EnumSet<Action> fromMask(Long mask) {
        long m = (mask == null ? 0L : mask);
        EnumSet<Action> set = EnumSet.noneOf(Action.class);
        for (Action a : values()) if ((m & a.bit) != 0) set.add(a);
        return set;
    }
    public static boolean includes(long mask, Action a) {
        return (mask & a.bit) != 0;
    }
}

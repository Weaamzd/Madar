package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InternalEmployeeDetailsDto {
    private String empNo;
    private String fullNameAr;
    private String email;
    private String jobTitle;
    private LocalDate hireDate;
    private LocalDate startDate;
    private String managerNo;
    private SubUniteMiniDto subUnite;
    private UniteMiniDto unite;
}
package com.RSADF.Murtakiz.modules.auth.core.dto;

public record DelegationScopeDtoFull(
        Long scopeId,

        // Unite (قد تكون null)
        Long uniteId,
        String uniteCode,
        String uniteName,

        // SubUnite (قد تكون null)
        Long subUniteId,
        String subUniteCode,
        String subUniteName,

        // حقولك الإضافية في الجدول
        String regionCode,
        String moduleKey,
        String permissionKey,

        // الماسك الخام + أسماء الأفعال المفكوكة (اختياري لراحة الفرونت)
        Long actionsMask,
        java.util.List<String> actions // مثل ["READ","CREATE","UPDATE"...]
) {}

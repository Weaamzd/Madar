package com.RSADF.Murtakiz.modules.auth.infra.service;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


/*
@Component
class LoginAttemptService {
    private final Map<String, Integer> failures = new ConcurrentHashMap<>();
    private final int MAX = 5;

    public void onSuccess(String u){ failures.remove(u); }
    public void onFailure(String u){ failures.merge(u, 1, Integer::sum); }
    public boolean blocked(String u){ return failures.getOrDefault(u,0) >= MAX; }
}
*/

public interface LoginAttemptService {
    boolean blocked(String username);
    void onSuccess(String username);
    void onFailure(String username);
}
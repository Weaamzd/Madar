package com.RSADF.Murtakiz.modules.auth.infra.service;



import com.RSADF.Murtakiz.modules.auth.core.entity.JwtBlacklist;
import com.RSADF.Murtakiz.modules.auth.core.entity.UserSession;
import com.RSADF.Murtakiz.modules.auth.infra.repository.JwtBlacklistRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserSessionRepository;

import com.RSADF.Murtakiz.modules.auth.jwt.TokenHash;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

@Service
@RequiredArgsConstructor
public class LogoutService {

    private final JwtBlacklistRepository blacklistRepo;
    private final UserSessionRepository sessionRepo;
    private final JwtInspector jwtInspector;


    @Transactional
    public void logoutCurrent(HttpServletRequest request, String reason) {
        String token = HttpTokenResolver.resolveAccessToken(request);
        if (token == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Missing access token");
        }

        String hash = TokenHash.sha256(token);


        if (!blacklistRepo.existsByTokenHash(hash)) {
            JwtBlacklist row = new JwtBlacklist();
            row.setTokenHash(hash);
            row.setJti(safe(() -> jwtInspector.extractJti(token)));
            row.setSubject(safe(() -> jwtInspector.extractSubject(token)));
            row.setExpiresAt(safe(() -> jwtInspector.extractExpiry(token)));
            row.setRevokedAt(LocalDateTime.now());
            row.setReason(reason != null ? reason : "USER_LOGOUT");
            row.setUserAgent(request.getHeader("User-Agent"));
            row.setIpAddress(request.getRemoteAddr());
            blacklistRepo.save(row);
        }


        Optional<UserSession> sessionOpt = sessionRepo.findByAccessTokenHashAndRevokedAtIsNull(hash);
        sessionOpt.ifPresent(s -> {
            s.setRevokedAt(LocalDateTime.now());
            sessionRepo.save(s);
        });


    }

    /** تسجيل الخروج من كل الأجهزة (كل الجلسات للمستخدم صاحب هذا التوكن) */
    @Transactional
    public long logoutAllDevices(HttpServletRequest request, String reason) {
        String token = HttpTokenResolver.resolveAccessToken(request);
        if (token == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Missing access token");
        }


        String subject = jwtInspector.extractSubject(token);
        Long userId = parseUserId(subject);
        if (userId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid token subject");
        }


        List<UserSession> active = sessionRepo.findByUser_IdAndRevokedAtIsNull(userId);
        LocalDateTime now = LocalDateTime.now();
        active.forEach(s -> s.setRevokedAt(now));
        sessionRepo.saveAll(active);


        return active.size();
    }

    private static Long parseUserId(String subject) {
        try { return subject == null ? null : Long.valueOf(subject); }
        catch (NumberFormatException e) { return null; }
    }

    private static <T> T safe(Supplier<T> fn) {
        try { return fn.get(); } catch (Exception e) { return null; }
    }
}

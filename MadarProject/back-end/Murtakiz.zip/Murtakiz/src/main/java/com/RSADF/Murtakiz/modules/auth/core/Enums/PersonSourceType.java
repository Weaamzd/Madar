package com.RSADF.Murtakiz.modules.auth.core.Enums;

public enum PersonSourceType {
    INTERNAL,
    EXTERNAL
}

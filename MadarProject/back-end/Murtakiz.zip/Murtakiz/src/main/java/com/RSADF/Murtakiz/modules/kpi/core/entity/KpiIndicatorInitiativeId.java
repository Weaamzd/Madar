package com.RSADF.Murtakiz.modules.kpi.core.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.*;

import java.io.Serializable;



import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class KpiIndicatorInitiativeId implements Serializable {

    private String kpiCode;
    private String initiativeCode;
}



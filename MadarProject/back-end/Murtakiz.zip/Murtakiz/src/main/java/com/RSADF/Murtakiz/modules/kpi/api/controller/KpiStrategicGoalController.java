package com.RSADF.Murtakiz.modules.kpi.api.controller;

import com.RSADF.Murtakiz.SecurityUtils;
import com.RSADF.Murtakiz.modules.kpi.core.dto.CreateKpiStrategicGoalRequest;
import com.RSADF.Murtakiz.modules.kpi.core.dto.KpiStrategicGoalDto;
import com.RSADF.Murtakiz.modules.kpi.infra.service.KpiStrategicGoalService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/murtakiz/kpi/goals")
@RequiredArgsConstructor
public class KpiStrategicGoalController {

    private final KpiStrategicGoalService goalService;

    @PostMapping
    public ResponseEntity<KpiStrategicGoalDto> createGoal(
            @RequestBody CreateKpiStrategicGoalRequest request
    ) {
        String actorEmpNo = SecurityUtils.actorEmpNo();
        String ctxEmpNo = SecurityUtils.ctxEmpNo();
        if (actorEmpNo == null) {
            throw new AccessDeniedException("لا يمكن تحديد رقم الموظف من التوكن (actorEmpNo = null)");
        }
        KpiStrategicGoalDto dto = goalService.createGoal(request, actorEmpNo, ctxEmpNo);
        return ResponseEntity.status(HttpStatus.CREATED).body(dto);
    }


    @GetMapping("/by-unite")
    public Page<KpiStrategicGoalDto> getByUnite(
            @RequestParam Long uniteId,

            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String nameAr,
            @RequestParam(required = false) String goalType,
            @RequestParam(required = false) String perspectiveCode,
            @RequestParam(required = false) String regionCode,
            @RequestParam(required = false) String statusCode,

            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return goalService.getGoalsByUnite(
                uniteId,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                page,
                size,
                unpaged
        );
    }



    @GetMapping("/by-sub-unite")
    public Page<KpiStrategicGoalDto> getBySubUnite(
            @RequestParam Long subUniteId,

            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String nameAr,
            @RequestParam(required = false) String goalType,
            @RequestParam(required = false) String perspectiveCode,
            @RequestParam(required = false) String regionCode,
            @RequestParam(required = false) String statusCode,

            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return goalService.getGoalsBySubUnite(
                subUniteId,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                page,
                size,
                unpaged
        );
    }



    @GetMapping("/all")
    public Page<KpiStrategicGoalDto> getAll(
            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String nameAr,
            @RequestParam(required = false) String goalType,
            @RequestParam(required = false) String perspectiveCode,
            @RequestParam(required = false) String regionCode,
            @RequestParam(required = false) String statusCode,

            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return goalService.getAllGoals(
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                page,
                size,
                unpaged
        );
    }


    @GetMapping("/search")
    public Page<KpiStrategicGoalDto> search(
            @RequestParam(required = false) Long uniteId,
            @RequestParam(required = false) Long subUniteId,

            @RequestParam(required = false) String uniteName,
            @RequestParam(required = false) String subUniteName,
            @RequestParam(required = false) String code,
            @RequestParam(required = false) String nameAr,
            @RequestParam(required = false) String goalType,
            @RequestParam(required = false) String perspectiveCode,
            @RequestParam(required = false) String regionCode,
            @RequestParam(required = false) String statusCode,

            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) Boolean unpaged
    ) {
        return goalService.searchGoalsByUniteOrSubUnite(
                uniteId,
                subUniteId,
                uniteName,
                subUniteName,
                code,
                nameAr,
                goalType,
                perspectiveCode,
                regionCode,
                statusCode,
                page,
                size,
                unpaged
        );
    }
}


package com.RSADF.Murtakiz.modules.auth.core.dto;


public record DelegationScopeDto(
        Long scopeId,
        Long uniteId,
        String uniteName,
        Long subUniteId,
        String subUniteName,
        Long actionsMask
) {}

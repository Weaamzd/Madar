package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.CurrentRegionDto;
import com.RSADF.Murtakiz.modules.auth.core.entity.CurrentRegion;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import com.RSADF.Murtakiz.modules.auth.infra.repository.CurrentRegionRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UniteRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@Transactional(readOnly = true)
public class CurrentRegionService {

    private final CurrentRegionRepository currentRegionRepo;
    private final UniteRepository uniteRepo;

    public CurrentRegionService(CurrentRegionRepository currentRegionRepo,
                               UniteRepository uniteRepo) {
        this.currentRegionRepo = currentRegionRepo;
        this.uniteRepo = uniteRepo;
    }


    public CurrentRegionDto getCurrentRegionByUnite(Long uniteId) {

        Unite u = uniteRepo.findById(uniteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Unite غير موجود: " + uniteId));


        CurrentRegion cr = currentRegionRepo.findFirstByUnite_IdOrderByIdDesc(uniteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "لا توجد منطقة حالية لهذه الوحدة: " + uniteId));


        CurrentRegionDto dto = new CurrentRegionDto();
        dto.setId(cr.getId());
        dto.setRegionCode(cr.getRegionCode());
        dto.setRegionDbKey(cr.getRegionDbKey());
        dto.setUniteId(u.getId());
        dto.setUniteCode(u.getCode());
        dto.setUniteName(u.getName());
        return dto;
    }
}

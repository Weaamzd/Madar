package com.RSADF.Murtakiz.modules.auth.core.entity;

public class UserLinkHistory {
}

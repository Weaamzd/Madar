package com.RSADF.Murtakiz.modules.auth.jwt;


import io.jsonwebtoken.Claims;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Component
public class JwtInspector {

    public String extractJti(Claims claims) {
        return claims.getId(); // JTI
    }
    public LocalDateTime extractExpiry(Claims claims) {
        Date exp = claims.getExpiration();
        return (exp == null) ? null : LocalDateTime.ofInstant(exp.toInstant(), ZoneId.systemDefault());
    }
}

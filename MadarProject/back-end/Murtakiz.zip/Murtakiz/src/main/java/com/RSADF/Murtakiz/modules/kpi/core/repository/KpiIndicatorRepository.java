package com.RSADF.Murtakiz.modules.kpi.core.repository;

import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicator;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

public interface KpiIndicatorRepository extends JpaRepository<KpiIndicator, Long> {
    @Query(
            value = """
            SELECT i.*
            FROM SYS.KPI_INDICATOR i
            WHERE (:goalCode   IS NULL OR i.GOAL_CODE   = :goalCode)
              AND (:isMain     IS NULL OR i.IS_MAIN     = :isMain)
              AND (:isActive   IS NULL OR i.IS_ACTIVE   = :isActive)
              AND (
                    i.OWNER_UNITE_ID = :uniteId
                 OR i.OWNER_SUB_UNITE_ID IN (
                        SELECT su.SUB_UNITE_ID
                        FROM SYS.SUB_UNITE su
                        START WITH su.UNITE_ID = :uniteId
                        CONNECT BY PRIOR su.SUB_UNITE_ID = su.PARENT_SUB_UNITE_ID
                   )
              )
            """,
            nativeQuery = true
    )
    List<KpiIndicator> findByUniteTreeNative(
            @Param("goalCode") String goalCode,
            @Param("uniteId") Long uniteId,
            @Param("isMain") String isMain,
            @Param("isActive") String isActive
    );

    @Query(
            value = """
            SELECT i.*
            FROM SYS.KPI_INDICATOR i
            WHERE (:goalCode   IS NULL OR i.GOAL_CODE   = :goalCode)
              AND (:isMain     IS NULL OR i.IS_MAIN     = :isMain)
              AND (:isActive   IS NULL OR i.IS_ACTIVE   = :isActive)
              AND i.OWNER_SUB_UNITE_ID IN (
                    SELECT su.SUB_UNITE_ID
                    FROM SYS.SUB_UNITE su
                    START WITH su.SUB_UNITE_ID = :subUniteId
                    CONNECT BY PRIOR su.SUB_UNITE_ID = su.PARENT_SUB_UNITE_ID
              )
            """,
            nativeQuery = true
    )
    List<KpiIndicator> findBySubUniteTreeNative(
            @Param("goalCode") String goalCode,
            @Param("subUniteId") Long subUniteId,
            @Param("isMain") String isMain,
            @Param("isActive") String isActive
    );

    @Query(
            value = "SELECT KPI_ID, OWNER_UNITE_ID, OWNER_SUB_UNITE_ID FROM SYS.KPI_INDICATOR",
            nativeQuery = true
    )
    List<Object[]> debugIds();

    boolean existsByCode(String code);

    Optional<KpiIndicator> findByCode(String code);

    long countByGoalCode(String goalCode);

    @Query("""
            select k
            from KpiIndicator k
            where k.isMain = 'Y'
              and k.isActive = 'Y'
              and (:uniteId is null or k.ownerUnite.id = :uniteId)
            """)
    List<KpiIndicator> findMainIndicatorsByUnite(@Param("uniteId") Long uniteId);

    List<KpiIndicator> findByGoalCodeAndIsActive(String goalCode, String isActive);

    List<KpiIndicator> findByParentKpiCodeAndIsActive(String parentKpiCode, String isActive);


    @Query("""
           select k
           from KpiIndicator k
           left join k.ownerUnite u
           left join k.ownerSubUnite su
           where (:goalCode   is null or k.goalCode = :goalCode)
             and (:uniteId    is null or u.id = :uniteId)
             and (:subUniteId is null or su.id = :subUniteId)
             and (:isMain     is null or k.isMain = :isMain)
             and (:isActive   is null or k.isActive = :isActive)
           """)
    Page<KpiIndicator> searchIndicators(
            @Param("goalCode")   String goalCode,
            @Param("uniteId")    Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("isMain")     String isMain,
            @Param("isActive")   String isActive,
            Pageable pageable
    );


    List<KpiIndicator> findByParentKpiCode(String parentKpiCode);
}


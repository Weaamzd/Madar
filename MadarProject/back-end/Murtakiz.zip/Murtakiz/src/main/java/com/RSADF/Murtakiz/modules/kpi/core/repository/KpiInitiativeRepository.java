package com.RSADF.Murtakiz.modules.kpi.core.repository;

import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiInitiative;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface KpiInitiativeRepository extends JpaRepository<KpiInitiative, Long> {
  /*  boolean existsByCode(String code);
    Optional<KpiInitiative> findByCode(String code);*/

    boolean existsByInitiativeCode(String initiativeCode);

    Optional<KpiInitiative> findByInitiativeCode(String initiativeCode);
}

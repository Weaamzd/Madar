package com.RSADF.Murtakiz.modules.kpi.core.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class CreateKpiIndicatorReadingRequest {

    private String kpiCode;

    private LocalDate periodStartDate;
    private LocalDate periodEndDate;
    private String periodLabel;

    private Double actualValue;
    private String statusCode;

    private String dataSourceName;
    private String notes;
}


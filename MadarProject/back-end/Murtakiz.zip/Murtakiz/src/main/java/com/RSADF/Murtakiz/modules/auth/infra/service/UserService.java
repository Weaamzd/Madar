package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import com.RSADF.Murtakiz.modules.auth.core.entity.ExternalEmployee;
import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRoleRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final UserRoleRepository userRoleRepository;
    private final UserSessionRepository userSessionRepository;

    public UserService(UserRepository userRepository,
                       UserRoleRepository userRoleRepository,
                       UserSessionRepository userSessionRepository) {
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
        this.userSessionRepository = userSessionRepository;
    }


    public void checkUserAuto(String username) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        if (userOpt.isPresent()) {
            System.out.println(" المستخدم موجود: " + userOpt.get().getUsername());
        } else {
            System.out.println(" المستخدم غير موجود");
        }
    }




    @Transactional(readOnly = true)
    public Optional<UserSummary> getProfileByEmpNo(String empNo) {

        Optional<User> opt = userRepository.findOneWithDetailsByEmpNo(empNo);
        if (opt.isEmpty()) return Optional.empty();

        User u = opt.get();

        String fullName = null, email = null, jobTitle = null, regionCode = null, regionDbKey = null;

        if (u.getEmployee() != null) {
            fullName = u.getEmployee().getFullNameAr();
            email    = u.getEmployee().getEmail();
            jobTitle = u.getEmployee().getJobTitle();
        }
        if (u.getCurrentRegion() != null) {
            regionCode = u.getCurrentRegion().getRegionCode();
            regionDbKey = u.getCurrentRegion().getRegionDbKey();
        }

        List<String> roles = Optional
                .ofNullable(userRoleRepository.findRoleNamesByUserId(u.getId()))
                .orElseGet(List::of);

        UserSummary summary = new UserSummary(
                u.getId(),
                u.getUsername(),
                empNo,
                fullName,
                email,
                jobTitle,
                regionCode,
                regionDbKey,
                roles
        );

        return Optional.of(summary);
    }


    public Optional<UserFullProfileDto> getFullProfileByUsername(String username) {
        Optional<User> opt = userRepository.findOneWithEverythingByUsername(username);
        if (opt.isEmpty()) return Optional.empty();

        User u = opt.get();

        UserMiniDto userDto = new UserMiniDto(
                u.getId(),
                u.getUsername(),
                u.getStatus(),
                u.getLastLoginAt(),
                u.getCurrentRegion() != null ? u.getCurrentRegion().getId() : null,
                u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionCode() : null,
                u.getCurrentRegion() != null ? u.getCurrentRegion().getRegionDbKey() : null
        );


        List<String> roles = Optional
                .ofNullable(userRoleRepository.findRoleNamesByUserId(u.getId()))
                .orElseGet(List::of);

        boolean loggedIn = false;
        if (userSessionRepository != null) {
            loggedIn = userSessionRepository.hasActiveSessions(u.getId(), LocalDateTime.now());
        }

        InternalEmployeeDetailsDto internal = null;
        ExternalEmployeeDetailsDto2 external = null;
        String profileType = "UNLINKED";

        if (u.getEmployee() != null) {
            Employee e = u.getEmployee();

            SubUniteMiniDto subDto = null;
            UniteMiniDto uniteDto = null;
            if (e.getSubUnite() != null) {
                var su = e.getSubUnite();
                subDto = new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
                if (su.getUnite() != null) {
                    var uu = su.getUnite();
                    uniteDto = new UniteMiniDto(uu.getId(), uu.getCode(), uu.getName());
                }
            }

            internal = InternalEmployeeDetailsDto.builder()
                    .empNo(e.getEmpNo())
                    .fullNameAr(e.getFullNameAr())
                    .email(e.getEmail())
                    .jobTitle(e.getJobTitle())
                    .hireDate(e.getHireDate())
                    .startDate(e.getStartDate())
                    .managerNo(e.getManagerNo())
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .build();

            profileType = "INTERNAL";
        } else if (u.getExternalEmployee() != null) {
            ExternalEmployee ee = u.getExternalEmployee();

            SubUniteMiniDto subDto = null;
            UniteMiniDto uniteDto = null;
            if (ee.getSubUniteId() != null) {
                var su = ee.getSubUniteId();
                subDto = new SubUniteMiniDto(su.getId(), su.getCode(), su.getName());
                if (su.getUnite() != null) {
                    var uu = su.getUnite();
                    uniteDto = new UniteMiniDto(uu.getId(), uu.getCode(), uu.getName());
                }
            }

            external = ExternalEmployeeDetailsDto2.builder()
                    .id(ee.getId())
                    .fullNameAr(ee.getFullNameAr())
                    .fullNameEn(ee.getFullNameEn())
                    .email(ee.getEmail())
                    .phone(ee.getPhone())
                    .organizationName(ee.getOrganizationName())
                    .jobTitle(ee.getJobTitle())
                    .collaborationType(ee.getCollaborationType())
                    .startDate(ee.getStartDate())
                    .endDate(ee.getEndDate())
                    .status(ee.getStatus())
                    .notes(ee.getNotes())
                    .managerEmpNo(ee.getEmpManagerNo() != null ? ee.getEmpManagerNo().getEmpNo() : null)
                    .subUnite(subDto)
                    .unite(uniteDto)
                    .build();

            profileType = "EXTERNAL";
        }

        return Optional.of(
                UserFullProfileDto.builder()
                        .profileType(profileType)
                        .user(userDto)
                        .roles(roles)
                        .loggedIn(loggedIn)
                        .internalDetails(internal)
                        .externalDetails(external)
                        .build()
        );
    }
    //  @Query
    /*public void checkUserManual(String username) {
        Optional<User> userOpt = userRepository.findRawByUsername(username);
        userOpt.ifPresentOrElse(
                user -> System.out.println(" وجدنا المستخدم: " + user.getUsername()),
                () -> System.out.println(" لا يوجد مستخدم بهذا الاسم")
        );
    }*/
}

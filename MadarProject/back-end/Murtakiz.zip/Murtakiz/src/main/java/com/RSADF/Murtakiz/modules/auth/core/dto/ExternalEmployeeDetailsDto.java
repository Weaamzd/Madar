package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalEmployeeDetailsDto {
    private String id;
    private String fullNameAr;
    private String fullNameEn;
    private String email;
    private String phone;
    private String organizationName;
    private String jobTitle;
    private String collaborationType;
    private LocalDate startDate;
    private LocalDate endDate;
    private String status;
    private String notes;

    // المدير (اختياري)
    private String managerEmpNo;

    // علاقات التنظيم المصغّرة
    private SubUniteMiniDto subUnite; // id, code, name
    private UniteMiniDto unite;       // id, code, name
}


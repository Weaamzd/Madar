package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import com.RSADF.Murtakiz.modules.auth.core.dto.*;
import com.RSADF.Murtakiz.modules.auth.core.dto.PageResponse;
import com.RSADF.Murtakiz.modules.auth.core.entity.*;

import com.RSADF.Murtakiz.modules.auth.infra.repository.*;
import com.RSADF.Murtakiz.modules.auth.jwt.ClaimsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;


import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static freemarker.template.utility.StringUtil.emptyToNull;

@Service
@Transactional
public class DelegationService {

    private final SecurityDelegationRepository delegationRepo;
    private final SecurityDelegationScopeRepository scopeRepo;
    private final SecurityDelegationSessionRepository sessionRepo;
    private final JwtBlacklistRepository blacklistRepo;
    private final ClaimsMapper claimsMapper;
    private final UserRepository userRepo;
    private final UniteRepository uniteRepo;
    private final SubUniteRepository subUniteRepo;
    private final JwtService jwtService;
    private final UserRoleRepository userRoleRepo;


    private static java.util.List<String> actionsFromMask(Long mask) {
        if (mask == null || mask == 0L) return java.util.List.of();
        java.util.EnumSet<Action> set = Action.fromMask(mask);

        return set.stream().map(Enum::name).toList();
    }

    @Transactional(readOnly = true)
    public java.util.List<DelegationFullDetailsDto> listAllDelegationsFull() {
        var delegations = delegationRepo.findAllWithPeople();
        return buildFull(delegations);
    }


    @Transactional(readOnly = true)
    public java.util.List<DelegationFullDetailsDto> listDelegationsFullFiltered(
            String creatorEmpNo, String delegatorEmpNo, String delegateeEmpNo, DelegationStatus status) {
        var delegations = delegationRepo.findAllWithPeopleFiltered(
                emptyToNull(creatorEmpNo), emptyToNull(delegatorEmpNo), emptyToNull(delegateeEmpNo), status);
        return buildFull(delegations);
    }

    @Transactional(readOnly = true)
    public List<DelegationFullDetailsDto> listDelegationsFullFilteredByScope(
            Long uniteId,
            Long subUniteId,
            String creatorEmpNo,
            String delegatorEmpNo,
            String delegateeEmpNo,
            DelegationStatus status
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }

        var delegations = delegationRepo.findAllByScopeFiltered(
                uniteId, subUniteId,
                emptyToNull(creatorEmpNo),
                emptyToNull(delegatorEmpNo),
                emptyToNull(delegateeEmpNo),
                status
        );

        return buildFull(delegations);
    }



    private java.util.List<DelegationFullDetailsDto> buildFull(java.util.List<SecurityDelegation> delegations) {
        var ids = delegations.stream().map(SecurityDelegation::getId).toList();


        var scopes = scopeRepo.findAllByDelegationIdsWithJoins(ids);
        var scopesByDeleg = scopes.stream().collect(java.util.stream.Collectors.groupingBy(s -> s.getDelegation().getId()));

        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999, 12, 31, 23, 59, 59);

        java.util.List<DelegationFullDetailsDto> out = new java.util.ArrayList<>(delegations.size());

        for (var d : delegations) {
            var dScopes = scopesByDeleg.getOrDefault(d.getId(), java.util.List.of());

            long maskAgg = dScopes.stream()
                    .map(SecurityDelegationScope::getActionsMask)
                    .filter(java.util.Objects::nonNull)
                    .reduce(0L, (a,b) -> a | b);
            if (maskAgg == 0) maskAgg = Action.ALL_MASK;

            var actionsAll = new java.util.LinkedHashSet<String>();
            actionsAll.addAll(actionsFromMask(maskAgg));

            var scopeDtos = new java.util.ArrayList<DelegationScopeDtoFull>(dScopes.size());
            for (var s : dScopes) {
                var unite = s.getUnite();
                var sub   = s.getSubUnite();

                var oneScopeActions = actionsFromMask(s.getActionsMask());
                actionsAll.addAll(oneScopeActions);

                scopeDtos.add(new DelegationScopeDtoFull(
                        s.getId(),
                        // unite
                        (unite != null ? unite.getId() : null),
                        (unite != null ? unite.getCode() : null),
                        (unite != null ? unite.getName() : null),
                        // sub
                        (sub != null ? sub.getId() : null),
                        (sub != null ? sub.getCode() : null),
                        (sub != null ? sub.getName() : null),
                        // extra cols
                        s.getRegionCode(),
                        s.getModuleKey(),
                        s.getPermissionKey(),
                        s.getActionsMask(),
                        oneScopeActions
                ));
            }


            boolean withinWindow = !now.isBefore(d.getStartAt()) &&
                    !now.isAfter(d.getEndAt() == null ? maxTime : d.getEndAt());
            boolean activeNow = (d.getStatus() == DelegationStatus.ACTIVE) && withinWindow;


            var du = d.getDelegatorUser();
            var de = d.getDelegateeUser();
            var cu = d.getCreatedByUser();
            var abu = d.getAcceptedByUser();

            var due = (du != null ? du.getEmployee() : null);
            var dee = (de != null ? de.getEmployee() : null);
            var cue = (cu != null ? cu.getEmployee() : null);
            var abue = (abu != null ? abu.getEmployee() : null);


            long activeSessions = sessionRepo.countActiveByDelegationId(d.getId());
            long totalSessions  = sessionRepo.countByDelegationId(d.getId());

            out.add(new DelegationFullDetailsDto(
                    d.getId(),
                    d.getStatus(),
                    d.getScopeType(),
                    d.getRequireAcceptance(),
                    d.getAllowSubdelegate(),
                    d.getNoExpiry(),
                    d.getStartAt(),
                    d.getEndAt(),
                    d.getCreatedAt(),

                    activeNow,
                    withinWindow,

                    du != null ? du.getEmpNo() : null,
                    du != null ? du.getUsername() : null,
                    due != null ? due.getFullNameAr() : null,

                    de != null ? de.getEmpNo() : null,
                    de != null ? de.getUsername() : null,
                    dee != null ? dee.getFullNameAr() : null,

                    cu != null ? cu.getEmpNo() : null,
                    cu != null ? cu.getUsername() : null,
                    cue != null ? cue.getFullNameAr() : null,

                    d.getAcceptedAt(),
                    abu != null ? abu.getEmpNo() : null,
                    abu != null ? abu.getUsername() : null,
                    abue != null ? abue.getFullNameAr() : null,

                    maskAgg,
                    new java.util.ArrayList<>(actionsAll),

                    activeSessions,
                    totalSessions,

                    scopeDtos
            ));
        }
        return out;
    }

    private static String emptyToNull(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }

    public DelegationService(SecurityDelegationRepository delegationRepo,
                             SecurityDelegationScopeRepository scopeRepo,
                             SecurityDelegationSessionRepository sessionRepo,
                             JwtBlacklistRepository blacklistRepo,
                             ClaimsMapper claimsMapper,
                             UserRepository userRepo,
                             UniteRepository uniteRepo,
                             SubUniteRepository subUniteRepo,
                             JwtService jwtService,
                             UserRoleRepository userRoleRepo) {
        this.delegationRepo = delegationRepo;
        this.scopeRepo = scopeRepo;
        this.sessionRepo = sessionRepo;
        this.blacklistRepo = blacklistRepo;
        this.claimsMapper = claimsMapper;
        this.userRepo = userRepo;
        this.uniteRepo = uniteRepo;
        this.subUniteRepo = subUniteRepo;
        this.jwtService = jwtService;
        this.userRoleRepo = userRoleRepo;
    }

    public DelegationResponse create(CreateDelegationRequest req, String delegatorEmpNoFromToken) {
        String delegatorEmpNo = (req.getDelegatorEmpNo() != null && !req.getDelegatorEmpNo().isBlank())
                ? req.getDelegatorEmpNo()
                : delegatorEmpNoFromToken;

        if (delegatorEmpNo == null || delegatorEmpNo.isBlank())
            throw bad("delegatorEmpNo is required (body or token)");

        if (req.getDelegateeEmpNo() == null || req.getDelegateeEmpNo().isBlank())
            throw bad("delegateeEmpNo is required");

        if (delegatorEmpNo.equals(req.getDelegateeEmpNo()))
            throw bad("Cannot delegate to self");

        if (req.getStartAt() == null)
            throw bad("startAt is required");

        if (Boolean.TRUE.equals(req.getNoExpiry())) {
            if (req.getEndAt() != null) throw bad("endAt must be null when noExpiry=true");
        } else {
            if (req.getEndAt() == null) throw bad("endAt is required when noExpiry=false");
            if (!req.getEndAt().isAfter(req.getStartAt()))
                throw bad("endAt must be after startAt");
        }

        if (req.getScopeType() == null) throw bad("scopeType is required");

        User delegator = userRepo.findByEmpNo(delegatorEmpNo)
                .orElseThrow(() -> notFound("Delegator user not found by empNo: " + delegatorEmpNo));
        User delegatee = userRepo.findByEmpNo(req.getDelegateeEmpNo())
                .orElseThrow(() -> notFound("Delegatee user not found by empNo: " + req.getDelegateeEmpNo()));

        LocalDateTime maxTime = LocalDateTime.of(9999, 12, 31, 23, 59, 59);
        LocalDateTime newStart = req.getStartAt();
        LocalDateTime newEnd   = Boolean.TRUE.equals(req.getNoExpiry()) ? maxTime : req.getEndAt();
        boolean existsOverlap = delegationRepo.existsOverlappingOpen(
                delegatorEmpNo,
                req.getDelegateeEmpNo(),
                newStart,
                newEnd,
                maxTime,
                List.of(DelegationStatus.ACTIVE, DelegationStatus.PENDING)
        );
        if (existsOverlap) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Delegation already exists (ACTIVE/PENDING) for this pair within the selected dates");
        }

        SecurityDelegation d = new SecurityDelegation();
        d.setDelegatorUser(delegator);
        d.setDelegateeUser(delegatee);
        d.setScopeType(req.getScopeType());
        d.setRequireAcceptance(Boolean.TRUE.equals(req.getRequireAcceptance()));
        d.setAllowSubdelegate(Boolean.TRUE.equals(req.getAllowSubdelegate()));
        d.setStartAt(req.getStartAt());
        d.setNoExpiry(Boolean.TRUE.equals(req.getNoExpiry()));
        d.setEndAt(req.getNoExpiry() ? null : req.getEndAt());
        d.setCreatedAt(LocalDateTime.now());
        d.setCreatedByUser(delegator);

        boolean startsInFuture = req.getStartAt().isAfter(LocalDateTime.now());
        if (Boolean.TRUE.equals(req.getRequireAcceptance())) {
            d.setStatus(DelegationStatus.PENDING);
        } else {
            d.setStatus(startsInFuture ? DelegationStatus.PENDING : DelegationStatus.ACTIVE);
        }

        delegationRepo.save(d);

        long scopesCount = 0;
        long mask = resolveActionsMask(req.getActions()); // null/empty => ALL

        if (req.getScopeType() == DelegationScopeType.ALL) {

        } else {
            if (req.getUniteId() != null) {
                Unite unite = uniteRepo.findById(req.getUniteId())
                        .orElseThrow(() -> notFound("Unite not found: " + req.getUniteId()));
                SecurityDelegationScope s = new SecurityDelegationScope();
                s.setDelegation(d);
                s.setUnite(unite);
                s.setActionsMask(mask);
                scopeRepo.save(s);
                scopesCount++;
            }

            if (req.getSubUnitIds() != null && !req.getSubUnitIds().isEmpty()) {
                List<SubUnite> subs = subUniteRepo.findByIdIn(req.getSubUnitIds());
                if (subs.size() != req.getSubUnitIds().size()) {
                    throw bad("Some subUnitIds do not exist");
                }
                for (SubUnite su : subs) {
                    SecurityDelegationScope s = new SecurityDelegationScope();
                    s.setDelegation(d);
                    s.setSubUnite(su);
                    s.setActionsMask(mask);
                    scopeRepo.save(s);
                    scopesCount++;
                }
            }

            if (req.getUniteId() == null && (req.getSubUnitIds() == null || req.getSubUnitIds().isEmpty())) {
                throw bad("LIMITED scope requires uniteId or subUnitIds");
            }
        }

        return new DelegationResponse(
                d.getId(),
                d.getStatus().name(),
                d.getStartAt(),
                d.getEndAt(),
                d.getNoExpiry(),
                delegatorEmpNo,
                req.getDelegateeEmpNo(),
                d.getScopeType(),
                scopesCount
        );
    }

    private static long resolveActionsMask(List<String> actions) {
        if (actions == null || actions.isEmpty()) return Action.ALL_MASK;
        EnumSet<Action> set = EnumSet.noneOf(Action.class);
        for (String s : actions) {
            try {
                set.add(Action.valueOf(s.trim().toUpperCase()));
            } catch (Exception ex) {
                throw bad("Unknown action: " + s + " (valid: READ,CREATE,UPDATE,DELETE,APPROVE)");
            }
        }
        return Action.toMask(set);
    }

    private static ResponseStatusException bad(String msg) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, msg);
    }
    private static ResponseStatusException notFound(String msg) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, msg);
    }

    @Transactional(readOnly = true)
    public boolean hasActiveDelegation(String delegatorEmpNo, String delegateeEmpNo) {
        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999, 12, 31, 23, 59, 59);
        var list = delegationRepo.findActiveByEmpNos(
                delegatorEmpNo,
                delegateeEmpNo,
                now,
                maxTime,
                DelegationStatus.ACTIVE
        );
        return !list.isEmpty();
    }

    public DelegationResponse revoke(Long delegationId, String actorEmpNo) {
        SecurityDelegation d = delegationRepo.findByIdForUpdate(delegationId)
                .orElseThrow(() -> notFound("Delegation not found: " + delegationId));

        String delegator = d.getDelegatorUser().getEmpNo();
        String createdBy  = d.getCreatedByUser() != null ? d.getCreatedByUser().getEmpNo() : null;
        boolean allowed = actorEmpNo == null
                || actorEmpNo.equals(delegator)
                || (createdBy != null && createdBy.equals(actorEmpNo));
        if (!allowed) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not allowed to revoke this delegation");
        }

        if (d.getStatus() == DelegationStatus.REVOKED || d.getStatus() == DelegationStatus.EXPIRED) {
            long scopesCount = scopeRepo.countByDelegation_Id(d.getId());
            return new DelegationResponse(
                    d.getId(), d.getStatus().name(), d.getStartAt(), d.getEndAt(), d.getNoExpiry(),
                    d.getDelegatorUser().getEmpNo(), d.getDelegateeUser().getEmpNo(), d.getScopeType(), scopesCount
            );
        }

        LocalDateTime now = LocalDateTime.now();
        d.setStatus(DelegationStatus.REVOKED);
        d.setNoExpiry(false);
        if (d.getEndAt() == null || d.getEndAt().isAfter(now)) {
            d.setEndAt(now);
        }
        delegationRepo.save(d);

        sessionRepo.deactivateAllByDelegationId(d.getId(), now);

        long scopesCount = scopeRepo.countByDelegation_Id(d.getId());
        return new DelegationResponse(
                d.getId(), d.getStatus().name(), d.getStartAt(), d.getEndAt(), d.getNoExpiry(),
                d.getDelegatorUser().getEmpNo(), d.getDelegateeUser().getEmpNo(), d.getScopeType(), scopesCount
        );
    }

    @Transactional(readOnly = true)
    public List<ActingContextDto> listActingContexts(String actorEmpNo) {
        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999,12,31,23,59,59);
        var list = delegationRepo.findEligibleForActor(actorEmpNo, now, maxTime, DelegationStatus.ACTIVE);

        List<ActingContextDto> out = new ArrayList<>();
        for (var d : list) {
            var scopes = scopeRepo.findByDelegation_Id(d.getId());
            long mask = scopes.stream()
                    .map(SecurityDelegationScope::getActionsMask)
                    .filter(Objects::nonNull)
                    .reduce(0L, (a,b) -> a | b);
            var uniteIds = scopes.stream().map(SecurityDelegationScope::getUnite).filter(Objects::nonNull).map(Unite::getId).toList();
            var subIds = scopes.stream().map(SecurityDelegationScope::getSubUnite).filter(Objects::nonNull).map(SubUnite::getId).toList();

            out.add(new ActingContextDto(
                    d.getId(),
                    d.getDelegatorUser().getEmpNo(),
                    d.getDelegatorUser().getUsername(),
                    d.getScopeType(),
                    mask == 0 ? Action.ALL_MASK : mask,
                    uniteIds, subIds,
                    d.getStartAt(), d.getEndAt()
            ));
        }
        return out;
    }


    public ActingTokenResponse startActing(Long delegationId, String actorEmpNo, String userAgent, String ipAddress) {

        SecurityDelegation d = delegationRepo.findByIdForUpdate(delegationId)
                .orElseThrow(() -> notFound("Delegation not found: " + delegationId));

        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999,12,31,23,59,59);
        if (d.getStatus() != DelegationStatus.ACTIVE || now.isBefore(d.getStartAt())
                || now.isAfter(d.getEndAt() == null ? maxTime : d.getEndAt()))
            throw bad("Delegation is not active in time window");

        if (!d.getDelegateeUser().getEmpNo().equals(actorEmpNo))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Actor is not the delegatee");

        User actor = d.getDelegateeUser();
        User onBehalf = d.getDelegatorUser();


        var scopes = scopeRepo.findByDelegation_Id(d.getId());
        long actionsMask = scopes.stream()
                .map(SecurityDelegationScope::getActionsMask)
                .filter(Objects::nonNull)
                .reduce(0L, (a,b) -> a | b);
        if (actionsMask == 0) actionsMask = Action.ALL_MASK;

        var uniteIds = scopes.stream().map(s -> s.getUnite() == null ? null : s.getUnite().getId())
                .filter(Objects::nonNull).toList();
        var subIds = scopes.stream().map(s -> s.getSubUnite() == null ? null : s.getSubUnite().getId())
                .filter(Objects::nonNull).toList();


        SecurityDelegationSession s = new SecurityDelegationSession();
        s.setDelegation(d);
        s.setActor(actor);
        s.setOnBehalf(onBehalf);
        s.setActStartAt(now);
        s.setActive(true);
        sessionRepo.save(s);


        Map<String, Object> claims = new HashMap<>(claimsMapper.toClaims(actor));
        claims.put("username", actor.getUsername());
        claims.put("emp_no", actor.getEmpNo());
        claims.put("act", true);
        claims.put("ctx_emp_no", onBehalf.getEmpNo());

        Map<String, Object> onBehalfMap = Map.of(
                "user_id", String.valueOf(onBehalf.getId()),
                "emp_no", onBehalf.getEmpNo(),
                "username", onBehalf.getUsername()
        );
        claims.put("on_behalf", onBehalfMap);

        Map<String, Object> delMap = new HashMap<>();
        delMap.put("id", d.getId());
        delMap.put("session_id", s.getId());
        delMap.put("scope_type", d.getScopeType().name());
        delMap.put("actions_mask", actionsMask);
        if (!uniteIds.isEmpty()) delMap.put("unite_ids", uniteIds);
        if (!subIds.isEmpty())   delMap.put("sub_unite_ids", subIds);
        claims.put("delegation", delMap);

        List<String> rolesOfA = safeRoleNamesForUser(onBehalf);
        claims.put("roles_effective", rolesOfA);


        claims.put("roles", rolesOfA);


        List<String> rolesOfActor = safeRoleNamesForUser(actor);
        claims.put("roles_actor", rolesOfActor);

        List<String> permsOfA = Collections.emptyList();
        claims.put("permissions_effective", permsOfA);

        var issued = jwtService.generateAccessTokenAndPersistSession(actor, claims, userAgent, ipAddress);

        s.setTokenJti(issued.jti());
        sessionRepo.save(s);

        return new ActingTokenResponse(issued.accessToken(), issued.expiresAt(), issued.jti(), s.getId(), d.getId());
    }


    public void stopActing(Long actingSessionId, String tokenHash) {
        LocalDateTime now = LocalDateTime.now();

        sessionRepo.deactivateById(actingSessionId, now);

        if (blacklistRepo != null && tokenHash != null) {
            if (!blacklistRepo.existsByTokenHash(tokenHash)) {
                JwtBlacklist b = new JwtBlacklist();
                b.setTokenHash(tokenHash);
                b.setRevokedAt(now);
                b.setReason("stop-acting");
                blacklistRepo.save(b);
            }
        }
    }




    private List<String> safeRoleNamesForUser(User u) {
        if (u == null || u.getId() == null) return List.of();
        try {

            List<String> names = userRoleRepo.findRoleNamesByUserId(u.getId());
            if (names == null) return List.of();

            return names.stream()
                    .filter(Objects::nonNull)
                    .map(String::trim)
                    .filter(s -> !s.isEmpty())
                    .collect(Collectors.toList());
        } catch (Exception ex) {
            return List.of();
        }
    }

    @Transactional(readOnly = true)
    public List<DelegationFullDto> listDelegationsCreatedBy(String creatorEmpNo) {
        Objects.requireNonNull(creatorEmpNo, "creatorEmpNo is required");

        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999,12,31,23,59,59);

        List<SecurityDelegation> rows = delegationRepo.findAllCreatedByEmpNo(creatorEmpNo);
        List<DelegationFullDto> out = new ArrayList<>(rows.size());

        for (var d : rows) {

            var scopes = scopeRepo.findByDelegation_Id(d.getId());

            long maskAgg = scopes.stream()
                    .map(SecurityDelegationScope::getActionsMask)
                    .filter(Objects::nonNull)
                    .reduce(0L, (a,b) -> a | b);
            if (maskAgg == 0) maskAgg = Action.ALL_MASK;

            List<DelegationScopeDto> scopeDtos = new ArrayList<>();
            for (var s : scopes) {
                Long uniteId = (s.getUnite() != null) ? s.getUnite().getId() : null;
                String uniteName = (s.getUnite() != null) ? s.getUnite().getName() : null;
                Long subId = (s.getSubUnite() != null) ? s.getSubUnite().getId() : null;
                String subName = (s.getSubUnite() != null) ? s.getSubUnite().getName() : null;

                scopeDtos.add(new DelegationScopeDto(
                        s.getId(),
                        uniteId, uniteName,
                        subId, subName,
                        s.getActionsMask()
                ));
            }


            boolean withinWindow = !now.isBefore(d.getStartAt())
                    && !now.isAfter( (d.getEndAt()==null ? maxTime : d.getEndAt()) );
            boolean activeNow = (d.getStatus() == DelegationStatus.ACTIVE) && withinWindow;


            long activeSessions = sessionRepo.countActiveByDelegationId(d.getId());

            out.add(new DelegationFullDto(
                    d.getId(),
                    d.getStatus(),
                    d.getStartAt(),
                    d.getEndAt(),
                    d.getNoExpiry(),
                    d.getRequireAcceptance(),
                    d.getAllowSubdelegate(),
                    d.getScopeType(),

                    maskAgg,
                    scopeDtos,

                    d.getDelegatorUser().getEmpNo(),
                    d.getDelegatorUser().getUsername(),
                    d.getDelegateeUser().getEmpNo(),
                    d.getDelegateeUser().getUsername(),

                    d.getCreatedAt(),
                    d.getCreatedByUser()!=null ? d.getCreatedByUser().getEmpNo() : null,

                    activeNow,
                    activeSessions
            ));
        }

        return out;
    }



    @Transactional(readOnly = true)
    public PageResponse<DelegationFullDetailsDto> listDelegationsByUnitOrSubFull(
            Long uniteId, Long subUniteId,
            String creatorEmpNo, String delegatorEmpNo,
            String delegateeEmpNo, DelegationStatus status,
            Integer page, Integer size,
            Boolean unpaged
    ) {
        if (uniteId == null && subUniteId == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "يجب تمرير uniteId أو subUniteId");
        }

        boolean doUnpaged = Boolean.TRUE.equals(unpaged)
                || page == null || size == null || page < 0 || size <= 0;

        List<SecurityDelegation> delegations;
        long total = 0;
        int totalPages = 1;

        if (doUnpaged) {
            delegations = delegationRepo.findByScopeWithPeopleUnpaged(
                    uniteId, subUniteId, creatorEmpNo, delegatorEmpNo, delegateeEmpNo, status
            );
        } else {
            Pageable pageable = PageRequest.of(page, size);
            Page<SecurityDelegation> p = delegationRepo.findByScopeWithPeoplePaged(
                    uniteId, subUniteId, creatorEmpNo, delegatorEmpNo, delegateeEmpNo, status, pageable
            );
            delegations = p.getContent();
            total = p.getTotalElements();
            totalPages = p.getTotalPages();
        }

        List<Long> ids = delegations.stream().map(SecurityDelegation::getId).toList();
        Map<Long, List<SecurityDelegationScope>> scopesByDelegation = Map.of();
        if (!ids.isEmpty()) {
            var scopes = scopeRepo.findAllByDelegationIdsWithJoins(ids);
            scopesByDelegation = scopes.stream().collect(Collectors.groupingBy(s -> s.getDelegation().getId()));
        }

        var now = LocalDateTime.now();
        var maxTime = LocalDateTime.of(9999,12,31,23,59,59);

        List<DelegationFullDetailsDto> content = new ArrayList<>(delegations.size());
        for (var d : delegations) {
            var sc = scopesByDelegation.getOrDefault(d.getId(), List.of());

            long maskAgg = sc.stream()
                    .map(SecurityDelegationScope::getActionsMask)
                    .filter(Objects::nonNull)
                    .reduce(0L, (a,b)-> a|b);
            if (maskAgg == 0) maskAgg = Action.ALL_MASK;

            boolean withinWindow =
                    !now.isBefore(d.getStartAt()) &&
                            !now.isAfter(d.getEndAt()==null ? maxTime : d.getEndAt());
            boolean activeNow = d.getStatus() == DelegationStatus.ACTIVE && withinWindow;

            long activeSessions = sessionRepo.countActiveByDelegationId(d.getId());
            long totalSessions  = sessionRepo.countByDelegationId(d.getId());

            var scopeDtos = sc.stream().map(s -> new DelegationScopeDtoFull(
                    s.getId(),
                    s.getUnite()    != null ? s.getUnite().getId()   : null,
                    s.getUnite()    != null ? s.getUnite().getCode() : null,
                    s.getUnite()    != null ? s.getUnite().getName() : null,
                    s.getSubUnite() != null ? s.getSubUnite().getId()   : null,
                    s.getSubUnite() != null ? s.getSubUnite().getCode() : null,
                    s.getSubUnite() != null ? s.getSubUnite().getName() : null,
                    s.getRegionCode(),
                    s.getModuleKey(),
                    s.getPermissionKey(),
                    s.getActionsMask(),
                    Action.fromMask(s.getActionsMask()).stream().map(Enum::name).toList()
            )).toList();

            String delegatorFullAr = (d.getDelegatorUser()!=null && d.getDelegatorUser().getEmployee()!=null)
                    ? d.getDelegatorUser().getEmployee().getFullNameAr() : null;
            String delegateeFullAr = (d.getDelegateeUser()!=null && d.getDelegateeUser().getEmployee()!=null)
                    ? d.getDelegateeUser().getEmployee().getFullNameAr() : null;
            String createdByFullAr = (d.getCreatedByUser()!=null && d.getCreatedByUser().getEmployee()!=null)
                    ? d.getCreatedByUser().getEmployee().getFullNameAr() : null;
            String acceptedByFullAr = (d.getAcceptedByUser()!=null && d.getAcceptedByUser().getEmployee()!=null)
                    ? d.getAcceptedByUser().getEmployee().getFullNameAr() : null;

            content.add(new DelegationFullDetailsDto(
                    d.getId(),
                    d.getStatus(),
                    d.getScopeType(),
                    d.getRequireAcceptance(),
                    d.getAllowSubdelegate(),
                    d.getNoExpiry(),
                    d.getStartAt(),
                    d.getEndAt(),
                    d.getCreatedAt(),
                    activeNow,
                    withinWindow,

                    d.getDelegatorUser()!=null ? d.getDelegatorUser().getEmpNo() : null,
                    d.getDelegatorUser()!=null ? d.getDelegatorUser().getUsername() : null,
                    delegatorFullAr,

                    d.getDelegateeUser()!=null ? d.getDelegateeUser().getEmpNo() : null,
                    d.getDelegateeUser()!=null ? d.getDelegateeUser().getUsername() : null,
                    delegateeFullAr,

                    d.getCreatedByUser()!=null ? d.getCreatedByUser().getEmpNo() : null,
                    d.getCreatedByUser()!=null ? d.getCreatedByUser().getUsername() : null,
                    createdByFullAr,

                    d.getAcceptedAt(),
                    d.getAcceptedByUser()!=null ? d.getAcceptedByUser().getEmpNo() : null,
                    d.getAcceptedByUser()!=null ? d.getAcceptedByUser().getUsername() : null,
                    acceptedByFullAr,

                    maskAgg,
                    Action.fromMask(maskAgg).stream().map(Enum::name).toList(),

                    activeSessions,
                    totalSessions,

                    scopeDtos
            ));
        }

        if (doUnpaged) {
            return new PageResponse<>(content, content.size(), 1, null, null, true);
        } else {
            boolean last = (page + 1) >= totalPages;
            return new PageResponse<>(content, total, totalPages, page, size, last);
        }
    }

}



/*
    public DelegationResponse create(CreateDelegationRequest req, String delegatorEmpNoFromToken) {

        String delegatorEmpNo = (req.getDelegatorEmpNo() != null && !req.getDelegatorEmpNo().isBlank())
                ? req.getDelegatorEmpNo()
                : delegatorEmpNoFromToken;

        if (delegatorEmpNo == null || delegatorEmpNo.isBlank())
            throw bad("delegatorEmpNo is required (body or token)");

        if (req.getDelegateeEmpNo() == null || req.getDelegateeEmpNo().isBlank())
            throw bad("delegateeEmpNo is required");

        if (delegatorEmpNo.equals(req.getDelegateeEmpNo()))
            throw bad("Cannot delegate to self");

        if (req.getStartAt() == null)
            throw bad("startAt is required");

        if (Boolean.TRUE.equals(req.getNoExpiry())) {

            if (req.getEndAt() != null) throw bad("endAt must be null when noExpiry=true");
        } else {
            if (req.getEndAt() == null) throw bad("endAt is required when noExpiry=false");
            if (!req.getEndAt().isAfter(req.getStartAt()))
                throw bad("endAt must be after startAt");
        }

        if (req.getScopeType() == null) throw bad("scopeType is required");


        User delegator = userRepo.findByEmpNo(delegatorEmpNo)
                .orElseThrow(() -> notFound("Delegator user not found by empNo: " + delegatorEmpNo));
        User delegatee = userRepo.findByEmpNo(req.getDelegateeEmpNo())
                .orElseThrow(() -> notFound("Delegatee user not found by empNo: " + req.getDelegateeEmpNo()));


        SecurityDelegation d = new SecurityDelegation();
        d.setDelegatorUser(delegator);
        d.setDelegateeUser(delegatee);
        d.setScopeType(req.getScopeType());
        d.setRequireAcceptance(Boolean.TRUE.equals(req.getRequireAcceptance()));
        d.setAllowSubdelegate(Boolean.TRUE.equals(req.getAllowSubdelegate()));
        d.setStartAt(req.getStartAt());
        d.setNoExpiry(Boolean.TRUE.equals(req.getNoExpiry()));
        d.setEndAt(req.getNoExpiry() ? null : req.getEndAt());
        d.setCreatedAt(LocalDateTime.now());
        d.setCreatedByUser(delegator);


        boolean startsInFuture = req.getStartAt().isAfter(LocalDateTime.now());
        if (Boolean.TRUE.equals(req.getRequireAcceptance())) {
            d.setStatus(DelegationStatus.PENDING);
        } else {
            d.setStatus(startsInFuture ? DelegationStatus.PENDING : DelegationStatus.ACTIVE);
        }

        delegationRepo.save(d);


        long scopesCount = 0;
        long mask = resolveActionsMask(req.getActions()); // null/empty => ALL

        if (req.getScopeType() == DelegationScopeType.ALL) {

        } else {

            if (req.getUniteId() != null) {
                Unite unite = uniteRepo.findById(req.getUniteId())
                        .orElseThrow(() -> notFound("Unite not found: " + req.getUniteId()));
                SecurityDelegationScope s = new SecurityDelegationScope();
                s.setDelegation(d);
                s.setUnite(unite);
                s.setActionsMask(mask); // ALL أو subset
                scopeRepo.save(s);
                scopesCount++;
            }


            if (req.getSubUnitIds() != null && !req.getSubUnitIds().isEmpty()) {
                List<SubUnite> subs = subUniteRepo.findByIdIn(req.getSubUnitIds());
                if (subs.size() != req.getSubUnitIds().size()) {
                    throw bad("Some subUnitIds do not exist");
                }
                for (SubUnite su : subs) {
                    SecurityDelegationScope s = new SecurityDelegationScope();
                    s.setDelegation(d);
                    s.setSubUnite(su);
                    s.setActionsMask(mask);
                    scopeRepo.save(s);
                    scopesCount++;
                }
            }

            if (req.getUniteId() == null && (req.getSubUnitIds() == null || req.getSubUnitIds().isEmpty())) {
                throw bad("LIMITED scope requires uniteId or subUnitIds");
            }
        }

        return new DelegationResponse(
                d.getId(),
                d.getStatus().name(),
                d.getStartAt(),
                d.getEndAt(),
                d.getNoExpiry(),
                delegatorEmpNo,
                req.getDelegateeEmpNo(),
                d.getScopeType(),
                scopesCount
        );
    }*/


/*@Service
@Transactional
@RequiredArgsConstructor
public class DelegationService {

    private final SecurityDelegationRepository delegationRepo;
    private final SecurityDelegationScopeRepository scopeRepo;
    private final UserRepository userRepo;
    private final UniteRepository uniteRepo;
    private final SubUniteRepository subUniteRepo;

    public DelegationResponse create(CreateDelegationRequest req, Long currentUserIdFromToken) {
        // 1) Resolve identities
        Long delegatorId = (req.getDelegatorUserId() != null) ? req.getDelegatorUserId() : currentUserIdFromToken;
        if (delegatorId == null) throw bad("Delegator is required (body or token).");
        if (req.getDelegateeUserId() == null) throw bad("delegateeUserId is required.");
        if (Objects.equals(delegatorId, req.getDelegateeUserId())) throw bad("Cannot delegate to self.");

        User delegator = userRepo.findById(delegatorId)
                .orElseThrow(() -> notFound("Delegator not found: " + delegatorId));
        User delegatee = userRepo.findById(req.getDelegateeUserId())
                .orElseThrow(() -> notFound("Delegatee not found: " + req.getDelegateeUserId()));

        // 2) Validate time window
        if (req.getStartAt() == null) throw bad("startAt is required.");
        boolean noExpiry = Boolean.TRUE.equals(req.getNoExpiry());
        if (noExpiry) {
            if (req.getEndAt() != null) throw bad("When noExpiry=true, endAt must be null.");
        } else {
            if (req.getEndAt() == null) throw bad("endAt is required when noExpiry=false.");
            if (!req.getEndAt().isAfter(req.getStartAt())) throw bad("endAt must be after startAt.");
        }

        // 3) Create delegation header
        SecurityDelegation d = new SecurityDelegation();
        d.setDelegator(delegator);
        d.setDelegatee(delegatee);
        d.setScopeType(Objects.requireNonNull(req.getScopeType(), "scopeType is required."));
        d.setRequireAcceptance(Boolean.TRUE.equals(req.getRequireAcceptance()));
        d.setAllowSubdelegate(Boolean.TRUE.equals(req.getAllowSubdelegate()));
        d.setStartAt(req.getStartAt());
        d.setEndAt(req.getEndAt());      // may be null
        d.setNoExpiry(noExpiry);
        d.setCreatedBy(delegator);       // أو اجعلها مستخدم الجلسة لو مختلف
        d.setCreatedAt(LocalDateTime.now());

        // initial status
        boolean startsInFuture = req.getStartAt().isAfter(LocalDateTime.now());
        if (Boolean.TRUE.equals(req.getRequireAcceptance())) {
            d.setStatus(DelegationStatus.PENDING);
        } else {
            d.setStatus(startsInFuture ? DelegationStatus.PENDING : DelegationStatus.ACTIVE);
        }

        delegationRepo.save(d);

        // 4) Build scopes (four scenarios)
        long scopesCount = 0;
        if (req.getScopeType() == DelegationScopeType.ALL) {
            // (1) قسم كامل + كل شعبه + كامل الصلاحيات (لا نضيف صفوف)
            //     أو قسم كامل + كل شعبه + صلاحيات محدودة؟
            // ➜ بما أن ALL يعني "كل النظام"، لا نضيف صفوف.
            //    إن أردت حصره على قسم معيّن بصلاحيات محدودة، فهذا ليس ALL، بل LIMITED مع uniteId + actions.
        } else { // LIMITED
            long mask = resolveActionsMask(req.getActions()); // null/empty => ALL_MASK

            // الحالات المدعومة:
            // (2) قسم كامل + كل شعبه + كامل الصلاحيات  => LIMITED + uniteId + actions=null
            // (3) قسم كامل + كل شعبه + صلاحيات محدودة => LIMITED + uniteId + actions=[...]
            // (4) شعب محددة تحت القسم + كامل الصلاحيات => LIMITED + subUnitIds + actions=null
            // (5) شعب محددة تحت القسم + صلاحيات محدودة => LIMITED + subUnitIds + actions=[...]

            boolean hasUnite = (req.getUniteId() != null);
            boolean hasSubs  = (req.getSubUnitIds() != null && !req.getSubUnitIds().isEmpty());

            if (!hasUnite && !hasSubs) {
                throw bad("LIMITED scope requires uniteId or subUnitIds.");
            }

            if (hasUnite) {
                Unite unite = uniteRepo.findById(req.getUniteId())
                        .orElseThrow(() -> notFound("Unite not found: " + req.getUniteId()));
                SecurityDelegationScope s = new SecurityDelegationScope();
                s.setDelegation(d);
                s.setUnite(unite);
                s.setActionsMask(mask);
                scopeRepo.save(s);
                scopesCount++;
            }

            if (hasSubs) {
                List<SubUnite> subs = subUniteRepo.findByIdIn(req.getSubUnitIds());
                if (subs.size() != req.getSubUnitIds().size()) {
                    throw bad("Some subUnitIds do not exist.");
                }
                for (SubUnite su : subs) {
                    SecurityDelegationScope s = new SecurityDelegationScope();
                    s.setDelegation(d);
                    s.setSubUnite(su);
                    s.setActionsMask(mask);
                    scopeRepo.save(s);
                    scopesCount++;
                }
            }
        }

        return new DelegationResponse(
                d.getId(),
                d.getStatus().name(),
                d.getStartAt(),
                d.getEndAt(),
                d.getNoExpiry() != null && d.getNoExpiry(),
                d.getDelegator().getId(),
                d.getDelegatee().getId(),
                d.getScopeType(),
                scopesCount
        );
    }


    private static long resolveActionsMask(List<String> actions) {
        if (actions == null || actions.isEmpty()) return Action.ALL_MASK;
        EnumSet<Action> set = EnumSet.noneOf(Action.class);
        for (String s : actions) {
            try {
                set.add(Action.valueOf(s.trim().toUpperCase()));
            } catch (Exception ex) {
                throw bad("Unknown action: " + s + " (valid: READ,CREATE,UPDATE,DELETE,APPROVE)");
            }
        }
        return Action.toMask(set);
    }

    private static ResponseStatusException bad(String msg) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, msg);
    }
    private static ResponseStatusException notFound(String msg) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, msg);
    }
}*/


/*
package com.RSADF.Murtakiz.modules.auth.infra.service;

import com.RSADF.Murtakiz.modules.auth.core.Enums.Action;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationScopeType;
import com.RSADF.Murtakiz.modules.auth.core.Enums.DelegationStatus;
import com.RSADF.Murtakiz.modules.auth.core.dto.CreateDelegationRequest;
import com.RSADF.Murtakiz.modules.auth.core.dto.DelegationResponse;
import com.RSADF.Murtakiz.modules.auth.core.entity.*;
import com.RSADF.Murtakiz.modules.auth.infra.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;

@Service
@Transactional
public class DelegationService {

    private final SecurityDelegationRepository delegationRepo;
    private final SecurityDelegationScopeRepository scopeRepo;
    private final UserRepository userRepo;
    private final UniteRepository uniteRepo;
    private final SubUniteRepository subUniteRepo;

    public DelegationService(SecurityDelegationRepository delegationRepo,
                             SecurityDelegationScopeRepository scopeRepo,
                             UserRepository userRepo,
                             UniteRepository uniteRepo,
                             SubUniteRepository subUniteRepo) {
        this.delegationRepo = delegationRepo;
        this.scopeRepo = scopeRepo;
        this.userRepo = userRepo;
        this.uniteRepo = uniteRepo;
        this.subUniteRepo = subUniteRepo;
    }

    public DelegationResponse create(CreateDelegationRequest req, Long currentUserIdFromToken) {

        Long delegatorId = (req.getDelegatorUserId() != null) ? req.getDelegatorUserId() : currentUserIdFromToken;
        if (delegatorId == null) throw bad("Delegator is required (body or token)");
        if (req.getDelegateeUserId() == null) throw bad("delegateeUserId is required");
        if (Objects.equals(delegatorId, req.getDelegateeUserId())) throw bad("Cannot delegate to self");

        if (req.getStartAt() == null || req.getEndAt() == null) throw bad("startAt/endAt are required");
        if (!req.getEndAt().isAfter(req.getStartAt())) throw bad("endAt must be after startAt");

        if (req.getScopeType() == null) throw bad("scopeType is required");

        User delegator = userRepo.findById(delegatorId)
                .orElseThrow(() -> notFound("Delegator not found: " + delegatorId));
        User delegatee = userRepo.findById(req.getDelegateeUserId())
                .orElseThrow(() -> notFound("Delegatee not found: " + req.getDelegateeUserId()));


        SecurityDelegation d = new SecurityDelegation();
        d.setDelegator(delegator);
        d.setDelegatee(delegatee);
        d.setScopeType(req.getScopeType());
        d.setRequireAcceptance(Boolean.TRUE.equals(req.getRequireAcceptance()));
        d.setAllowSubdelegate(Boolean.TRUE.equals(req.getAllowSubdelegate()));
        d.setStartAt(req.getStartAt());
        d.setEndAt(req.getEndAt());
        d.setCreatedAt(LocalDateTime.now());


        boolean startsInFuture = req.getStartAt().isAfter(LocalDateTime.now());
        if (Boolean.TRUE.equals(req.getRequireAcceptance())) {
            d.setStatus(DelegationStatus.PENDING);
        } else {
            d.setStatus(startsInFuture ? DelegationStatus.PENDING : DelegationStatus.ACTIVE);
        }

        delegationRepo.save(d);

        long scopesCount = 0;
        if (req.getScopeType() == DelegationScopeType.ALL) {

        } else {
            // LIMITED
            long mask = resolveActionsMask(req.getActions()); // null/empty => ALL_MASK

            if (req.getUniteId() != null) {
                Unite unite = uniteRepo.findById(req.getUniteId())
                        .orElseThrow(() -> notFound("Unite not found: " + req.getUniteId()));

                SecurityDelegationScope s = new SecurityDelegationScope();
                s.setDelegation(d);
                s.setUnite(unite);
                s.setActionsMask(mask);
                scopeRepo.save(s);
                scopesCount++;
            }


            if (req.getSubUnitIds() != null && !req.getSubUnitIds().isEmpty()) {
                List<SubUnite> subs = subUniteRepo.findByIdIn(req.getSubUnitIds());
                if (subs.size() != req.getSubUnitIds().size()) {
                    throw bad("Some subUnitIds do not exist");
                }
                for (SubUnite su : subs) {
                    SecurityDelegationScope s = new SecurityDelegationScope();
                    s.setDelegation(d);
                    s.setSubUnite(su);
                    s.setActionsMask(mask);
                    scopeRepo.save(s);
                    scopesCount++;
                }
            }


            if (scopesCount == 0) {
                throw bad("LIMITED scope requires uniteId or subUnitIds");
            }
        }

        return new DelegationResponse(
                d.getId(),
                d.getStatus().name(),
                d.getStartAt(),
                d.getEndAt(),
                d.getDelegator().getId(),
                d.getDelegatee().getId(),
                d.getScopeType(),
                scopesCount
        );
    }

    private static long resolveActionsMask(List<String> actions) {
        if (actions == null || actions.isEmpty()) return Action.ALL_MASK;
        EnumSet<Action> set = EnumSet.noneOf(Action.class);
        for (String s : actions) {
            try {
                set.add(Action.valueOf(s.trim().toUpperCase()));
            } catch (Exception ex) {
                throw bad("Unknown action: " + s + " (valid: READ,CREATE,UPDATE,DELETE,APPROVE)");
            }
        }
        return Action.toMask(set);
    }

    private static ResponseStatusException bad(String msg) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, msg);
    }
    private static ResponseStatusException notFound(String msg) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, msg);
    }
}
*/

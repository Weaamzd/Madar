package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

    @Query("""
    select e
    from Employee e
    left join fetch e.subUnite su
    left join fetch su.unite u
    where e.empNo = :empNo
    """)
    Optional<Employee> findByIdWithSubUnite(@Param("empNo") String empNo);

    @Query("""
    select e
    from Employee e
    left join fetch e.subUnite su
    left join fetch su.unite u
    where not exists (
        select 1 from User ux
        where ux.empNo = e.empNo
    )
      and (:empNo       is null or e.empNo like concat(:empNo, '%'))
      and (:fullNameAr  is null or lower(e.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
      and (:uniteName   is null or lower(u.name) like lower(concat('%', :uniteName,  '%')))
      and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
    order by e.empNo
""")
    List<Employee> findInternalWithoutUserWithOrgFiltered(
            @Param("empNo") String empNo,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );

    @Query(value = """
        SELECT 
            e.emp_no           AS empNo,
            e.emp_full_name_ar AS empFullNameAr
        FROM SYS.EMPLOYEES e
        WHERE EXISTS (
            SELECT 1 
            FROM SYS.EMPLOYEES c
            WHERE c.emp_manager_no = e.emp_no   -- لديه مرؤوس واحد على الأقل
        )
        ORDER BY e.emp_full_name_ar
        """, nativeQuery = true)
    List<ManagerNameProjection> findAllManagers();



    @Query("""
        select e
        from Employee e
        left join fetch e.subUnite su
        left join fetch su.unite u
    """)
    List<Employee> findAllWithOrg();

    @Query("""
    select e
    from Employee e
    left join fetch e.subUnite su
    left join fetch su.unite u
    where ( (:uniteId    is not null and su.unite.id = :uniteId)
         or (:subUniteId is not null and su.id       = :subUniteId) )
      and (:empNo       is null or e.empNo like concat(:empNo, '%'))
      and (:fullNameAr  is null or lower(e.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
      and (:uniteName   is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
      and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
    order by e.empNo
""")
    List<Employee> findByOrgScopeWithTextFilters(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("empNo") String empNo,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );

    @Query("""
    select e
    from Employee e
    left join fetch e.subUnite su
    left join fetch su.unite u
    where (:empNo is null or e.empNo like concat(:empNo, '%'))
      and (:fullNameAr is null or lower(e.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
      and (:uniteName is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
      and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
    order by e.empNo
""")
    List<Employee> findAllWithOrgFiltered(
            @Param("empNo") String empNo,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName
    );
    @Query("""
select distinct m.empNo as empNo, m.fullNameAr as empFullNameAr
from Employee m
left join m.subUnite su
left join su.unite u
where
    /* الحالة 1: عندي موظفون في النطاق يرفعون لهذا الشخص */
    ( :subUniteId is not null and exists (
          select 1 from Employee e
          where e.subUnite.id = :subUniteId
            and e.managerNo   = m.empNo
    ))
 or ( :uniteId is not null and exists (
          select 1 from Employee e
          where e.subUnite.unite.id = :uniteId
            and e.managerNo         = m.empNo
    ))

    /* الحالة 2: رؤساء داخل النطاق managerNo IS NULL */
 or ( :subUniteId is not null and su.id = :subUniteId and m.managerNo is null )
 or ( :uniteId    is not null and u.id  = :uniteId    and m.managerNo is null )

order by m.fullNameAr
""")
    List<ManagerNameProjection> findManagersByOrgScope(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId
    );


    @Query("select count(e) from Employee e where e.managerNo = :managerNo")
    long countDirectReports(@Param("managerNo") String managerNo);

    List<Employee> findByManagerNo(String managerNo);

    @Query("""
    select e
    from Employee e
    where e.subUnite.id = :subUniteId
      and exists (select 1 from Employee r where r.managerNo = e.empNo)
""")
    List<Employee> findManagersBySubUniteId(@Param("subUniteId") Long subUniteId);

    @Query("""
select e
from Employee e
left join fetch e.subUnite su
left join fetch su.unite u
where ( (:uniteId is not null and su.unite.id = :uniteId)
     or (:subUniteId is not null and su.id       = :subUniteId) )
  and (:empNo        is null or e.empNo like concat(:empNo, '%'))
  and (:fullNameAr   is null or lower(e.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
  and (:uniteName    is null or lower(u.name) like lower(concat('%', :uniteName, '%')))
  and (:subUniteName is null or lower(su.name) like lower(concat('%', :subUniteName, '%')))
  and (:managerNo    is null or e.managerNo = :managerNo)
order by e.empNo
""")
    List<Employee> findByOrgScopeWithTextFiltersAndManager(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("empNo") String empNo,
            @Param("fullNameAr") String fullNameAr,
            @Param("uniteName") String uniteName,
            @Param("subUniteName") String subUniteName,
            @Param("managerNo") String managerNo
    );


    @Query("""
        select e
        from Employee e
        left join fetch e.subUnite su
        left join fetch su.unite u
        where not exists (
            select 1 from User usr where usr.empNo = e.empNo
        )
        and (
              (:subUniteId is not null and su.id = :subUniteId)
           or (:uniteId    is not null and u.id  = :uniteId)
        )
        and (:q is null or lower(e.empNo) like lower(concat('%', :q, '%')) or lower(e.fullNameAr) like lower(concat('%', :q, '%')))
        and (:fullNameAr is null or lower(e.fullNameAr) like lower(concat('%', :fullNameAr, '%')))
        order by e.empNo
    """)
    List<Employee> findInternalWithoutUserInScope(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("q") String q,
            @Param("fullNameAr") String fullNameAr
    );


}

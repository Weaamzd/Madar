package com.RSADF.Murtakiz.modules.auth.infra.service;

import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import com.RSADF.Murtakiz.modules.auth.core.entity.UserRegistrationRequest;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRegistrationRequestRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class UserAutoDisableScheduler {

    private final UserRegistrationRequestRepository registrationRequestRepository;
    private final UserRepository userRepository;


    @Scheduled(cron = "0 0 2 * * ?")
    @Transactional
    public void disableUsersIfNoAdminResponse() {


        LocalDateTime limit = LocalDateTime.now().minusDays(3);


        List<UserRegistrationRequest> oldRequests =
                registrationRequestRepository.findAllPendingOlderThan(limit);

        for (UserRegistrationRequest req : oldRequests) {
            User user = req.getUser();
            if (user == null) continue;

            if (user.getAllowedDays() != null) {
                LocalDateTime expireAt = user.getCreatedAt().plusDays(user.getAllowedDays());
                if (expireAt.isAfter(LocalDateTime.now())) {

                    continue;
                }
            }


            user.setStatus("Inactive");
            userRepository.save(user);

            req.setStageStatus("EXPIRED");
            req.setUpdatedAt(LocalDateTime.now());
            registrationRequestRepository.save(req);
        }
    }
}

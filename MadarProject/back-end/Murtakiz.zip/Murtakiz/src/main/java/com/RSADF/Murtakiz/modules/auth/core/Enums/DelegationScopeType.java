package com.RSADF.Murtakiz.modules.auth.core.Enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum DelegationScopeType {
    ALL, LIMITED
}
package com.RSADF.Murtakiz.modules.auth.infra.repository;


import com.RSADF.Murtakiz.modules.auth.core.entity.User;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query("""
    select u
    from User u
    left join fetch u.employee e
    left join fetch e.subUnite esu
    left join fetch esu.unite eu
    left join fetch u.externalEmployee xe
    left join fetch xe.subUniteId xsu
    left join fetch xsu.unite xu
    left join fetch u.currentRegion cr
    where lower(u.username) = lower(:username)
""")
    Optional<User> findOneWithEverythingByUsername(@Param("username") String username);


    @Query("""
    select u
    from User u
    left join fetch u.currentRegion cr
    where u.externalEmpId = :extEmpId
""")
    Optional<User> findByExternalEmpIdWithRegion(@Param("extEmpId") String extEmpId);



    /**
     * linkedState:
     *  - 'UNLINKED' => u.empNo is null AND u.externalEmpId is null
     *  - 'LINKED'   => (u.empNo is not null OR u.externalEmpId is not null)
     *  - null/'ALL' => لا يطبق شرط الارتباط
     */
    @Query("""
        select u
        from User u
        left join fetch u.employee e
        left join fetch u.currentRegion cr
        where (:username   is null or lower(u.username) like lower(concat('%', :username, '%')))
          and (:status     is null or lower(u.status) = lower(:status))
          and (
                (:linkedState is null or upper(:linkedState) = 'ALL')
             or (upper(:linkedState) = 'UNLINKED' and u.empNo is null and u.externalEmpId is null)
             or (upper(:linkedState) = 'LINKED'   and (u.empNo is not null or u.externalEmpId is not null))
          )
        order by u.id
    """)
    List<User> findAllByFiltersWithRegion(
            @Param("username") String username,
            @Param("status")   String status,
            @Param("linkedState") String linkedState
    );

    @Query("""
        select u
        from User u
        left join fetch u.currentRegion cr
        where u.empNo is null
          and u.externalEmpId is null
          and (:username is null or lower(u.username) like lower(concat('%', :username, '%')))
          and (:status   is null or lower(u.status) = lower(:status))
        order by u.id
    """)
    List<User> findAllUnlinkedUsersWithRegion(@Param("username") String username,
                                              @Param("status")   String status);





    //Optional<User> findOneWithDetailsByEmpNo(@Param("empNo") String empNo);
/*    @Query("""
         select u from User u where u.empNo = :empNo
  """)
    Optional<User> findByEmpNo(@Param("empNo") String empNo);*/

    Optional<User> findByEmpNo(String empNo);

    Optional<User> findByUsername(String username);
    boolean existsByUsername(String username);

    Optional<User> findByExternalEmpId(String externalEmpId);

    @Query("""
   select u
   from User u
   join u.employee e
   where e.empNo = :empNo
""")
    Optional<User> findByEmployeeEmpNo(@Param("empNo") String empNo);


    @Query("""
       select u
       from User u
       join u.employee e
       left join fetch u.currentRegion cr
       where e.empNo in :empNos
    """)
    List<User> findAllByEmployeeEmpNoInWithRegion(@Param("empNos") Collection<String> empNos);
   /* @EntityGraph(attributePaths = {"employee", "currentRegion"})
    Optional<User> findOneWithDetailsByEmployee_EmpNo(String empNo);*/

    @Query("""
       select u from User u
       left join fetch u.employee e
       left join fetch u.currentRegion cr
       where e.empNo = :empNo
    """)
    Optional<User> findOneWithDetailsByEmpNo(@Param("empNo") String empNo);



    @Query("""
           select u
           from User u
           join fetch u.employee e
           left join fetch u.currentRegion cr
           where e.empNo = :empNo
           """)
    Optional<User> findByEmployeeEmpNoWithRegion(@Param("empNo") String empNo);



    boolean existsByUsernameAndIdNot(String username, Long id);

    @Query("""
    select u
    from User u
    left join fetch u.currentRegion cr
    where u.externalEmpId in :extIds
""")
    List<User> findAllByExternalEmpIdInWithRegion(@Param("extIds") Collection<String> extIds);



    @Query("""
    select u
    from User u
    left join fetch u.employee e
    left join fetch e.subUnite esu
    left join fetch esu.unite eu
    left join fetch u.externalEmployee xe
    left join fetch xe.subUniteId xsu
    left join fetch xsu.unite xu
    left join fetch u.currentRegion cr
    where
          (
            ( :uniteId is not null and ( (eu.id = :uniteId) or (xu.id = :uniteId) ) )
            or
            ( :subUniteId is not null and ( (esu.id = :subUniteId) or (xsu.id = :subUniteId) ) )
          )
      and (:username   is null or lower(u.username) like lower(concat('%', :username, '%')))
      and (:status     is null or lower(u.status) = lower(:status))
      and (
            (:linkedState is null or upper(:linkedState) = 'ALL')
         or (upper(:linkedState) = 'UNLINKED' and u.empNo is null and u.externalEmpId is null)
         or (upper(:linkedState) = 'LINKED'   and (u.empNo is not null or u.externalEmpId is not null))
          )
    order by u.id
    """)
    List<User> findAllByFiltersWithRegionAndOrgScope(
            @Param("uniteId") Long uniteId,
            @Param("subUniteId") Long subUniteId,
            @Param("username") String username,
            @Param("status")   String status,
            @Param("linkedState") String linkedState
    );


    // Optional<User> findByEmployee_EmpNo(String empNo);

/*    @EntityGraph(attributePaths = {"employee", "currentRegion"})
    Optional<User> findOneWithDetailsByUsername(String username);*/


    /*@Query(value = """
      SELECT u.USER_ID, u.USERNAME, u.PASSWORD_HASH, u.STATUS, u.LAST_LOGIN_AT,
             u.EMP_NO, u.CURRENT_REGION_ID
      FROM USERS u
      WHERE u.USERNAME = :username
      """, nativeQuery = true)*/
    /*Optional<User> findRawByUsername(@Param("username") String username);*/
}

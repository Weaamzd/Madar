package com.RSADF.Murtakiz.modules.auth.core.dto;

import com.RSADF.Murtakiz.modules.auth.core.Enums.PersonSourceType;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UnifiedPersonDetailsDto {
    private PersonSourceType sourceType;

    private String empNo;
    private String extEmpId;

    private String fullNameAr;
    private String fullNameEn;
    private String email;
    private String phone;
    private String jobTitle;

    private LocalDate hireDate;
    private LocalDate startDate;
    private String managerNo;

    private String organizationName;
    private String collaborationType;
    private LocalDate externalStartDate;
    private LocalDate externalEndDate;
    private String externalStatus;

    private SubUniteMiniDto subUnite;
    private UniteMiniDto unite;

    private UserMiniDto user;

    private String regionCode;
    private String regionDbKey;

    private List<String> roles;

    private boolean loggedIn;

    // ↘ جديد: هل يملك مستخدم مرتبط؟
    private boolean hasUser;
}

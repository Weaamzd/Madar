package com.RSADF.Murtakiz.modules.kpi.core.dto;


import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class KpiIndicatorReadingDto {

    private Long id;

    private String kpiCode;

    private LocalDate periodStartDate;
    private LocalDate periodEndDate;
    private String periodLabel;

    private Double actualValue;
    private String statusCode;

    private String dataSourceName;
    private String notes;

    private LocalDateTime enteredAt;
    private String enteredByEmpNo;

    private String isLocked;
}


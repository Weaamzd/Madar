package com.RSADF.Murtakiz;



public interface Roles {
    String SYSTEM_ADMIN       = "SYSTEM_ADMIN";
    String EMPLOYEE           = "EMPLOYEE";
    String DEPARTMENT_MANAGER = "DEPARTMENT_MANAGER";
    String SECTION_MANAGER    = "SECTION_MANAGER";
    String OFFICE_MANAGER     = "OFFICE_MANAGER";
    String SUBUNIT_MANAGER    = "SUBUNIT_MANAGER";
}

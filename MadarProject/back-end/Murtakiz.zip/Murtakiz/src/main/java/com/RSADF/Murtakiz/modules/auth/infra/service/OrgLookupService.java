package com.RSADF.Murtakiz.modules.auth.infra.service;


import com.RSADF.Murtakiz.modules.auth.core.dto.SubUniteDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.SubUniteTreeDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.UniteDto;
import com.RSADF.Murtakiz.modules.auth.core.dto.UniteMiniDto;
import com.RSADF.Murtakiz.modules.auth.core.entity.SubUnite;
import com.RSADF.Murtakiz.modules.auth.core.entity.Unite;
import com.RSADF.Murtakiz.modules.auth.infra.repository.SubUniteRepository;
import com.RSADF.Murtakiz.modules.auth.infra.repository.UniteRepository;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class OrgLookupService {

    private final UniteRepository uniteRepo;
    private final SubUniteRepository subUniteRepo;

    public OrgLookupService(UniteRepository uniteRepo, SubUniteRepository subUniteRepo) {
        this.uniteRepo = uniteRepo;
        this.subUniteRepo = subUniteRepo;
    }

    public SubUniteDto getSubUnite(Long subUniteId) {
        SubUnite s = subUniteRepo.findById(subUniteId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "SubUnite غير موجود: " + subUniteId
                ));


        return toDtoWithHasChildren(s);
    }


    public UniteDto getUnite(Long uniteId) {
        Unite u = uniteRepo.findById(uniteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Unite غير موجود: " + uniteId));

        UniteDto dto = new UniteDto();
        dto.setId(u.getId());
        dto.setCode(u.getCode());
        dto.setName(u.getName());
        if (u.getUniteType() != null) {
            dto.setUniteTypeId(u.getUniteType().getId());
            dto.setUniteTypeName(u.getUniteType().getName());
        }
        return dto;
    }

    public List<?> listSubUnitesUnderUnite(Long uniteId, Integer depth) {
        uniteRepo.findById(uniteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Unite غير موجود: " + uniteId));

        int d = (depth == null ? 1 : Math.max(1, Math.min(depth, 10)));

        if (d == 1) {
            List<SubUnite> subs = subUniteRepo.findByUnite_IdAndParentIsNull(uniteId);
            return subs.stream().map(this::toDtoWithHasChildren).collect(Collectors.toList());
        } else {
            List<SubUnite> all = subUniteRepo.findAllByUniteIdWithJoins(uniteId);
            return buildTreeForUnite(all, d);

        }
    }


    public SubUniteTreeDto getSubUniteSubtree(Long subUniteId, Integer depth) {
        SubUnite root = subUniteRepo.findById(subUniteId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "SubUnite غير موجود: " + subUniteId));

        int d = (depth == null ? 4 : Math.max(1, Math.min(depth, 10)));

        Map<Long, List<SubUnite>> childrenMap = new HashMap<>();
        List<Long> frontier = List.of(root.getId());
        for (int level = 1; level <= d; level++) {
            List<SubUnite> kids = subUniteRepo.findByParent_IdIn(frontier);
            if (kids.isEmpty()) break;

            Map<Long, List<SubUnite>> grouped = kids.stream()
                    .collect(Collectors.groupingBy(s -> s.getParent().getId()));
            childrenMap.putAll(grouped);

            frontier = kids.stream().map(SubUnite::getId).toList();
        }

        return toTreeNode(root, childrenMap, d, 1);
    }



    private SubUniteDto toDtoWithHasChildren(SubUnite s) {
        SubUniteDto dto = new SubUniteDto();
        dto.setId(s.getId());
        dto.setCode(s.getCode());
        dto.setName(s.getName());
        dto.setUniteId(s.getUnite() != null ? s.getUnite().getId() : null);
        if (s.getUniteType() != null) {
            dto.setUniteTypeId(s.getUniteType().getId());
            dto.setUniteTypeName(s.getUniteType().getName());
        }
        dto.setParentSubUniteId(s.getParent() != null ? s.getParent().getId() : null);
        dto.setHasChildren(subUniteRepo.existsByParent_Id(s.getId()));
        return dto;
    }

    private List<SubUniteTreeDto> buildTreeForUnite(List<SubUnite> all, int maxDepth) {
        Map<Long, List<SubUnite>> byParent = new HashMap<>();
        List<SubUnite> roots = new ArrayList<>();

        for (SubUnite s : all) {
            Long parentId = (s.getParent() != null ? s.getParent().getId() : null);
            if (parentId == null) {
                roots.add(s);
            } else {
                byParent.computeIfAbsent(parentId, k -> new ArrayList<>()).add(s);
            }
        }

        return roots.stream()
                .map(r -> toTreeNode(r, byParent, maxDepth, 1))
                .collect(Collectors.toList());
    }

    private SubUniteTreeDto toTreeNode(SubUnite node,
                                       Map<Long, List<SubUnite>> childrenMap,
                                       int maxDepth,
                                       int level) {
        SubUniteTreeDto dto = baseTreeNode(node);
        List<SubUnite> kids = childrenMap.getOrDefault(node.getId(), Collections.emptyList());
        dto.setHasChildren(!kids.isEmpty());

        if (level < maxDepth && !kids.isEmpty()) {
            for (SubUnite k : kids) {
                dto.getChildren().add(toTreeNode(k, childrenMap, maxDepth, level + 1));
            }
        }
        return dto;
    }

    private SubUniteTreeDto baseTreeNode(SubUnite s) {
        SubUniteTreeDto dto = new SubUniteTreeDto();
        dto.setId(s.getId());
        dto.setCode(s.getCode());
        dto.setName(s.getName());
        dto.setUniteId(s.getUnite() != null ? s.getUnite().getId() : null);
        if (s.getUniteType() != null) {
            dto.setUniteTypeId(s.getUniteType().getId());
            dto.setUniteTypeName(s.getUniteType().getName());
        }
        dto.setParentSubUniteId(s.getParent() != null ? s.getParent().getId() : null);
        return dto;
    }

    public List<UniteMiniDto> listAllUnitesMini() {
        List<Unite> all = uniteRepo.findAll(Sort.by(Sort.Direction.ASC, "name"));
        return all.stream()
                .map(u -> new UniteMiniDto(u.getId(), u.getCode(), u.getName()))
                .collect(Collectors.toList());
    }

    public List<UniteDto> listAllUnites() {
        List<Unite> all = uniteRepo.findAll(Sort.by(Sort.Direction.ASC, "name"));
        return all.stream().map(this::toUniteDto).collect(Collectors.toList());
    }

    private UniteDto toUniteDto(Unite u) {
        UniteDto dto = new UniteDto();
        dto.setId(u.getId());
        dto.setCode(u.getCode());
        dto.setName(u.getName());
        if (u.getUniteType() != null) {
            dto.setUniteTypeId(u.getUniteType().getId());
            dto.setUniteTypeName(u.getUniteType().getName());
        }
        return dto;
    }
}


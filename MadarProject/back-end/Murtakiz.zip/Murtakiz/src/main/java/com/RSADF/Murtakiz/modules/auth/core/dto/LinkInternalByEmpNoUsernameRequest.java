package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LinkInternalByEmpNoUsernameRequest {
    @NotBlank
    String username;    // <-- بدلاً من userId
    @NotBlank String empNo;       // رقم الموظف الداخلي
    //Long currentRegionId;         // اختياري
    String note;                  // للتوثيق في الهيستوري
}
package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.SecurityDelegationScope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public interface SecurityDelegationScopeRepository extends JpaRepository<SecurityDelegationScope, Long> {
    long countByDelegation_Id(Long delegationId);
    List<SecurityDelegationScope> findByDelegation_Id(Long delegationId);

    //List<SecurityDelegationScope> findByDelegation_Id(Long delegationId);

    @Query("""
       select s
       from SecurityDelegationScope s
       left join fetch s.unite u
       left join fetch s.subUnite su
       where s.delegation.id in :delegationIds
    """)
    List<SecurityDelegationScope> findAllByDelegationIdsWithJoins(@Param("delegationIds") java.util.Collection<Long> delegationIds);


   /* @Query("""
   select s
   from SecurityDelegationScope s
   left join fetch s.unite u
   left join fetch s.subUnite su
   where s.delegation.id in :delegationIds
""")
    List<SecurityDelegationScope> findAllByDelegationIdsWithJoins(@Param("delegationIds") Collection<Long> delegationIds);*/


}
package com.RSADF.Murtakiz.modules.kpi.core.repository;

import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorReading;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface KpiIndicatorReadingRepository
        extends JpaRepository<KpiIndicatorReading, Long> {

    Optional<KpiIndicatorReading> findTopByKpiCodeOrderByPeriodStartDateDesc(String kpiCode);

    List<KpiIndicatorReading> findByKpiCodeOrderByPeriodStartDateDesc(String kpiCode);
}


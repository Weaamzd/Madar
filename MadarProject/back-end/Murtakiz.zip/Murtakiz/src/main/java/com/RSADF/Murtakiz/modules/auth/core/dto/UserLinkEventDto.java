package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class UserLinkEventDto {
    private String linkType;      // INTERNAL | EXTERNAL
    private String empNo;         // إن وُجد
    private String extEmpId;      // إن وُجد
    private LocalDateTime linkedAt;
    private LocalDateTime unlinkedAt; // null لو ما أُغلق
    private String actionNote;
    private String actorEmpNo;
}




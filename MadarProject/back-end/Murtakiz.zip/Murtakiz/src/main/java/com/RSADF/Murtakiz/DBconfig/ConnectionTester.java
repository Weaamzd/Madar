package com.RSADF.Murtakiz.DBconfig;


import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

@Component
public class ConnectionTester implements CommandLineRunner {

    private final DataSource dataSource;

    public ConnectionTester(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void run(String... args) {
        System.out.println("== اختبار اتصال قاعدة البيانات ==");

        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData md = conn.getMetaData();
            System.out.println("Connected to: " + md.getDatabaseProductName() + " - " + md.getDatabaseProductVersion());
            System.out.println("Driver: " + md.getDriverName());
            System.out.println("AutoCommit: " + conn.getAutoCommit());

            try (var st = conn.createStatement();
                 var rs = st.executeQuery("SELECT 1 FROM DUAL")) {
                if (rs.next()) {
                    System.out.println("Result: " + rs.getInt(1));
                }
            }
        } catch (Exception e) {
            System.err.println("فشل الاتصال: " + e.getMessage());
        }
    }
}


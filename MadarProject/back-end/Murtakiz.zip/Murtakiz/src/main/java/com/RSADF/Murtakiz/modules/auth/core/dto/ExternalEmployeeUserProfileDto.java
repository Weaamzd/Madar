package com.RSADF.Murtakiz.modules.auth.core.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalEmployeeUserProfileDto {
    private ExternalEmployeeDetailsDto details; // بيانات الموظف الخارجي
    private UserMiniDto user;                   // المستخدم المرتبط (قد يكون null)
    private List<String> roles;                 // أسماء الأدوار
    private boolean loggedIn;                   // هل لديه جلسة نشطة الآن؟
}


package com.RSADF.Murtakiz.modules.auth.core.dto;

import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public class AssignRolesRequest {
    @NotEmpty
    private List<String> roles; // أسماء الأدوار

    public List<String> getRoles() { return roles; }
    public void setRoles(List<String> roles) { this.roles = roles; }
}
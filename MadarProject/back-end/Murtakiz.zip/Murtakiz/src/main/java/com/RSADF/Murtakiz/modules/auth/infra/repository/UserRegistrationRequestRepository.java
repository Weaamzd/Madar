package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.UserRegistrationRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRegistrationRequestRepository extends JpaRepository<UserRegistrationRequest, Long> {


  Optional<UserRegistrationRequest> findTopByUserIdAndCurrentStageAndStageStatusOrderByCreatedAtDesc(
          Long userId,
          String currentStage,
          String stageStatus
  );


    @Query("""
        select r
        from UserRegistrationRequest r
        join fetch r.user u
        where r.stageStatus = 'PENDING'
          and r.createdAt <= :limit
    """)
    List<UserRegistrationRequest> findAllPendingOlderThan(@Param("limit") LocalDateTime limit);



  @Query(
          value = """
            select r
            from UserRegistrationRequest r
            join fetch r.user u
            left join fetch u.employee e
            left join fetch e.subUnite esu
            left join fetch esu.unite eu
            left join fetch u.externalEmployee xe
            left join fetch xe.subUniteId xsu
            left join fetch xsu.unite xu
            where (:username    is null or lower(u.username) like lower(concat('%', :username, '%')))
              and (:stageStatus is null or lower(r.stageStatus) = lower(:stageStatus))
              and (
                    (:uniteId   is null and :subUniteId is null)
                 or (
                        (:uniteId   is not null and (eu.id = :uniteId or xu.id = :uniteId))
                     or (:subUniteId is not null and (esu.id = :subUniteId or xsu.id = :subUniteId))
                    )
              )
            order by r.createdAt desc
        """,
          countQuery = """
            select count(r)
            from UserRegistrationRequest r
            join r.user u
            left join u.employee e
            left join e.subUnite esu
            left join esu.unite eu
            left join u.externalEmployee xe
            left join xe.subUniteId xsu
            left join xsu.unite xu
            where (:username    is null or lower(u.username) like lower(concat('%', :username, '%')))
              and (:stageStatus is null or lower(r.stageStatus) = lower(:stageStatus))
              and (
                    (:uniteId   is null and :subUniteId is null)
                 or (
                        (:uniteId   is not null and (eu.id = :uniteId or xu.id = :uniteId))
                     or (:subUniteId is not null and (esu.id = :subUniteId or xsu.id = :subUniteId))
                    )
              )
        """
  )
  Page<UserRegistrationRequest> searchFull(
          @Param("username")    String username,
          @Param("stageStatus") String stageStatus,
          @Param("uniteId")     Long uniteId,
          @Param("subUniteId")  Long subUniteId,
          Pageable pageable
  );


  @Query("""
        select r
        from UserRegistrationRequest r
        left join fetch r.user u
        left join fetch u.employee e
        left join fetch e.subUnite esu
        left join fetch esu.unite eu
        left join fetch u.externalEmployee xe
        left join fetch xe.subUniteId xsu
        left join fetch xsu.unite xu
        left join fetch u.currentRegion cr
        order by r.createdAt desc
    """)
  List<UserRegistrationRequest> findAllWithUserFullDetails();


  @Query("""
        select r
        from UserRegistrationRequest r
        left join fetch r.user u
        left join fetch u.employee e
        left join fetch e.subUnite esu
        left join fetch esu.unite eu
        left join fetch u.externalEmployee xe
        left join fetch xe.subUniteId xsu
        left join fetch xsu.unite xu
        left join fetch u.currentRegion cr
        where 
            ( :uniteId is null 
              or ( (eu.id = :uniteId) or (xu.id = :uniteId) )
            )
          and 
            ( :subUniteId is null 
              or ( (esu.id = :subUniteId) or (xsu.id = :subUniteId) )
            )
        order by r.createdAt desc
    """)
  List<UserRegistrationRequest> findAllWithUserFullDetailsAndOrgScope(
          @Param("uniteId") Long uniteId,
          @Param("subUniteId") Long subUniteId
  );


  @Query("""
    select r
    from UserRegistrationRequest r
    left join fetch r.user u
    left join u.employee e
    left join e.subUnite esu
    left join esu.unite eu
    left join u.externalEmployee xe
    left join xe.subUniteId xsu
    left join xsu.unite xu
    left join u.currentRegion cr
    where lower(u.username) = lower(:username)
    order by r.createdAt desc
""")
  List<UserRegistrationRequest> findAllByUsernameWithUserFullDetails(@Param("username") String username);

}


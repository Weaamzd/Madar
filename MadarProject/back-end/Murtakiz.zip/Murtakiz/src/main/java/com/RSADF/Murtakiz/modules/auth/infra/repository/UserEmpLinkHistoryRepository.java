package com.RSADF.Murtakiz.modules.auth.infra.repository;

import com.RSADF.Murtakiz.modules.auth.core.entity.UserEmpLinkHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface UserEmpLinkHistoryRepository extends JpaRepository<UserEmpLinkHistory, Long> {

    List<UserEmpLinkHistory> findAllByUserIdOrderByLinkedAtAsc(Long userId);

   /* @Query("""
      select h
      from UserEmpLinkHistory h
      where h.user.id = :userId
      order by h.linkedAt asc
    """)
    List<UserEmpLinkHistory> findAllByUserIdOrderByLinkedAtAsc(@Param("userId") Long userId);
*/

    @Query("""
      select h from UserEmpLinkHistory h
      where h.user.id = :userId
        and h.linkType = :linkType
        and h.unlinkedAt is null
      order by h.linkedAt desc
    """)
    List<UserEmpLinkHistory> findOpenByUserAndType(@Param("userId") Long userId,
                                                   @Param("linkType") String linkType);


    @Modifying
    @Query("""
      update UserEmpLinkHistory h
      set h.unlinkedAt = :now
      where h.user.id = :userId
        and h.linkType = :linkType
        and h.unlinkedAt is null
    """)
    int closeOpenByUserAndType(@Param("userId") Long userId,
                               @Param("linkType") String linkType,
                               @Param("now") LocalDateTime now);

    @Modifying
    @Query("""
  update UserEmpLinkHistory h
  set h.unlinkedAt = :closedAt,
      h.actionNote = coalesce(:note, h.actionNote),
      h.actorEmpNo = coalesce(:actorEmpNo, h.actorEmpNo)
  where h.user.id = :userId
    and h.linkType = :type
    and h.unlinkedAt is null
""")
    int closeOpenByUserAndType(@Param("userId") Long userId,
                               @Param("type") String type,
                               @Param("closedAt") LocalDateTime closedAt,
                               @Param("note") String note,
                               @Param("actorEmpNo") String actorEmpNo);

}

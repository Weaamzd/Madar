package com.RSADF.Murtakiz.modules.kpi.core.repository;

import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorInitiative;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiIndicatorInitiativeId;
import com.RSADF.Murtakiz.modules.kpi.core.entity.KpiInitiative;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KpiIndicatorInitiativeRepository
        extends JpaRepository<KpiIndicatorInitiative, KpiIndicatorInitiativeId> {

    @Query("""
        select link.initiative
        from KpiIndicatorInitiative link
        where link.kpi.code = :kpiCode
    """)
    List<KpiInitiative> findInitiativesByKpiCode(@Param("kpiCode") String kpiCode);
}
